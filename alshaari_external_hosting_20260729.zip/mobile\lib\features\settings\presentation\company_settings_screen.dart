import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';

class CompanySettingsScreen extends StatefulWidget {
  const CompanySettingsScreen({super.key});

  @override
  State<CompanySettingsScreen> createState() => _CompanySettingsScreenState();
}

class _CompanySettingsScreenState extends State<CompanySettingsScreen> {
  final _formKey = GlobalKey<FormState>();
  bool loading = true;
  bool saving = false;

  final companyName = TextEditingController();
  final legalName = TextEditingController();
  final phone = TextEditingController();
  final email = TextEditingController();
  final address = TextEditingController();
  final taxNumber = TextEditingController();
  final commercialRecord = TextEditingController();
  final defaultCurrency = TextEditingController(text: 'YER');
  final invoicePrefix = TextEditingController(text: 'INV');
  final receiptPrefix = TextEditingController(text: 'RV');
  final paymentPrefix = TextEditingController(text: 'PV');
  final primaryColor = TextEditingController(text: '#B87E62');
  final secondaryColor = TextEditingController(text: '#1C1C1C');
  final notes = TextEditingController();

  @override
  void initState() {
    super.initState();
    loadSettings();
  }

  @override
  void dispose() {
    for (final controller in [
      companyName,
      legalName,
      phone,
      email,
      address,
      taxNumber,
      commercialRecord,
      defaultCurrency,
      invoicePrefix,
      receiptPrefix,
      paymentPrefix,
      primaryColor,
      secondaryColor,
      notes,
    ]) {
      controller.dispose();
    }
    super.dispose();
  }

  String textValue(Map<String, dynamic> data, String key, String fallback) {
    final value = data[key];
    if (value == null || '$value'.isEmpty) return fallback;
    return '$value';
  }

  Future<void> loadSettings() async {
    setState(() => loading = true);
    try {
      await apiClient.loadToken();
      final res = await apiClient.dio.get('/settings/company');
      final data = Map<String, dynamic>.from(res.data as Map);
      companyName.text = textValue(
          data, 'company_name', 'الشعري لصناعة وحلول الأثاث المخصص والديكور');
      legalName.text = textValue(data, 'legal_name', '');
      phone.text = textValue(data, 'phone', '');
      email.text = textValue(data, 'email', '');
      address.text = textValue(data, 'address', '');
      taxNumber.text = textValue(data, 'tax_number', '');
      commercialRecord.text = textValue(data, 'commercial_record', '');
      defaultCurrency.text = textValue(data, 'default_currency', 'YER');
      invoicePrefix.text = textValue(data, 'invoice_prefix', 'INV');
      receiptPrefix.text = textValue(data, 'receipt_prefix', 'RV');
      paymentPrefix.text = textValue(data, 'payment_prefix', 'PV');
      primaryColor.text = textValue(data, 'primary_color', '#B87E62');
      secondaryColor.text = textValue(data, 'secondary_color', '#1C1C1C');
      notes.text = textValue(data, 'notes', '');
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('تعذر تحميل إعدادات الشركة: ${messageOf(e)}')),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String messageOf(Object error) {
    if (error is DioException) {
      final detail = error.response?.data;
      if (detail is Map && detail['detail'] != null) return '${detail['detail']}';
      if (error.response?.statusCode == 403) return 'ليست لديك صلاحية كافية';
    }
    return '$error';
  }

  Map<String, dynamic> payload() {
    return {
      'company_name': companyName.text.trim(),
      'legal_name': legalName.text.trim(),
      'phone': phone.text.trim(),
      'email': email.text.trim(),
      'address': address.text.trim(),
      'tax_number': taxNumber.text.trim(),
      'commercial_record': commercialRecord.text.trim(),
      'default_currency': defaultCurrency.text.trim().toUpperCase(),
      'invoice_prefix': invoicePrefix.text.trim().toUpperCase(),
      'receipt_prefix': receiptPrefix.text.trim().toUpperCase(),
      'payment_prefix': paymentPrefix.text.trim().toUpperCase(),
      'primary_color': primaryColor.text.trim(),
      'secondary_color': secondaryColor.text.trim(),
      'notes': notes.text.trim(),
    };
  }

  Future<void> saveSettings() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => saving = true);
    try {
      await apiClient.loadToken();
      await apiClient.dio.put('/settings/company', data: payload());
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ إعدادات الشركة بنجاح')),
      );
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('فشل حفظ الإعدادات: ${messageOf(e)}')),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  String? requiredText(String? value) {
    if (value == null || value.trim().isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }

  String? colorText(String? value) {
    final text = value?.trim() ?? '';
    if (!RegExp(r'^#[0-9A-Fa-f]{6}$').hasMatch(text)) {
      return 'اكتب اللون بصيغة #B87E62';
    }
    return null;
  }

  Widget field(
    TextEditingController controller,
    String label, {
    String? hint,
    String? Function(String?)? validator,
    int lines = 1,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      minLines: lines,
      maxLines: lines,
      keyboardType: keyboardType,
      validator: validator,
      decoration: InputDecoration(labelText: label, hintText: hint),
    );
  }

  Widget section(String title, List<Widget> children) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              title,
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 14),
            LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 760;
                if (!wide) {
                  return Column(
                    children: children
                        .map((child) => Padding(
                              padding: const EdgeInsets.only(bottom: 12),
                              child: child,
                            ))
                        .toList(),
                  );
                }
                return Wrap(
                  spacing: 12,
                  runSpacing: 12,
                  children: children
                      .map((child) => SizedBox(
                            width: (constraints.maxWidth - 12) / 2,
                            child: child,
                          ))
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('إعدادات الشركة'),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'العودة للوحة التحكم',
              onPressed: () => context.go('/dashboard'),
              icon: const Icon(Icons.dashboard_outlined),
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    Container(
                      padding: const EdgeInsets.all(18),
                      decoration: BoxDecoration(
                        color: AlshaariColors.deepGreen,
                        borderRadius: BorderRadius.circular(8),
                        border: Border.all(color: AlshaariColors.brass),
                      ),
                      child: Row(
                        children: [
                          Container(
                            width: 46,
                            height: 46,
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(.10),
                              borderRadius: BorderRadius.circular(8),
                            ),
                            child: const Icon(Icons.business,
                                color: Colors.white),
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  'هوية النظام الرسمية',
                                  style: Theme.of(context)
                                      .textTheme
                                      .titleLarge
                                      ?.copyWith(
                                          color: Colors.white,
                                          fontWeight: FontWeight.w900),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'تستخدم هذه البيانات في الفواتير والسندات والتقارير والنسخ المطبوعة.',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodySmall
                                      ?.copyWith(
                                          color: const Color(0xFFE8DDC8)),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 12),
                    section('بيانات المنشأة', [
                      field(companyName, 'اسم المنشأة',
                          validator: requiredText),
                      field(legalName, 'الاسم القانوني'),
                      field(phone, 'الهاتف', keyboardType: TextInputType.phone),
                      field(email, 'البريد الإلكتروني',
                          keyboardType: TextInputType.emailAddress),
                      field(address, 'العنوان', lines: 2),
                      field(notes, 'ملاحظات داخلية', lines: 2),
                    ]),
                    const SizedBox(height: 12),
                    section('البيانات النظامية والمالية', [
                      field(taxNumber, 'الرقم الضريبي'),
                      field(commercialRecord, 'السجل التجاري'),
                      field(defaultCurrency, 'العملة الافتراضية',
                          validator: requiredText),
                      field(invoicePrefix, 'بادئة الفواتير',
                          validator: requiredText),
                      field(receiptPrefix, 'بادئة سندات القبض',
                          validator: requiredText),
                      field(paymentPrefix, 'بادئة سندات الصرف',
                          validator: requiredText),
                    ]),
                    const SizedBox(height: 12),
                    section('الهوية البصرية', [
                      field(primaryColor, 'اللون الأساسي',
                          hint: '#B87E62', validator: colorText),
                      field(secondaryColor, 'اللون الثانوي',
                          hint: '#1C1C1C', validator: colorText),
                    ]),
                    const SizedBox(height: 16),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: FilledButton.icon(
                        onPressed: saving ? null : saveSettings,
                        icon: saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.save_outlined),
                        label: Text(saving ? 'جاري الحفظ...' : 'حفظ الإعدادات'),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
