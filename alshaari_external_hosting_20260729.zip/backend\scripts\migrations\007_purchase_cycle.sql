CREATE TABLE IF NOT EXISTS purchase_requests (
    id SERIAL PRIMARY KEY,
    request_no VARCHAR(80) UNIQUE NOT NULL,
    date DATE NOT NULL,
    requested_by INTEGER NULL,
    department VARCHAR(120) NULL,
    cost_center_id INTEGER NULL,
    project_id INTEGER NULL,
    request_type VARCHAR(40) DEFAULT 'materials',
    priority VARCHAR(30) DEFAULT 'normal',
    status VARCHAR(30) DEFAULT 'draft',
    description TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchase_request_lines (
    id SERIAL PRIMARY KEY,
    request_id INTEGER NOT NULL,
    item_id INTEGER NULL,
    item_name VARCHAR(180) NOT NULL,
    qty NUMERIC(14, 3) DEFAULT 0,
    unit VARCHAR(30) DEFAULT 'pcs',
    estimated_unit_cost NUMERIC(14, 2) DEFAULT 0,
    estimated_total NUMERIC(14, 2) DEFAULT 0,
    needed_date DATE NULL,
    notes TEXT NULL
);

CREATE TABLE IF NOT EXISTS purchase_orders (
    id SERIAL PRIMARY KEY,
    po_no VARCHAR(80) UNIQUE NOT NULL,
    supplier_id INTEGER NOT NULL,
    purchase_request_id INTEGER NULL,
    date DATE NOT NULL,
    expected_delivery_date DATE NULL,
    payment_terms VARCHAR(120) NULL,
    currency VARCHAR(10) DEFAULT 'YER',
    project_id INTEGER NULL,
    cost_center_id INTEGER NULL,
    status VARCHAR(30) DEFAULT 'draft',
    description TEXT NULL,
    created_by INTEGER NULL,
    approved_by INTEGER NULL,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS purchase_order_lines (
    id SERIAL PRIMARY KEY,
    po_id INTEGER NOT NULL,
    item_id INTEGER NULL,
    item_name VARCHAR(180) NOT NULL,
    qty_ordered NUMERIC(14, 3) DEFAULT 0,
    qty_received NUMERIC(14, 3) DEFAULT 0,
    unit VARCHAR(30) DEFAULT 'pcs',
    unit_price NUMERIC(14, 2) DEFAULT 0,
    discount NUMERIC(14, 2) DEFAULT 0,
    tax NUMERIC(14, 2) DEFAULT 0,
    total NUMERIC(14, 2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS goods_receipts (
    id SERIAL PRIMARY KEY,
    grn_no VARCHAR(80) UNIQUE NOT NULL,
    po_id INTEGER NULL,
    supplier_id INTEGER NOT NULL,
    date DATE NOT NULL,
    received_by INTEGER NULL,
    warehouse_id INTEGER NULL,
    status VARCHAR(30) DEFAULT 'draft',
    notes TEXT NULL,
    attachment_id INTEGER NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS goods_receipt_lines (
    id SERIAL PRIMARY KEY,
    grn_id INTEGER NOT NULL,
    po_line_id INTEGER NULL,
    item_id INTEGER NOT NULL,
    qty_ordered NUMERIC(14, 3) DEFAULT 0,
    qty_received NUMERIC(14, 3) DEFAULT 0,
    qty_rejected NUMERIC(14, 3) DEFAULT 0,
    unit VARCHAR(30) DEFAULT 'pcs',
    condition_status VARCHAR(30) DEFAULT 'accepted',
    notes TEXT NULL
);

CREATE TABLE IF NOT EXISTS supplier_invoices (
    id SERIAL PRIMARY KEY,
    internal_invoice_no VARCHAR(80) UNIQUE NOT NULL,
    supplier_invoice_no VARCHAR(120) NULL,
    supplier_id INTEGER NOT NULL,
    po_id INTEGER NULL,
    grn_id INTEGER NULL,
    invoice_date DATE NOT NULL,
    due_date DATE NULL,
    invoice_type VARCHAR(40) DEFAULT 'inventory',
    currency VARCHAR(10) DEFAULT 'YER',
    subtotal NUMERIC(14, 2) DEFAULT 0,
    discount NUMERIC(14, 2) DEFAULT 0,
    tax NUMERIC(14, 2) DEFAULT 0,
    net_amount NUMERIC(14, 2) DEFAULT 0,
    paid_amount NUMERIC(14, 2) DEFAULT 0,
    status VARCHAR(30) DEFAULT 'draft',
    description TEXT NULL,
    attachment_id INTEGER NULL,
    created_by INTEGER NULL,
    approved_by INTEGER NULL,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE supplier_invoices ADD COLUMN IF NOT EXISTS paid_amount NUMERIC(14, 2) DEFAULT 0;

CREATE TABLE IF NOT EXISTS supplier_invoice_lines (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER NOT NULL,
    item_id INTEGER NULL,
    description TEXT NOT NULL,
    qty NUMERIC(14, 3) DEFAULT 0,
    unit_price NUMERIC(14, 2) DEFAULT 0,
    account_code VARCHAR(30) NOT NULL,
    project_id INTEGER NULL,
    cost_center_id INTEGER NULL,
    total NUMERIC(14, 2) DEFAULT 0
);

CREATE TABLE IF NOT EXISTS supplier_payments (
    id SERIAL PRIMARY KEY,
    payment_no VARCHAR(80) UNIQUE NOT NULL,
    supplier_id INTEGER NOT NULL,
    invoice_id INTEGER NULL,
    payment_date DATE NOT NULL,
    amount NUMERIC(14, 2) DEFAULT 0,
    payment_method VARCHAR(40) NOT NULL,
    cash_account_code VARCHAR(30) DEFAULT '10101',
    currency VARCHAR(10) DEFAULT 'YER',
    description TEXT NULL,
    attachment_id INTEGER NULL,
    status VARCHAR(30) DEFAULT 'draft',
    created_by INTEGER NULL,
    approved_by INTEGER NULL,
    approved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
