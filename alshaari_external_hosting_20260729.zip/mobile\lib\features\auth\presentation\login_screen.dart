import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(text: '777017187');
  final password = TextEditingController(text: '12345678');
  bool loading = false;

  static const appName = '\u0627\u0644\u0634\u0639\u0631\u064a';
  static const appSubtitle =
      '\u0646\u0638\u0627\u0645 \u0645\u0627\u0644\u064a \u0644\u0635\u0646\u0627\u0639\u0629 \u0627\u0644\u0623\u062b\u0627\u062b';

  String loginErrorMessage(Object error) {
    if (error is DioException) {
      if (error.response?.statusCode == 401) {
        return '\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641 \u0623\u0648 \u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631 \u063a\u064a\u0631 \u0635\u062d\u064a\u062d\u0629';
      }
      if (error.type == DioExceptionType.connectionError ||
          error.type == DioExceptionType.connectionTimeout ||
          error.type == DioExceptionType.receiveTimeout) {
        return '\u062a\u0639\u0630\u0631 \u0627\u0644\u0627\u062a\u0635\u0627\u0644 \u0628\u0627\u0644\u062e\u0627\u062f\u0645\u060c \u062a\u0623\u0643\u062f \u0623\u0646 \u0627\u0644\u0646\u0638\u0627\u0645 \u064a\u0639\u0645\u0644';
      }
    }
    return '\u0641\u0634\u0644 \u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644\u060c \u062d\u0627\u0648\u0644 \u0645\u0631\u0629 \u0623\u062e\u0631\u0649';
  }

  Future<void> login() async {
    setState(() => loading = true);
    try {
      final res = await apiClient.dio.post(
        '/auth/login',
        data: {'phone': phone.text.trim(), 'password': password.text},
      );
      final payload = Map<String, dynamic>.from(res.data as Map);
      await apiClient.setSession(
        token: '${payload['access_token']}',
        role: payload['role']?.toString(),
        name: payload['name']?.toString(),
        permissions:
            (payload['permissions'] as List?)?.map((item) => '$item').toList(),
      );
      if (!mounted) return;
      context.go('/dashboard');
    } catch (e) {
      if (!mounted) return;
      final messenger = ScaffoldMessenger.of(context);
      messenger.clearSnackBars();
      messenger.showSnackBar(
        SnackBar(
          content: Text(loginErrorMessage(e)),
          duration: const Duration(seconds: 6),
          action: SnackBarAction(
            label: '\u0625\u063a\u0644\u0627\u0642',
            onPressed: messenger.hideCurrentSnackBar,
          ),
        ),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Scaffold(
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 980),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: LayoutBuilder(
              builder: (context, constraints) {
                final wide = constraints.maxWidth >= 760;
                final brand = _BrandPanel(textTheme: textTheme);
                final form = _LoginPanel(
                  phone: phone,
                  password: password,
                  loading: loading,
                  onLogin: login,
                );

                if (wide) {
                  return Row(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Expanded(flex: 5, child: brand),
                      const SizedBox(width: 16),
                      Expanded(flex: 4, child: form),
                    ],
                  );
                }

                return SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      brand,
                      const SizedBox(height: 12),
                      form,
                    ],
                  ),
                );
              },
            ),
          ),
        ),
      ),
      bottomNavigationBar: Padding(
        padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
        child: Text(
          '\u0627\u0644\u0634\u0639\u0631\u064a \u0644\u0644\u0623\u062b\u0627\u062b | \u0625\u062f\u0627\u0631\u0629 \u0645\u0627\u0644\u064a\u0629 \u0648\u0645\u0634\u0627\u0631\u064a\u0639 \u0648\u0645\u062e\u0632\u0648\u0646',
          textAlign: TextAlign.center,
          style: textTheme.bodySmall?.copyWith(color: AlshaariColors.slate),
        ),
      ),
    );
  }
}

class _BrandPanel extends StatelessWidget {
  final TextTheme textTheme;

  const _BrandPanel({required this.textTheme});

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 310),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AlshaariColors.deepGreen,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AlshaariColors.brass),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              const BrandMark(size: 54),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _LoginScreenState.appName,
                    style: textTheme.headlineSmall?.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 3),
                  Text(
                    _LoginScreenState.appSubtitle,
                    style: textTheme.bodyMedium?.copyWith(
                      color: const Color(0xFFE8DDC8),
                    ),
                  ),
                ],
              ),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '\u0645\u0646 \u0627\u0644\u0648\u0631\u0634\u0629 \u0625\u0644\u0649 \u0627\u0644\u0631\u0628\u062d\u064a\u0629',
                style: textTheme.headlineMedium?.copyWith(
                  color: Colors.white,
                  fontWeight: FontWeight.w900,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                '\u0645\u062a\u0627\u0628\u0639\u0629 \u0627\u0644\u0635\u0646\u062f\u0648\u0642\u060c \u0627\u0644\u0645\u062e\u0632\u0648\u0646\u060c \u062a\u0643\u0627\u0644\u064a\u0641 \u0627\u0644\u0645\u0634\u0627\u0631\u064a\u0639\u060c \u0648\u0627\u0644\u0627\u0639\u062a\u0645\u0627\u062f \u0627\u0644\u0645\u062d\u0627\u0633\u0628\u064a \u0645\u0646 \u0634\u0627\u0634\u0629 \u0648\u0627\u062d\u062f\u0629.',
                style: textTheme.bodyLarge?.copyWith(
                  color: const Color(0xFFF4EAD6),
                  height: 1.5,
                ),
              ),
            ],
          ),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: const [
              _BrandChip(
                  icon: Icons.inventory_2,
                  label: '\u0645\u062e\u0632\u0648\u0646'),
              _BrandChip(
                  icon: Icons.account_balance_wallet,
                  label: '\u0635\u0646\u062f\u0648\u0642'),
              _BrandChip(
                  icon: Icons.handyman,
                  label: '\u0645\u0634\u0627\u0631\u064a\u0639'),
              _BrandChip(
                  icon: Icons.receipt_long, label: '\u0642\u064a\u0648\u062f'),
            ],
          ),
        ],
      ),
    );
  }
}

class _BrandChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _BrandChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(.09),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.white24),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: AlshaariColors.brass),
          const SizedBox(width: 6),
          Text(label, style: const TextStyle(color: Colors.white)),
        ],
      ),
    );
  }
}

class _LoginPanel extends StatelessWidget {
  final TextEditingController phone;
  final TextEditingController password;
  final bool loading;
  final VoidCallback onLogin;

  const _LoginPanel({
    required this.phone,
    required this.password,
    required this.loading,
    required this.onLogin,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                const BrandMark(),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '\u062a\u0633\u062c\u064a\u0644 \u0627\u0644\u062f\u062e\u0648\u0644',
                        style: textTheme.titleLarge?.copyWith(
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        '\u0627\u062f\u062e\u0644 \u0628\u064a\u0627\u0646\u0627\u062a \u0627\u0644\u0645\u0633\u062a\u062e\u062f\u0645 \u0627\u0644\u0645\u0639\u062a\u0645\u062f',
                        style: textTheme.bodySmall?.copyWith(
                          color: AlshaariColors.slate,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(
                labelText:
                    '\u0631\u0642\u0645 \u0627\u0644\u0647\u0627\u062a\u0641',
                prefixIcon: Icon(Icons.phone_iphone),
              ),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: password,
              obscureText: true,
              decoration: const InputDecoration(
                labelText:
                    '\u0643\u0644\u0645\u0629 \u0627\u0644\u0645\u0631\u0648\u0631',
                prefixIcon: Icon(Icons.lock_outline),
              ),
            ),
            const SizedBox(height: 18),
            FilledButton.icon(
              onPressed: loading ? null : onLogin,
              icon: loading
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.login),
              label: Text(
                loading
                    ? '\u062c\u0627\u0631\u064a \u0627\u0644\u062f\u062e\u0648\u0644...'
                    : '\u062f\u062e\u0648\u0644',
              ),
            ),
          ],
        ),
      ),
    );
  }
}
