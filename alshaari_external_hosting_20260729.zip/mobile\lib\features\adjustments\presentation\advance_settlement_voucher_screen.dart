import 'package:flutter/material.dart';

import '../../transactions/presentation/transaction_form_screen.dart';

class AdvanceSettlementVoucherScreen extends StatelessWidget {
  const AdvanceSettlementVoucherScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const TransactionFormScreen(initialType: 'advance_settlement');
  }
}
