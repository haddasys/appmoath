from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import (
    ROLE_ACCOUNTANT,
    ROLE_ACCOUNTANT_ADMIN,
    ROLE_CASHIER,
    ROLE_DATA_ENTRY,
    ROLE_INVENTORY,
    ROLE_MANAGER,
    ROLE_PRODUCTION,
    ROLE_PURCHASING,
    ROLE_READ_ONLY,
    get_current_user,
    normalize_role,
    permissions_for_user,
    require_roles,
)
from app.core.security import hash_password
from app.db.database import get_db
from app.models.models import AuditLog, Permission, Role, User
from app.schemas.schemas import RolePermissionsUpdate, UserCreate, UserPasswordUpdate, UserUpdate

router = APIRouter(prefix="/api/v1/access-control", tags=["Access Control"])

DEFAULT_ROLES = [
    (ROLE_MANAGER, "المدير العام", "صلاحية كاملة على النظام"),
    (ROLE_ACCOUNTANT_ADMIN, "المحاسب الرئيسي", "اعتماد التسويات والفترات والعمليات المحاسبية الحساسة"),
    (ROLE_ACCOUNTANT, "المحاسب", "القيود، الاعتماد، التقارير، الفواتير"),
    (ROLE_CASHIER, "أمين الصندوق", "القبض والصرف ومتابعة الصندوق"),
    (ROLE_PURCHASING, "مسؤول المشتريات", "الموردون والمشتريات"),
    (ROLE_INVENTORY, "مسؤول المخزون", "المواد وحركات المخزون"),
    (ROLE_PRODUCTION, "مسؤول الإنتاج", "المشاريع وتكاليف التشغيل"),
    (ROLE_DATA_ENTRY, "مدخل بيانات", "إدخال بيانات تشغيلية بدون اعتماد"),
    (ROLE_READ_ONLY, "مشاهد فقط", "استعراض التقارير والبيانات بدون تعديل"),
]

DEFAULT_PERMISSIONS = {
    ROLE_MANAGER: [
        "users.manage",
        "roles.manage",
        "settings.manage",
        "master_data.write",
        "transactions.write",
        "employees.write",
        "payroll.write",
        "payroll.approve",
        "payroll.pay",
        "transactions.approve",
        "transactions.reverse",
        "approve_adjustment_journal",
        "manage_settlements",
        "approve_supplier_invoice",
        "approve_supplier_payment",
        "approve_inventory_adjustment",
        "close_period",
        "open_closed_period",
        "invoices.write",
        "invoices.post",
        "reports.view",
        "reports.print",
    ],
    ROLE_ACCOUNTANT_ADMIN: [
        "master_data.write",
        "suppliers.write",
        "purchases.write",
        "inventory.write",
        "materials.issue",
        "transactions.write",
        "employees.write",
        "payroll.write",
        "payroll.approve",
        "payroll.pay",
        "transactions.approve",
        "transactions.reverse",
        "approve_adjustment_journal",
        "manage_settlements",
        "approve_supplier_invoice",
        "approve_supplier_payment",
        "approve_inventory_adjustment",
        "close_period",
        "open_closed_period",
        "invoices.write",
        "invoices.post",
        "reports.view",
        "reports.print",
    ],
    ROLE_ACCOUNTANT: [
        "master_data.write",
        "suppliers.write",
        "purchases.write",
        "inventory.write",
        "materials.issue",
        "transactions.write",
        "employees.write",
        "payroll.write",
        "payroll.approve",
        "payroll.pay",
        "transactions.approve",
        "transactions.reverse",
        "approve_adjustment_journal",
        "manage_settlements",
        "approve_supplier_invoice",
        "approve_supplier_payment",
        "approve_inventory_adjustment",
        "close_period",
        "invoices.write",
        "invoices.post",
        "reports.view",
        "reports.print",
    ],
    ROLE_CASHIER: [
        "transactions.write",
        "cashbox.write",
        "reports.view",
        "reports.print",
    ],
    ROLE_PURCHASING: [
        "suppliers.write",
        "purchases.write",
        "invoices.write",
        "reports.view",
    ],
    ROLE_INVENTORY: [
        "inventory.write",
        "materials.issue",
        "reports.view",
    ],
    ROLE_PRODUCTION: [
        "projects.write",
        "project_costs.write",
        "reports.view",
    ],
    ROLE_DATA_ENTRY: [
        "master_data.write",
        "transactions.write",
        "invoices.write",
        "reports.view",
    ],
    ROLE_READ_ONLY: [
        "reports.view",
    ],
}

PERMISSION_LABELS = {
    "users.manage": "إدارة المستخدمين",
    "roles.manage": "إدارة الصلاحيات",
    "settings.manage": "إعدادات النظام",
    "master_data.write": "إدارة البيانات الأساسية",
    "employees.write": "إدارة بيانات العمال والموظفين",
    "payroll.write": "إنشاء وتعديل كشوف الرواتب",
    "payroll.approve": "اعتماد كشوف الرواتب",
    "payroll.pay": "دفع الرواتب",
    "transactions.write": "إدخال الحركات المالية",
    "transactions.approve": "اعتماد الحركات",
    "transactions.reverse": "عكس/إلغاء الحركات",
    "approve_adjustment_journal": "اعتماد سندات التسوية الحسابية",
    "manage_settlements": "إدارة التسويات",
    "approve_supplier_invoice": "اعتماد فواتير الموردين",
    "approve_supplier_payment": "اعتماد سندات دفع الموردين",
    "approve_inventory_adjustment": "اعتماد تسويات المخزون",
    "close_period": "إقفال الفترات المالية",
    "open_closed_period": "فتح فترة مالية مغلقة",
    "cashbox.write": "عمليات الصندوق",
    "invoices.write": "إنشاء الفواتير",
    "invoices.post": "ترحيل الفواتير",
    "reports.view": "عرض التقارير",
    "reports.print": "طباعة التقارير",
    "suppliers.write": "إدارة الموردين",
    "purchases.write": "إدارة المشتريات",
    "inventory.write": "إدارة المخزون",
    "materials.issue": "صرف المواد للمشاريع",
    "projects.write": "إدارة المشاريع",
    "project_costs.write": "تسجيل تكاليف المشاريع",
}


def ensure_default_roles(db: Session):
    for code, name, notes in DEFAULT_ROLES:
        role = db.query(Role).filter(Role.code == code).first()
        if role:
            # Keep the seeded Arabic names readable after older corrupted builds.
            role.name = name
            role.notes = notes
        else:
            db.add(Role(code=code, name=name, notes=notes))

        existing = {
            row.permission
            for row in db.query(Permission).filter(Permission.role_code == code).all()
        }
        for permission in DEFAULT_PERMISSIONS.get(code, []):
            if permission not in existing:
                db.add(Permission(role_code=code, permission=permission))
    db.commit()


def user_to_dict(user: User) -> dict:
    return {
        "id": user.id,
        "name": user.name,
        "phone": user.phone,
        "role": normalize_role(user.role),
        "is_active": bool(user.is_active),
        "created_at": user.created_at,
    }


def active_manager_count(db: Session) -> int:
    return (
        db.query(User)
        .filter(User.is_active == True, User.role.in_([ROLE_MANAGER, "general_manager"]))
        .count()
    )


@router.get("/me")
def current_access_profile(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_default_roles(db)
    data = user_to_dict(user)
    data["permissions"] = permissions_for_user(db, user)
    return data


@router.get("/roles")
def list_roles(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_default_roles(db)
    roles = db.query(Role).order_by(Role.id).all()
    permissions = db.query(Permission).order_by(Permission.role_code, Permission.permission).all()
    permissions_by_role: dict[str, list[str]] = {}
    for permission in permissions:
        permissions_by_role.setdefault(permission.role_code, []).append(permission.permission)

    return {
        "roles": [
            {
                "id": role.id,
                "code": role.code,
                "name": role.name,
                "notes": role.notes,
                "permissions": permissions_by_role.get(role.code, []),
            }
            for role in roles
        ],
        "permission_labels": PERMISSION_LABELS,
    }


@router.put("/roles/{role_code}/permissions")
def update_role_permissions(
    role_code: str,
    data: RolePermissionsUpdate,
    db: Session = Depends(get_db),
    user=Depends(require_roles(ROLE_MANAGER)),
):
    ensure_default_roles(db)
    role = db.query(Role).filter(Role.code == role_code).first()
    if not role:
        raise HTTPException(status_code=404, detail="الدور غير موجود")

    allowed_permissions = set(PERMISSION_LABELS)
    unknown = [permission for permission in data.permissions if permission not in allowed_permissions]
    if unknown:
        raise HTTPException(status_code=400, detail=f"صلاحيات غير معروفة: {', '.join(unknown)}")

    if role_code == ROLE_MANAGER and "users.manage" not in data.permissions:
        raise HTTPException(
            status_code=400,
            detail="لا يمكن حذف صلاحية إدارة المستخدمين من المدير العام",
        )

    db.query(Permission).filter(Permission.role_code == role_code).delete()
    for permission in sorted(set(data.permissions)):
        db.add(Permission(role_code=role_code, permission=permission))
    db.add(
        AuditLog(
            user_id=user.id,
            action="update_role_permissions",
            entity="role",
            entity_id=role.id,
            details=role_code,
        )
    )
    db.commit()
    return list_roles(db, user)


@router.get("/users")
def list_users(db: Session = Depends(get_db), user=Depends(require_roles(ROLE_MANAGER))):
    ensure_default_roles(db)
    users = db.query(User).order_by(User.id.desc()).all()
    return [user_to_dict(row) for row in users]


@router.post("/users")
def create_user(data: UserCreate, db: Session = Depends(get_db), user=Depends(require_roles(ROLE_MANAGER))):
    ensure_default_roles(db)
    role = normalize_role(data.role)
    if not db.query(Role).filter(Role.code == role).first():
        raise HTTPException(status_code=400, detail="الدور غير موجود")
    if db.query(User).filter(User.phone == data.phone).first():
        raise HTTPException(status_code=400, detail="رقم الهاتف مستخدم مسبقا")
    if len(data.password) < 6:
        raise HTTPException(status_code=400, detail="كلمة المرور يجب أن تكون 6 أحرف على الأقل")

    new_user = User(
        name=data.name,
        phone=data.phone,
        password_hash=hash_password(data.password),
        role=role,
        is_active=data.is_active,
    )
    db.add(new_user)
    db.flush()
    db.add(
        AuditLog(
            user_id=user.id,
            action="create_user",
            entity="user",
            entity_id=new_user.id,
            details=new_user.phone,
        )
    )
    db.commit()
    db.refresh(new_user)
    return user_to_dict(new_user)


@router.patch("/users/{user_id}")
def update_user(
    user_id: int,
    data: UserUpdate,
    db: Session = Depends(get_db),
    user=Depends(require_roles(ROLE_MANAGER)),
):
    ensure_default_roles(db)
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="المستخدم غير موجود")

    new_role = normalize_role(data.role) if data.role is not None else normalize_role(target.role)
    new_active = data.is_active if data.is_active is not None else bool(target.is_active)

    if target.id == user.id and not new_active:
        raise HTTPException(status_code=400, detail="لا يمكن تعطيل المستخدم الحالي")
    if normalize_role(target.role) == ROLE_MANAGER and (new_role != ROLE_MANAGER or not new_active) and active_manager_count(db) <= 1:
        raise HTTPException(status_code=400, detail="يجب بقاء مدير عام نشط واحد على الأقل")
    if not db.query(Role).filter(Role.code == new_role).first():
        raise HTTPException(status_code=400, detail="الدور غير موجود")

    if data.phone and data.phone != target.phone:
        if db.query(User).filter(User.phone == data.phone, User.id != target.id).first():
            raise HTTPException(status_code=400, detail="رقم الهاتف مستخدم مسبقا")
        target.phone = data.phone
    if data.name is not None:
        target.name = data.name
    target.role = new_role
    target.is_active = new_active

    db.add(
        AuditLog(
            user_id=user.id,
            action="update_user",
            entity="user",
            entity_id=target.id,
            details=target.phone,
        )
    )
    db.commit()
    db.refresh(target)
    return user_to_dict(target)


@router.patch("/users/{user_id}/password")
def update_user_password(
    user_id: int,
    data: UserPasswordUpdate,
    db: Session = Depends(get_db),
    user=Depends(require_roles(ROLE_MANAGER)),
):
    target = db.query(User).filter(User.id == user_id).first()
    if not target:
        raise HTTPException(status_code=404, detail="المستخدم غير موجود")
    if len(data.password) < 6:
        raise HTTPException(status_code=400, detail="كلمة المرور يجب أن تكون 6 أحرف على الأقل")
    target.password_hash = hash_password(data.password)
    db.add(
        AuditLog(
            user_id=user.id,
            action="update_user_password",
            entity="user",
            entity_id=target.id,
            details=target.phone,
        )
    )
    db.commit()
    return {"ok": True}
