import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/printing/official_print.dart';
import '../../../core/printing/print_document.dart';

class InvoicesScreen extends StatefulWidget {
  const InvoicesScreen({super.key});

  @override
  State<InvoicesScreen> createState() => _InvoicesScreenState();
}

class _InvoicesScreenState extends State<InvoicesScreen>
    with SingleTickerProviderStateMixin {
  late final TabController tabController;
  final formKey = GlobalKey<FormState>();

  bool loading = true;
  bool saving = false;
  bool posting = false;

  List<dynamic> invoices = [];
  List<dynamic> customers = [];
  List<dynamic> suppliers = [];
  List<dynamic> projects = [];
  CompanyPrintProfile printProfile = CompanyPrintProfile.defaults();
  List<_InvoiceLineDraft> lines = [_InvoiceLineDraft()];

  String invoiceType = 'customer';
  int? partyId;
  int? projectId;
  DateTime invoiceDate = DateTime.now();
  final notesController = TextEditingController();

  @override
  void initState() {
    super.initState();
    tabController = TabController(length: 2, vsync: this);
    configureAndLoad();
  }

  @override
  void dispose() {
    tabController.dispose();
    notesController.dispose();
    for (final line in lines) {
      line.dispose();
    }
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadData();
  }

  String get selectedPartyLabel => invoiceType == 'customer' ? 'العميل' : 'المورد';

  List<dynamic> get selectedParties => invoiceType == 'customer' ? customers : suppliers;

  String formatDate(DateTime value) {
    final month = value.month.toString().padLeft(2, '0');
    final day = value.day.toString().padLeft(2, '0');
    return '${value.year}-$month-$day';
  }

  double get invoiceTotal {
    return lines.fold<double>(0, (sum, line) => sum + line.total);
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
      if (error.response?.statusCode == 403) {
        return 'لا تملك صلاحية تنفيذ هذه العملية';
      }
    }
    return 'حدث خطأ غير متوقع';
  }

  Future<List<dynamic>> getList(String endpoint) async {
    final res = await apiClient.dio.get(endpoint);
    if (res.data is List) return res.data as List<dynamic>;
    if (res.data is Map && res.data['items'] is List) {
      return res.data['items'] as List<dynamic>;
    }
    return [];
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        getList('/invoices'),
        getList('/customers'),
        getList('/suppliers'),
        getList('/projects'),
        loadCompanyPrintProfile(),
      ]);

      if (!mounted) return;
      setState(() {
        invoices = result[0] as List<dynamic>;
        customers = result[1] as List<dynamic>;
        suppliers = result[2] as List<dynamic>;
        projects = result[3] as List<dynamic>;
        printProfile = result[4] as CompanyPrintProfile;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل الفواتير: ${friendlyError(e)}');
    }
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void resetForm() {
    notesController.clear();
    for (final line in lines) {
      line.dispose();
    }
    setState(() {
      invoiceType = 'customer';
      partyId = null;
      projectId = null;
      invoiceDate = DateTime.now();
      lines = [_InvoiceLineDraft()];
    });
  }

  Future<void> chooseDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: invoiceDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2100),
    );
    if (picked != null) setState(() => invoiceDate = picked);
  }

  Future<void> saveInvoice() async {
    if (!formKey.currentState!.validate()) return;
    if (partyId == null) {
      showMessage('اختر $selectedPartyLabel');
      return;
    }
    if (invoiceTotal <= 0) {
      showMessage('إجمالي الفاتورة يجب أن يكون أكبر من صفر');
      return;
    }

    setState(() => saving = true);
    try {
      final payload = {
        'invoice_type': invoiceType,
        'party_type': invoiceType,
        'party_id': partyId,
        'project_id': projectId,
        'date': formatDate(invoiceDate),
        'total': invoiceTotal.toStringAsFixed(2),
        'notes': notesController.text.trim().isEmpty
            ? null
            : notesController.text.trim(),
        'lines': lines
            .map(
              (line) => {
                'item_description': line.descriptionController.text.trim(),
                'qty': line.qty.toStringAsFixed(3),
                'unit_price': line.unitPrice.toStringAsFixed(2),
                'total': line.total.toStringAsFixed(2),
                'project_id': projectId,
              },
            )
            .toList(),
      };

      await apiClient.dio.post('/invoices', data: payload);
      await loadData();
      resetForm();
      tabController.animateTo(0);
      showMessage('تم حفظ الفاتورة كمسودة');
    } catch (e) {
      showMessage('فشل حفظ الفاتورة: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> postInvoice(Map<String, dynamic> invoice) async {
    final id = invoice['id'];
    if (id == null) return;

    setState(() => posting = true);
    try {
      await apiClient.dio.post('/invoices/$id/post');
      await loadData();
      showMessage('تم ترحيل الفاتورة');
    } catch (e) {
      showMessage('فشل الترحيل: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => posting = false);
    }
  }

  DropdownMenuItem<int> entityItem(Map<String, dynamic> item) {
    final label = item['name'] ??
        item['project_code'] ??
        item['code'] ??
        item['phone'] ??
        item['id'];
    return DropdownMenuItem<int>(
      value: item['id'] as int,
      child: Text('$label', overflow: TextOverflow.ellipsis),
    );
  }

  Widget moneyText(dynamic value, {bool strong = false}) {
    return Text(
      '${value ?? 0}',
      style: TextStyle(
        fontWeight: strong ? FontWeight.w900 : FontWeight.w700,
        color: strong ? AlshaariColors.deepGreen : AlshaariColors.ink,
      ),
    );
  }

  String htmlEscape(Object? value) {
    return '${value ?? ''}'
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
  }

  String partyName(Map<String, dynamic> invoice) {
    final list = invoice['invoice_type'] == 'supplier' ? suppliers : customers;
    for (final raw in list) {
      final party = Map<String, dynamic>.from(raw as Map);
      if (party['id'] == invoice['party_id']) return '${party['name'] ?? party['id']}';
    }
    return '${invoice['party_id'] ?? '-'}';
  }

  String invoicePrintHtml(Map<String, dynamic> invoice) {
    final lines = (invoice['lines'] as List?) ?? [];
    final type = invoice['invoice_type'] == 'supplier'
        ? '?????? ????'
        : '?????? ????';
    final buffer = StringBuffer(
      officialPrintHeader(
        printProfile,
        type,
        subtitle:
            '??? ????????: ${printHtmlEscape(invoice['invoice_no'] ?? invoice['id'])}',
      ),
    );

    buffer.write('''
    <div class="grid">
      <div class="box"><b>?????</b><span>${printHtmlEscape(partyName(invoice))}</span></div>
      <div class="box"><b>???????</b><span>${printHtmlEscape(invoice['date'])}</span></div>
      <div class="box"><b>??????</b><span>${printHtmlEscape(invoice['status'])}</span></div>
    </div>
    <table>
      <thead>
        <tr><th>#</th><th>??? ?????</th><th class="amount">??????</th><th class="amount">?????</th><th class="amount">????????</th></tr>
      </thead>
      <tbody>
''');

    if (lines.isEmpty) {
      buffer.write('<tr><td colspan="5">?? ???? ????.</td></tr>');
    } else {
      for (var i = 0; i < lines.length; i++) {
        final line = Map<String, dynamic>.from(lines[i] as Map);
        buffer.write('''
        <tr>
          <td>${i + 1}</td>
          <td>${printHtmlEscape(line['item_description'])}</td>
          <td class="amount">${printHtmlEscape(line['qty'])}</td>
          <td class="amount">${printHtmlEscape(line['unit_price'])}</td>
          <td class="amount">${printHtmlEscape(line['total'])}</td>
        </tr>
''');
      }
    }

    buffer.write('''
      </tbody>
    </table>
    <div class="total"><span>????????</span><span>${printHtmlEscape(invoice['total'])} ${printHtmlEscape(printProfile.defaultCurrency)}</span></div>
    <div class="notes"><b>???????:</b> ${printHtmlEscape(invoice['notes'])}</div>
''');
    buffer.write(officialPrintFooter());
    return buffer.toString();
  }

  Future<void> printInvoice(Map<String, dynamic> invoice) async {
    try {
      await openPrintDocument(
        title: '${invoice['invoice_no'] ?? 'invoice'}',
        content: invoicePrintHtml(invoice),
      );
    } catch (_) {
      showMessage('الطباعة متاحة حاليًا من نسخة الويب');
    }
  }

  Widget buildInvoiceList() {
    if (loading) return const Center(child: CircularProgressIndicator());

    if (invoices.isEmpty) {
      return RefreshIndicator(
        onRefresh: loadData,
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const SizedBox(height: 84),
            Icon(
              Icons.receipt_long_outlined,
              size: 56,
              color: AlshaariColors.deepGreen.withOpacity(.55),
            ),
            const SizedBox(height: 14),
            const Center(
              child: Text(
                'لا توجد فواتير',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: loadData,
      child: ListView.separated(
        padding: const EdgeInsets.all(14),
        itemCount: invoices.length,
        separatorBuilder: (_, __) => const SizedBox(height: 8),
        itemBuilder: (_, index) {
          final invoice = Map<String, dynamic>.from(invoices[index] as Map);
          final type = invoice['invoice_type'] == 'supplier' ? 'فاتورة مورد' : 'فاتورة عميل';
          final status = '${invoice['status'] ?? 'draft'}';
          final isDraft = status == 'draft' || status == 'open';
          final linesCount = (invoice['lines'] as List?)?.length ?? 0;

          return Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 44,
                        height: 44,
                        decoration: BoxDecoration(
                          color: AlshaariColors.deepGreen.withOpacity(.10),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Icon(
                          invoice['invoice_type'] == 'supplier'
                              ? Icons.local_shipping_outlined
                              : Icons.person_outline,
                          color: AlshaariColors.deepGreen,
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${invoice['invoice_no'] ?? '#${invoice['id']}'} - $type',
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                            const SizedBox(height: 3),
                            Text(
                              '${invoice['date'] ?? '-'} | البنود: $linesCount',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: AlshaariColors.slate,
                                  ),
                            ),
                          ],
                        ),
                      ),
                      _StatusPill(status: status),
                    ],
                  ),
                  const Divider(height: 22),
                  Row(
                    children: [
                      Expanded(child: Text('الإجمالي', style: Theme.of(context).textTheme.bodySmall)),
                      moneyText(invoice['total'], strong: true),
                    ],
                  ),
                  if ((invoice['notes'] ?? '').toString().isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${invoice['notes']}',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    alignment: WrapAlignment.end,
                    children: [
                      OutlinedButton.icon(
                        onPressed: () => printInvoice(invoice),
                        icon: const Icon(Icons.print_outlined),
                        label: const Text('طباعة'),
                      ),
                      if (isDraft)
                        FilledButton.icon(
                          onPressed: posting ? null : () => postInvoice(invoice),
                          icon: posting
                              ? const SizedBox(
                                  width: 16,
                                  height: 16,
                                  child: CircularProgressIndicator(strokeWidth: 2),
                                )
                              : const Icon(Icons.task_alt),
                          label: const Text('ترحيل'),
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget buildForm() {
    if (loading) return const Center(child: CircularProgressIndicator());

    return Form(
      key: formKey,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SegmentedButton<String>(
            segments: const [
              ButtonSegment(
                value: 'customer',
                label: Text('عميل'),
                icon: Icon(Icons.person_outline),
              ),
              ButtonSegment(
                value: 'supplier',
                label: Text('مورد'),
                icon: Icon(Icons.local_shipping_outlined),
              ),
            ],
            selected: {invoiceType},
            onSelectionChanged: (value) {
              setState(() {
                invoiceType = value.first;
                partyId = null;
              });
            },
          ),
          const SizedBox(height: 14),
          DropdownButtonFormField<int>(
            initialValue: partyId,
            decoration: InputDecoration(labelText: selectedPartyLabel),
            items: selectedParties
                .map((raw) => entityItem(Map<String, dynamic>.from(raw as Map)))
                .toList(),
            validator: (value) => value == null ? 'اختر $selectedPartyLabel' : null,
            onChanged: (value) => setState(() => partyId = value),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            initialValue: projectId,
            decoration: const InputDecoration(labelText: 'المشروع'),
            items: projects
                .map((raw) => entityItem(Map<String, dynamic>.from(raw as Map)))
                .toList(),
            onChanged: (value) => setState(() => projectId = value),
          ),
          const SizedBox(height: 12),
          InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: chooseDate,
            child: InputDecorator(
              decoration: const InputDecoration(labelText: 'تاريخ الفاتورة'),
              child: Row(
                children: [
                  const Icon(Icons.calendar_today_outlined, size: 18),
                  const SizedBox(width: 8),
                  Text(formatDate(invoiceDate)),
                ],
              ),
            ),
          ),
          const SizedBox(height: 18),
          Text(
            'بنود الفاتورة',
            style: Theme.of(context).textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w900,
                ),
          ),
          const SizedBox(height: 10),
          ...lines.asMap().entries.map((entry) {
            final index = entry.key;
            final line = entry.value;
            return _InvoiceLineEditor(
              key: ValueKey(line),
              index: index,
              line: line,
              canRemove: lines.length > 1,
              onChanged: () => setState(() {}),
              onRemove: () {
                setState(() {
                  lines.removeAt(index).dispose();
                });
              },
            );
          }),
          OutlinedButton.icon(
            onPressed: () => setState(() => lines.add(_InvoiceLineDraft())),
            icon: const Icon(Icons.add),
            label: const Text('إضافة بند'),
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: notesController,
            maxLines: 3,
            decoration: const InputDecoration(labelText: 'ملاحظات'),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AlshaariColors.deepGreen.withOpacity(.08),
              border: Border.all(color: AlshaariColors.border),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Expanded(
                  child: Text(
                    'الإجمالي',
                    style: TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                moneyText(invoiceTotal.toStringAsFixed(2), strong: true),
              ],
            ),
          ),
          const SizedBox(height: 16),
          FilledButton.icon(
            onPressed: saving ? null : saveInvoice,
            icon: saving
                ? const SizedBox(
                    width: 18,
                    height: 18,
                    child: CircularProgressIndicator(strokeWidth: 2),
                  )
                : const Icon(Icons.save_outlined),
            label: Text(saving ? 'جاري الحفظ...' : 'حفظ الفاتورة'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('الفواتير والذمم'),
            ],
          ),
          actions: [
            IconButton(
              onPressed: loadData,
              icon: const Icon(Icons.refresh),
            ),
          ],
          bottom: TabBar(
            controller: tabController,
            tabs: const [
              Tab(icon: Icon(Icons.receipt_long_outlined), text: 'الفواتير'),
              Tab(icon: Icon(Icons.add_circle_outline), text: 'إنشاء'),
            ],
          ),
        ),
        body: TabBarView(
          controller: tabController,
          children: [
            buildInvoiceList(),
            buildForm(),
          ],
        ),
      ),
    );
  }
}

class _InvoiceLineDraft {
  final descriptionController = TextEditingController();
  final qtyController = TextEditingController(text: '1');
  final unitPriceController = TextEditingController();

  double get qty => double.tryParse(qtyController.text.trim()) ?? 0;

  double get unitPrice => double.tryParse(unitPriceController.text.trim()) ?? 0;

  double get total => qty * unitPrice;

  void dispose() {
    descriptionController.dispose();
    qtyController.dispose();
    unitPriceController.dispose();
  }
}

class _InvoiceLineEditor extends StatelessWidget {
  final int index;
  final _InvoiceLineDraft line;
  final bool canRemove;
  final VoidCallback onChanged;
  final VoidCallback onRemove;

  const _InvoiceLineEditor({
    super.key,
    required this.index,
    required this.line,
    required this.canRemove,
    required this.onChanged,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'بند ${index + 1}',
                    style: const TextStyle(fontWeight: FontWeight.w900),
                  ),
                ),
                if (canRemove)
                  IconButton(
                    onPressed: onRemove,
                    icon: const Icon(Icons.delete_outline),
                    tooltip: 'حذف',
                  ),
              ],
            ),
            const SizedBox(height: 8),
            TextFormField(
              controller: line.descriptionController,
              decoration: const InputDecoration(labelText: 'وصف البند'),
              validator: (value) {
                if ((value ?? '').trim().isEmpty) return 'أدخل وصف البند';
                return null;
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: line.qtyController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'الكمية'),
                    onChanged: (_) => onChanged(),
                    validator: (value) {
                      final parsed = double.tryParse((value ?? '').trim()) ?? 0;
                      if (parsed <= 0) return 'كمية غير صحيحة';
                      return null;
                    },
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: TextFormField(
                    controller: line.unitPriceController,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'السعر'),
                    onChanged: (_) => onChanged(),
                    validator: (value) {
                      final parsed = double.tryParse((value ?? '').trim()) ?? 0;
                      if (parsed <= 0) return 'سعر غير صحيح';
                      return null;
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Expanded(child: Text('إجمالي البند')),
                Text(
                  line.total.toStringAsFixed(2),
                  style: const TextStyle(
                    color: AlshaariColors.deepGreen,
                    fontWeight: FontWeight.w900,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _StatusPill extends StatelessWidget {
  final String status;

  const _StatusPill({required this.status});

  @override
  Widget build(BuildContext context) {
    final posted = status == 'posted';
    final color = posted ? const Color(0xFF2F7D57) : AlshaariColors.copper;
    final label = posted ? 'مرحلة' : 'مسودة';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(.10),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(.35)),
      ),
      child: Text(
        label,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w800,
          fontSize: 12,
        ),
      ),
    );
  }
}
