CREATE TABLE IF NOT EXISTS adjustment_vouchers (
    id INTEGER PRIMARY KEY,
    voucher_no VARCHAR(80) UNIQUE NOT NULL,
    date DATE NOT NULL,
    reason VARCHAR(60) NOT NULL,
    description TEXT NOT NULL,
    attachment_url VARCHAR(500) NULL,
    status VARCHAR(30) DEFAULT 'draft',
    created_by INTEGER NULL,
    approved_by INTEGER NULL,
    approved_at TIMESTAMP NULL,
    reversal_of_id INTEGER NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE adjustment_vouchers ADD COLUMN IF NOT EXISTS attachment_url VARCHAR(500);
ALTER TABLE adjustment_vouchers ADD COLUMN IF NOT EXISTS rejected_by INTEGER NULL;
ALTER TABLE adjustment_vouchers ADD COLUMN IF NOT EXISTS rejected_at TIMESTAMP NULL;
ALTER TABLE adjustment_vouchers ADD COLUMN IF NOT EXISTS reversed_by INTEGER NULL;
ALTER TABLE adjustment_vouchers ADD COLUMN IF NOT EXISTS reversed_at TIMESTAMP NULL;

CREATE TABLE IF NOT EXISTS adjustment_voucher_lines (
    id INTEGER PRIMARY KEY,
    voucher_id INTEGER NOT NULL,
    account_code VARCHAR(30) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    debit NUMERIC(14, 2) DEFAULT 0,
    credit NUMERIC(14, 2) DEFAULT 0,
    project_id INTEGER NULL,
    cost_center_id INTEGER NULL,
    party_type VARCHAR(50) NULL,
    party_id INTEGER NULL,
    description TEXT NULL
);
