from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_approval_role
from app.db.database import get_db
from app.models.models import AuditLog, Setting
from app.schemas.schemas import CompanySettings

router = APIRouter(prefix="/api/v1/settings", tags=["Settings"])

COMPANY_SETTING_KEYS = set(CompanySettings.model_fields.keys())


def default_company_settings() -> dict:
    return CompanySettings().model_dump()


@router.get("/company")
def get_company_settings(db: Session = Depends(get_db), user=Depends(get_current_user)):
    values = default_company_settings()
    rows = db.query(Setting).filter(Setting.key.in_(COMPANY_SETTING_KEYS)).all()
    for row in rows:
        values[row.key] = row.value
    return values


@router.put("/company")
def update_company_settings(
    data: CompanySettings,
    db: Session = Depends(get_db),
    user=Depends(require_approval_role),
):
    payload = data.model_dump()
    for key, value in payload.items():
        row = db.query(Setting).filter(Setting.key == key).first()
        if not row:
            row = Setting(key=key)
            db.add(row)
        row.value = "" if value is None else str(value)

    db.add(
        AuditLog(
            user_id=user.id,
            action="update_company_settings",
            entity="settings",
            entity_id=None,
            details=payload.get("company_name", ""),
        )
    )
    db.commit()
    return payload
