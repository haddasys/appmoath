import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/printing/official_print.dart';
import '../../../core/printing/print_document.dart';

class ReportsScreen extends StatefulWidget {
  final int initialTab;

  const ReportsScreen({super.key, this.initialTab = 0});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen>
    with SingleTickerProviderStateMixin {
  late final TabController controller;

  bool loading = true;
  Map<String, dynamic> trialBalance = {};
  Map<String, dynamic> profitLoss = {};
  Map<String, dynamic> cashFlow = {};
  List<dynamic> projects = [];
  List<dynamic> overBudgetProjects = [];
  List<dynamic> costCenterReport = [];
  List<dynamic> workerAdvancesReport = [];
  List<dynamic> costCenterExpensesReport = [];
  List<dynamic> customerAgingReport = [];
  List<dynamic> supplierAgingReport = [];
  Map<String, dynamic> purchaseSummary = {};
  List<dynamic> openPurchaseOrders = [];
  List<dynamic> grniReport = [];
  List<dynamic> inventoryBalanceReport = [];
  List<dynamic> projectMaterialCostsReport = [];
  List<dynamic> directProjectPurchasesReport = [];
  List<dynamic> accountingPeriods = [];
  List<dynamic> journalEntries = [];
  bool ledgerLoading = false;
  CompanyPrintProfile printProfile = CompanyPrintProfile.defaults();
  final trialFromDateController = TextEditingController();
  final trialToDateController = TextEditingController();
  final journalFromDateController = TextEditingController();
  final journalToDateController = TextEditingController();
  int? selectedTrialPeriodId;
  int? selectedJournalPeriodId;
  String journalStatusFilter = 'posted';
  int trialBalanceLevel = 4;
  bool trialIncludeZero = true;

  @override
  void initState() {
    super.initState();
    controller = TabController(
      length: 10,
      vsync: this,
      initialIndex: widget.initialTab.clamp(0, 9),
    );
    configureAndLoad();
  }

  @override
  void dispose() {
    controller.dispose();
    trialFromDateController.dispose();
    trialToDateController.dispose();
    journalFromDateController.dispose();
    journalToDateController.dispose();
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadReports();
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
      if (error.response?.statusCode == 403) {
        return 'لا تملك صلاحية عرض هذا التقرير';
      }
    }
    return 'حدث خطأ غير متوقع';
  }

  Future<void> loadReports() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        apiClient.dio.get(trialBalanceEndpoint()),
        apiClient.dio.get('/reports/profit-loss'),
        apiClient.dio.get('/reports/cash-flow'),
        apiClient.dio.get('/reports/project-profitability'),
        apiClient.dio.get('/reports/over-budget-projects'),
        apiClient.dio.get('/reports/cost-centers'),
        apiClient.dio.get('/reports/worker-advances'),
        apiClient.dio.get('/reports/cost-center-expenses'),
        apiClient.dio.get('/reports/customer-aging'),
        apiClient.dio.get('/reports/supplier-aging'),
        apiClient.dio.get('/reports/purchase-summary'),
        apiClient.dio.get('/reports/open-purchase-orders'),
        apiClient.dio.get('/reports/grni'),
        apiClient.dio.get('/reports/inventory-balance'),
        apiClient.dio.get('/reports/project-material-costs'),
        apiClient.dio.get('/reports/direct-project-purchases'),
        apiClient.dio.get('/accounting-periods'),
        apiClient.dio.get(journalEntriesEndpoint()),
        loadCompanyPrintProfile(),
      ]);

      final trialBalanceResponse = result[0] as Response;
      final profitLossResponse = result[1] as Response;
      final cashFlowResponse = result[2] as Response;
      final projectsResponse = result[3] as Response;
      final overBudgetProjectsResponse = result[4] as Response;
      final costCentersResponse = result[5] as Response;
      final workerAdvancesResponse = result[6] as Response;
      final costCenterExpensesResponse = result[7] as Response;
      final customerAgingResponse = result[8] as Response;
      final supplierAgingResponse = result[9] as Response;
      final purchaseSummaryResponse = result[10] as Response;
      final openPurchaseOrdersResponse = result[11] as Response;
      final grniResponse = result[12] as Response;
      final inventoryBalanceResponse = result[13] as Response;
      final projectMaterialCostsResponse = result[14] as Response;
      final directProjectPurchasesResponse = result[15] as Response;
      final accountingPeriodsResponse = result[16] as Response;
      final journalEntriesResponse = result[17] as Response;

      if (!mounted) return;
      setState(() {
        trialBalance =
            Map<String, dynamic>.from(trialBalanceResponse.data as Map);
        profitLoss = Map<String, dynamic>.from(profitLossResponse.data as Map);
        cashFlow = Map<String, dynamic>.from(cashFlowResponse.data as Map);
        projects = (projectsResponse.data as List?) ?? [];
        overBudgetProjects = (overBudgetProjectsResponse.data as List?) ?? [];
        costCenterReport = (costCentersResponse.data as List?) ?? [];
        workerAdvancesReport = (workerAdvancesResponse.data as List?) ?? [];
        costCenterExpensesReport =
            (costCenterExpensesResponse.data as List?) ?? [];
        customerAgingReport = (customerAgingResponse.data as List?) ?? [];
        supplierAgingReport = (supplierAgingResponse.data as List?) ?? [];
        purchaseSummary =
            Map<String, dynamic>.from(purchaseSummaryResponse.data as Map);
        openPurchaseOrders = (openPurchaseOrdersResponse.data as List?) ?? [];
        grniReport = (grniResponse.data as List?) ?? [];
        inventoryBalanceReport = (inventoryBalanceResponse.data as List?) ?? [];
        projectMaterialCostsReport =
            (projectMaterialCostsResponse.data as List?) ?? [];
        directProjectPurchasesReport =
            (directProjectPurchasesResponse.data as List?) ?? [];
        accountingPeriods = (accountingPeriodsResponse.data as List?) ?? [];
        if (journalEntriesResponse.data is List) {
          journalEntries = journalEntriesResponse.data as List<dynamic>;
        } else if (journalEntriesResponse.data is Map &&
            journalEntriesResponse.data['items'] is List) {
          journalEntries =
              journalEntriesResponse.data['items'] as List<dynamic>;
        } else {
          journalEntries = [];
        }
        printProfile = result[18] as CompanyPrintProfile;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل التقارير: ${friendlyError(e)}');
    }
  }

  String trialBalanceEndpoint() {
    final params = <String, String>{
      'level': '$trialBalanceLevel',
      'include_zero': '$trialIncludeZero',
    };

    final fromDate = trialFromDateController.text.trim();
    final toDate = trialToDateController.text.trim();

    if (selectedTrialPeriodId != null) {
      params['period_id'] = '$selectedTrialPeriodId';
    } else {
      if (fromDate.isNotEmpty) params['from_date'] = fromDate;
      if (toDate.isNotEmpty) params['to_date'] = toDate;
    }

    return '/accounting/trial-balance?${Uri(queryParameters: params).query}';
  }

  String journalEntriesEndpoint() {
    final params = <String, String>{};
    final fromDate = journalFromDateController.text.trim();
    final toDate = journalToDateController.text.trim();

    if (selectedJournalPeriodId != null) {
      params['period_id'] = '$selectedJournalPeriodId';
    } else {
      if (fromDate.isNotEmpty) params['from_date'] = fromDate;
      if (toDate.isNotEmpty) params['to_date'] = toDate;
    }
    if (journalStatusFilter != 'all') {
      params['status'] = journalStatusFilter;
    }

    final query = Uri(queryParameters: params).query;
    return query.isEmpty
        ? '/accounting/journal-entries'
        : '/accounting/journal-entries?$query';
  }

  String ledgerEndpoint(String accountCode) {
    final params = <String, String>{
      'status': 'posted',
    };
    final fromDate = trialFromDateController.text.trim();
    final toDate = trialToDateController.text.trim();

    if (selectedTrialPeriodId != null) {
      params['period_id'] = '$selectedTrialPeriodId';
    } else {
      if (fromDate.isNotEmpty) params['from_date'] = fromDate;
      if (toDate.isNotEmpty) params['to_date'] = toDate;
    }

    final query = Uri(queryParameters: params).query;
    return query.isEmpty
        ? '/accounting/ledger/${Uri.encodeComponent(accountCode)}'
        : '/accounting/ledger/${Uri.encodeComponent(accountCode)}?$query';
  }

  double numericValue(dynamic value) =>
      double.tryParse('${value ?? 0}'.replaceAll(',', '')) ?? 0;

  Future<void> loadLedgerForAccount(Map<String, dynamic> account) async {
    final accountCode = '${account['account_code'] ?? ''}'.trim();
    if (accountCode.isEmpty || ledgerLoading) return;

    setState(() => ledgerLoading = true);
    try {
      final response = await apiClient.dio.get(ledgerEndpoint(accountCode));
      final rows = (response.data as List?) ?? [];
      if (!mounted) return;
      showLedgerSheet(account, rows);
    } catch (e) {
      if (!mounted) return;
      showMessage('فشل تحميل كشف الحساب: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => ledgerLoading = false);
    }
  }

  void showLedgerSheet(Map<String, dynamic> account, List<dynamic> rows) {
    double totalDebit = 0;
    double totalCredit = 0;
    double runningBalance = 0;
    final renderedRows = rows.map((raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      final debit = numericValue(row['debit']);
      final credit = numericValue(row['credit']);
      totalDebit += debit;
      totalCredit += credit;
      runningBalance += debit - credit;
      return {
        ...row,
        'running_balance': runningBalance.toStringAsFixed(2),
      };
    }).toList();

    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (context) {
        return Directionality(
          textDirection: ui.TextDirection.rtl,
          child: DraggableScrollableSheet(
            expand: false,
            initialChildSize: 0.82,
            minChildSize: 0.45,
            maxChildSize: 0.95,
            builder: (context, scrollController) {
              return ListView(
                controller: scrollController,
                padding: const EdgeInsets.all(16),
                children: [
                  Row(
                    children: [
                      const Icon(Icons.account_balance_wallet_outlined,
                          color: AlshaariColors.copper),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          'كشف حساب ${account['account_code'] ?? ''} - ${account['account_name'] ?? ''}',
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w900,
                            color: AlshaariColors.ink,
                          ),
                        ),
                      ),
                      IconButton(
                        onPressed: () => Navigator.pop(context),
                        icon: const Icon(Icons.close),
                      ),
                    ],
                  ),
                  const SizedBox(height: 10),
                  cardsGrid([
                    summaryCard('إجمالي المدين', totalDebit.toStringAsFixed(2),
                        Icons.south_west,
                        color: const Color(0xFF2F7D57)),
                    summaryCard('إجمالي الدائن', totalCredit.toStringAsFixed(2),
                        Icons.north_east,
                        color: AlshaariColors.copper),
                    summaryCard(
                        'الرصيد',
                        (totalDebit - totalCredit).toStringAsFixed(2),
                        Icons.account_balance,
                        color: AlshaariColors.deepGreen),
                  ]),
                  const SizedBox(height: 10),
                  printButton(
                    'طباعة كشف الحساب',
                    () => printReport(
                      'كشف حساب',
                      ledgerHtml(
                        account,
                        renderedRows,
                        totalDebit,
                        totalCredit,
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  if (renderedRows.isEmpty)
                    const Card(
                      child: ListTile(
                        leading: Icon(Icons.info_outline),
                        title: Text(
                            'لا توجد حركات لهذا الحساب ضمن الفلاتر الحالية'),
                      ),
                    )
                  else
                    ...renderedRows.map((row) {
                      return Card(
                        child: Padding(
                          padding: const EdgeInsets.all(14),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Row(
                                children: [
                                  const Icon(Icons.receipt_long,
                                      color: AlshaariColors.copper),
                                  const SizedBox(width: 8),
                                  Expanded(
                                    child: Text(
                                      '${row['entry_no'] ?? '-'}',
                                      style: const TextStyle(
                                          fontWeight: FontWeight.w900),
                                    ),
                                  ),
                                  Chip(label: Text('${row['status'] ?? '-'}')),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Text('التاريخ: ${row['entry_date'] ?? '-'}'),
                              if ('${row['entry_description'] ?? ''}'
                                  .trim()
                                  .isNotEmpty)
                                Text('بيان القيد: ${row['entry_description']}'),
                              if ('${row['description'] ?? ''}'
                                  .trim()
                                  .isNotEmpty)
                                Text('بيان السطر: ${row['description']}'),
                              Text(
                                  'المصدر: ${row['source_type'] ?? '-'} #${row['source_id'] ?? '-'}'),
                              const Divider(height: 20),
                              _ReportLine('مدين', row['debit']),
                              _ReportLine('دائن', row['credit']),
                              _ReportLine(
                                  'الرصيد التراكمي', row['running_balance']),
                            ],
                          ),
                        ),
                      );
                    }),
                ],
              );
            },
          ),
        );
      },
    );
  }

  Future<void> pickTrialDate(TextEditingController target) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
    );

    if (selected == null) return;

    selectedTrialPeriodId = null;
    target.text = selected.toIso8601String().substring(0, 10);
    await loadReports();
  }

  Future<void> pickJournalDate(TextEditingController target) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
    );

    if (selected == null) return;

    selectedJournalPeriodId = null;
    target.text = selected.toIso8601String().substring(0, 10);
    await loadReports();
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  String money(dynamic value) => '${value ?? 0}';

  String sourceDisplay(Map<String, dynamic> row) {
    final label = '${row['source_label'] ?? row['source_type'] ?? '-'}';
    final no = '${row['source_no'] ?? row['source_id'] ?? '-'}';
    return '$label #$no';
  }

  String accountingPeriodLabel(Map<String, dynamic> period) {
    final year = period['year'] ?? '-';
    final month = '${period['month'] ?? '-'}'.padLeft(2, '0');
    final status = period['status'] == 'closed' ? 'مغلقة' : 'مفتوحة';
    return '$year-$month ($status)';
  }

  String htmlEscape(Object? value) {
    return '${value ?? ''}'
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
  }

  String printHeader(String title) {
    return officialPrintHeader(printProfile, title);
  }

  String printFooter() {
    return officialPrintFooter();
  }

  Future<void> printReport(String title, String html) async {
    try {
      await openPrintDocument(title: title, content: html);
    } catch (_) {
      showMessage('الطباعة متاحة حاليًا من نسخة الويب');
    }
  }

  String trialBalanceHtml() {
    final rows = (trialBalance['rows'] as List?) ?? [];
    final totals =
        Map<String, dynamic>.from((trialBalance['totals'] as Map?) ?? {});
    final balanced = trialBalance['is_balanced'] == true;
    final buffer = StringBuffer(printHeader('ميزان المراجعة'));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>إجمالي المدين</b><span>${htmlEscape(totals['total_debit'])}</span></div>
      <div class="box"><b>إجمالي الدائن</b><span>${htmlEscape(totals['total_credit'])}</span></div>
      <div class="box"><b>حالة الميزان</b><span class="${balanced ? 'ok' : 'warn'}">${balanced ? 'متوازن' : 'غير متوازن'}</span></div>
    </div>
    <table>
      <thead><tr><th>الكود</th><th>الحساب</th><th>المستوى</th><th class="amount">مدين</th><th class="amount">دائن</th><th class="amount">الرصيد</th></tr></thead>
      <tbody>
''');
    if (rows.isEmpty) {
      buffer.write('<tr><td colspan="6">لا توجد قيود مرحلة.</td></tr>');
    } else {
      for (final raw in rows) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['account_code'])}</td>
          <td>${htmlEscape(row['account_name'])}</td>
          <td>${htmlEscape(row['account_level'])}</td>
          <td class="amount">${htmlEscape(row['total_debit'])}</td>
          <td class="amount">${htmlEscape(row['total_credit'])}</td>
          <td class="amount">${htmlEscape(row['balance'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String simpleReportHtml(
      String title, List<MapEntry<String, dynamic>> values) {
    final buffer = StringBuffer(printHeader(title));
    buffer.write('<div class="grid">');
    for (final item in values) {
      buffer.write(
          '<div class="box"><b>${htmlEscape(item.key)}</b><span>${htmlEscape(item.value)}</span></div>');
    }
    buffer.write('</div>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String ledgerHtml(
    Map<String, dynamic> account,
    List<Map<String, dynamic>> rows,
    double totalDebit,
    double totalCredit,
  ) {
    final title =
        'كشف حساب ${account['account_code'] ?? ''} - ${account['account_name'] ?? ''}';
    final buffer = StringBuffer(printHeader(title));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>إجمالي المدين</b><span>${htmlEscape(totalDebit.toStringAsFixed(2))}</span></div>
      <div class="box"><b>إجمالي الدائن</b><span>${htmlEscape(totalCredit.toStringAsFixed(2))}</span></div>
      <div class="box"><b>الرصيد</b><span>${htmlEscape((totalDebit - totalCredit).toStringAsFixed(2))}</span></div>
    </div>
    <table>
      <thead><tr><th>رقم القيد</th><th>التاريخ</th><th>المصدر</th><th>البيان</th><th class="amount">مدين</th><th class="amount">دائن</th><th class="amount">الرصيد التراكمي</th></tr></thead>
      <tbody>
''');
    if (rows.isEmpty) {
      buffer.write(
          '<tr><td colspan="7">لا توجد حركات لهذا الحساب ضمن الفلاتر الحالية.</td></tr>');
    } else {
      for (final row in rows) {
        final description =
            '${row['description'] ?? row['entry_description'] ?? ''}'.trim();
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['entry_no'])}</td>
          <td>${htmlEscape(row['entry_date'])}</td>
          <td>${htmlEscape(sourceDisplay(row))}</td>
          <td>${htmlEscape(description)}</td>
          <td class="amount">${htmlEscape(row['debit'])}</td>
          <td class="amount">${htmlEscape(row['credit'])}</td>
          <td class="amount">${htmlEscape(row['running_balance'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String projectsHtml() {
    final buffer = StringBuffer(printHeader('ربحية المشاريع'));
    buffer.write('''
    <h2>المشاريع المتجاوزة للتكلفة</h2>
    <table>
      <thead><tr><th>المشروع</th><th class="amount">التكلفة المقدرة</th><th class="amount">التكلفة الفعلية</th><th class="amount">الانحراف</th><th>الحالة</th></tr></thead>
      <tbody>
''');
    if (overBudgetProjects.isEmpty) {
      buffer.write(
          '<tr><td colspan="5">لا توجد مشاريع تجاوزت تقدير التكلفة.</td></tr>');
    } else {
      for (final raw in overBudgetProjects) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['project_code'])} - ${htmlEscape(row['project_name'])}</td>
          <td class="amount">${htmlEscape(row['estimated_total_cost'])}</td>
          <td class="amount">${htmlEscape(row['actual_total_cost'])}</td>
          <td class="amount">${htmlEscape(row['cost_variance'])}</td>
          <td>${htmlEscape(row['over_budget_message'] ?? 'تجاوز التكلفة المقدرة')}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write('''
    <h2>ربحية كل المشاريع</h2>
    <table>
      <thead><tr><th>المشروع</th><th class="amount">قيمة العقد</th><th class="amount">التحصيل</th><th class="amount">التكلفة</th><th class="amount">الربح</th><th class="amount">الهامش</th></tr></thead>
      <tbody>
''');
    if (projects.isEmpty) {
      buffer.write('<tr><td colspan="6">لا توجد مشاريع.</td></tr>');
    } else {
      for (final raw in projects) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['project_code'])} - ${htmlEscape(row['project_name'])}</td>
          <td class="amount">${htmlEscape(row['contract_value'])}</td>
          <td class="amount">${htmlEscape(row['collected'])}</td>
          <td class="amount">${htmlEscape(row['total_cost'])}</td>
          <td class="amount">${htmlEscape(row['net_profit'])}</td>
          <td class="amount">${htmlEscape(row['profit_margin_percent'])}%</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String costCentersHtml() {
    final buffer = StringBuffer(printHeader('تقرير مراكز التكلفة'));
    buffer.write('''
    <table>
      <thead><tr><th>الكود</th><th>مركز التكلفة</th><th>النوع</th><th>طريقة التحميل</th><th class="amount">المباشر</th><th class="amount">مع الأبناء</th><th class="amount">تكاليف المشاريع</th><th class="amount">الموازنة</th><th class="amount">الانحراف</th></tr></thead>
      <tbody>
''');
    if (costCenterReport.isEmpty) {
      buffer.write('<tr><td colspan="9">لا توجد مراكز تكلفة.</td></tr>');
    } else {
      for (final raw in costCenterReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['code'])}</td>
          <td>${htmlEscape(row['name'])}</td>
          <td>${htmlEscape(row['type'])}</td>
          <td>${htmlEscape(row['allocation_method'])}</td>
          <td class="amount">${htmlEscape(row['net_amount'])}</td>
          <td class="amount">${htmlEscape(row['total_with_children'])}</td>
          <td class="amount">${htmlEscape(row['project_costs_with_children'])}</td>
          <td class="amount">${htmlEscape(row['budget_amount'])}</td>
          <td class="amount">${htmlEscape(row['budget_variance'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String workerAdvancesHtml() {
    final buffer = StringBuffer(printHeader('تقرير السلف والعهد'));
    buffer.write('''
    <table>
      <thead><tr><th>العامل</th><th class="amount">إجمالي السلف</th><th class="amount">إجمالي التسويات</th><th class="amount">الرصيد المفتوح</th><th>الحالة</th></tr></thead>
      <tbody>
''');
    if (workerAdvancesReport.isEmpty) {
      buffer.write('<tr><td colspan="5">لا توجد سلف أو عهد مفتوحة.</td></tr>');
    } else {
      for (final raw in workerAdvancesReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        final high = row['risk_level'] == 'high';
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['worker_name'])}</td>
          <td class="amount">${htmlEscape(row['total_advances'])}</td>
          <td class="amount">${htmlEscape(row['total_settlements'])}</td>
          <td class="amount">${htmlEscape(row['open_balance'])}</td>
          <td class="${high ? 'warn' : 'ok'}">${high ? 'مرتفع' : 'طبيعي'}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String costCenterExpensesHtml() {
    final buffer = StringBuffer(printHeader('مصروفات مراكز التكلفة'));
    buffer.write('''
    <table>
      <thead><tr><th>المركز</th><th>النوع</th><th class="amount">إجمالي المدين</th><th class="amount">إجمالي الدائن</th><th class="amount">صافي التكلفة</th><th class="amount">المشاريع</th><th class="amount">النسبة</th></tr></thead>
      <tbody>
''');
    if (costCenterExpensesReport.isEmpty) {
      buffer
          .write('<tr><td colspan="7">لا توجد مصروفات مراكز تكلفة.</td></tr>');
    } else {
      for (final raw in costCenterExpensesReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['code'])} - ${htmlEscape(row['name'])}</td>
          <td>${htmlEscape(row['type'])}</td>
          <td class="amount">${htmlEscape(row['total_debit'])}</td>
          <td class="amount">${htmlEscape(row['total_credit'])}</td>
          <td class="amount">${htmlEscape(row['net_cost'])}</td>
          <td class="amount">${htmlEscape(row['linked_projects'])}</td>
          <td class="amount">${htmlEscape(row['cost_share_percent'])}%</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String agingHtml() {
    final buffer = StringBuffer(printHeader('أعمار الذمم'));
    buffer.write('''
    <h2>أعمار ذمم العملاء</h2>
    <table>
      <thead><tr><th>العميل</th><th class="amount">حالي</th><th class="amount">1-30</th><th class="amount">31-60</th><th class="amount">61-90</th><th class="amount">أكثر من 90</th><th class="amount">الإجمالي</th><th>المخاطر</th></tr></thead>
      <tbody>
''');
    if (customerAgingReport.isEmpty) {
      buffer.write('<tr><td colspan="8">لا توجد ذمم مدينة مفتوحة.</td></tr>');
    } else {
      for (final raw in customerAgingReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['customer'])}</td>
          <td class="amount">${htmlEscape(row['current'])}</td>
          <td class="amount">${htmlEscape(row['days_1_30'])}</td>
          <td class="amount">${htmlEscape(row['days_31_60'])}</td>
          <td class="amount">${htmlEscape(row['days_61_90'])}</td>
          <td class="amount">${htmlEscape(row['days_over_90'])}</td>
          <td class="amount">${htmlEscape(row['total'])}</td>
          <td>${htmlEscape(row['risk_level'])}</td>
        </tr>
''');
      }
    }
    buffer.write('''
      </tbody>
    </table>
    <h2>أعمار ذمم الموردين</h2>
    <table>
      <thead><tr><th>المورد</th><th class="amount">حالي</th><th class="amount">1-30</th><th class="amount">31-60</th><th class="amount">61-90</th><th class="amount">أكثر من 90</th><th class="amount">الإجمالي</th><th>المخاطر</th></tr></thead>
      <tbody>
''');
    if (supplierAgingReport.isEmpty) {
      buffer.write('<tr><td colspan="8">لا توجد ذمم دائنة مفتوحة.</td></tr>');
    } else {
      for (final raw in supplierAgingReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['supplier'])}</td>
          <td class="amount">${htmlEscape(row['current'])}</td>
          <td class="amount">${htmlEscape(row['days_1_30'])}</td>
          <td class="amount">${htmlEscape(row['days_31_60'])}</td>
          <td class="amount">${htmlEscape(row['days_61_90'])}</td>
          <td class="amount">${htmlEscape(row['days_over_90'])}</td>
          <td class="amount">${htmlEscape(row['total'])}</td>
          <td>${htmlEscape(row['risk_level'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String purchaseInventoryHtml() {
    final buffer = StringBuffer(printHeader('تقرير المشتريات والمخزون'));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>فواتير الموردين المعتمدة</b><span>${htmlEscape(purchaseSummary['approved_invoices'])}</span></div>
      <div class="box"><b>دفعات الموردين المعتمدة</b><span>${htmlEscape(purchaseSummary['approved_payments'])}</span></div>
      <div class="box"><b>أوامر شراء مفتوحة</b><span>${htmlEscape(purchaseSummary['open_purchase_orders'])}</span></div>
      <div class="box"><b>طلبات شراء بانتظار المتابعة</b><span>${htmlEscape(purchaseSummary['pending_purchase_requests'])}</span></div>
    </div>
    <h2>رصيد المخزون</h2>
    <table>
      <thead><tr><th>الكود</th><th>المادة</th><th class="amount">المتاح</th><th class="amount">المحجوز</th><th class="amount">الصافي</th><th class="amount">متوسط التكلفة</th><th class="amount">القيمة</th></tr></thead>
      <tbody>
''');
    if (inventoryBalanceReport.isEmpty) {
      buffer.write('<tr><td colspan="7">لا توجد أرصدة مخزون.</td></tr>');
    } else {
      for (final raw in inventoryBalanceReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['code'])}</td>
          <td>${htmlEscape(row['name'])}</td>
          <td class="amount">${htmlEscape(row['current_qty'])}</td>
          <td class="amount">${htmlEscape(row['reserved_qty'])}</td>
          <td class="amount">${htmlEscape(row['available_qty'])}</td>
          <td class="amount">${htmlEscape(row['avg_cost'])}</td>
          <td class="amount">${htmlEscape(row['stock_value'])}</td>
        </tr>
''');
      }
    }
    buffer.write('''
      </tbody>
    </table>
    <h2>مواد المشاريع</h2>
    <table>
      <thead><tr><th>المشروع</th><th>المادة</th><th class="amount">الكمية</th><th class="amount">التكلفة</th><th>النوع</th></tr></thead>
      <tbody>
''');
    if (projectMaterialCostsReport.isEmpty) {
      buffer.write(
          '<tr><td colspan="5">لا توجد مواد مصروفة أو شراء مباشر للمشاريع.</td></tr>');
    } else {
      for (final raw in projectMaterialCostsReport) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['project_name'])}</td>
          <td>${htmlEscape(row['item_name'])}</td>
          <td class="amount">${htmlEscape(row['qty'])}</td>
          <td class="amount">${htmlEscape(row['total_cost'])}</td>
          <td>${htmlEscape(row['movement_type'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  String journalEntriesHtml() {
    final buffer = StringBuffer(printHeader('دفتر اليومية'));
    buffer.write('''
    <table>
      <thead><tr><th>رقم القيد</th><th>التاريخ</th><th>المصدر</th><th>البيان</th><th class="amount">مدين</th><th class="amount">دائن</th><th>الحالة</th></tr></thead>
      <tbody>
''');
    if (journalEntries.isEmpty) {
      buffer
          .write('<tr><td colspan="7">لا توجد قيود مطابقة للفلاتر.</td></tr>');
    } else {
      for (final raw in journalEntries) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
        <tr>
          <td>${htmlEscape(row['entry_no'] ?? row['id'])}</td>
          <td>${htmlEscape(row['entry_date'])}</td>
          <td>${htmlEscape(sourceDisplay(row))}</td>
          <td>${htmlEscape(row['description'])}</td>
          <td class="amount">${htmlEscape(row['total_debit'])}</td>
          <td class="amount">${htmlEscape(row['total_credit'])}</td>
          <td>${htmlEscape(row['status'])}</td>
        </tr>
''');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    return buffer.toString();
  }

  Widget summaryCard(String title, dynamic value, IconData icon,
      {Color? color}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: (color ?? AlshaariColors.deepGreen).withOpacity(.10),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color ?? AlshaariColors.deepGreen),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  Text(
                    money(value),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget cardsGrid(List<Widget> cards) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 720) {
          return Column(
            children: cards
                .map((card) => Padding(
                    padding: const EdgeInsets.only(bottom: 8), child: card))
                .toList(),
          );
        }
        return GridView.count(
          crossAxisCount: 3,
          childAspectRatio: 2.8,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: cards,
        );
      },
    );
  }

  Widget printButton(String label, VoidCallback onPressed) {
    return Align(
      alignment: Alignment.centerLeft,
      child: FilledButton.icon(
        onPressed: onPressed,
        icon: const Icon(Icons.print_outlined),
        label: Text(label),
      ),
    );
  }

  Widget trialBalanceFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 760;
            final periodDropdown = DropdownButtonFormField<int?>(
              initialValue: selectedTrialPeriodId,
              decoration: const InputDecoration(
                labelText: 'الفترة المالية',
                prefixIcon: Icon(Icons.event_available_outlined),
              ),
              items: [
                const DropdownMenuItem<int?>(
                  value: null,
                  child: Text('بدون فترة محددة'),
                ),
                ...accountingPeriods.map((raw) {
                  final period = Map<String, dynamic>.from(raw as Map);
                  final idRaw = period['id'];
                  final id = idRaw is int ? idRaw : int.tryParse('$idRaw');
                  return DropdownMenuItem<int?>(
                    value: id,
                    child: Text(accountingPeriodLabel(period)),
                  );
                }),
              ],
              onChanged: (value) async {
                setState(() {
                  selectedTrialPeriodId = value;
                  if (value != null) {
                    trialFromDateController.clear();
                    trialToDateController.clear();
                  }
                });
                await loadReports();
              },
            );
            final fields = [
              Expanded(
                child: TextFormField(
                  controller: trialFromDateController,
                  enabled: selectedTrialPeriodId == null,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'من تاريخ',
                    suffixIcon: IconButton(
                      onPressed: () => pickTrialDate(trialFromDateController),
                      icon: const Icon(Icons.calendar_today_outlined),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8, height: 8),
              Expanded(
                child: TextFormField(
                  controller: trialToDateController,
                  enabled: selectedTrialPeriodId == null,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'إلى تاريخ',
                    suffixIcon: IconButton(
                      onPressed: () => pickTrialDate(trialToDateController),
                      icon: const Icon(Icons.event_outlined),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 8, height: 8),
              Expanded(
                child: DropdownButtonFormField<int>(
                  initialValue: trialBalanceLevel,
                  decoration: const InputDecoration(labelText: 'مستوى الحساب'),
                  items: const [
                    DropdownMenuItem(value: 3, child: Text('رئيسي / مستوى 3')),
                    DropdownMenuItem(value: 4, child: Text('تفصيلي / مستوى 4')),
                  ],
                  onChanged: (value) async {
                    if (value == null) return;
                    setState(() => trialBalanceLevel = value);
                    await loadReports();
                  },
                ),
              ),
            ];

            final buttons = Wrap(
              spacing: 8,
              runSpacing: 8,
              crossAxisAlignment: WrapCrossAlignment.center,
              children: [
                FilterChip(
                  selected: trialIncludeZero,
                  label: const Text('إظهار الحسابات الصفرية'),
                  onSelected: (value) async {
                    setState(() => trialIncludeZero = value);
                    await loadReports();
                  },
                ),
                OutlinedButton.icon(
                  onPressed: () async {
                    trialFromDateController.clear();
                    trialToDateController.clear();
                    setState(() {
                      selectedTrialPeriodId = null;
                      trialBalanceLevel = 4;
                      trialIncludeZero = true;
                    });
                    await loadReports();
                  },
                  icon: const Icon(Icons.clear),
                  label: const Text('مسح الفلاتر'),
                ),
                FilledButton.icon(
                  onPressed: loadReports,
                  icon: const Icon(Icons.refresh),
                  label: const Text('تحديث الميزان'),
                ),
              ],
            );

            if (compact) {
              final fromField = (fields[0] as Expanded).child;
              final toField = (fields[2] as Expanded).child;
              final levelField = (fields[4] as Expanded).child;
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: periodDropdown,
                  ),
                  Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: fromField),
                  Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: toField),
                  Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: levelField),
                  buttons,
                ],
              );
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                periodDropdown,
                const SizedBox(height: 10),
                Row(children: fields),
                const SizedBox(height: 10),
                buttons,
              ],
            );
          },
        ),
      ),
    );
  }

  Widget journalFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final compact = constraints.maxWidth < 760;
            final periodDropdown = DropdownButtonFormField<int?>(
              initialValue: selectedJournalPeriodId,
              decoration: const InputDecoration(
                labelText: 'الفترة المالية',
                prefixIcon: Icon(Icons.event_available_outlined),
              ),
              items: [
                const DropdownMenuItem<int?>(
                  value: null,
                  child: Text('بدون فترة محددة'),
                ),
                ...accountingPeriods.map((raw) {
                  final period = Map<String, dynamic>.from(raw as Map);
                  final idRaw = period['id'];
                  final id = idRaw is int ? idRaw : int.tryParse('$idRaw');
                  return DropdownMenuItem<int?>(
                    value: id,
                    child: Text(accountingPeriodLabel(period)),
                  );
                }),
              ],
              onChanged: (value) async {
                setState(() {
                  selectedJournalPeriodId = value;
                  if (value != null) {
                    journalFromDateController.clear();
                    journalToDateController.clear();
                  }
                });
                await loadReports();
              },
            );

            final fromField = TextFormField(
              controller: journalFromDateController,
              enabled: selectedJournalPeriodId == null,
              readOnly: true,
              decoration: InputDecoration(
                labelText: 'من تاريخ',
                suffixIcon: IconButton(
                  onPressed: () => pickJournalDate(journalFromDateController),
                  icon: const Icon(Icons.calendar_today_outlined),
                ),
              ),
            );
            final toField = TextFormField(
              controller: journalToDateController,
              enabled: selectedJournalPeriodId == null,
              readOnly: true,
              decoration: InputDecoration(
                labelText: 'إلى تاريخ',
                suffixIcon: IconButton(
                  onPressed: () => pickJournalDate(journalToDateController),
                  icon: const Icon(Icons.event_outlined),
                ),
              ),
            );
            final statusField = DropdownButtonFormField<String>(
              initialValue: journalStatusFilter,
              decoration: const InputDecoration(labelText: 'حالة القيد'),
              items: const [
                DropdownMenuItem(value: 'all', child: Text('كل الحالات')),
                DropdownMenuItem(value: 'posted', child: Text('مرحل')),
                DropdownMenuItem(value: 'draft', child: Text('مسودة')),
              ],
              onChanged: (value) async {
                if (value == null) return;
                setState(() => journalStatusFilter = value);
                await loadReports();
              },
            );
            final buttons = Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  onPressed: () async {
                    journalFromDateController.clear();
                    journalToDateController.clear();
                    setState(() {
                      selectedJournalPeriodId = null;
                      journalStatusFilter = 'posted';
                    });
                    await loadReports();
                  },
                  icon: const Icon(Icons.clear),
                  label: const Text('مسح الفلاتر'),
                ),
                FilledButton.icon(
                  onPressed: loadReports,
                  icon: const Icon(Icons.refresh),
                  label: const Text('تحديث الدفتر'),
                ),
              ],
            );

            if (compact) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  periodDropdown,
                  const SizedBox(height: 8),
                  fromField,
                  const SizedBox(height: 8),
                  toField,
                  const SizedBox(height: 8),
                  statusField,
                  const SizedBox(height: 10),
                  buttons,
                ],
              );
            }

            return Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                periodDropdown,
                const SizedBox(height: 10),
                Row(
                  children: [
                    Expanded(child: fromField),
                    const SizedBox(width: 8),
                    Expanded(child: toField),
                    const SizedBox(width: 8),
                    Expanded(child: statusField),
                  ],
                ),
                const SizedBox(height: 10),
                buttons,
              ],
            );
          },
        ),
      ),
    );
  }

  Widget trialBalanceView() {
    final rows = (trialBalance['rows'] as List?) ?? [];
    final totals =
        Map<String, dynamic>.from((trialBalance['totals'] as Map?) ?? {});
    final balanced = trialBalance['is_balanced'] == true;

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        trialBalanceFilters(),
        const SizedBox(height: 10),
        cardsGrid([
          summaryCard('إجمالي المدين', totals['total_debit'], Icons.south_west,
              color: const Color(0xFF2F7D57)),
          summaryCard('إجمالي الدائن', totals['total_credit'], Icons.north_east,
              color: AlshaariColors.copper),
          summaryCard('حالة الميزان', balanced ? 'متوازن' : 'غير متوازن',
              balanced ? Icons.verified : Icons.warning_amber,
              color:
                  balanced ? const Color(0xFF2F7D57) : AlshaariColors.copper),
        ]),
        const SizedBox(height: 10),
        printButton('طباعة ميزان المراجعة',
            () => printReport('ميزان المراجعة', trialBalanceHtml())),
        const SizedBox(height: 14),
        Card(
          color: AlshaariColors.copper.withOpacity(.08),
          child: ListTile(
            leading: ledgerLoading
                ? const CircularProgressIndicator()
                : const Icon(Icons.touch_app),
            title: const Text('اضغط على كود الحساب أو اسمه لعرض كشف الحساب'),
            subtitle: const Text(
              'سيتم تطبيق نفس فترة ميزان المراجعة على كشف الحساب تلقائيًا.',
            ),
          ),
        ),
        const SizedBox(height: 10),
        if (rows.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد قيود مرحلة')))
        else
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              columns: const [
                DataColumn(label: Text('الكود')),
                DataColumn(label: Text('الحساب')),
                DataColumn(label: Text('المستوى')),
                DataColumn(label: Text('مدين')),
                DataColumn(label: Text('دائن')),
                DataColumn(label: Text('الرصيد')),
              ],
              rows: rows.map((raw) {
                final row = Map<String, dynamic>.from(raw as Map);
                return DataRow(cells: [
                  DataCell(
                    Text(
                      '${row['account_code'] ?? ''}',
                      style: const TextStyle(
                        color: AlshaariColors.copper,
                        fontWeight: FontWeight.w900,
                      ),
                    ),
                    onTap: () => loadLedgerForAccount(row),
                  ),
                  DataCell(
                    Text(
                      '${row['account_name'] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w800),
                    ),
                    onTap: () => loadLedgerForAccount(row),
                  ),
                  DataCell(Text('${row['account_level'] ?? ''}')),
                  DataCell(Text(money(row['total_debit']))),
                  DataCell(Text(money(row['total_credit']))),
                  DataCell(Text(money(row['balance']))),
                ]);
              }).toList(),
            ),
          ),
      ],
    );
  }

  Widget journalEntriesView() {
    final totalDebit = journalEntries.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + (double.tryParse('${row['total_debit'] ?? 0}') ?? 0);
    });
    final totalCredit = journalEntries.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + (double.tryParse('${row['total_credit'] ?? 0}') ?? 0);
    });

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        journalFilters(),
        const SizedBox(height: 10),
        cardsGrid([
          summaryCard('عدد القيود', journalEntries.length, Icons.receipt_long,
              color: AlshaariColors.copper),
          summaryCard(
              'إجمالي المدين', totalDebit.toStringAsFixed(2), Icons.south_west,
              color: const Color(0xFF2F7D57)),
          summaryCard(
              'إجمالي الدائن', totalCredit.toStringAsFixed(2), Icons.north_east,
              color: AlshaariColors.deepGreen),
        ]),
        const SizedBox(height: 10),
        printButton('طباعة دفتر اليومية',
            () => printReport('دفتر اليومية', journalEntriesHtml())),
        const SizedBox(height: 14),
        if (journalEntries.isEmpty)
          const Card(
              child: ListTile(title: Text('لا توجد قيود مطابقة للفلاتر')))
        else
          ...journalEntries.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.receipt_long,
                            color: AlshaariColors.copper),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${row['entry_no'] ?? '#${row['id']}'}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Chip(label: Text('${row['status'] ?? '-'}')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text('التاريخ: ${row['entry_date'] ?? '-'}'),
                    Text(
                        'المصدر: ${row['source_type'] ?? '-'} #${row['source_id'] ?? '-'}'),
                    if ('${row['description'] ?? ''}'.trim().isNotEmpty)
                      Text('البيان: ${row['description']}'),
                    const Divider(height: 20),
                    _ReportLine('إجمالي المدين', row['total_debit']),
                    _ReportLine('إجمالي الدائن', row['total_credit']),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget profitLossView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        cardsGrid([
          summaryCard('الإيرادات', profitLoss['revenues'], Icons.trending_up,
              color: const Color(0xFF2F7D57)),
          summaryCard('المصروفات', profitLoss['expenses'], Icons.trending_down,
              color: AlshaariColors.copper),
          summaryCard('صافي الربح', profitLoss['net_profit'],
              Icons.account_balance_wallet_outlined,
              color: AlshaariColors.deepGreen),
        ]),
        const SizedBox(height: 10),
        printButton(
          'طباعة الأرباح والخسائر',
          () => printReport(
            'تقرير الأرباح والخسائر',
            simpleReportHtml(
              'تقرير الأرباح والخسائر',
              [
                MapEntry('الإيرادات', profitLoss['revenues']),
                MapEntry('المصروفات', profitLoss['expenses']),
                MapEntry('صافي الربح', profitLoss['net_profit']),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget cashFlowView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        cardsGrid([
          summaryCard(
              'التدفقات الداخلة', cashFlow['cash_inflow'], Icons.call_received,
              color: const Color(0xFF2F7D57)),
          summaryCard(
              'التدفقات الخارجة', cashFlow['cash_outflow'], Icons.call_made,
              color: AlshaariColors.copper),
          summaryCard('صافي التدفق النقدي', cashFlow['net_cash_flow'],
              Icons.payments_outlined,
              color: AlshaariColors.deepGreen),
        ]),
        const SizedBox(height: 10),
        printButton(
          'طباعة التدفق النقدي',
          () => printReport(
            'تقرير التدفق النقدي',
            simpleReportHtml(
              'تقرير التدفق النقدي',
              [
                MapEntry('التدفقات الداخلة', cashFlow['cash_inflow']),
                MapEntry('التدفقات الخارجة', cashFlow['cash_outflow']),
                MapEntry('صافي التدفق النقدي', cashFlow['net_cash_flow']),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget projectsView() {
    final totalOverBudgetVariance =
        overBudgetProjects.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['cost_variance']);
    });
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        printButton('طباعة ربحية المشاريع',
            () => printReport('ربحية المشاريع', projectsHtml())),
        const SizedBox(height: 12),
        Card(
          color: overBudgetProjects.isEmpty
              ? const Color(0xFFEFF8F1)
              : const Color(0xFFFFF7ED),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Icon(
                      overBudgetProjects.isEmpty
                          ? Icons.verified_outlined
                          : Icons.warning_amber_rounded,
                      color: overBudgetProjects.isEmpty
                          ? const Color(0xFF2F7D57)
                          : const Color(0xFFC77800),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: Text(
                        overBudgetProjects.isEmpty
                            ? 'لا توجد مشاريع متجاوزة للتكلفة'
                            : 'مشاريع تجاوزت التكلفة المقدرة',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ),
                    Text(
                      '${overBudgetProjects.length}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
                if (overBudgetProjects.isNotEmpty) ...[
                  const SizedBox(height: 10),
                  _ReportLine(
                    'إجمالي الانحراف',
                    totalOverBudgetVariance.toStringAsFixed(2),
                  ),
                  const Divider(height: 20),
                  ...overBudgetProjects.take(5).map((raw) {
                    final row = Map<String, dynamic>.from(raw as Map);
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            '${row['project_code'] ?? ''} - ${row['project_name'] ?? ''}',
                            style: const TextStyle(fontWeight: FontWeight.w800),
                          ),
                          _ReportLine(
                            'التكلفة المقدرة',
                            row['estimated_total_cost'],
                          ),
                          _ReportLine(
                            'التكلفة الفعلية',
                            row['actual_total_cost'],
                          ),
                          _ReportLine('الانحراف', row['cost_variance']),
                        ],
                      ),
                    );
                  }),
                  if (overBudgetProjects.length > 5)
                    Text(
                      'يوجد ${overBudgetProjects.length - 5} مشروع إضافي في تقرير الطباعة.',
                      style: TextStyle(color: Colors.grey.shade700),
                    ),
                ],
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (projects.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد مشاريع')))
        else
          ...projects.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '${row['project_code'] ?? ''} - ${row['project_name'] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const Divider(height: 20),
                    _ReportLine('قيمة العقد', row['contract_value']),
                    _ReportLine('التحصيل', row['collected']),
                    _ReportLine('التكلفة', row['total_cost']),
                    _ReportLine('صافي الربح', row['net_profit']),
                    _ReportLine(
                        'هامش الربح', '${row['profit_margin_percent'] ?? 0}%'),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget costCentersView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        printButton('طباعة تقرير مراكز التكلفة',
            () => printReport('تقرير مراكز التكلفة', costCentersHtml())),
        const SizedBox(height: 12),
        if (costCenterReport.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد مراكز تكلفة')))
        else
          ...costCenterReport.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.account_tree_outlined),
                title: Text('${row['code'] ?? ''} - ${row['name'] ?? ''}'),
                subtitle: Text(
                  'النوع: ${row['type'] ?? '-'} | ${row['is_postable'] == false ? 'تجميعي' : 'قابل للترحيل'} | '
                  'طريقة التحميل: ${row['allocation_method'] ?? '-'} | '
                  'تكاليف المشاريع مع الأبناء: ${row['project_costs_with_children'] ?? 0}',
                ),
                trailing: Text('${row['total_with_children'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
      ],
    );
  }

  Widget workerAdvancesView() {
    final totalOpen = workerAdvancesReport.fold<double>(
      0,
      (sum, raw) =>
          sum +
          ((Map<String, dynamic>.from(raw as Map)['open_balance'] as num?)
                  ?.toDouble() ??
              0),
    );

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        cardsGrid([
          summaryCard(
              'عدد العمال', workerAdvancesReport.length, Icons.groups_outlined,
              color: AlshaariColors.deepGreen),
          summaryCard('الرصيد المفتوح', '$totalOpen YER',
              Icons.assignment_late_outlined,
              color: const Color(0xFFE08A2E)),
        ]),
        const SizedBox(height: 10),
        printButton('طباعة تقرير السلف والعهد',
            () => printReport('تقرير السلف والعهد', workerAdvancesHtml())),
        const SizedBox(height: 12),
        if (workerAdvancesReport.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد سلف أو عهد مفتوحة')))
        else
          ...workerAdvancesReport.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            final high = row['risk_level'] == 'high';
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.assignment_ind_outlined),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${row['worker_name'] ?? 'عامل'}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Chip(
                          label: Text(high ? 'رصيد مرتفع' : 'طبيعي'),
                          backgroundColor: (high
                                  ? AlshaariColors.copper
                                  : const Color(0xFF2F7D57))
                              .withOpacity(.12),
                          labelStyle: TextStyle(
                              color: high
                                  ? AlshaariColors.copper
                                  : const Color(0xFF2F7D57)),
                        ),
                      ],
                    ),
                    const Divider(height: 20),
                    _ReportLine('إجمالي السلف المصروفة', row['total_advances']),
                    _ReportLine('إجمالي التسويات', row['total_settlements']),
                    _ReportLine('الرصيد المفتوح', row['open_balance']),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget costCenterExpensesView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        printButton(
            'طباعة مصروفات مراكز التكلفة',
            () =>
                printReport('مصروفات مراكز التكلفة', costCenterExpensesHtml())),
        const SizedBox(height: 12),
        if (costCenterExpensesReport.isEmpty)
          const Card(
              child: ListTile(title: Text('لا توجد مصروفات مراكز تكلفة')))
        else
          ...costCenterExpensesReport.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(
                      '${row['code'] ?? ''} - ${row['name'] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 6),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        Chip(label: Text('النوع: ${row['type'] ?? '-'}')),
                        Chip(
                            label: Text(
                                'المشاريع: ${row['linked_projects'] ?? 0}')),
                        Chip(
                            label: Text(
                                'النسبة: ${row['cost_share_percent'] ?? 0}%')),
                      ],
                    ),
                    const Divider(height: 20),
                    _ReportLine('إجمالي المدين', row['total_debit']),
                    _ReportLine('إجمالي الدائن', row['total_credit']),
                    _ReportLine('صافي التكلفة', row['net_cost']),
                  ],
                ),
              ),
            );
          }),
      ],
    );
  }

  Widget agingCard(Map<String, dynamic> row, String nameKey, IconData icon) {
    final partyType = nameKey == 'customer' ? 'customer' : 'supplier';
    final idKey = nameKey == 'customer' ? 'customer_id' : 'supplier_id';
    final partyId = row[idKey];
    final risk = '${row['risk_level'] ?? 'normal'}';
    final riskColor = risk == 'high'
        ? const Color(0xFFC43D32)
        : risk == 'medium'
            ? const Color(0xFFE08A2E)
            : const Color(0xFF2F7D57);

    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: partyId == null
            ? null
            : () => context.go('/statements?type=$partyType&id=$partyId'),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  Icon(icon, color: AlshaariColors.copper),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      '${row[nameKey] ?? '-'}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                  ),
                  Chip(
                    label: Text(risk == 'high'
                        ? 'مرتفع'
                        : risk == 'medium'
                            ? 'متوسط'
                            : 'طبيعي'),
                    backgroundColor: riskColor.withOpacity(.12),
                    labelStyle: TextStyle(color: riskColor),
                  ),
                ],
              ),
              const Divider(height: 20),
              _ReportLine('حالي', row['current']),
              _ReportLine('1 - 30 يوم', row['days_1_30']),
              _ReportLine('31 - 60 يوم', row['days_31_60']),
              _ReportLine('61 - 90 يوم', row['days_61_90']),
              _ReportLine('أكثر من 90 يوم', row['days_over_90']),
              const Divider(height: 18),
              _ReportLine('الإجمالي المستحق', row['total']),
              const SizedBox(height: 8),
              Align(
                alignment: Alignment.centerLeft,
                child: TextButton.icon(
                  onPressed: partyId == null
                      ? null
                      : () =>
                          context.go('/statements?type=$partyType&id=$partyId'),
                  icon: const Icon(Icons.open_in_new),
                  label: const Text('فتح كشف الحساب'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget agingSection(
    String title,
    List<dynamic> rows,
    String nameKey,
    IconData icon,
    String emptyText,
  ) {
    final total = rows.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['total']);
    });
    final highRisk = rows.where((raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return row['risk_level'] == 'high';
    }).length;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w900,
            color: AlshaariColors.ink,
          ),
        ),
        const SizedBox(height: 10),
        cardsGrid([
          summaryCard('عدد الحسابات', rows.length, icon,
              color: AlshaariColors.copper),
          summaryCard('الإجمالي', total.toStringAsFixed(2),
              Icons.account_balance_wallet_outlined,
              color: AlshaariColors.deepGreen),
          summaryCard('مخاطر عالية', highRisk, Icons.warning_amber,
              color: const Color(0xFFE08A2E)),
        ]),
        const SizedBox(height: 10),
        if (rows.isEmpty)
          Card(child: ListTile(title: Text(emptyText)))
        else
          ...rows.map((raw) =>
              agingCard(Map<String, dynamic>.from(raw as Map), nameKey, icon)),
      ],
    );
  }

  Widget agingView() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        printButton(
          'طباعة أعمار الذمم',
          () => printReport('أعمار الذمم', agingHtml()),
        ),
        const SizedBox(height: 12),
        agingSection(
          'أعمار ذمم العملاء',
          customerAgingReport,
          'customer',
          Icons.people_alt_outlined,
          'لا توجد ذمم مدينة مفتوحة.',
        ),
        const SizedBox(height: 18),
        agingSection(
          'أعمار ذمم الموردين',
          supplierAgingReport,
          'supplier',
          Icons.local_shipping_outlined,
          'لا توجد ذمم دائنة مفتوحة.',
        ),
      ],
    );
  }

  Widget purchaseInventoryView() {
    final inventoryValue = inventoryBalanceReport.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['stock_value']);
    });
    final projectMaterials =
        projectMaterialCostsReport.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['total_cost']);
    });
    final directPurchases =
        directProjectPurchasesReport.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['amount']);
    });
    final grniTotal = grniReport.fold<double>(0, (sum, raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return sum + numericValue(row['estimated_amount']);
    });

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        cardsGrid([
          summaryCard('فواتير الموردين', purchaseSummary['approved_invoices'],
              Icons.receipt_long,
              color: AlshaariColors.copper),
          summaryCard('دفعات الموردين', purchaseSummary['approved_payments'],
              Icons.payments_outlined,
              color: AlshaariColors.deepGreen),
          summaryCard('أوامر مفتوحة', purchaseSummary['open_purchase_orders'],
              Icons.shopping_cart_checkout,
              color: const Color(0xFFE08A2E)),
          summaryCard('قيمة المخزون', inventoryValue.toStringAsFixed(2),
              Icons.inventory_2_outlined,
              color: AlshaariColors.walnut),
          summaryCard('مواد المشاريع', projectMaterials.toStringAsFixed(2),
              Icons.construction_outlined,
              color: AlshaariColors.copper),
          summaryCard('GRNI غير مفوتر', grniTotal.toStringAsFixed(2),
              Icons.assignment_late_outlined,
              color: const Color(0xFFE08A2E)),
        ]),
        const SizedBox(height: 10),
        printButton(
          'طباعة المشتريات والمخزون',
          () =>
              printReport('تقرير المشتريات والمخزون', purchaseInventoryHtml()),
        ),
        const SizedBox(height: 12),
        sectionTitle('أوامر الشراء المفتوحة'),
        if (openPurchaseOrders.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد أوامر شراء مفتوحة')))
        else
          ...openPurchaseOrders.take(10).map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.shopping_cart_checkout,
                    color: AlshaariColors.copper),
                title: Text('${row['po_no'] ?? '-'}'),
                subtitle: Text(
                    'الحالة: ${row['status'] ?? '-'} | المورد #${row['supplier_id'] ?? '-'}'),
                trailing: Text('${row['total'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
        const SizedBox(height: 12),
        sectionTitle('GRNI - استلامات غير مفوترة'),
        if (grniReport.isEmpty)
          const Card(
              child: ListTile(title: Text('لا توجد استلامات غير مفوترة')))
        else
          ...grniReport.take(10).map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.inventory_outlined,
                    color: AlshaariColors.copper),
                title: Text('${row['grn_no'] ?? '-'}'),
                subtitle: Text(
                    'المورد #${row['supplier_id'] ?? '-'} | التاريخ: ${row['date'] ?? '-'}'),
                trailing: Text('${row['estimated_amount'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
        const SizedBox(height: 12),
        sectionTitle('رصيد المخزون'),
        if (inventoryBalanceReport.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد أرصدة مخزون')))
        else
          ...inventoryBalanceReport.take(12).map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text('${row['code'] ?? ''} - ${row['name'] ?? ''}',
                        style: const TextStyle(fontWeight: FontWeight.w900)),
                    const Divider(height: 20),
                    _ReportLine('الكمية الحالية', row['current_qty']),
                    _ReportLine('الكمية المحجوزة', row['reserved_qty']),
                    _ReportLine('الصافي المتاح', row['available_qty']),
                    _ReportLine('قيمة المخزون', row['stock_value']),
                  ],
                ),
              ),
            );
          }),
        const SizedBox(height: 12),
        sectionTitle('مواد المشاريع والشراء المباشر'),
        cardsGrid([
          summaryCard('إجمالي مواد المشاريع',
              projectMaterials.toStringAsFixed(2), Icons.construction_outlined,
              color: AlshaariColors.deepGreen),
          summaryCard('الشراء المباشر', directPurchases.toStringAsFixed(2),
              Icons.receipt_outlined,
              color: AlshaariColors.copper),
        ]),
        if (projectMaterialCostsReport.isEmpty)
          const Card(
              child: ListTile(title: Text('لا توجد مواد محملة على المشاريع')))
        else
          ...projectMaterialCostsReport.take(12).map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.work_outline,
                    color: AlshaariColors.copper),
                title: Text('${row['project_name'] ?? '-'}'),
                subtitle: Text(
                    '${row['item_name'] ?? '-'} | ${row['movement_type'] ?? '-'}'),
                trailing: Text('${row['total_cost'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
      ],
    );
  }

  Widget sectionTitle(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 18,
          fontWeight: FontWeight.w900,
          color: AlshaariColors.ink,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('التقارير المالية'),
            ],
          ),
          actions: [
            IconButton(onPressed: loadReports, icon: const Icon(Icons.refresh)),
          ],
          bottom: TabBar(
            controller: controller,
            isScrollable: true,
            tabs: const [
              Tab(icon: Icon(Icons.balance), text: 'ميزان المراجعة'),
              Tab(icon: Icon(Icons.receipt_long), text: 'دفتر اليومية'),
              Tab(icon: Icon(Icons.show_chart), text: 'الأرباح والخسائر'),
              Tab(icon: Icon(Icons.payments_outlined), text: 'التدفق النقدي'),
              Tab(icon: Icon(Icons.work_outline), text: 'ربحية المشاريع'),
              Tab(
                  icon: Icon(Icons.account_tree_outlined),
                  text: 'مراكز التكلفة'),
              Tab(
                  icon: Icon(Icons.assignment_ind_outlined),
                  text: 'السلف والعهد'),
              Tab(
                  icon: Icon(Icons.analytics_outlined),
                  text: 'مصروفات المراكز'),
              Tab(icon: Icon(Icons.schedule_outlined), text: 'أعمار الذمم'),
              Tab(
                  icon: Icon(Icons.inventory_2_outlined),
                  text: 'المشتريات والمخزون'),
            ],
          ),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                controller: controller,
                children: [
                  trialBalanceView(),
                  journalEntriesView(),
                  profitLossView(),
                  cashFlowView(),
                  projectsView(),
                  costCentersView(),
                  workerAdvancesView(),
                  costCenterExpensesView(),
                  agingView(),
                  purchaseInventoryView(),
                ],
              ),
      ),
    );
  }
}

class _ReportLine extends StatelessWidget {
  final String label;
  final dynamic value;

  const _ReportLine(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(
              child: Text(label, style: Theme.of(context).textTheme.bodySmall)),
          Text('$value', style: const TextStyle(fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}
