﻿from fastapi import FastAPI
from app.api.v1.operation_policies import router as operation_policies_router
from app.api.v1.accounting import router as accounting_router
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from sqlalchemy import text
import os
from app.db.database import SessionLocal
from app.services.accounting_defaults import ensure_accounting_defaults
from app.services.cost_center_schema import ensure_cost_center_schema
from app.services.adjustment_schema import ensure_adjustment_schema
from app.services.purchase_schema import ensure_purchase_schema
from app.services.inventory_schema import ensure_inventory_schema
from app.services.accounting_periods import ensure_accounting_period_schema
from app.services.payroll_schema import ensure_payroll_schema
from app.services.document_sequence import ensure_document_sequence_schema
from app.services.offline_sync_schema import ensure_offline_sync_schema
from app.services.project_costing import ensure_project_costing_schema

# Legacy routers kept for current Flutter screens and Swagger compatibility.
from app.api.auth import router as auth_router
from app.api.basic import router as basic_router
from app.api.transactions import router as transactions_router
from app.api.reports import router as reports_router
from app.api.uploads import router as uploads_router

# V3 API routers.
from app.api.v1.auth import router as v1_auth_router
from app.api.v1.basic import router as v1_basic_router
from app.api.v1.transactions import router as v1_transactions_router
from app.api.v1.documents import router as v1_documents_router
from app.api.v1.dashboard import router as v1_dashboard_router
from app.api.v1.reports import router as v1_reports_router
from app.api.v1.go_live import router as v1_go_live_router
from app.api.v1.document_sequences import router as v1_document_sequences_router
from app.api.v1.invoices import router as v1_invoices_router
from app.api.v1.access_control import router as v1_access_control_router
from app.api.v1.audit import router as v1_audit_router
from app.api.v1.inventory import router as v1_inventory_router
from app.api.v1.production import router as v1_production_router
from app.api.v1.projects import router as v1_projects_router
from app.api.v1.settings import router as v1_settings_router
from app.api.v1.adjustment_vouchers import router as v1_adjustment_vouchers_router
from app.api.v1.settlement_vouchers import router as v1_settlement_vouchers_router
from app.api.v1.purchases import router as v1_purchases_router
from app.api.v1.settlements import router as v1_settlements_router
from app.api.v1.accounting_periods import router as v1_accounting_periods_router
from app.api.v1.payroll import router as v1_payroll_router
from app.api.v1.devices import router as v1_devices_router
from app.api.v1.sync import router as v1_sync_router

load_dotenv()

app = FastAPI(title="نظام الشعري المالي API", version="0.3.0")


@app.on_event("startup")
def startup_accounting_defaults():
    db = SessionLocal()
    try:
        ensure_accounting_defaults(db)
        ensure_document_sequence_schema(db)
        ensure_cost_center_schema(db)
        ensure_adjustment_schema(db)
        ensure_purchase_schema(db)
        ensure_inventory_schema(db)
        ensure_accounting_period_schema(db)
        ensure_payroll_schema(db)
        ensure_offline_sync_schema(db)
        ensure_project_costing_schema(db)
    finally:
        db.close()

allowed_origins = [
    origin.strip()
    for origin in os.getenv(
        "ALLOWED_ORIGINS",
        "http://localhost:3000,http://localhost:8000,http://localhost:8080",
    ).split(",")
    if origin.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_origin_regex=os.getenv(
        "ALLOWED_ORIGIN_REGEX",
        r"http://(localhost|127\.0\.0\.1|192\.168\.[0-9]{1,3}\.[0-9]{1,3}|10\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}|172\.(1[6-9]|2[0-9]|3[0-1])\.[0-9]{1,3}\.[0-9]{1,3}):[0-9]+",
    ),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Current/legacy endpoints.
app.include_router(auth_router)
app.include_router(basic_router)
app.include_router(transactions_router)
app.include_router(reports_router)
app.include_router(uploads_router)

# Structured API v1 endpoints.
app.include_router(v1_auth_router)
app.include_router(v1_basic_router)
app.include_router(v1_transactions_router)
app.include_router(v1_documents_router)
app.include_router(v1_dashboard_router)
app.include_router(accounting_router)
app.include_router(v1_reports_router)
app.include_router(v1_go_live_router)
app.include_router(v1_document_sequences_router)
app.include_router(v1_invoices_router)
app.include_router(v1_access_control_router)
app.include_router(v1_audit_router)
app.include_router(v1_inventory_router)
app.include_router(v1_production_router)
app.include_router(v1_projects_router)
app.include_router(v1_settings_router)
app.include_router(v1_adjustment_vouchers_router)
app.include_router(v1_settlement_vouchers_router)
app.include_router(v1_purchases_router)
app.include_router(v1_settlements_router)
app.include_router(v1_accounting_periods_router)
app.include_router(v1_payroll_router)
app.include_router(v1_devices_router)
app.include_router(v1_sync_router)

@app.get("/")
def root():
    return {"message": "نظام الشعري المالي يعمل بنجاح", "version": "0.3.0"}

@app.get("/ready")
def ready():
    db = SessionLocal()
    try:
        db.execute(text("SELECT 1"))
        return {"status": "ready", "database": "ok"}
    finally:
        db.close()
@app.get("/health")
def health():
    return {
        "status": "ok",
        "service": "Alshaari Finance & Projects",
        "offline_sync": "enabled",
        "version": "0.3.0",
    }

app.include_router(operation_policies_router)



