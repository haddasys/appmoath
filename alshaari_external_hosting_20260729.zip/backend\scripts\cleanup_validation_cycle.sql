BEGIN;

-- Cleanup only the validation cycle created during system testing.
-- Project: 3, customer: 2, supplier: 2, worker: 3, item: 27, transactions: 20-23.

UPDATE accounts
SET balance = balance - 155000
WHERE code = '10101';

DELETE FROM journal_entry_lines
WHERE journal_entry_id IN (
    SELECT id
    FROM journal_entries
    WHERE source_type = 'transaction'
      AND source_id IN (20, 21, 22, 23)
);

DELETE FROM journal_entries
WHERE source_type = 'transaction'
  AND source_id IN (20, 21, 22, 23);

DELETE FROM project_costs
WHERE source_type = 'transaction'
  AND source_id IN (20, 21, 22, 23);

DELETE FROM stock_movements
WHERE transaction_id IN (20, 21, 22, 23);

DELETE FROM audit_logs
WHERE entity = 'transaction'
  AND entity_id IN (20, 21, 22, 23);

DELETE FROM transactions
WHERE id IN (20, 21, 22, 23);

DELETE FROM projects
WHERE id = 3
  AND project_code = 'ASH-PRJ-2026-0003';

DELETE FROM items
WHERE id = 27
  AND code = 'MDF-20260509170001';

DELETE FROM workers
WHERE id = 3;

DELETE FROM suppliers
WHERE id = 2;

DELETE FROM customers
WHERE id = 2;

COMMIT;
