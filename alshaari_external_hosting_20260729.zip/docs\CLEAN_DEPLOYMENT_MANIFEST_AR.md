# ملف تصفية النشر

تاريخ المراجعة: 2026-07-11

## الهدف

تجهيز المشروع للنشر التجريبي دون حذف أي بيانات من الجهاز، وذلك بعزل الملفات المحلية والمولدة والحساسة عن Git وعن حزمة النشر.

## يدخل في النشر

- `backend/app/`
- `backend/requirements.txt`
- `backend/Dockerfile`
- `backend/.dockerignore`
- `backend/scripts/` فقط للسكريبتات الضرورية غير المدمرة
- `mobile/lib/`
- `mobile/assets/`
- `mobile/android/`
- `mobile/pubspec.yaml`
- `docs/` للوثائق التشغيلية

## لا يدخل في النشر

- `.env` و`.env.*`
- `backend/alshaari.db`
- `backend/venv/`
- `mobile/build/`
- `mobile/.dart_tool/`
- `dist/`
- `backups/`
- `backup_before_v2_*/`
- `android-sdk/`
- `jdk/`
- `.idea/`
- ملفات logs
- ملفات keystore أو key.properties
- نسخ upgrade المؤقتة:
  - `alshaari-finance-projects/`
  - `alshaari_v2_upgrade/`
  - `alshaari_v3_upgrade/`

## ملاحظات مراجعة الحجم

أكبر الملفات داخل المشروع حاليًا ناتجة من:

- Flutter build outputs.
- Android intermediate native libs.
- `.dart_tool`.
- Python virtual environment.
- APK debug قديم.

هذه ليست جزءًا من كود النظام ولا يجب رفعها للسيرفر.

## حالة Git الحالية

- الفرع الحالي: `deploy/google-cloud`.
- لا توجد commits سابقة.
- توجد ملفات كثيرة غير متتبعة.
- لا ينصح بعمل commit شامل قبل مراجعة staged/untracked source-only.

## أوامر فحص قبل أي رفع

```powershell
git status --short
git check-ignore -v backend/.env backend/alshaari.db mobile/build dist backups
```

## أمر فحص جاهزية Backend

```powershell
cd backend
.\venv\Scripts\python.exe scripts\readiness_check.py
```
