import 'package:flutter/material.dart';

import '../features/adjustments/presentation/adjustment_voucher_screen.dart';
import '../features/dashboard/presentation/dashboard_screen.dart';
import '../features/purchases/presentation/purchase_cycle_screen.dart';
import '../features/transactions/presentation/transaction_form_screen.dart';

/// Legacy Navigator routes kept for compatibility with older entry points.
///
/// The active app uses GoRouter in `router.dart`; these aliases prevent stale
/// imports from breaking analysis while routing users to the current screens.
final Map<String, WidgetBuilder> appRoutes = {
  '/': (ctx) => const DashboardScreen(),
  '/dashboard': (ctx) => const DashboardScreen(),
  '/documents/new': (ctx) => const TransactionFormScreen(),
  '/transactions/new': (ctx) => const TransactionFormScreen(),
  '/purchase-requests': (ctx) => const PurchaseCycleScreen(),
  '/purchase-requests/new': (ctx) => const PurchaseCycleScreen(),
  '/supplier-invoices': (ctx) => const PurchaseCycleScreen(),
  '/settlement-vouchers': (ctx) => const AdjustmentVoucherScreen(),
  '/cash-transfers': (ctx) => const TransactionFormScreen(
        initialType: 'cash_transfer',
      ),
};
