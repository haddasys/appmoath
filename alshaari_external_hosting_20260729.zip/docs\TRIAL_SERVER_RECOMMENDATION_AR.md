# توصية السيرفر التجريبي المجاني

تاريخ المراجعة: 2026-07-11

## القرار المختصر

الخيار الأنسب للتجربة المجانية الحالية هو:

1. Backend FastAPI على Render Free Web Service.
2. قاعدة البيانات PostgreSQL على Supabase Free.
3. Flutter Web يمكن نشره كملفات Static لاحقًا، أو بناء APK مع `API_BASE_URL` يشير إلى رابط Render.

هذا الاختيار مناسب الآن لأن مشروع Google Cloud الموجود `alshaari-lean-erp` لا يوجد عليه Billing مفعّل، وبالتالي لا يصلح للنشر العملي على Cloud Run/Cloud SQL قبل تفعيل Billing.

## لماذا ليس Google Cloud الآن؟

- الحساب والمشروع موجودان، لكن Billing غير مفعّل.
- Cloud Run لديه Free Tier، لكن نشر Cloud Run وCloud Build وArtifact Registry يحتاج مشروعًا مفعّل الفوترة عمليًا.
- Cloud SQL ليس خدمة مجانية دائمة، ويوجد Trial/credits فقط حسب الأهلية.
- لذلك Google Cloud ممتاز للإنتاج لاحقًا، لكنه ليس أسرع مسار مجاني للتجربة الآن.

## لماذا Render + Supabase؟

### Render

- مناسب لتشغيل FastAPI بسرعة.
- يدعم HTTPS تلقائيًا.
- مناسب كرابط Backend للتطبيق على الجوال.

ملاحظة: Render Postgres المجاني محدود كخيار تجريبي، لذلك أفضل استخدام Supabase للقاعدة في التجربة.

### Supabase

- يوفر PostgreSQL مجانيًا.
- Free plan يتضمن 500MB database و1GB file storage.
- مناسب لتجربة النظام ببيانات محدودة.

قيوده المهمة:

- لا توجد backups تلقائية في الخطة المجانية.
- المشروع قد يتوقف بعد أسبوع من عدم النشاط.
- لا يصلح كبيئة إنتاج مالية حقيقية دون خطة مدفوعة ونسخ احتياطي.

## التوصية الفنية

للتجربة:

```text
Flutter APK / Web
        |
        v
Render Free Web Service: FastAPI backend
        |
        v
Supabase Free PostgreSQL
```

للإنتاج لاحقًا:

```text
Flutter APK / Web
        |
        v
Google Cloud Run
        |
        v
Cloud SQL PostgreSQL
```

## حالة التطبيق بعد المراجعة

الجاهزية المحاسبية المحلية جيدة حسب `backend/scripts/readiness_check.py`:

- الجداول المالية الأساسية موجودة.
- ترقيم المستندات موجود.
- الصناديق والمحافظ موجودة.
- القيود متوازنة.
- لا توجد قيود مكررة لنفس المصدر.
- جداول Offline/Sync موجودة.
- جدول الحضور جاهز.

## موانع النشر التي يجب إصلاحها قبل الرفع

1. لا يوجد Alembic migrations رسمي.
2. `DATABASE_URL` يعود إلى SQLite إذا لم يضبط، وهذا خطر في الاستضافة.
3. لا يوجد `/ready` يتحقق من قاعدة البيانات.
4. `deploy_google_cloud_run.ps1` يسمح افتراضيًا بـ `ALLOWED_ORIGINS=*` وهذا غير مناسب.
5. ملفات كثيرة محلية ومولدة موجودة داخل مجلد العمل ويجب عدم رفعها.
6. Android package name لا يزال `com.example.alshaari_finance_app`.

## إعدادات البيئة المقترحة للتجربة

على Render:

```text
APP_ENV=production
DATABASE_URL=postgresql+psycopg://USER:PASSWORD@HOST:5432/postgres
SECRET_KEY=<secret-from-render-env>
ALLOWED_ORIGINS=https://<frontend-domain>
ALLOWED_ORIGIN_REGEX=
ACCESS_TOKEN_EXPIRE_MINUTES=1440
```

أمر التشغيل:

```text
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Build command:

```text
pip install -r requirements.txt
```

Root directory:

```text
backend
```

## خطة التنفيذ التالية

1. إضافة `/ready` وفشل واضح إذا `APP_ENV=production` ولا يوجد `DATABASE_URL` PostgreSQL.
2. تجهيز ملف `render.yaml` اختياريًا بدون أسرار.
3. إنشاء مشروع Supabase Free واستخراج Connection String يدويًا.
4. إنشاء Render Web Service وربط متغيرات البيئة.
5. تشغيل readiness check على السيرفر.
6. بناء APK:

```text
flutter build apk --release --dart-define=API_BASE_URL=https://<render-service>.onrender.com
```

## تنبيه مالي

هذا السيرفر مناسب للتجربة فقط. لا تستخدمه كإنتاج مالي حقيقي دون نسخ احتياطي يومي، مراقبة، صلاحيات قوية، قاعدة بيانات مستقرة، وخطة rollback.
