import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../local_db/local_database.dart';
import '../local_db/local_entities.dart';
import '../local_db/local_record.dart';
import '../network/api_client.dart';
import '../offline_queue/sync_queue_item.dart';
import '../storage/device_identity.dart';
import 'sync_models.dart';

class SyncService {
  final LocalDatabase database;

  const SyncService({required this.database});

  Future<SyncRunSummary> pushPending() async {
    await apiClient.loadToken();
    final pending = await database.pendingQueue();
    if (pending.isEmpty) {
      return const SyncRunSummary(
        attempted: 0,
        synced: 0,
        failed: 0,
        conflict: 0,
      );
    }

    await _markBatchSyncing(pending);

    final attachmentRows =
        pending.where((item) => item.entityType == 'attachment').toList();
    final documentRows =
        pending.where((item) => item.entityType != 'attachment').toList();

    final attachmentSummary = await _pushAttachments(attachmentRows);
    if (documentRows.isEmpty) {
      if (attachmentSummary.synced > 0) {
        final prefs = await SharedPreferences.getInstance();
        await prefs.setInt(
          'alshaari_last_sync_at',
          DateTime.now().millisecondsSinceEpoch,
        );
      }
      return attachmentSummary;
    }

    final deviceId = await deviceIdentity.getOrCreateDeviceId();
    final operations = documentRows.map((item) {
      return {
        'local_uuid': item.localId,
        'entity_type': item.entityType,
        'operation': item.operation,
        'payload': jsonDecode(item.payloadJson),
      };
    }).toList();

    try {
      final response = await apiClient.dio.post(
        '/sync/push',
        data: {
          'device_id': deviceId,
          'operations': operations,
        },
      );
      final results = (response.data['results'] as List? ?? [])
          .map((item) => Map<String, dynamic>.from(item as Map))
          .toList();
      final documentSummary = await _applyResults(documentRows, results);
      return SyncRunSummary(
        attempted: attachmentSummary.attempted + documentSummary.attempted,
        synced: attachmentSummary.synced + documentSummary.synced,
        failed: attachmentSummary.failed + documentSummary.failed,
        conflict: attachmentSummary.conflict + documentSummary.conflict,
      );
    } on DioException catch (error) {
      await _markBatchFailed(documentRows, _connectionMessage(error));
      return SyncRunSummary(
        attempted: pending.length,
        synced: attachmentSummary.synced,
        failed: attachmentSummary.failed + documentRows.length,
        conflict: 0,
      );
    }
  }

  Future<SyncStatusSnapshot> localStatus() async {
    final rows = await database.syncQueue();
    final prefs = await SharedPreferences.getInstance();
    final rawLastSync = prefs.getInt('alshaari_last_sync_at');
    return SyncStatusSnapshot(
      pending: rows.where((item) => item.status == 'pending').length,
      syncing: rows.where((item) => item.status == 'syncing').length,
      failed: rows.where((item) => item.status == 'failed').length,
      conflict: rows.where((item) => item.status == 'conflict').length,
      lastSyncAt: rawLastSync == null
          ? null
          : DateTime.fromMillisecondsSinceEpoch(rawLastSync),
    );
  }

  Future<SyncRunSummary> _applyResults(
    List<SyncQueueItem> pending,
    List<Map<String, dynamic>> results,
  ) async {
    var synced = 0;
    var failed = 0;
    var conflict = 0;
    final byLocalId = {for (final item in pending) item.localId: item};
    final processed = <String>{};
    final now = DateTime.now().millisecondsSinceEpoch;

    for (final result in results) {
      final localUuid = result['local_uuid']?.toString();
      if (localUuid == null) continue;
      processed.add(localUuid);
      final queueItem = byLocalId[localUuid];
      if (queueItem == null) continue;

      final status = result['status']?.toString() ?? 'failed';
      final errorMessage = result['error_message']?.toString();
      final updatedQueueItem = queueItem.copyWith(
        status: status,
        retryCount: status == 'synced'
            ? queueItem.retryCount
            : queueItem.retryCount + 1,
        errorMessage: errorMessage,
        updatedAt: now,
        syncedAt: status == 'synced' ? now : null,
      );
      await database.upsertQueueItem(updatedQueueItem);

      final localRecord = await database.findLocalRecord(localUuid);
      if (localRecord != null) {
        final updatedRecord = _updatedRecord(localRecord, result, status, now);
        await database.upsertLocalRecord(updatedRecord);
        await _updateLocalEntity(
            updatedRecord, result, status, errorMessage, now);
      }

      if (status == 'synced') {
        synced++;
      } else if (status == 'conflict') {
        conflict++;
      } else {
        failed++;
      }
    }

    for (final queueItem in pending) {
      if (processed.contains(queueItem.localId)) continue;
      const message =
          'لم يرجع الخادم نتيجة لهذه العملية، ستبقى للمراجعة وإعادة المحاولة.';
      await database.upsertQueueItem(
        queueItem.copyWith(
          status: 'failed',
          retryCount: queueItem.retryCount + 1,
          errorMessage: message,
          updatedAt: now,
        ),
      );
      final localRecord = await database.findLocalRecord(queueItem.localId);
      if (localRecord != null) {
        final updatedRecord = localRecord.copyWith(
          syncStatus: 'failed',
          updatedAt: now,
        );
        await database.upsertLocalRecord(updatedRecord);
        await _updateLocalEntity(
          updatedRecord,
          const <String, dynamic>{},
          'failed',
          message,
          now,
        );
      }
      failed++;
    }

    if (synced > 0) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('alshaari_last_sync_at', now);
    }

    return SyncRunSummary(
      attempted: pending.length,
      synced: synced,
      failed: failed,
      conflict: conflict,
    );
  }

  Future<SyncRunSummary> _pushAttachments(List<SyncQueueItem> rows) async {
    if (rows.isEmpty) {
      return const SyncRunSummary(
        attempted: 0,
        synced: 0,
        failed: 0,
        conflict: 0,
      );
    }
    var synced = 0;
    var failed = 0;
    final now = DateTime.now().millisecondsSinceEpoch;
    await apiClient.loadToken();

    for (final row in rows) {
      try {
        final payload = jsonDecode(row.payloadJson);
        if (payload is! Map) {
          throw const FormatException('بيانات المرفق غير صالحة.');
        }
        final data = Map<String, dynamic>.from(payload);
        final fileData = data['file_data_base64']?.toString();
        final fileName = data['file_name']?.toString() ?? 'attachment.jpg';
        final entityType = data['entity_type']?.toString() ?? 'attachment';
        final entityId = await _resolveAttachmentEntityId(data);
        if (fileData == null || fileData.isEmpty) {
          throw const FormatException('لا توجد بيانات ملف محفوظة محليًا.');
        }

        final response = await apiClient.dio.post(
          '/attachments/upload',
          queryParameters: {
            'entity': entityType,
            'entity_id': entityId,
          },
          data: FormData.fromMap({
            'file': MultipartFile.fromBytes(
              base64Decode(fileData),
              filename: fileName,
            ),
          }),
          options: Options(contentType: 'multipart/form-data'),
        );
        final responseData = response.data is Map
            ? Map<String, dynamic>.from(response.data as Map)
            : <String, dynamic>{};
        final serverAttachmentId =
            int.tryParse('${responseData['id'] ?? responseData['server_id']}');

        await database.upsertQueueItem(
          row.copyWith(
            status: 'synced',
            errorMessage: null,
            updatedAt: now,
            syncedAt: now,
          ),
        );
        await _updateLocalAttachment(
          row.localId,
          syncStatus: 'synced',
          serverAttachmentId: serverAttachmentId,
          errorMessage: null,
          syncedAt: now,
        );
        synced++;
      } catch (error) {
        final message = 'فشل رفع المرفق: $error';
        await database.upsertQueueItem(
          row.copyWith(
            status: 'failed',
            retryCount: row.retryCount + 1,
            errorMessage: message,
            updatedAt: now,
          ),
        );
        await _updateLocalAttachment(
          row.localId,
          syncStatus: 'failed',
          errorMessage: message,
        );
        failed++;
      }
    }

    return SyncRunSummary(
      attempted: rows.length,
      synced: synced,
      failed: failed,
      conflict: 0,
    );
  }

  Future<int> _resolveAttachmentEntityId(Map<String, dynamic> data) async {
    final entityId = int.tryParse('${data['entity_id'] ?? 0}') ?? 0;
    if (entityId > 0) return entityId;

    final entityLocalUuid = data['entity_local_uuid']?.toString();
    if (entityLocalUuid == null ||
        entityLocalUuid.isEmpty ||
        entityLocalUuid.startsWith('pending-')) {
      return entityId;
    }

    final linkedRecord = await database.findLocalRecord(entityLocalUuid);
    final serverId = linkedRecord?.serverId;
    if (serverId != null && serverId > 0) {
      return serverId;
    }

    throw const _AttachmentWaitingForDocument();
  }

  LocalRecord _updatedRecord(
    LocalRecord record,
    Map<String, dynamic> result,
    String status,
    int now,
  ) {
    final serverId =
        result['server_id'] is int ? result['server_id'] as int : null;
    return record.copyWith(
      syncStatus: status,
      serverId: serverId,
      officialDocumentNo: _officialNo(result),
      updatedAt: now,
    );
  }

  Future<void> _updateLocalEntity(
    LocalRecord record,
    Map<String, dynamic> result,
    String status,
    String? errorMessage,
    int now,
  ) async {
    if (record.entityType != 'transaction' &&
        record.entityType != 'transactions' &&
        record.entityType != 'attendance_bulk' &&
        record.entityType != 'bulk_attendance') {
      return;
    }
    final decoded = jsonDecode(record.payloadJson);
    if (decoded is! Map) return;
    final payload = Map<String, dynamic>.from(decoded);
    if (record.entityType == 'attendance_bulk' ||
        record.entityType == 'bulk_attendance') {
      await _updateBulkAttendanceDrafts(
        parentLocalUuid: record.localUuid,
        status: status == 'synced' ? 'synced' : status,
        syncedAt: status == 'synced' ? now : null,
        now: now,
      );
      return;
    }
    await database.upsertLocalTransaction(
      LocalTransactionDraft.fromPayload(
        localUuid: record.localUuid,
        temporaryNo: record.temporaryNo,
        payload: payload,
        now: now,
        status: status == 'synced' ? 'synced' : status,
        createdOffline: payload['created_offline'] == true,
        serverId: record.serverId,
        officialNo: record.officialDocumentNo ?? _officialNo(result),
        errorMessage: errorMessage,
        syncedAt: status == 'synced' ? now : null,
      ),
    );
  }

  Future<void> _updateBulkAttendanceDrafts({
    required String parentLocalUuid,
    required String status,
    required int? syncedAt,
    required int now,
  }) async {
    final rows = await database.localAttendance();
    for (final row in rows) {
      final decoded = jsonDecode(row.payloadJson);
      if (decoded is! Map) continue;
      final payload = Map<String, dynamic>.from(decoded);
      if (payload['parent_local_uuid']?.toString() != parentLocalUuid) {
        continue;
      }
      await database.upsertLocalAttendance(
        LocalAttendanceDraft(
          localUuid: row.localUuid,
          serverId: row.serverId,
          employeeId: row.employeeId,
          attendanceDate: row.attendanceDate,
          status: row.status,
          projectId: row.projectId,
          costCenterId: row.costCenterId,
          notes: row.notes,
          syncStatus: status,
          payloadJson: row.payloadJson,
          createdAt: row.createdAt,
          updatedAt: now,
          syncedAt: syncedAt ?? row.syncedAt,
        ),
      );
    }
  }

  Future<void> _updateLocalAttachment(
    String localUuid, {
    required String syncStatus,
    int? serverAttachmentId,
    String? errorMessage,
    int? syncedAt,
  }) async {
    final rows = await database.localAttachments();
    for (final row in rows) {
      if (row.localUuid != localUuid) continue;
      await database.upsertLocalAttachment(
        LocalAttachmentDraft(
          localUuid: row.localUuid,
          entityLocalUuid: row.entityLocalUuid,
          entityType: row.entityType,
          filePath: row.filePath,
          fileName: row.fileName,
          mimeType: row.mimeType,
          serverAttachmentId: serverAttachmentId ?? row.serverAttachmentId,
          syncStatus: syncStatus,
          errorMessage: errorMessage,
          fileDataBase64: row.fileDataBase64,
          createdAt: row.createdAt,
          syncedAt: syncedAt ?? row.syncedAt,
        ),
      );
      return;
    }
  }

  String? _officialNo(Map<String, dynamic> result) {
    return (result['official_document_no'] ??
            result['official_no'] ??
            result['voucher_no'] ??
            result['document_no'] ??
            result['transaction_no'])
        ?.toString();
  }

  Future<void> _markBatchSyncing(List<SyncQueueItem> rows) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final row in rows) {
      await database.upsertQueueItem(
        row.copyWith(
          status: 'syncing',
          errorMessage: null,
          updatedAt: now,
        ),
      );
      final localRecord = await database.findLocalRecord(row.localId);
      if (localRecord != null) {
        final updatedRecord = localRecord.copyWith(
          syncStatus: 'syncing',
          updatedAt: now,
        );
        await database.upsertLocalRecord(updatedRecord);
        await _updateLocalEntity(
          updatedRecord,
          const <String, dynamic>{},
          'syncing',
          null,
          now,
        );
      }
    }
  }

  Future<void> _markBatchFailed(
    List<SyncQueueItem> rows,
    String message,
  ) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final row in rows) {
      await database.upsertQueueItem(
        row.copyWith(
          status: 'failed',
          retryCount: row.retryCount + 1,
          errorMessage: message,
          updatedAt: now,
        ),
      );
      final localRecord = await database.findLocalRecord(row.localId);
      if (localRecord != null) {
        final updatedRecord = localRecord.copyWith(
          syncStatus: 'failed',
          updatedAt: now,
        );
        await database.upsertLocalRecord(updatedRecord);
        await _updateLocalEntity(
          updatedRecord,
          const <String, dynamic>{},
          'failed',
          message,
          now,
        );
      }
    }
  }

  String _connectionMessage(DioException error) {
    if (error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout) {
      return 'تعذر الاتصال بالخادم، ستبقى العمليات بانتظار المزامنة.';
    }
    return error.response?.data?.toString() ?? 'فشلت المزامنة.';
  }
}

final syncService = SyncService(database: localDatabase);

class _AttachmentWaitingForDocument implements Exception {
  const _AttachmentWaitingForDocument();

  @override
  String toString() {
    return 'لم تتم مزامنة المستند المرتبط بالمرفق بعد. سيعاد رفع المرفق بعد مزامنة المستند.';
  }
}
