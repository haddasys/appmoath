from datetime import date

from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_permission
from app.db.database import get_db
from app.schemas.schemas import (
    AttendanceBulkCreate,
    AttendanceCreate,
    EmployeeAdjustmentCreate,
    EmployeeAdjustmentRejectRequest,
    EmployeeCreate,
    PayrollPayRequest,
    PayrollPeriodCreate,
    PayrollUpdateRequest,
)
from app.services.attendance_service import (
    bulk_save_attendance,
    create_attendance,
    get_daily_attendance,
    get_monthly_attendance,
    update_attendance,
)
from app.services.employee_adjustment_service import (
    approve_adjustment,
    create_adjustment,
    reject_adjustment,
)
from app.services.payroll_schema import ensure_payroll_schema
from app.services.payroll_service import (
    approve_payroll,
    calculate_payroll_period,
    create_payroll_period,
    employee_statement,
    list_payroll_periods,
    list_payrolls,
    pay_payroll,
    payroll_period,
    payroll_summary,
    update_payroll_draft,
)


router = APIRouter(prefix="/api/v1", tags=["Payroll"])


def rows_to_dict(rows):
    return [dict(row) for row in rows]


@router.get("/employees")
def list_employees(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_payroll_schema(db)
    rows = db.execute(
        text(
            """
            SELECT *
            FROM employees
            ORDER BY COALESCE(is_active, TRUE) DESC, name
            """
        )
    ).mappings().all()
    return rows_to_dict(rows)


@router.post("/employees")
def add_employee(
    data: EmployeeCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("employees.write")),
):
    ensure_payroll_schema(db)
    row = db.execute(
        text(
            """
            INSERT INTO employees (
                name, phone, job_title, department, wage_type, daily_wage,
                monthly_wage, friday_included, qat_allowance_daily,
                transport_allowance_daily, food_allowance_daily, is_active,
                notes, created_at
            )
            VALUES (
                :name, :phone, :job_title, :department, :wage_type, :daily_wage,
                :monthly_wage, :friday_included, :qat_allowance_daily,
                :transport_allowance_daily, :food_allowance_daily, :is_active,
                :notes, CURRENT_TIMESTAMP
            )
            RETURNING *
            """
        ),
        data.model_dump(),
    ).mappings().first()
    db.commit()
    return dict(row)


@router.get("/employees/{employee_id}")
def get_employee(
    employee_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    row = db.execute(
        text("SELECT * FROM employees WHERE id = :id"),
        {"id": employee_id},
    ).mappings().first()
    if not row:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="العامل غير موجود")
    return dict(row)


@router.put("/employees/{employee_id}")
def update_employee(
    employee_id: int,
    data: EmployeeCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("employees.write")),
):
    ensure_payroll_schema(db)
    payload = data.model_dump()
    payload["id"] = employee_id
    row = db.execute(
        text(
            """
            UPDATE employees
            SET name = :name,
                phone = :phone,
                job_title = :job_title,
                department = :department,
                wage_type = :wage_type,
                daily_wage = :daily_wage,
                monthly_wage = :monthly_wage,
                friday_included = :friday_included,
                qat_allowance_daily = :qat_allowance_daily,
                transport_allowance_daily = :transport_allowance_daily,
                food_allowance_daily = :food_allowance_daily,
                is_active = :is_active,
                notes = :notes
            WHERE id = :id
            RETURNING *
            """
        ),
        payload,
    ).mappings().first()
    if not row:
        from fastapi import HTTPException

        raise HTTPException(status_code=404, detail="العامل غير موجود")
    db.commit()
    return dict(row)


@router.get("/attendance")
def list_attendance(
    from_date: date | None = None,
    to_date: date | None = None,
    employee_id: int | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    conditions = []
    params = {"from_date": from_date, "to_date": to_date, "employee_id": employee_id}
    if from_date:
        conditions.append("a.date >= :from_date")
    if to_date:
        conditions.append("a.date <= :to_date")
    if employee_id:
        conditions.append("a.employee_id = :employee_id")
    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    rows = db.execute(
        text(
            f"""
            SELECT a.*, e.name AS employee_name
            FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            {where_clause}
            ORDER BY a.date DESC, e.name
            LIMIT 500
            """
        ),
        params,
    ).mappings().all()
    return rows_to_dict(rows)


@router.post("/attendance")
def add_attendance(
    data: AttendanceCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return create_attendance(db, data, user.id)


@router.get("/attendance/daily")
def daily_attendance(
    date: date,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return get_daily_attendance(db, date)


@router.post("/attendance/bulk")
def bulk_attendance(
    data: AttendanceBulkCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return bulk_save_attendance(
        db,
        data.date,
        data.records,
        data.project_id,
        data.cost_center_id,
        user.id,
    )


@router.put("/attendance/{attendance_id}")
def edit_attendance(
    attendance_id: int,
    data: AttendanceCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return update_attendance(db, attendance_id, data, user.id)


@router.get("/attendance/monthly")
def monthly_attendance(
    year: int,
    month: int,
    employee_id: int | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return get_monthly_attendance(db, year, month, employee_id)


@router.get("/employee-adjustments")
def list_employee_adjustments(
    employee_id: int | None = None,
    status: str | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    conditions = []
    params = {"employee_id": employee_id, "status": status}
    if employee_id:
        conditions.append("ea.employee_id = :employee_id")
    if status:
        conditions.append("ea.status = :status")
    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    rows = db.execute(
        text(
            f"""
            SELECT ea.*, e.name AS employee_name
            FROM employee_adjustments ea
            JOIN employees e ON e.id = ea.employee_id
            {where_clause}
            ORDER BY ea.date DESC, ea.id DESC
            """
        ),
        params,
    ).mappings().all()
    return rows_to_dict(rows)


@router.post("/employee-adjustments")
def add_employee_adjustment(
    data: EmployeeAdjustmentCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return create_adjustment(db, data, user.id)


@router.post("/employee-adjustments/{adjustment_id}/approve")
def approve_employee_adjustment(
    adjustment_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.approve")),
):
    ensure_payroll_schema(db)
    return approve_adjustment(db, adjustment_id, user.id)


@router.post("/employee-adjustments/{adjustment_id}/reject")
def reject_employee_adjustment(
    adjustment_id: int,
    data: EmployeeAdjustmentRejectRequest | None = None,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.approve")),
):
    ensure_payroll_schema(db)
    return reject_adjustment(db, adjustment_id, user.id, data.reason if data else None)


@router.post("/payroll-periods")
def add_payroll_period(
    data: PayrollPeriodCreate,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return create_payroll_period(db, data, user.id)


@router.get("/payroll-periods")
def get_payroll_periods(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_payroll_schema(db)
    return list_payroll_periods(db)


@router.get("/payroll-periods/{period_id}")
def get_payroll_period(
    period_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return payroll_period(db, period_id)


@router.post("/payroll-periods/{period_id}/calculate")
def calculate_period(
    period_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return calculate_payroll_period(db, period_id, user.id)


@router.get("/payroll-periods/{period_id}/payrolls")
def get_period_payrolls(
    period_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return list_payrolls(db, period_id)


@router.post("/payrolls/{payroll_id}/approve")
def approve_employee_payroll(
    payroll_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.approve")),
):
    ensure_payroll_schema(db)
    return approve_payroll(db, payroll_id, user.id)


@router.put("/payrolls/{payroll_id}")
def edit_employee_payroll(
    payroll_id: int,
    data: PayrollUpdateRequest,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.write")),
):
    ensure_payroll_schema(db)
    return update_payroll_draft(db, payroll_id, data, user.id)


@router.post("/payrolls/{payroll_id}/pay")
def pay_employee_payroll(
    payroll_id: int,
    data: PayrollPayRequest,
    db: Session = Depends(get_db),
    user=Depends(require_permission("payroll.pay")),
):
    ensure_payroll_schema(db)
    return pay_payroll(db, payroll_id, data, user.id)


@router.get("/reports/employee-statement/{employee_id}")
def employee_statement_report(
    employee_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return employee_statement(db, employee_id)


@router.get("/reports/payroll-summary")
def payroll_summary_report(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    return payroll_summary(db, year, month)


@router.get("/reports/attendance-summary")
def attendance_summary_report(
    year: int,
    month: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    rows = get_monthly_attendance(db, year, month)
    summary: dict[int, dict] = {}
    for row in rows:
        item = summary.setdefault(
            row["employee_id"],
            {
                "employee_id": row["employee_id"],
                "employee_name": row["employee_name"],
                "present": 0,
                "absent": 0,
                "half_day": 0,
                "paid_fridays": 0,
            },
        )
        if row["status"] == "present":
            item["present"] += 1
        elif row["status"] == "absent":
            item["absent"] += 1
        elif row["status"] == "half_day":
            item["half_day"] += 1
        elif row["status"] == "friday_paid":
            item["paid_fridays"] += 1
    return list(summary.values())


@router.get("/reports/open-employee-advances")
def open_employee_advances_report(
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    rows = db.execute(
        text(
            """
            SELECT
                e.id AS employee_id,
                e.name AS employee_name,
                COALESCE(SUM(CASE WHEN ea.adjustment_type IN ('advance', 'custody') THEN ea.amount ELSE 0 END), 0) AS total_advances,
                COALESCE(SUM(p.advances_total), 0) AS settled,
                COALESCE(SUM(CASE WHEN ea.adjustment_type IN ('advance', 'custody') THEN ea.amount ELSE 0 END), 0)
                  - COALESCE(SUM(p.advances_total), 0) AS open_balance
            FROM employees e
            LEFT JOIN employee_adjustments ea
              ON ea.employee_id = e.id
             AND ea.status = 'approved'
            LEFT JOIN payrolls p
              ON p.employee_id = e.id
             AND p.status IN ('approved', 'paid')
            GROUP BY e.id, e.name
            HAVING COALESCE(SUM(CASE WHEN ea.adjustment_type IN ('advance', 'custody') THEN ea.amount ELSE 0 END), 0)
                  - COALESCE(SUM(p.advances_total), 0) <> 0
            ORDER BY open_balance DESC
            """
        )
    ).mappings().all()
    return rows_to_dict(rows)


@router.get("/reports/project-labor-costs")
def project_labor_costs_report(
    project_id: int | None = Query(None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_payroll_schema(db)
    filter_clause = "AND pc.project_id = :project_id" if project_id else ""
    rows = db.execute(
        text(
            f"""
            SELECT
                pc.project_id,
                p.name AS project_name,
                pc.cost_center_id,
                cc.name AS cost_center_name,
                pc.amount,
                pc.date,
                pc.source_id AS payroll_id,
                pc.notes
            FROM project_costs pc
            JOIN projects p ON p.id = pc.project_id
            LEFT JOIN cost_centers cc ON cc.id = pc.cost_center_id
            WHERE pc.source_type = 'payroll'
              {filter_clause}
            ORDER BY pc.date DESC, pc.id DESC
            """
        ),
        {"project_id": project_id},
    ).mappings().all()
    return rows_to_dict(rows)
