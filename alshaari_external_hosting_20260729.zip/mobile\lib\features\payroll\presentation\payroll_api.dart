import 'package:dio/dio.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../core/config.dart';

Future<Dio> payrollDio() async {
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
      headers: const {'Accept': 'application/json'},
    ),
  );
  final prefs = await SharedPreferences.getInstance();
  final token = prefs.getString('token') ??
      prefs.getString('access_token') ??
      prefs.getString('auth_token');
  if (token != null && token.isNotEmpty) {
    dio.options.headers['Authorization'] = 'Bearer $token';
  }
  return dio;
}

List<Map<String, dynamic>> asList(dynamic value) {
  if (value is List) {
    return value
        .whereType<Map>()
        .map((item) => Map<String, dynamic>.from(item))
        .toList();
  }
  if (value is Map && value['items'] is List) {
    return asList(value['items']);
  }
  return const [];
}

String formatMoney(dynamic value) {
  final number = value is num ? value : num.tryParse('$value') ?? 0;
  final formatted = NumberFormat.decimalPattern('ar').format(number);
  return '$formatted ريال';
}

String todayIso() => DateFormat('yyyy-MM-dd').format(DateTime.now());

String errorMessage(Object error) {
  if (error is DioException) {
    final detail = error.response?.data is Map
        ? error.response?.data['detail']
        : error.response?.data;
    if (detail != null && '$detail'.trim().isNotEmpty) return '$detail';
  }
  return 'تعذر تنفيذ العملية. تأكد من اتصال الخادم ثم حاول مرة أخرى.';
}
