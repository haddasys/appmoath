from sqlalchemy.orm import Session
from sqlalchemy import inspect, text

from app.db.database import engine
from app.models.models import AdjustmentVoucher, AdjustmentVoucherLine, DocumentSequence


def ensure_adjustment_schema(db: Session) -> None:
    AdjustmentVoucher.__table__.create(bind=engine, checkfirst=True)
    AdjustmentVoucherLine.__table__.create(bind=engine, checkfirst=True)

    columns = {col["name"] for col in inspect(engine).get_columns("adjustment_vouchers")}
    for column_name, definition in [
        ("attachment_url", "VARCHAR(500)"),
        ("rejected_by", "INTEGER"),
        ("rejected_at", "TIMESTAMP"),
        ("reversed_by", "INTEGER"),
        ("reversed_at", "TIMESTAMP"),
    ]:
        if column_name not in columns:
            db.execute(text(f"ALTER TABLE adjustment_vouchers ADD COLUMN {column_name} {definition}"))
            db.commit()

    seq = (
        db.query(DocumentSequence)
        .filter(DocumentSequence.document_type == "adjustment_voucher")
        .first()
    )
    if not seq:
        db.add(
            DocumentSequence(
                document_type="adjustment_voucher",
                prefix="ASH-ADJ",
                next_number=1,
                padding=4,
                is_active=True,
            )
        )
        db.commit()
