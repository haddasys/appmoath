import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/widgets/alshaari_ui.dart';
import 'payroll_api.dart';

class EmployeeAdjustmentsScreen extends StatefulWidget {
  const EmployeeAdjustmentsScreen({super.key});

  @override
  State<EmployeeAdjustmentsScreen> createState() =>
      _EmployeeAdjustmentsScreenState();
}

class _EmployeeAdjustmentsScreenState extends State<EmployeeAdjustmentsScreen> {
  bool loading = true;
  List<Map<String, dynamic>> employees = [];
  List<Map<String, dynamic>> adjustments = [];
  int? employeeId;
  String type = 'advance';
  final amount = TextEditingController();
  final description = TextEditingController();

  static const types = {
    'advance': 'سلفة',
    'custody': 'عهدة',
    'deduction': 'خصم',
    'bonus': 'مكافأة',
    'qat': 'قات',
    'transport': 'مواصلات',
    'food': 'غداء',
    'overtime_amount': 'إضافي',
    'other': 'أخرى',
  };

  static const statuses = {
    'draft': 'مسودة',
    'approved': 'معتمدة',
    'rejected': 'مرفوضة',
  };

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final dio = await payrollDio();
      final employeesRes = await dio.get('/api/v1/employees');
      final adjustmentsRes = await dio.get('/api/v1/employee-adjustments');
      if (!mounted) return;
      final loadedEmployees = asList(employeesRes.data);
      setState(() {
        employees = loadedEmployees;
        employeeId ??= loadedEmployees.isNotEmpty
            ? loadedEmployees.first['id'] as int?
            : null;
        adjustments = asList(adjustmentsRes.data);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> save() async {
    if (employeeId == null ||
        num.tryParse(amount.text) == null ||
        description.text.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('اختر العامل وأدخل المبلغ والبيان.')),
      );
      return;
    }
    try {
      final dio = await payrollDio();
      await dio.post('/api/v1/employee-adjustments', data: {
        'employee_id': employeeId,
        'date': todayIso(),
        'adjustment_type': type,
        'amount': num.parse(amount.text),
        'description': description.text.trim(),
      });
      if (!mounted) return;
      amount.clear();
      description.clear();
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ التعديل كمسودة.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> approve(int id) async {
    try {
      final dio = await payrollDio();
      await dio.post('/api/v1/employee-adjustments/$id/approve');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم اعتماد التعديل.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  String employeeName(dynamic id) {
    for (final employee in employees) {
      if (employee['id'] == id) return '${employee['name']}';
    }
    return 'عامل #$id';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('السلف والبدلات'),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh))
          ],
        ),
        body: RefreshIndicator(
          onRefresh: load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const AlshaariPageHeader(
                title: 'تعديلات العامل',
                subtitle:
                    'السلف لا تعتبر مصروفًا، وتظهر كذمة حتى تتم تسويتها أو خصمها.',
                icon: Icons.tune,
              ),
              const SizedBox(height: 12),
              AlshaariSectionCard(
                title: 'إضافة تعديل',
                icon: Icons.add_card,
                child: Column(
                  children: [
                    DropdownButtonFormField<int>(
                      initialValue: employeeId,
                      decoration: const InputDecoration(labelText: 'العامل'),
                      items: employees
                          .map((item) => DropdownMenuItem<int>(
                              value: item['id'] as int?,
                              child: Text('${item['name']}')))
                          .toList(),
                      onChanged: (value) => setState(() => employeeId = value),
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      initialValue: type,
                      decoration:
                          const InputDecoration(labelText: 'نوع التعديل'),
                      items: types.entries
                          .map((entry) => DropdownMenuItem(
                              value: entry.key, child: Text(entry.value)))
                          .toList(),
                      onChanged: (value) =>
                          setState(() => type = value ?? 'advance'),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: amount,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(labelText: 'المبلغ'),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                        controller: description,
                        decoration: const InputDecoration(labelText: 'البيان')),
                    const SizedBox(height: 14),
                    SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: save,
                        icon: const Icon(Icons.save),
                        label: const Text('حفظ كمسودة'),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (loading)
                const Center(
                    child: Padding(
                        padding: EdgeInsets.all(24),
                        child: CircularProgressIndicator())),
              if (!loading && adjustments.isEmpty)
                const AlshaariSectionCard(
                    child: Text('لا توجد سلف أو تعديلات مسجلة.')),
              ...adjustments.map((item) {
                final status = '${item['status'] ?? 'draft'}';
                final approved = status == 'approved';
                return Card(
                  child: ListTile(
                    title: Text(
                        '${types['${item['adjustment_type']}'] ?? item['adjustment_type']} - ${employeeName(item['employee_id'])}'),
                    subtitle: Text(
                        '${formatMoney(item['amount'])} | ${item['description'] ?? ''}'),
                    leading: AlshaariStatusBadge(
                      label: statuses[status] ?? status,
                      color: approved
                          ? AlshaariColors.success
                          : AlshaariColors.warning,
                    ),
                    trailing: approved
                        ? null
                        : FilledButton(
                            onPressed: () => approve(item['id'] as int),
                            child: const Text('اعتماد'),
                          ),
                  ),
                );
              }),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }
}
