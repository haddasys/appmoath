﻿from sqlalchemy import text
from app.db.database import engine

DDL = """
CREATE TABLE IF NOT EXISTS journal_entries (
    id SERIAL PRIMARY KEY,
    entry_no VARCHAR(50) UNIQUE NOT NULL,
    entry_date DATE NOT NULL,
    source_type VARCHAR(50),
    source_id INTEGER,
    description TEXT,
    status VARCHAR(30) DEFAULT 'posted',
    total_debit NUMERIC(14,2) DEFAULT 0,
    total_credit NUMERIC(14,2) DEFAULT 0,
    created_by INTEGER,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS journal_entry_lines (
    id SERIAL PRIMARY KEY,
    journal_entry_id INTEGER NOT NULL REFERENCES journal_entries(id) ON DELETE CASCADE,
    account_code VARCHAR(30) NOT NULL,
    account_name VARCHAR(255) NOT NULL,
    debit NUMERIC(14,2) DEFAULT 0,
    credit NUMERIC(14,2) DEFAULT 0,
    project_id INTEGER,
    party_type VARCHAR(50),
    party_id INTEGER,
    description TEXT
);

CREATE TABLE IF NOT EXISTS posting_rules (
    id SERIAL PRIMARY KEY,
    operation_type VARCHAR(80) UNIQUE NOT NULL,
    debit_account_code VARCHAR(30) NOT NULL,
    credit_account_code VARCHAR(30) NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE
);

CREATE INDEX IF NOT EXISTS idx_journal_entries_source
ON journal_entries(source_type, source_id);

CREATE INDEX IF NOT EXISTS idx_journal_lines_account
ON journal_entry_lines(account_code);

CREATE INDEX IF NOT EXISTS idx_journal_lines_project
ON journal_entry_lines(project_id);
"""

def main():
    with engine.begin() as conn:
        conn.execute(text(DDL))
    print("Accounting engine tables created successfully.")

if __name__ == "__main__":
    main()
