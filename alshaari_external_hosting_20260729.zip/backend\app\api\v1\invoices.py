from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_approval_role
from app.db.database import get_db
from app.models.models import Invoice
from app.schemas.schemas import InvoiceCreate
from app.services.invoice_service import create_invoice, invoice_to_dict, post_invoice

router = APIRouter(prefix="/api/v1/invoices", tags=["Invoices"])


@router.get("")
def list_invoices(db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoices = db.query(Invoice).order_by(Invoice.id.desc()).limit(500).all()
    return [invoice_to_dict(db, invoice) for invoice in invoices]


@router.get("/{invoice_id}")
def get_invoice(invoice_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="الفاتورة غير موجودة")
    return invoice_to_dict(db, invoice)


@router.post("")
def add_invoice(data: InvoiceCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return invoice_to_dict(db, create_invoice(db, data, user.id))


@router.post("/{invoice_id}/post")
def post(invoice_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return invoice_to_dict(db, post_invoice(db, invoice_id, user.id))
