export 'print_document_stub.dart'
    if (dart.library.html) 'print_document_web.dart';
