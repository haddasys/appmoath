from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.api.v1 import adjustment_vouchers as adjustment_api
from app.core.deps import get_current_user, require_permission
from app.db.database import get_db
from app.schemas.schemas import (
    AdjustmentVoucherCreate,
    AdjustmentVoucherRejectRequest,
    AdjustmentVoucherReverseRequest,
)


router = APIRouter(prefix="/api/v1/settlement-vouchers", tags=["Settlement Vouchers"])


@router.get("")
def list_settlement_vouchers(
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return adjustment_api.list_adjustment_vouchers(db=db, user=user)


@router.post("")
def create_settlement_voucher(
    data: AdjustmentVoucherCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return adjustment_api.create_adjustment_voucher(data=data, db=db, user=user)


@router.get("/{voucher_id}")
def get_settlement_voucher(
    voucher_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return adjustment_api.get_adjustment_voucher(
        voucher_id=voucher_id, db=db, user=user
    )


@router.post("/{voucher_id}/approve")
def approve_settlement_voucher(
    voucher_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_permission("approve_adjustment_journal")),
):
    return adjustment_api.approve_adjustment_voucher(
        voucher_id=voucher_id, db=db, user=user
    )


@router.post("/{voucher_id}/reject")
def reject_settlement_voucher(
    voucher_id: int,
    data: AdjustmentVoucherRejectRequest | None = None,
    db: Session = Depends(get_db),
    user=Depends(require_permission("approve_adjustment_journal")),
):
    return adjustment_api.reject_adjustment_voucher(
        voucher_id=voucher_id, data=data, db=db, user=user
    )


@router.post("/{voucher_id}/reverse")
def reverse_settlement_voucher(
    voucher_id: int,
    data: AdjustmentVoucherReverseRequest,
    db: Session = Depends(get_db),
    user=Depends(require_permission("approve_adjustment_journal")),
):
    return adjustment_api.reverse_adjustment_voucher(
        voucher_id=voucher_id, data=data, db=db, user=user
    )
