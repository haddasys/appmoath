import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/permissions.dart';
import '../../../core/widgets/alshaari_ui.dart';

class AdjustmentVoucherScreen extends StatefulWidget {
  const AdjustmentVoucherScreen({super.key});

  @override
  State<AdjustmentVoucherScreen> createState() =>
      _AdjustmentVoucherScreenState();
}

class _AdjustmentLine {
  int? accountId;
  String? accountCode;
  int? projectId;
  int? costCenterId;
  String partyType = 'none';
  int? partyId;
  final debit = TextEditingController();
  final credit = TextEditingController();
  final description = TextEditingController();

  void dispose() {
    debit.dispose();
    credit.dispose();
    description.dispose();
  }
}

class _AdjustmentVoucherScreenState extends State<AdjustmentVoucherScreen> {
  final formKey = GlobalKey<FormState>();
  bool loading = true;
  bool saving = false;
  String settlementType = 'general_adjustment';
  String? settlementSubtype;
  final dateController = TextEditingController();
  final descriptionController = TextEditingController();
  final lines = <_AdjustmentLine>[];

  List<dynamic> vouchers = [];
  List<dynamic> accounts = [];
  List<dynamic> projects = [];
  List<dynamic> costCenters = [];
  List<dynamic> customers = [];
  List<dynamic> suppliers = [];
  List<dynamic> workers = [];
  Set<String> permissions = {};

  final settlementTypes = const [
    {'value': 'general_adjustment', 'label': 'تسوية حسابية عامة'},
    {'value': 'error_correction', 'label': 'تصحيح خطأ قيد سابق'},
    {'value': 'worker_advance_settlement', 'label': 'تسوية سلفة عامل'},
    {'value': 'supplier_settlement', 'label': 'تسوية رصيد مورد'},
    {'value': 'customer_settlement', 'label': 'تسوية رصيد عميل'},
    {'value': 'inventory_settlement', 'label': 'تسوية قيمة مخزون'},
    {'value': 'project_cost_settlement', 'label': 'تسوية تكاليف مشروع'},
    {'value': 'accrued_expense', 'label': 'إثبات مصروف مستحق'},
    {'value': 'accrued_revenue', 'label': 'إثبات إيراد مستحق'},
    {'value': 'reclassification', 'label': 'إعادة تصنيف'},
    {'value': 'opening_balance', 'label': 'رصيد افتتاحي'},
    {'value': 'other', 'label': 'أخرى'},
  ];

  final workerSubtypes = const [
    {'value': 'wage_project', 'label': 'أجر عمل على مشروع'},
    {'value': 'wage_general', 'label': 'أجر عمل عام'},
    {'value': 'expense_project', 'label': 'مصروف مشروع مسدد من سلفة'},
    {'value': 'cash_return', 'label': 'إعادة مبلغ نقدي من سلفة'},
    {'value': 'salary_deduction', 'label': 'خصم من الراتب'},
  ];

  final partyTypes = const [
    {'value': 'none', 'label': 'بدون طرف'},
    {'value': 'customer', 'label': 'عميل'},
    {'value': 'supplier', 'label': 'مورد'},
    {'value': 'worker', 'label': 'عامل'},
  ];

  @override
  void initState() {
    super.initState();
    dateController.text = DateTime.now().toIso8601String().substring(0, 10);
    lines.add(_AdjustmentLine());
    lines.add(_AdjustmentLine());
    loadData();
  }

  @override
  void dispose() {
    dateController.dispose();
    descriptionController.dispose();
    for (final line in lines) {
      line.dispose();
    }
    super.dispose();
  }

  Future<List<dynamic>> getList(String path) async {
    final res = await apiClient.dio.get(path);
    if (res.data is List) return res.data as List<dynamic>;
    return [];
  }

  Future<List<dynamic>> getSettlementVouchers() async {
    try {
      return await getList('/settlement-vouchers');
    } catch (_) {
      return await getList('/adjustment-vouchers');
    }
  }

  Future<void> postSettlementVoucher(Map<String, dynamic> payload) async {
    try {
      await apiClient.dio.post('/settlement-vouchers', data: payload);
    } catch (_) {
      await apiClient.dio.post('/adjustment-vouchers', data: payload);
    }
  }

  Future<void> approveSettlementVoucher(int id) async {
    try {
      await apiClient.dio.post('/settlement-vouchers/$id/approve');
    } catch (_) {
      await apiClient.dio.post('/adjustment-vouchers/$id/approve');
    }
  }

  Future<void> rejectSettlementVoucher(int id) async {
    try {
      await apiClient.dio.post('/settlement-vouchers/$id/reject', data: {});
    } catch (_) {
      await apiClient.dio.post('/adjustment-vouchers/$id/reject', data: {});
    }
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      await apiClient.loadToken();
      final loadedPermissions = await AlshaariPermissions.currentPermissions();
      final loadedVouchers = await getSettlementVouchers();
      final result = await Future.wait([
        getList('/accounts'),
        getList('/projects'),
        getList('/cost-centers'),
        getList('/customers'),
        getList('/suppliers'),
        getList('/workers'),
      ]);
      if (!mounted) return;
      setState(() {
        vouchers = loadedVouchers;
        accounts =
            (result[0]).where((a) => a['is_active'] == true).toList();
        projects = result[1];
        costCenters = result[2];
        customers = result[3];
        suppliers = result[4];
        workers = result[5];
        permissions = loadedPermissions;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل بيانات سند التسوية: ${friendlyError(e)}');
    }
  }

  String friendlyError(Object e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (e.message != null) return e.message!;
    }
    return '$e';
  }

  bool can(String permission) {
    return AlshaariPermissions.hasPermission(permissions, permission);
  }

  void showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  double asDouble(String value) => double.tryParse(value.trim()) ?? 0;

  double totalDebit() =>
      lines.fold(0, (sum, line) => sum + asDouble(line.debit.text));

  double totalCredit() =>
      lines.fold(0, (sum, line) => sum + asDouble(line.credit.text));

  double difference() => totalDebit() - totalCredit();

  String money(double value) => value.toStringAsFixed(2);

  DropdownMenuItem<String> stringItem(Map<String, String> item) {
    return DropdownMenuItem(
        value: item['value'], child: Text(item['label'] ?? ''));
  }

  List<dynamic> partyList(String partyType) {
    if (partyType == 'customer') return customers;
    if (partyType == 'supplier') return suppliers;
    if (partyType == 'worker') return workers;
    return [];
  }

  String itemLabel(Map<String, dynamic> item) {
    return '${item['code'] ?? item['project_code'] ?? ''} ${item['name'] ?? item['title'] ?? ''}'
        .trim();
  }

  void addLine() {
    setState(() => lines.add(_AdjustmentLine()));
  }

  void removeLine(int index) {
    if (lines.length <= 2) {
      showMessage('سند التسوية يجب أن يحتوي على سطرين على الأقل');
      return;
    }
    setState(() {
      final removed = lines.removeAt(index);
      removed.dispose();
    });
  }

  bool validateBalanced() {
    if (lines.length < 2) {
      showMessage('سند التسوية يجب أن يحتوي على سطرين على الأقل');
      return false;
    }
    if (descriptionController.text.trim().length < 5) {
      showMessage('اكتب بيانًا واضحًا لسند التسوية');
      return false;
    }
    for (var i = 0; i < lines.length; i++) {
      final line = lines[i];
      final debit = asDouble(line.debit.text);
      final credit = asDouble(line.credit.text);
      if (line.accountCode == null) {
        showMessage('اختر الحساب في السطر ${i + 1}');
        return false;
      }
      if (debit > 0 && credit > 0) {
        showMessage('السطر ${i + 1}: لا يجوز إدخال مدين ودائن معًا');
        return false;
      }
      if (debit <= 0 && credit <= 0) {
        showMessage('السطر ${i + 1}: أدخل مدين أو دائن');
        return false;
      }
      if (line.projectId != null && line.costCenterId == null) {
        showMessage('السطر ${i + 1}: عند اختيار مشروع يجب اختيار مركز تكلفة');
        return false;
      }
    }
    if (difference().abs() > .009) {
      showMessage('سند التسوية غير متوازن');
      return false;
    }
    return true;
  }

  Future<void> saveDraft() async {
    if (!formKey.currentState!.validate() || !validateBalanced()) return;
    setState(() => saving = true);
    try {
      final payload = {
        'date': dateController.text.trim(),
        'reason': settlementType, // Mapping 'reason' to backend field
        'subtype': settlementSubtype,
        'description': descriptionController.text.trim(),
        'lines': lines.map((line) {
          return {
            'account_code': line.accountCode,
            'debit': asDouble(line.debit.text),
            'credit': asDouble(line.credit.text),
            'account_name': accounts
                .firstWhere((a) => a['code'] == line.accountCode)['name'],
            'project_id': line.projectId,
            'cost_center_id': line.costCenterId,
            'party_type': line.partyType,
            'party_id': line.partyId,
            'description': line.description.text.trim(),
          };
        }).toList(),
      };
      await postSettlementVoucher(payload);
      if (!mounted) return;
      showMessage('تم حفظ سند التسوية كمسودة بنجاح');
      descriptionController.clear();
      for (final line in lines) {
        line.dispose();
      }
      lines
        ..clear()
        ..add(_AdjustmentLine())
        ..add(_AdjustmentLine());
      await loadData();
    } catch (e) {
      showMessage('فشل حفظ سند التسوية: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> approveVoucher(int id) async {
    final confirmed = await showAlshaariConfirmDialog(
      context: context,
      title: 'تأكيد اعتماد سند التسوية',
      message:
          'بعد اعتماد سند التسوية سيتم إنشاء قيد محاسبي ولا يمكن تعديله إلا بسند عكسي.',
      confirmLabel: 'اعتماد',
    );
    if (!confirmed) return;
    try {
      await approveSettlementVoucher(id);
      showMessage('تم اعتماد سند التسوية وإنشاء القيد المحاسبي');
      await loadData();
    } catch (e) {
      showMessage('فشل اعتماد سند التسوية: ${friendlyError(e)}');
    }
  }

  Future<void> rejectVoucher(int id) async {
    try {
      await rejectSettlementVoucher(id);
      showMessage('تم رفض سند التسوية');
      await loadData();
    } catch (e) {
      showMessage('فشل رفض سند التسوية: ${friendlyError(e)}');
    }
  }

  Widget lineCard(int index, _AdjustmentLine line) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text('سطر القيد ${index + 1}',
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
                IconButton(
                  onPressed: () => removeLine(index),
                  icon: const Icon(Icons.delete_outline),
                ),
              ],
            ),
            DropdownButtonFormField<String>(
              initialValue: line.accountCode,
              decoration: const InputDecoration(labelText: 'الحساب'),
              items: accounts.map((raw) {
                final item = Map<String, dynamic>.from(raw as Map);
                final code = '${item['code'] ?? ''}';
                return DropdownMenuItem<String>(
                  value: code,
                  child: Text('$code - ${item['name'] ?? ''}',
                      overflow: TextOverflow.ellipsis),
                );
              }).toList(),
              validator: (value) => value == null ? 'اختر الحساب' : null,
              onChanged: (value) {
                setState(() {
                  line.accountCode = value;
                  final account = accounts
                      .map((raw) => Map<String, dynamic>.from(raw as Map))
                      .firstWhere(
                        (item) => '${item['code']}' == value,
                        orElse: () => {},
                      );
                  line.accountId = account['id'] as int?;
                });
              },
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: TextFormField(
                    controller: line.debit,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'مدين'),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: TextFormField(
                    controller: line.credit,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(labelText: 'دائن'),
                    onChanged: (_) => setState(() {}),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              initialValue: line.projectId,
              decoration: const InputDecoration(labelText: 'المشروع - اختياري'),
              items: projects.map((raw) {
                final item = Map<String, dynamic>.from(raw as Map);
                return DropdownMenuItem<int>(
                  value: item['id'] as int,
                  child: Text(itemLabel(item), overflow: TextOverflow.ellipsis),
                );
              }).toList(),
              onChanged: (value) => setState(() => line.projectId = value),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<int>(
              initialValue: line.costCenterId,
              decoration:
                  const InputDecoration(labelText: 'مركز التكلفة - اختياري'),
              items: costCenters.map((raw) {
                final item = Map<String, dynamic>.from(raw as Map);
                return DropdownMenuItem<int>(
                  value: item['id'] as int,
                  child: Text(itemLabel(item), overflow: TextOverflow.ellipsis),
                );
              }).toList(),
              onChanged: (value) => setState(() => line.costCenterId = value),
            ),
            const SizedBox(height: 10),
            DropdownButtonFormField<String>(
              initialValue: line.partyType,
              decoration:
                  const InputDecoration(labelText: 'نوع الطرف - اختياري'),
              items: partyTypes.map(stringItem).toList(),
              onChanged: (value) => setState(() {
                line.partyType = value ?? 'none';
                line.partyId = null;
              }),
            ),
            if (line.partyType != 'none') ...[
              const SizedBox(height: 10),
              DropdownButtonFormField<int>(
                initialValue: line.partyId,
                decoration: const InputDecoration(labelText: 'الطرف المرتبط'),
                items: partyList(line.partyType).map((raw) {
                  final item = Map<String, dynamic>.from(raw as Map);
                  return DropdownMenuItem<int>(
                    value: item['id'] as int,
                    child:
                        Text(itemLabel(item), overflow: TextOverflow.ellipsis),
                  );
                }).toList(),
                onChanged: (value) => setState(() => line.partyId = value),
              ),
            ],
            const SizedBox(height: 10),
            TextFormField(
              controller: line.description,
              decoration: const InputDecoration(labelText: 'بيان السطر'),
            ),
          ],
        ),
      ),
    );
  }

  Widget totalsCard() {
    final diff = difference();
    return AlshaariSectionCard(
      title: 'ملخص التوازن المحاسبي',
      icon: Icons.calculate_outlined,
      child: Column(
        children: [
          if (diff.abs() > 0.009)
            Container(
              padding: const EdgeInsets.all(8),
              margin: const EdgeInsets.only(bottom: 12),
              decoration: BoxDecoration(
                  color: AlshaariColors.danger.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8)),
              child: Row(children: [
                Icon(Icons.warning_amber_rounded, color: AlshaariColors.danger),
                const SizedBox(width: 8),
                const Text('القيد غير متوازن حالياً',
                    style: TextStyle(color: AlshaariColors.danger))
              ]),
            ),
          _SummaryLine(
              'إجمالي المدين', money(totalDebit()), AlshaariColors.success),
          _SummaryLine(
              'إجمالي الدائن', money(totalCredit()), AlshaariColors.copper),
          _SummaryLine(
              'الفرق',
              money(diff),
              diff.abs() > .009
                  ? AlshaariColors.danger
                  : AlshaariColors.success),
        ],
      ),
    );
  }

  Widget voucherCard(Map<String, dynamic> voucher) {
    final status = '${voucher['status'] ?? 'draft'}';
    final lines = (voucher['lines'] as List?) ?? [];
    final id = voucher['id'] as int;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  '${voucher['voucher_no'] ?? ''}',
                  style: const TextStyle(
                      fontWeight: FontWeight.w900,
                      fontSize: 16,
                      color: AlshaariColors.copper),
                ),
                AlshaariStatusBadge.byStatus(status),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                const Icon(Icons.history_edu,
                    size: 16, color: AlshaariColors.slate),
                const SizedBox(width: 8),
                Expanded(
                    child: Text('${voucher['description'] ?? '-'}',
                        style: const TextStyle(fontSize: 14))),
              ],
            ),
            const SizedBox(height: 8),
            AlshaariMoneyText(
                'مدين: ${voucher['total_debit'] ?? 0} | دائن: ${voucher['total_credit'] ?? 0} | الفرق: ${voucher['difference'] ?? 0}'),
            const Divider(height: 20),
            ...lines.map((raw) {
              final line = Map<String, dynamic>.from(raw as Map);
              return Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Text(
                  '${line['account_code']} - ${line['account_name']} | مدين ${line['debit']} | دائن ${line['credit']}',
                ),
              );
            }),
            if (status == 'draft' && can('approve_adjustment_journal')) ...[
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => approveVoucher(id),
                      icon: const Icon(Icons.check),
                      label: const Text('اعتماد'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => rejectVoucher(id),
                      icon: const Icon(Icons.close),
                      label: const Text('رفض'),
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('سند تسوية'),
          actions: [
            IconButton(onPressed: loadData, icon: const Icon(Icons.refresh)),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل البيانات...')
            : RefreshIndicator(
                onRefresh: loadData,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    AlshaariPageHeader(
                      title: 'سند التسوية الموحد',
                      subtitle:
                          'إثبات أو تسوية الذمم والمخزون والتكاليف غير النقدية.',
                      icon: Icons.balance_outlined,
                    ),
                    const SizedBox(height: 12),
                    Form(
                      key: formKey,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          AlshaariSectionCard(
                            title: 'بيانات السند',
                            icon: Icons.edit_note_outlined,
                            child: Column(
                              children: [
                                DropdownButtonFormField<String>(
                                  initialValue: settlementType,
                                  decoration: const InputDecoration(
                                      labelText: 'نوع التسوية'),
                                  items:
                                      settlementTypes.map(stringItem).toList(),
                                  onChanged: (value) => setState(() =>
                                      settlementType =
                                          value ?? 'general_adjustment'),
                                ),
                                if (settlementType ==
                                    'worker_advance_settlement') ...[
                                  const SizedBox(height: 10),
                                  DropdownButtonFormField<String>(
                                    initialValue: settlementSubtype,
                                    decoration: const InputDecoration(
                                        labelText: 'تفصيل تسوية السلفة',
                                        hintText:
                                            'اختر نوع التأثير على السلفة'),
                                    items:
                                        workerSubtypes.map(stringItem).toList(),
                                    onChanged: (value) => setState(
                                        () => settlementSubtype = value),
                                    validator: (v) => v == null
                                        ? 'مطلوب عند تسوية السلف'
                                        : null,
                                  ),
                                ],
                                const SizedBox(height: 12),
                                TextFormField(
                                  controller: dateController,
                                  decoration: const InputDecoration(
                                      labelText: 'التاريخ'),
                                  validator: (value) =>
                                      (value ?? '').trim().isEmpty
                                          ? 'أدخل التاريخ'
                                          : null,
                                ),
                                const SizedBox(height: 10),
                                TextFormField(
                                  controller: descriptionController,
                                  maxLines: 3,
                                  decoration: const InputDecoration(
                                      labelText: 'البيان'),
                                  validator: (value) =>
                                      (value ?? '').trim().length < 5
                                          ? 'اكتب بيانًا واضحًا'
                                          : null,
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 12),
                          ...List.generate(lines.length,
                              (index) => lineCard(index, lines[index])),
                          OutlinedButton.icon(
                            onPressed: addLine,
                            icon: const Icon(Icons.add),
                            label: const Text('إضافة سطر قيد'),
                          ),
                          const SizedBox(height: 12),
                          totalsCard(),
                          const SizedBox(height: 12),
                          FilledButton.icon(
                            onPressed: saving || difference().abs() > .009
                                ? null
                                : saveDraft,
                            icon: saving
                                ? const SizedBox(
                                    width: 18,
                                    height: 18,
                                    child: CircularProgressIndicator(
                                        strokeWidth: 2))
                                : const Icon(Icons.save),
                            label:
                                Text(saving ? 'جاري الحفظ...' : 'حفظ كمسودة'),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 18),
                    AlshaariSectionCard(
                      title: 'سندات التسوية',
                      subtitle:
                          'السندات المعتمدة تنشئ قيودًا محاسبية ولا تعدل إلا بسند عكسي.',
                      icon: Icons.fact_check_outlined,
                      child: vouchers.isEmpty
                          ? const AlshaariEmptyState(
                              title: 'لا توجد سندات تسوية')
                          : Column(
                              children: vouchers.map((raw) {
                                return voucherCard(
                                    Map<String, dynamic>.from(raw as Map));
                              }).toList(),
                            ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}

class _SummaryLine extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _SummaryLine(this.label, this.value, this.color);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          Expanded(child: Text(label)),
          Text(value,
              style: TextStyle(color: color, fontWeight: FontWeight.w900)),
        ],
      ),
    );
  }
}
