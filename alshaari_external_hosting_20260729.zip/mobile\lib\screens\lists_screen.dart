import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import 'project_profitability_screen.dart';
import 'party_statement_screen.dart';

class ListsScreen extends StatefulWidget {
  const ListsScreen({super.key});
  @override
  State<ListsScreen> createState() => _ListsScreenState();
}

class _ListsScreenState extends State<ListsScreen> {
  int refreshKey = 0;
  Future<List<dynamic>> fetch(String path) async => (await apiClient.dio.get(path)).data as List<dynamic>;

  Future<void> approve(int id) async { try { await apiClient.dio.patch('/transactions/$id/approve'); if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(TextSnack('تم اعتماد الحركة رقم $id')); setState(() => refreshKey++); } catch(e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(TextSnack('فشل الاعتماد: $e')); } }
  Future<void> reject(int id) async { try { await apiClient.dio.patch('/transactions/$id/reject'); if (!mounted) return; ScaffoldMessenger.of(context).showSnackBar(TextSnack('تم رفض الحركة رقم $id')); setState(() => refreshKey++); } catch(e) { if (mounted) ScaffoldMessenger.of(context).showSnackBar(TextSnack('فشل الرفض: $e')); } }

  SnackBar TextSnack(String s) => SnackBar(content: Text(s));

  Widget simpleList(String path, {void Function(Map<String,dynamic>)? onTap}) {
    return FutureBuilder<List<dynamic>>(key: ValueKey('$path-$refreshKey'), future: fetch(path), builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final items = snap.data!;
      if (items.isEmpty) return const Center(child: Text('لا توجد بيانات'));
      return ListView.separated(itemCount: items.length, separatorBuilder: (_,__) => const Divider(height:1), itemBuilder: (_, i) {
        final e = Map<String,dynamic>.from(items[i] as Map);
        final title = e['name'] ?? e['project_code'] ?? e['code'] ?? e['type'] ?? 'عنصر';
        final sub = e['code'] != null ? 'ID: ${e['id']} | كود: ${e['code']} | رصيد: ${e['current_qty'] ?? ''}' : 'ID: ${e['id']}';
        return ListTile(title: Text('$title'), subtitle: Text(sub), trailing: const Icon(Icons.chevron_left), onTap: onTap == null ? null : () => onTap(e));
      });
    });
  }

  Widget transactionsList() {
    return FutureBuilder<List<dynamic>>(key: ValueKey('tx-$refreshKey'), future: fetch('/transactions'), builder: (context, snap) {
      if (!snap.hasData) return const Center(child: CircularProgressIndicator());
      final items = snap.data!;
      if (items.isEmpty) return const Center(child: Text('لا توجد حركات'));
      return ListView.separated(itemCount: items.length, separatorBuilder: (_,__) => const Divider(height:1), itemBuilder: (_, i) {
        final e = Map<String,dynamic>.from(items[i] as Map);
        final id = e['id'] as int;
        final status = '${e['status']}';
        return Card(margin: const EdgeInsets.all(8), child: Padding(padding: const EdgeInsets.all(10), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [Expanded(child: Text('#$id - ${e['type']}', style: const TextStyle(fontWeight: FontWeight.bold))), Chip(label: Text(status))]),
          Text('المبلغ: ${e['amount']} ${e['currency'] ?? ''}'),
          Text('المشروع: ${e['project_id'] ?? '-'} | المادة: ${e['item_id'] ?? '-'} | الكمية: ${e['qty'] ?? 0}'),
          if ((e['description'] ?? '').toString().isNotEmpty) Text('البيان: ${e['description']}'),
          if (status == 'draft') Row(children: [Expanded(child: FilledButton(onPressed: () => approve(id), child: const Text('اعتماد'))), const SizedBox(width: 8), Expanded(child: OutlinedButton(onPressed: () => reject(id), child: const Text('رفض')))]),
        ])));
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: ui.TextDirection.rtl, child: DefaultTabController(length: 7, child: Scaffold(appBar: AppBar(title: const Text('البيانات والتقارير'), actions: [IconButton(onPressed: () => setState(() => refreshKey++), icon: const Icon(Icons.refresh))], bottom: const TabBar(isScrollable: true, tabs: [Tab(text:'المشاريع'), Tab(text:'العملاء'), Tab(text:'الموردين'), Tab(text:'العمال'), Tab(text:'المخزون'), Tab(text:'الحسابات'), Tab(text:'الحركات') ])), body: TabBarView(children: [
      simpleList('/projects', onTap: (e) => Navigator.push(context, MaterialPageRoute(builder: (_) => ProjectProfitabilityScreen(projectId: e['id'] as int)))),
      simpleList('/customers', onTap: (e) => Navigator.push(context, MaterialPageRoute(builder: (_) => PartyStatementScreen(type: 'customer', id: e['id'] as int, title: 'كشف حساب عميل')))),
      simpleList('/suppliers', onTap: (e) => Navigator.push(context, MaterialPageRoute(builder: (_) => PartyStatementScreen(type: 'supplier', id: e['id'] as int, title: 'كشف حساب مورد')))),
      simpleList('/workers', onTap: (e) => Navigator.push(context, MaterialPageRoute(builder: (_) => PartyStatementScreen(type: 'worker', id: e['id'] as int, title: 'كشف عامل/عهد')))),
      simpleList('/items'),
      simpleList('/accounts'),
      transactionsList(),
    ]))));
  }
}
