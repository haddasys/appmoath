package com.example.alshaari_finance_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
