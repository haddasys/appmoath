import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../config.dart';

class ApiClient {
  late final Dio dio;
  String? token;

  ApiClient() {
    dio = Dio(BaseOptions(
      baseUrl: apiBaseUrl,
      connectTimeout: const Duration(seconds: 15),
      receiveTimeout: const Duration(seconds: 15),
      headers: {'Content-Type': 'application/json'},
    ));
  }

  static String get apiBaseUrl {
    return '${AppConfig.apiBaseUrl}/api/v1';
  }

  Future<void> loadToken() async {
    final sp = await SharedPreferences.getInstance();
    token = sp.getString('token');
    if (token != null) setToken(token!);
  }

  Future<void> setToken(String value) async {
    token = value;
    dio.options.headers['Authorization'] = 'Bearer $value';
    final sp = await SharedPreferences.getInstance();
    await sp.setString('token', value);
  }

  Future<void> setSession({
    required String token,
    String? role,
    String? name,
    List<String>? permissions,
  }) async {
    await setToken(token);
    final sp = await SharedPreferences.getInstance();
    if (role != null && role.trim().isNotEmpty) {
      await sp.setString('role', role);
    }
    if (name != null && name.trim().isNotEmpty) {
      await sp.setString('user_name', name);
    }
    if (permissions != null) {
      await sp.setString('permissions', jsonEncode(permissions));
    }
  }

  Future<void> clearToken() async {
    token = null;
    dio.options.headers.remove('Authorization');
    final sp = await SharedPreferences.getInstance();
    await sp.remove('token');
    await sp.remove('role');
    await sp.remove('user_role');
    await sp.remove('current_user_role');
    await sp.remove('user_name');
    await sp.remove('permissions');
  }
}

final apiClient = ApiClient();
