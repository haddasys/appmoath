import 'package:flutter/material.dart';
import '../core/api_client.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});
  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final phone = TextEditingController(text: '777017187');
  final password = TextEditingController(text: '12345678');
  bool loading = false;
  String? error;

  Future<void> login() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final res = await apiClient.dio.post('/auth/login', data: {
        'phone': phone.text.trim(),
        'password': password.text,
      });
      final payload = Map<String, dynamic>.from(res.data as Map);
      await apiClient.setSession(
        token: '${payload['access_token']}',
        role: payload['role']?.toString(),
        name: payload['name']?.toString(),
        permissions:
            (payload['permissions'] as List?)?.map((item) => '$item').toList(),
      );
      if (!mounted) return;
      Navigator.pushReplacementNamed(context, '/dashboard');
    } catch (e) {
      setState(() {
        error = 'فشل تسجيل الدخول. تأكد أن Backend يعمل.';
      });
    } finally {
      setState(() {
        loading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Icon(Icons.account_balance_wallet, size: 72),
                  const SizedBox(height: 16),
                  const Text('نظام الشعري المالي',
                      textAlign: TextAlign.center,
                      style:
                          TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 32),
                  TextField(
                      controller: phone,
                      keyboardType: TextInputType.phone,
                      decoration: const InputDecoration(
                          labelText: 'رقم الهاتف',
                          border: OutlineInputBorder())),
                  const SizedBox(height: 12),
                  TextField(
                      controller: password,
                      obscureText: true,
                      decoration: const InputDecoration(
                          labelText: 'كلمة المرور',
                          border: OutlineInputBorder())),
                  if (error != null)
                    Padding(
                        padding: const EdgeInsets.only(top: 12),
                        child: Text(error!,
                            style: const TextStyle(color: Colors.red))),
                  const SizedBox(height: 20),
                  FilledButton(
                      onPressed: loading ? null : login,
                      child: Text(loading ? 'جاري الدخول...' : 'دخول')),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
