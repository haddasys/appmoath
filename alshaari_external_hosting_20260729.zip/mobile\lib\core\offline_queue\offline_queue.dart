import 'dart:convert';

import '../local_db/local_database.dart';
import '../local_db/local_entities.dart';
import '../local_db/local_record.dart';
import 'sync_queue_item.dart';

class OfflineDraftResult {
  final String localUuid;
  final String temporaryNo;

  const OfflineDraftResult({
    required this.localUuid,
    required this.temporaryNo,
  });
}

class OfflineQueue {
  final LocalDatabase database;

  const OfflineQueue({required this.database});

  Future<OfflineDraftResult> enqueueCreate({
    required String entityType,
    required String documentType,
    required String temporaryPrefix,
    required Map<String, dynamic> payload,
  }) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final localUuid = database.newLocalUuid(entityType);
    final temporaryNo = await database.nextTemporaryNo(
      documentType,
      temporaryPrefix,
    );
    final enrichedPayload = <String, dynamic>{
      ...payload,
      'local_uuid': localUuid,
      'temporary_document_no': temporaryNo,
      'sync_status': 'pending_sync',
      'created_offline': true,
    };
    final payloadJson = jsonEncode(enrichedPayload);

    await database.upsertLocalRecord(
      LocalRecord(
        localUuid: localUuid,
        entityType: entityType,
        temporaryNo: temporaryNo,
        payloadJson: payloadJson,
        syncStatus: 'pending',
        createdAt: now,
        updatedAt: now,
      ),
    );

    if (entityType == 'transaction' || entityType == 'transactions') {
      await database.upsertLocalTransaction(
        LocalTransactionDraft.fromPayload(
          localUuid: localUuid,
          temporaryNo: temporaryNo,
          payload: enrichedPayload,
          now: now,
        ),
      );
    } else if (entityType == 'attendance_bulk' ||
        entityType == 'bulk_attendance') {
      await _storeBulkAttendanceDrafts(
        localUuid: localUuid,
        payload: enrichedPayload,
        now: now,
        syncStatus: 'pending',
      );
    }

    await database.upsertQueueItem(
      SyncQueueItem(
        id: database.newLocalUuid('sync_queue'),
        localId: localUuid,
        entityType: entityType,
        operation: 'create',
        payloadJson: payloadJson,
        status: 'pending',
        retryCount: 0,
        createdAt: now,
        updatedAt: now,
      ),
    );

    return OfflineDraftResult(
      localUuid: localUuid,
      temporaryNo: temporaryNo,
    );
  }

  Future<OfflineDraftResult> cacheSyncedCreate({
    required String entityType,
    required String documentType,
    required String temporaryPrefix,
    required Map<String, dynamic> payload,
    Map<String, dynamic>? serverResponse,
  }) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final serverId = _extractServerId(serverResponse);
    final officialNo = _extractOfficialNo(serverResponse);
    final localUuid = serverResponse?['local_uuid']?.toString() ??
        database.newLocalUuid(entityType);
    final temporaryNo = officialNo ??
        await database.nextTemporaryNo(
          documentType,
          temporaryPrefix,
        );
    final enrichedPayload = <String, dynamic>{
      ...payload,
      'local_uuid': localUuid,
      'temporary_document_no': temporaryNo,
      if (officialNo != null) 'official_document_no': officialNo,
      if (serverId != null) 'server_id': serverId,
      'sync_status': 'synced',
      'created_offline': false,
    };
    final payloadJson = jsonEncode(enrichedPayload);

    await database.upsertLocalRecord(
      LocalRecord(
        localUuid: localUuid,
        entityType: entityType,
        temporaryNo: temporaryNo,
        payloadJson: payloadJson,
        syncStatus: 'synced',
        serverId: serverId,
        officialDocumentNo: officialNo,
        createdAt: now,
        updatedAt: now,
      ),
    );

    if (entityType == 'transaction' || entityType == 'transactions') {
      await database.upsertLocalTransaction(
        LocalTransactionDraft.fromPayload(
          localUuid: localUuid,
          temporaryNo: temporaryNo,
          payload: enrichedPayload,
          now: now,
          status: 'synced',
          createdOffline: false,
          serverId: serverId,
          officialNo: officialNo,
          syncedAt: now,
        ),
      );
    } else if (entityType == 'attendance_bulk' ||
        entityType == 'bulk_attendance') {
      await _storeBulkAttendanceDrafts(
        localUuid: localUuid,
        payload: enrichedPayload,
        now: now,
        syncStatus: 'synced',
        syncedAt: now,
      );
    }

    return OfflineDraftResult(
      localUuid: localUuid,
      temporaryNo: temporaryNo,
    );
  }

  int? _extractServerId(Map<String, dynamic>? response) {
    if (response == null) return null;
    final data = response['data'];
    final raw = response['server_id'] ?? response['id'];
    if (raw is int) return raw;
    if (data is Map) {
      final nested = data['server_id'] ?? data['id'];
      if (nested is int) return nested;
    }
    return null;
  }

  String? _extractOfficialNo(Map<String, dynamic>? response) {
    if (response == null) return null;
    final data = response['data'];
    final raw = response['official_document_no'] ??
        response['official_no'] ??
        response['voucher_no'] ??
        response['document_no'] ??
        response['transaction_no'];
    if (raw != null) return raw.toString();
    if (data is Map) {
      final nested = data['official_document_no'] ??
          data['official_no'] ??
          data['voucher_no'] ??
          data['document_no'] ??
          data['transaction_no'];
      if (nested != null) return nested.toString();
    }
    return null;
  }

  Future<void> _storeBulkAttendanceDrafts({
    required String localUuid,
    required Map<String, dynamic> payload,
    required int now,
    required String syncStatus,
    int? syncedAt,
  }) async {
    final records = payload['records'];
    if (records is! List) return;
    final attendanceDate = '${payload['date'] ?? ''}';
    final projectId = _intOrNull(payload['project_id']);
    final costCenterId = _intOrNull(payload['cost_center_id']);
    for (final rawRecord in records) {
      if (rawRecord is! Map) continue;
      final record = Map<String, dynamic>.from(rawRecord);
      final employeeId = _intOrNull(record['employee_id']);
      if (employeeId == null) continue;
      final rowPayload = <String, dynamic>{
        ...payload,
        'parent_local_uuid': localUuid,
        'record': record,
      };
      await database.upsertLocalAttendance(
        LocalAttendanceDraft(
          localUuid: '$localUuid-$employeeId',
          employeeId: employeeId,
          attendanceDate: attendanceDate,
          status: '${record['status'] ?? 'present'}',
          projectId: _intOrNull(record['project_id']) ?? projectId,
          costCenterId: _intOrNull(record['cost_center_id']) ?? costCenterId,
          notes: record['notes']?.toString(),
          syncStatus: syncStatus,
          payloadJson: jsonEncode(rowPayload),
          createdAt: now,
          updatedAt: now,
          syncedAt: syncedAt,
        ),
      );
    }
  }

  int? _intOrNull(dynamic value) {
    if (value == null) return null;
    if (value is int) return value;
    return int.tryParse('$value');
  }
}

final offlineQueue = OfflineQueue(database: localDatabase);
