from datetime import date, datetime

from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.db.database import engine
from app.models.models import DocumentSequence


DEFAULT_PREFIXES = {
    "cash_receipt": "ASH-RCV",
    "cash_payment": "ASH-PAY",
    "cash_transfer": "ASH-TRF",
    "advance_payment": "ASH-ADV",
    "settlement_voucher": "ASH-SET",
    "adjustment_voucher": "ASH-ADJ",
    "sales_invoice": "ASH-SINV",
    "supplier_invoice": "ASH-PINV",
    "purchase_request": "ASH-PR",
    "purchase_order": "ASH-PO",
    "goods_receipt": "ASH-GRN",
    "inventory_issue": "ASH-ISS",
    "inventory_adjustment": "ASH-INVADJ",
    "payroll": "ASH-PRL",
    "supplier_payment": "ASH-SPV",
    "journal_entry": "ASH-JE",
    # Compatibility keys used by older services.
    "transaction": "ASH-DOC",
    "invoice": "ASH-SINV",
    "production_order": "ASH-PRD",
}


TRANSACTION_DOCUMENT_TYPES = {
    "receipt_from_customer": "cash_receipt",
    "cash_receipt": "cash_receipt",
    "customer_payment": "cash_receipt",
    "customer_advance": "cash_receipt",
    "general_payment": "cash_payment",
    "cash_payment": "cash_payment",
    "project_expense": "cash_payment",
    "material_purchase": "cash_payment",
    "worker_wage": "cash_payment",
    "supplier_advance": "supplier_payment",
    "supplier_payment": "supplier_payment",
    "cash_transfer": "cash_transfer",
    "advance_payment": "advance_payment",
    "advance_settlement": "settlement_voucher",
    "material_issue_to_project": "inventory_issue",
    "inventory_adjustment": "inventory_adjustment",
    "customer_invoice": "sales_invoice",
    "supplier_invoice": "supplier_invoice",
}


def _has_table(db: Session, table_name: str) -> bool:
    return inspect(db.get_bind()).has_table(table_name)


def _columns(db: Session, table_name: str) -> set[str]:
    if not _has_table(db, table_name):
        return set()
    return {column["name"] for column in inspect(db.get_bind()).get_columns(table_name)}


def _add_column_if_missing(db: Session, table_name: str, column_name: str, definition: str) -> None:
    if _has_table(db, table_name) and column_name not in _columns(db, table_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def ensure_document_sequence_schema(db: Session) -> None:
    DocumentSequence.__table__.create(bind=engine, checkfirst=True)

    _add_column_if_missing(db, "document_sequences", "year", "INTEGER")
    _add_column_if_missing(db, "document_sequences", "padding_length", "INTEGER DEFAULT 4")
    _add_column_if_missing(db, "document_sequences", "created_at", "TIMESTAMP")
    _add_column_if_missing(db, "document_sequences", "updated_at", "TIMESTAMP")

    _add_column_if_missing(db, "transactions", "voucher_no", "VARCHAR(80)")
    _add_column_if_missing(db, "journal_entries", "entry_no", "VARCHAR(80)")
    _add_column_if_missing(db, "supplier_invoices", "internal_invoice_no", "VARCHAR(80)")
    _add_column_if_missing(db, "supplier_payments", "payment_no", "VARCHAR(80)")
    _add_column_if_missing(db, "purchase_requests", "request_no", "VARCHAR(80)")
    _add_column_if_missing(db, "purchase_orders", "po_no", "VARCHAR(80)")
    _add_column_if_missing(db, "goods_receipts", "grn_no", "VARCHAR(80)")
    _add_column_if_missing(db, "settlement_vouchers", "voucher_no", "VARCHAR(80)")
    _add_column_if_missing(db, "payrolls", "payroll_no", "VARCHAR(80)")

    for document_type, prefix in DEFAULT_PREFIXES.items():
        seq = db.query(DocumentSequence).filter(DocumentSequence.document_type == document_type).first()
        if seq:
            if not getattr(seq, "prefix", None) or seq.prefix in {"TX", "JE", "RV", "PV", "INV", "PO"}:
                seq.prefix = prefix
            if not getattr(seq, "year", None):
                seq.year = date.today().year
            if not getattr(seq, "padding_length", None):
                seq.padding_length = getattr(seq, "padding", None) or 4
            if not getattr(seq, "padding", None):
                seq.padding = seq.padding_length or 4
            seq.is_active = True
        else:
            db.add(
                DocumentSequence(
                    document_type=document_type,
                    prefix=prefix,
                    year=date.today().year,
                    next_number=1,
                    padding=4,
                    padding_length=4,
                    is_active=True,
                )
            )
    db.commit()


def document_type_for_transaction(operation_type: str | None) -> str:
    return TRANSACTION_DOCUMENT_TYPES.get(operation_type or "", "transaction")


def _document_year(document_date=None) -> int:
    if isinstance(document_date, datetime):
        return document_date.year
    if isinstance(document_date, date):
        return document_date.year
    return date.today().year


def ensure_sequence(
    db: Session,
    document_type: str,
    document_date=None,
    prefix: str | None = None,
) -> DocumentSequence:
    year = _document_year(document_date)
    desired_prefix = prefix or DEFAULT_PREFIXES.get(document_type, document_type[:3].upper())
    seq = (
        db.query(DocumentSequence)
        .filter(DocumentSequence.document_type == document_type)
        .with_for_update()
        .first()
    )

    if not seq:
        seq = DocumentSequence(
            document_type=document_type,
            prefix=desired_prefix,
            year=year,
            next_number=1,
            padding=4,
            padding_length=4,
            is_active=True,
        )
        db.add(seq)
        db.flush()
        return seq

    if seq.prefix != desired_prefix:
        seq.prefix = desired_prefix
    if getattr(seq, "year", None) != year:
        seq.year = year
        seq.next_number = 1
    if not getattr(seq, "padding_length", None):
        seq.padding_length = getattr(seq, "padding", None) or 4
    if not getattr(seq, "padding", None):
        seq.padding = seq.padding_length or 4
    seq.is_active = True
    return seq


def next_document_no(
    db: Session,
    document_type: str,
    document_date=None,
    prefix: str | None = None,
) -> str:
    seq = ensure_sequence(db, document_type, document_date=document_date, prefix=prefix)
    year = getattr(seq, "year", None) or _document_year(document_date)
    padding = getattr(seq, "padding_length", None) or getattr(seq, "padding", None) or 4
    value = f"{seq.prefix}-{year}-{seq.next_number:0{padding}d}"
    seq.next_number += 1
    seq.updated_at = datetime.utcnow()
    db.flush()
    return value
