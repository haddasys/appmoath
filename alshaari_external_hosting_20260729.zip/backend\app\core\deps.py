from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import decode_token
from app.db.database import get_db
from app.models.models import Permission, User

security = HTTPBearer()

ROLE_MANAGER = "manager"
ROLE_ACCOUNTANT_ADMIN = "accountant_admin"
ROLE_ACCOUNTANT = "accountant"
ROLE_PURCHASING = "purchasing"
ROLE_PRODUCTION = "production"
ROLE_DATA_ENTRY = "data_entry"
ROLE_INVENTORY = "inventory"
ROLE_CASHIER = "cashier"
ROLE_READ_ONLY = "read_only"

ROLE_ALIASES = {
    "general_manager": ROLE_MANAGER,
    "accounting_manager": ROLE_ACCOUNTANT_ADMIN,
    "chief_accountant": ROLE_ACCOUNTANT_ADMIN,
    "المدير العام": ROLE_MANAGER,
    "محاسب مدير": ROLE_ACCOUNTANT_ADMIN,
    "المحاسب الرئيسي": ROLE_ACCOUNTANT_ADMIN,
    "المحاسب": ROLE_ACCOUNTANT,
    "مسؤول المشتريات": ROLE_PURCHASING,
    "مسؤول المخزون": ROLE_INVENTORY,
    "مسؤول الإنتاج": ROLE_PRODUCTION,
    "أمين الصندوق": ROLE_CASHIER,
    "مدخل بيانات": ROLE_DATA_ENTRY,
    "مشاهد فقط": ROLE_READ_ONLY,
}

ROLE_PERMISSION_FALLBACKS = {
    ROLE_MANAGER: {"*"},
    ROLE_ACCOUNTANT_ADMIN: {
        "master_data.write",
        "suppliers.write",
        "purchases.write",
        "inventory.write",
        "materials.issue",
        "transactions.write",
        "transactions.approve",
        "transactions.reverse",
        "payroll.write",
        "payroll.approve",
        "payroll.pay",
        "approve_adjustment_journal",
        "manage_settlements",
        "approve_supplier_invoice",
        "approve_supplier_payment",
        "approve_inventory_adjustment",
        "close_period",
        "open_closed_period",
        "reports.view",
        "reports.print",
    },
    ROLE_ACCOUNTANT: {
        "master_data.write",
        "suppliers.write",
        "purchases.write",
        "inventory.write",
        "materials.issue",
        "transactions.write",
        "transactions.approve",
        "transactions.reverse",
        "payroll.write",
        "payroll.approve",
        "payroll.pay",
        "approve_adjustment_journal",
        "manage_settlements",
        "approve_supplier_invoice",
        "approve_supplier_payment",
        "approve_inventory_adjustment",
        "close_period",
        "reports.view",
        "reports.print",
    },
    ROLE_PURCHASING: {
        "purchases.write",
        "suppliers.write",
        "reports.view",
    },
    ROLE_INVENTORY: {
        "inventory.write",
        "materials.issue",
        "reports.view",
    },
    ROLE_CASHIER: {
        "transactions.write",
        "cashbox.write",
        "reports.view",
    },
    ROLE_PRODUCTION: {
        "projects.write",
        "project_costs.write",
        "reports.view",
    },
    ROLE_DATA_ENTRY: {
        "master_data.write",
        "transactions.write",
        "invoices.write",
        "reports.view",
    },
    ROLE_READ_ONLY: {"reports.view"},
}


def normalize_role(role: str | None) -> str:
    return ROLE_ALIASES.get(role or "", role or ROLE_DATA_ENTRY)


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db),
):
    payload = decode_token(credentials.credentials)
    if not payload:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="رمز الدخول غير صالح",
        )
    phone = payload.get("sub")
    user = db.query(User).filter(User.phone == phone, User.is_active == True).first()
    if not user:
        raise HTTPException(status_code=401, detail="المستخدم غير موجود")
    user.role = normalize_role(user.role)
    return user


def require_roles(*roles: str):
    allowed = {normalize_role(r) for r in roles}

    def checker(user: User = Depends(get_current_user)):
        if normalize_role(user.role) not in allowed:
            raise HTTPException(
                status_code=403,
                detail="لا تملك صلاحية تنفيذ هذه العملية",
            )
        return user

    return checker


def require_approval_role(user: User = Depends(get_current_user)):
    if normalize_role(user.role) not in {ROLE_MANAGER, ROLE_ACCOUNTANT_ADMIN, ROLE_ACCOUNTANT}:
        raise HTTPException(status_code=403, detail="لا تملك صلاحية الاعتماد")
    return user


# Backward compatibility with legacy routes.
def require_manager_or_accountant(user: User = Depends(get_current_user)):
    if normalize_role(user.role) not in {ROLE_MANAGER, ROLE_ACCOUNTANT_ADMIN, ROLE_ACCOUNTANT}:
        raise HTTPException(status_code=403, detail="لا تملك صلاحية الاعتماد")
    return user


def user_has_permission(db: Session, user: User, permission: str) -> bool:
    role = normalize_role(getattr(user, "role", None))
    fallback = ROLE_PERMISSION_FALLBACKS.get(role, set())
    if "*" in fallback or permission in fallback:
        return True
    return (
        db.query(Permission)
        .filter(Permission.role_code == role, Permission.permission == permission)
        .first()
        is not None
    )


def permissions_for_user(db: Session, user: User) -> list[str]:
    role = normalize_role(getattr(user, "role", None))
    fallback = ROLE_PERMISSION_FALLBACKS.get(role, set())
    if "*" in fallback:
        return ["*"]
    stored = {
        row.permission
        for row in db.query(Permission).filter(Permission.role_code == role).all()
    }
    return sorted(fallback | stored)


def require_permission(permission: str):
    def checker(user: User = Depends(get_current_user), db: Session = Depends(get_db)):
        if not user_has_permission(db, user, permission):
            raise HTTPException(
                status_code=403,
                detail=f"لا تملك صلاحية تنفيذ هذه العملية: {permission}",
            )
        return user

    return checker
