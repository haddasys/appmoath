import '../network/api_client.dart';

class CompanyPrintProfile {
  final String companyName;
  final String legalName;
  final String phone;
  final String email;
  final String address;
  final String taxNumber;
  final String commercialRecord;
  final String defaultCurrency;
  final String primaryColor;
  final String secondaryColor;
  final String notes;

  const CompanyPrintProfile({
    required this.companyName,
    required this.legalName,
    required this.phone,
    required this.email,
    required this.address,
    required this.taxNumber,
    required this.commercialRecord,
    required this.defaultCurrency,
    required this.primaryColor,
    required this.secondaryColor,
    required this.notes,
  });

  factory CompanyPrintProfile.defaults() {
    return const CompanyPrintProfile(
      companyName: 'الشعري لحلول الأثاث المخصص والديكور',
      legalName: 'الشعري لحلول الأثاث المخصص والديكور',
      phone: '',
      email: '',
      address: '',
      taxNumber: '',
      commercialRecord: '',
      defaultCurrency: 'YER',
      primaryColor: '#B87E62',
      secondaryColor: '#1C1C1C',
      notes: '',
    );
  }

  factory CompanyPrintProfile.fromJson(Map<String, dynamic> json) {
    final defaults = CompanyPrintProfile.defaults();
    String value(String key, String fallback) {
      final raw = json[key];
      final text = raw == null ? '' : '$raw'.trim();
      return text.isEmpty ? fallback : text;
    }

    return CompanyPrintProfile(
      companyName: value('company_name', defaults.companyName),
      legalName: value('legal_name', defaults.legalName),
      phone: value('phone', defaults.phone),
      email: value('email', defaults.email),
      address: value('address', defaults.address),
      taxNumber: value('tax_number', defaults.taxNumber),
      commercialRecord: value('commercial_record', defaults.commercialRecord),
      defaultCurrency: value('default_currency', defaults.defaultCurrency),
      primaryColor: _safeColor(
        value('primary_color', defaults.primaryColor),
        defaults.primaryColor,
      ),
      secondaryColor: _safeColor(
        value('secondary_color', defaults.secondaryColor),
        defaults.secondaryColor,
      ),
      notes: value('notes', defaults.notes),
    );
  }

  String get displayName => legalName.isNotEmpty ? legalName : companyName;

  List<String> get infoLines {
    return [
      if (address.isNotEmpty) address,
      if (phone.isNotEmpty) 'هاتف: $phone',
      if (email.isNotEmpty) 'البريد: $email',
      if (taxNumber.isNotEmpty) 'الرقم الضريبي: $taxNumber',
      if (commercialRecord.isNotEmpty) 'السجل التجاري: $commercialRecord',
    ];
  }
}

Future<CompanyPrintProfile> loadCompanyPrintProfile() async {
  try {
    final response = await apiClient.dio.get('/settings/company');
    if (response.data is Map) {
      return CompanyPrintProfile.fromJson(
        Map<String, dynamic>.from(response.data as Map),
      );
    }
  } catch (_) {
    // Printing must remain available even if company settings are unavailable.
  }
  return CompanyPrintProfile.defaults();
}

String printHtmlEscape(Object? value) {
  return '${value ?? ''}'
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#39;');
}

String officialPrintHeader(
  CompanyPrintProfile profile,
  String title, {
  String? subtitle,
}) {
  final info = profile.infoLines
      .map((line) => '<div>${printHtmlEscape(line)}</div>')
      .join();
  final printedAt = DateTime.now().toIso8601String().substring(0, 10);
  final meta = subtitle ?? 'تاريخ الطباعة: $printedAt';

  return '''
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>${printHtmlEscape(title)}</title>
  <style>
    @page { size: A4; margin: 12mm; }
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: Cairo, Tahoma, Arial, sans-serif;
      color: #1C1C1C;
      background: #F4F1EA;
      font-size: 12px;
      line-height: 1.65;
    }
    .page {
      min-height: 277mm;
      padding: 22px;
      background: #fffdf8;
      border: 1px solid #D8C7B4;
      position: relative;
    }
    .page::before {
      content: "";
      position: absolute;
      inset: 10px;
      border: 1px solid #EFE4D6;
      pointer-events: none;
    }
    .head {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      gap: 20px;
      border-bottom: 2px solid ${profile.primaryColor};
      padding-bottom: 16px;
      margin-bottom: 18px;
      position: relative;
      z-index: 1;
    }
    .brand {
      display: flex;
      align-items: flex-start;
      gap: 12px;
    }
    .mark {
      width: 58px;
      height: 58px;
      display: grid;
      place-items: center;
      background: ${profile.secondaryColor};
      color: #fff;
      border: 2px solid ${profile.primaryColor};
      border-radius: 10px;
      font-size: 30px;
      font-weight: 900;
      line-height: 1;
    }
    h1, h2, h3 { margin: 0; }
    h1 { font-size: 20px; max-width: 390px; line-height: 1.45; }
    h2 { color: ${profile.primaryColor}; font-size: 24px; }
    h3 {
      margin-top: 18px;
      margin-bottom: 8px;
      font-size: 15px;
      color: ${profile.secondaryColor};
      border-right: 4px solid ${profile.primaryColor};
      padding-right: 8px;
    }
    .muted { color: #4F4F4F; font-size: 12px; line-height: 1.8; }
    .title { text-align: left; min-width: 230px; }
    .doc-meta {
      margin-top: 8px;
      display: inline-block;
      border: 1px solid #E5D9C8;
      border-radius: 8px;
      padding: 6px 10px;
      background: #F9F7F1;
      font-weight: 800;
      color: #4F4F4F;
    }
    .grid {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px;
      margin-bottom: 18px;
      position: relative;
      z-index: 1;
    }
    .box {
      border: 1px solid #E5D9C8;
      border-radius: 10px;
      padding: 12px;
      background: #F9F7F1;
      min-height: 72px;
    }
    .box b {
      display: block;
      font-size: 12px;
      color: #4F4F4F;
      margin-bottom: 5px;
    }
    .box span { font-weight: 900; font-size: 16px; }
    table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      margin-top: 10px;
      border: 1px solid #E5D9C8;
      border-radius: 10px;
      overflow: hidden;
      position: relative;
      z-index: 1;
    }
    th {
      background: ${profile.secondaryColor};
      color: #fff;
      padding: 10px;
      font-size: 12px;
      text-align: right;
    }
    td {
      padding: 10px;
      border-bottom: 1px solid #E5D9C8;
      font-size: 12px;
      vertical-align: top;
      background: #fff;
    }
    tr:last-child td { border-bottom: 0; }
    .amount { text-align: left; font-weight: 900; white-space: nowrap; }
    .ok { color: #2F7D57; font-weight: 900; }
    .warn { color: ${profile.primaryColor}; font-weight: 900; }
    .stamp {
      display: inline-block;
      border: 2px solid #2F7D57;
      color: #2F7D57;
      border-radius: 8px;
      padding: 6px 14px;
      font-weight: 900;
      transform: rotate(-4deg);
      margin-top: 10px;
    }
    .total {
      margin-top: 18px;
      margin-right: auto;
      width: 280px;
      border: 2px solid ${profile.primaryColor};
      border-radius: 10px;
      padding: 14px;
      display: flex;
      justify-content: space-between;
      font-size: 18px;
      font-weight: 900;
      position: relative;
      z-index: 1;
    }
    .notes {
      margin-top: 18px;
      min-height: 54px;
      border: 1px solid #E5D9C8;
      border-radius: 10px;
      padding: 12px;
      color: #4F4F4F;
      background: #fff;
      position: relative;
      z-index: 1;
    }
    .footer {
      margin-top: 34px;
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 24px;
      position: relative;
      z-index: 1;
    }
    .sign {
      height: 76px;
      border-top: 1px solid #4F4F4F;
      padding-top: 8px;
      color: #4F4F4F;
      margin-top: 46px;
      text-align: center;
    }
    .print-actions {
      position: fixed;
      top: 14px;
      left: 14px;
      display: flex;
      gap: 8px;
      z-index: 3;
    }
    .print-actions button {
      border: 0;
      border-radius: 8px;
      padding: 9px 14px;
      background: ${profile.primaryColor};
      color: #fff;
      font-weight: 800;
      cursor: pointer;
    }
    @media print {
      body { background: white; }
      .page { border: 0; padding: 0; min-height: auto; }
      .page::before { display: none; }
      .no-print, .print-actions { display: none; }
    }
  </style>
</head>
<body>
  <div class="print-actions no-print">
    <button onclick="window.print()">طباعة</button>
  </div>
  <div class="page">
    <div class="head">
      <div class="brand">
        <div class="mark">ش</div>
        <div>
          <h1>${printHtmlEscape(profile.displayName)}</h1>
          <div class="muted">$info</div>
        </div>
      </div>
      <div class="title">
        <h2>${printHtmlEscape(title)}</h2>
        <div class="doc-meta">${printHtmlEscape(meta)}</div>
      </div>
    </div>
''';
}

String officialPrintFooter() {
  return '''
    <div class="footer">
      <div class="sign">إعداد المحاسب</div>
      <div class="sign">مراجعة الإدارة</div>
      <div class="sign">الختم / الاعتماد</div>
    </div>
  </div>
  <script>window.addEventListener('load', () => window.print());</script>
</body>
</html>
''';
}

String _safeColor(String value, String fallback) {
  final pattern = RegExp(r'^#[0-9a-fA-F]{6}$');
  return pattern.hasMatch(value) ? value : fallback;
}
