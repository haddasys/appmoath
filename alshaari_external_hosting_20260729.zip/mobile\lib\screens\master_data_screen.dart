import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';

class MasterDataScreen extends StatefulWidget {
  const MasterDataScreen({super.key});
  @override
  State<MasterDataScreen> createState() => _MasterDataScreenState();
}

class _MasterDataScreenState extends State<MasterDataScreen> {
  int refreshKey = 0;
  Future<List<dynamic>> fetchList(String path) async => (await apiClient.dio.get(path)).data as List<dynamic>;
  void refresh() => setState(() => refreshKey++);
  void msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  Future<void> post(String path, Map<String, dynamic> data) async {
    try { await apiClient.dio.post(path, data: data); if (!mounted) return; Navigator.pop(context); msg('تم الحفظ بنجاح'); refresh(); }
    catch (e) { if (mounted) msg('فشل الحفظ: $e'); }
  }

  InputDecoration dec(String label) => InputDecoration(labelText: label, border: const OutlineInputBorder());
  TextFormField input(TextEditingController c, String label, {bool required = true, TextInputType type = TextInputType.text}) => TextFormField(controller: c, keyboardType: type, decoration: dec(label), validator: (v) => required && (v ?? '').trim().isEmpty ? 'هذا الحقل مطلوب' : null);

  Future<void> showSimpleForm(String title, List<Widget> fields, VoidCallback onSave) async {
    await showDialog(context: context, builder: (_) => Directionality(textDirection: ui.TextDirection.rtl, child: AlertDialog(title: Text(title), content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: fields)), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: onSave, child: const Text('حفظ'))])));
  }

  void customerForm() {
    final key = GlobalKey<FormState>(); final name = TextEditingController(); final phone = TextEditingController(); final address = TextEditingController(); final notes = TextEditingController();
    showSimpleForm('إضافة عميل', [Form(key: key, child: Column(children: [input(name,'اسم العميل'), const SizedBox(height:10), input(phone,'الهاتف', required:false), const SizedBox(height:10), input(address,'العنوان', required:false), const SizedBox(height:10), input(notes,'ملاحظات', required:false)]))], () { if (key.currentState!.validate()) post('/customers', {'name': name.text, 'phone': phone.text, 'address': address.text, 'notes': notes.text}); });
  }

  void supplierForm() {
    final key = GlobalKey<FormState>(); final name = TextEditingController(); final phone = TextEditingController(); final category = TextEditingController(); final notes = TextEditingController();
    showSimpleForm('إضافة مورد', [Form(key: key, child: Column(children: [input(name,'اسم المورد'), const SizedBox(height:10), input(phone,'الهاتف', required:false), const SizedBox(height:10), input(category,'نوع التوريد', required:false), const SizedBox(height:10), input(notes,'ملاحظات', required:false)]))], () { if (key.currentState!.validate()) post('/suppliers', {'name': name.text, 'phone': phone.text, 'category': category.text, 'notes': notes.text}); });
  }

  void workerForm() {
    final key = GlobalKey<FormState>(); final name = TextEditingController(); final phone = TextEditingController(); final daily = TextEditingController(text:'0'); final notes = TextEditingController();
    showSimpleForm('إضافة عامل', [Form(key: key, child: Column(children: [input(name,'اسم العامل'), const SizedBox(height:10), input(phone,'الهاتف', required:false), const SizedBox(height:10), input(daily,'الأجر اليومي', required:false, type: TextInputType.number), const SizedBox(height:10), input(notes,'ملاحظات', required:false)]))], () { if (key.currentState!.validate()) post('/workers', {'name': name.text, 'phone': phone.text, 'daily_wage': double.tryParse(daily.text) ?? 0, 'notes': notes.text}); });
  }

  void itemForm() {
    final key = GlobalKey<FormState>(); final code = TextEditingController(); final name = TextEditingController(); final unit = TextEditingController(text:'لوح'); final qty = TextEditingController(text:'0'); final avg = TextEditingController(text:'0'); final reorder = TextEditingController(text:'0');
    showSimpleForm('إضافة مادة مخزون', [Form(key: key, child: Column(children: [input(code,'كود المادة'), const SizedBox(height:10), input(name,'اسم المادة'), const SizedBox(height:10), input(unit,'الوحدة'), const SizedBox(height:10), input(qty,'الرصيد الحالي', type:TextInputType.number), const SizedBox(height:10), input(avg,'متوسط التكلفة', type:TextInputType.number), const SizedBox(height:10), input(reorder,'حد إعادة الطلب', type:TextInputType.number)]))], () { if (key.currentState!.validate()) post('/items', {'code': code.text, 'name': name.text, 'unit': unit.text, 'current_qty': double.tryParse(qty.text) ?? 0, 'avg_cost': double.tryParse(avg.text) ?? 0, 'reorder_level': double.tryParse(reorder.text) ?? 0}); });
  }

  Future<void> projectForm() async {
    final key = GlobalKey<FormState>(); final code = TextEditingController(); final name = TextEditingController(); final value = TextEditingController(text:'0'); final progress = TextEditingController(text:'0'); final notes = TextEditingController(); int? customerId; final customers = await fetchList('/customers'); if (!mounted) return;
    await showDialog(context: context, builder: (_) => StatefulBuilder(builder: (context, setLocal) => Directionality(textDirection: ui.TextDirection.rtl, child: AlertDialog(title: const Text('إضافة مشروع'), content: Form(key: key, child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [input(code,'رقم المشروع'), const SizedBox(height:10), input(name,'اسم المشروع'), const SizedBox(height:10), DropdownButtonFormField<int>(initialValue: customerId, decoration: dec('العميل'), items: customers.map((raw) { final e = Map<String,dynamic>.from(raw as Map); return DropdownMenuItem<int>(value: e['id'] as int, child: Text('${e['name']}')); }).toList(), onChanged: (v) => setLocal(() => customerId = v)), const SizedBox(height:10), input(value,'قيمة العقد', type:TextInputType.number), const SizedBox(height:10), input(progress,'نسبة الإنجاز %', required:false, type:TextInputType.number), const SizedBox(height:10), input(notes,'ملاحظات', required:false)]))), actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')), FilledButton(onPressed: () { if (key.currentState!.validate()) post('/projects', {'project_code': code.text, 'name': name.text, 'customer_id': customerId, 'contract_value': double.tryParse(value.text) ?? 0, 'status':'active', 'progress_percent': int.tryParse(progress.text) ?? 0, 'notes': notes.text}); }, child: const Text('حفظ'))]))));
  }

  Widget entityList(String title, String path, VoidCallback onAdd, String Function(Map<String,dynamic>) subtitle) {
    return Column(children: [Padding(padding: const EdgeInsets.all(12), child: SizedBox(width: double.infinity, child: FilledButton.icon(onPressed: onAdd, icon: const Icon(Icons.add), label: Text('إضافة $title')))), Expanded(child: FutureBuilder<List<dynamic>>(key: ValueKey('$path-$refreshKey'), future: fetchList(path), builder: (context, snap) { if (!snap.hasData) return const Center(child: CircularProgressIndicator()); final data = snap.data!; if (data.isEmpty) return Center(child: Text('لا توجد بيانات في $title')); return ListView.separated(itemCount: data.length, separatorBuilder: (_,__) => const Divider(height:1), itemBuilder: (_, i) { final e = Map<String,dynamic>.from(data[i] as Map); return ListTile(leading: CircleAvatar(child: Text('${e['id']}')), title: Text('${e['name'] ?? e['project_code'] ?? e['code'] ?? 'عنصر'}'), subtitle: Text(subtitle(e))); }); }))]);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: ui.TextDirection.rtl, child: DefaultTabController(length: 6, child: Scaffold(appBar: AppBar(title: const Text('إدارة البيانات الأساسية'), actions: [IconButton(onPressed: refresh, icon: const Icon(Icons.refresh))], bottom: const TabBar(isScrollable: true, tabs: [Tab(text:'الحسابات'), Tab(text:'العملاء'), Tab(text:'الموردين'), Tab(text:'العمال'), Tab(text:'المشاريع'), Tab(text:'المخزون') ])), body: TabBarView(children: [
      entityList('حساب', '/accounts', () => msg('إضافة الحسابات تتم من سكربت التأسيس حاليًا'), (e) => 'الكود: ${e['code']} | النوع: ${e['type']} | الرصيد: ${e['balance']}'),
      entityList('عميل', '/customers', customerForm, (e) => 'الهاتف: ${e['phone'] ?? '-'}'),
      entityList('مورد', '/suppliers', supplierForm, (e) => 'النوع: ${e['category'] ?? '-'} | الهاتف: ${e['phone'] ?? '-'}'),
      entityList('عامل', '/workers', workerForm, (e) => 'الأجر اليومي: ${e['daily_wage'] ?? 0}'),
      entityList('مشروع', '/projects', projectForm, (e) => 'الكود: ${e['project_code'] ?? '-'} | العقد: ${e['contract_value'] ?? 0}'),
      entityList('مادة', '/items', itemForm, (e) => 'الكود: ${e['code'] ?? '-'} | الرصيد: ${e['current_qty'] ?? 0} ${e['unit'] ?? ''}'),
    ]))));
  }
}
