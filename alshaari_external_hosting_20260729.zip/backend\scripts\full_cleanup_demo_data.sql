BEGIN;

-- Remove all operational/demo data while preserving system setup:
-- users, roles, permissions, chart of accounts, posting rules, settings.

DELETE FROM approvals;
DELETE FROM attachments;
DELETE FROM audit_logs;

DELETE FROM journal_entry_lines;
DELETE FROM journal_entries;

DELETE FROM project_costs;
DELETE FROM stock_movements;
DELETE FROM inventory_movements;

DELETE FROM purchase_items;
DELETE FROM purchases;
DELETE FROM invoices;

DELETE FROM transactions;
DELETE FROM cash_transactions;
DELETE FROM expenses;
DELETE FROM revenues;

DELETE FROM payrolls;
DELETE FROM attendance;
DELETE FROM advances;

DELETE FROM projects;
DELETE FROM workers;
DELETE FROM employees;
DELETE FROM customers;
DELETE FROM suppliers;
DELETE FROM items;
DELETE FROM inventory_items;
DELETE FROM cash_accounts;

UPDATE accounts
SET balance = 0;

COMMIT;
