from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.core.deps import get_current_user, require_approval_role
from app.models.models import Account, Customer, Supplier, Worker, Project, Item, Invoice, StockMovement
from app.schemas.schemas import AccountCreate, CustomerCreate, SupplierCreate, WorkerCreate, ProjectCreate, ItemCreate, InvoiceCreate, StockMovementCreate
from app.services.invoice_service import create_invoice, invoice_to_dict, post_invoice
from decimal import Decimal

router = APIRouter(tags=["Basic Data"])


def create_obj(db, model, data):
    obj = model(**data.model_dump())
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return obj


@router.post("/accounts")
def add_account(data: AccountCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    exists = db.query(Account).filter(Account.code == data.code).first()
    if exists:
        raise HTTPException(status_code=400, detail="كود الحساب موجود مسبقًا")
    return create_obj(db, Account, data)


@router.get("/accounts")
def list_accounts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Account).order_by(Account.code.asc()).all()


@router.post("/customers")
def add_customer(data: CustomerCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Customer, data)


@router.get("/customers")
def list_customers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Customer).order_by(Customer.id.desc()).all()


@router.get("/customers/{customer_id}/statement")
def customer_statement(customer_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoices = db.query(Invoice).filter(Invoice.invoice_type == "customer", Invoice.party_id == customer_id).all()
    total = sum(Decimal(i.total or 0) for i in invoices)
    paid = sum(Decimal(i.paid_amount or 0) for i in invoices)
    return {"customer_id": customer_id, "total_invoices": total, "paid": paid, "remaining": total - paid, "invoices": invoices}


@router.post("/suppliers")
def add_supplier(data: SupplierCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Supplier, data)


@router.get("/suppliers")
def list_suppliers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Supplier).order_by(Supplier.id.desc()).all()


@router.get("/suppliers/{supplier_id}/statement")
def supplier_statement(supplier_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoices = db.query(Invoice).filter(Invoice.invoice_type == "supplier", Invoice.party_id == supplier_id).all()
    total = sum(Decimal(i.total or 0) for i in invoices)
    paid = sum(Decimal(i.paid_amount or 0) for i in invoices)
    return {"supplier_id": supplier_id, "total_invoices": total, "paid": paid, "remaining": total - paid, "invoices": invoices}


@router.post("/workers")
def add_worker(data: WorkerCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Worker, data)


@router.get("/workers")
def list_workers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Worker).order_by(Worker.id.desc()).all()


@router.post("/projects")
def add_project(data: ProjectCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Project, data)


@router.get("/projects")
def list_projects(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Project).order_by(Project.id.desc()).all()


@router.post("/items")
def add_item(data: ItemCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    exists = db.query(Item).filter(Item.code == data.code).first()
    if exists:
        raise HTTPException(status_code=400, detail="كود المادة موجود مسبقًا")
    return create_obj(db, Item, data)


@router.get("/items")
def list_items(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Item).order_by(Item.code.asc()).all()


@router.get("/items/low-stock")
def low_stock(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Item).filter(Item.current_qty <= Item.reorder_level).order_by(Item.code.asc()).all()


@router.post("/invoices")
def add_invoice(data: InvoiceCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return invoice_to_dict(db, create_invoice(db, data, user.id))


@router.get("/invoices")
def list_invoices(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [invoice_to_dict(db, invoice) for invoice in db.query(Invoice).order_by(Invoice.id.desc()).all()]


@router.post("/invoices/{invoice_id}/post")
def post_basic_invoice(invoice_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return invoice_to_dict(db, post_invoice(db, invoice_id, user.id))


@router.post("/stock-movements")
def add_stock_movement(data: StockMovementCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    raise HTTPException(
        status_code=410,
        detail="تم إيقاف إدخال حركة مخزون مباشرة لأنه لا ينشئ قيدًا محاسبيًا. استخدم واجهات /api/v1/inventory المعتمدة",
    )


@router.get("/stock-movements")
def list_stock_movements(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(StockMovement).order_by(StockMovement.id.desc()).limit(300).all()
