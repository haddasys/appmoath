from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.api.v1.production import _ensure_project, ensure_production_tables
from app.core.deps import get_current_user
from app.db.database import get_db
from app.services.project_costing import (
    VALID_ESTIMATE_TYPES,
    ensure_project_costing_schema,
    project_cost_lines,
    project_profitability,
)

router = APIRouter(prefix="/api/v1", tags=["Projects"])


class ProjectEstimateCreate(BaseModel):
    estimate_type: str = Field(..., description="material/labor/service/direct_expense/other")
    description: str
    estimated_amount: float = Field(gt=0)
    notes: str | None = None


@router.get("/projects/{project_id}/costs")
def project_costs(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    ensure_project_costing_schema(db)
    _ensure_project(db, project_id)
    return project_profitability(db, project_id)


@router.get("/projects/{project_id}/profitability")
def project_profitability_view(
    project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)
):
    ensure_project_costing_schema(db)
    _ensure_project(db, project_id)
    return project_profitability(db, project_id)


@router.get("/projects/{project_id}/cost-lines")
def project_cost_lines_view(
    project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)
):
    ensure_project_costing_schema(db)
    _ensure_project(db, project_id)
    return project_cost_lines(db, project_id)


@router.get("/projects/{project_id}/estimate-comparison")
def project_estimate_comparison(
    project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)
):
    ensure_project_costing_schema(db)
    _ensure_project(db, project_id)
    return project_profitability(db, project_id)["comparison"]


@router.post("/projects/{project_id}/estimates")
def create_project_estimate(
    project_id: int,
    payload: ProjectEstimateCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_project_costing_schema(db)
    _ensure_project(db, project_id)
    if payload.estimate_type not in VALID_ESTIMATE_TYPES:
        raise HTTPException(status_code=400, detail="نوع التقدير غير صحيح")
    db.execute(
        text(
            """
        INSERT INTO project_estimates (
            project_id, estimate_type, description, estimated_amount, notes
        ) VALUES (
            :project_id, :estimate_type, :description, :estimated_amount, :notes
        )
        """,
        ),
        {
            "project_id": project_id,
            "estimate_type": payload.estimate_type,
            "description": payload.description,
            "estimated_amount": payload.estimated_amount,
            "notes": payload.notes,
        },
    )
    db.commit()
    return {"message": "تم حفظ تقدير تكلفة المشروع بنجاح"}
