from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, normalize_role
from app.db.database import get_db
from app.models.models import SupplierInvoice, Transaction

router = APIRouter(prefix="/api/v1", tags=["Settlements"])


ALL_OPTIONS = {
    "advance_settlement": {
        "label": "تسوية عهدة / سلفة عامل",
        "description": "إقفال أو تحميل عهدة عامل على أجر أو مشروع أو إرجاع نقدي.",
    },
    "adjustment_journal": {
        "label": "تسوية حسابية عامة",
        "description": "تصحيح حساب أو إثبات مستحق بدون حركة صندوق.",
    },
    "inventory_adjustment": {
        "label": "تسوية مخزون",
        "description": "تصحيح فرق جرد أو تلف أو نقص في المخزون.",
    },
    "supplier_adjustment": {
        "label": "تسوية مورد",
        "description": "تسوية فرق فاتورة أو خصم أو إشعار دائن لمورد.",
    },
    "customer_adjustment": {
        "label": "تسوية عميل",
        "description": "تسوية فرق حساب أو خصم أو إشعار دائن لعميل.",
    },
}

CONTEXT_OPTIONS = {
    "dashboard": list(ALL_OPTIONS),
    "worker": ["advance_settlement", "adjustment_journal"],
    "supplier": ["supplier_adjustment", "adjustment_journal"],
    "customer": ["customer_adjustment", "adjustment_journal"],
    "inventory": ["inventory_adjustment", "adjustment_journal"],
    "project": ["adjustment_journal", "inventory_adjustment", "advance_settlement"],
    "accounting": ["adjustment_journal", "advance_settlement"],
    "review": ["adjustment_journal", "advance_settlement"],
}

ROLE_ALLOWED = {
    "manager": set(ALL_OPTIONS),
    "accountant": set(ALL_OPTIONS),
    "accountant_admin": set(ALL_OPTIONS),
    "data_entry": set(ALL_OPTIONS),
    "inventory": {"inventory_adjustment", "adjustment_journal"},
    "purchasing": {"supplier_adjustment", "adjustment_journal"},
    "production": {"advance_settlement", "inventory_adjustment", "adjustment_journal"},
}

SETTLEMENT_TYPES = [
    {
        "value": "general_adjustment",
        "label": "تسوية حسابية عامة",
        "description": "تصحيح حساب أو إثبات مستحق بدون حركة صندوق.",
    },
    {
        "value": "worker_advance_settlement",
        "label": "تسوية سلفة / عهدة عامل",
        "description": "إقفال عهدة عامل أو تحميلها على أجر أو مشروع أو إرجاع نقدي.",
        "subtypes": [
            {"value": "wage_project", "label": "أجر مشروع"},
            {"value": "wage_general", "label": "أجر عام"},
            {"value": "expense_project", "label": "مصروف مشروع"},
            {"value": "cash_return", "label": "إرجاع نقدي"},
            {"value": "salary_deduction", "label": "خصم راتب"},
        ],
    },
    {
        "value": "supplier_settlement",
        "label": "تسوية مورد",
        "description": "تسوية فرق فاتورة أو خصم أو إشعار دائن لمورد.",
    },
    {
        "value": "customer_settlement",
        "label": "تسوية عميل",
        "description": "تسوية فرق حساب أو خصم أو إشعار دائن لعميل.",
    },
    {
        "value": "inventory_settlement",
        "label": "تسوية مخزون",
        "description": "إثبات فرق جرد أو تلف أو نقص أو زيادة مخزون.",
    },
    {
        "value": "project_cost_settlement",
        "label": "تسوية تكلفة مشروع",
        "description": "تحميل أو إعادة تصنيف تكلفة على مشروع ومركز تكلفة.",
    },
    {"value": "accrued_expense", "label": "إثبات مصروف مستحق"},
    {"value": "accrued_revenue", "label": "إثبات إيراد مستحق"},
    {"value": "reclassification", "label": "إعادة تصنيف"},
    {"value": "error_correction", "label": "تصحيح خطأ"},
    {"value": "opening_balance", "label": "رصيد افتتاحي"},
    {"value": "other", "label": "أخرى"},
]


def _money(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _worker_advance_balance(db: Session, worker_id: int | None) -> Decimal:
    if not worker_id:
        return Decimal("0")
    paid = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.type == "advance_payment",
            Transaction.status == "approved",
            Transaction.related_account_type == "worker",
            Transaction.related_id == worker_id,
        )
        .scalar()
    )
    settled = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.type == "advance_settlement",
            Transaction.status == "approved",
            Transaction.related_account_type == "worker",
            Transaction.related_id == worker_id,
        )
        .scalar()
    )
    return _money(paid) - _money(settled)


def _supplier_open_balance(db: Session, supplier_id: int | None) -> Decimal:
    if not supplier_id:
        return Decimal("0")
    total = (
        db.query(
            func.coalesce(
                func.sum(SupplierInvoice.net_amount - SupplierInvoice.paid_amount), 0
            )
        )
        .filter(
            SupplierInvoice.supplier_id == supplier_id,
            SupplierInvoice.status.notin_(["paid", "cancelled"]),
        )
        .scalar()
    )
    return _money(total)


def _enabled_for_role(option_type: str, role: str) -> tuple[bool, str | None]:
    allowed = ROLE_ALLOWED.get(role, {"adjustment_journal"})
    if option_type not in allowed:
        return False, "لا توجد صلاحية لهذا النوع من التسوية"
    if role in {"data_entry", "inventory", "production", "purchasing"}:
        return True, "متاح لإنشاء مسودة وتحتاج للاعتماد"
    return True, None


@router.get("/settlement-options")
def settlement_options(
    context_type: str = Query("dashboard"),
    context_id: int | None = Query(None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    context = (context_type or "dashboard").strip().lower()
    role = normalize_role(getattr(user, "role", None))
    option_types = CONTEXT_OPTIONS.get(context, CONTEXT_OPTIONS["dashboard"])
    options = []

    for option_type in option_types:
        base = ALL_OPTIONS[option_type]
        enabled, reason = _enabled_for_role(option_type, role)

        if enabled and context == "worker" and option_type == "advance_settlement":
            if _worker_advance_balance(db, context_id) <= 0:
                enabled = False
                reason = "لا توجد سلف أو عهد مفتوحة لهذا العامل"

        if enabled and context == "supplier" and option_type == "supplier_adjustment":
            if context_id and _supplier_open_balance(db, context_id) <= 0:
                reason = "لا توجد ذمم مفتوحة، ويمكن إنشاء تسوية عامة عند الحاجة"

        options.append(
            {
                "type": option_type,
                "label": base["label"],
                "description": base["description"],
                "enabled": enabled,
                "reason": reason,
            }
        )

    return options


@router.get("/settlement-types")
def settlement_types(user=Depends(get_current_user)):
    return SETTLEMENT_TYPES
