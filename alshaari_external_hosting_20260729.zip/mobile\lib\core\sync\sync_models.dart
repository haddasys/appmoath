class SyncRunSummary {
  final int attempted;
  final int synced;
  final int failed;
  final int conflict;

  const SyncRunSummary({
    required this.attempted,
    required this.synced,
    required this.failed,
    required this.conflict,
  });

  bool get hasWork => attempted > 0;
}

class SyncStatusSnapshot {
  final int pending;
  final int syncing;
  final int failed;
  final int conflict;
  final DateTime? lastSyncAt;

  const SyncStatusSnapshot({
    required this.pending,
    required this.syncing,
    required this.failed,
    required this.conflict,
    this.lastSyncAt,
  });
}
