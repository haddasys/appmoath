import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/widgets/alshaari_ui.dart';
import 'payroll_api.dart';

class EmployeeStatementScreen extends StatefulWidget {
  final int employeeId;

  const EmployeeStatementScreen({super.key, required this.employeeId});

  @override
  State<EmployeeStatementScreen> createState() =>
      _EmployeeStatementScreenState();
}

class _EmployeeStatementScreenState extends State<EmployeeStatementScreen> {
  bool loading = true;
  Map<String, dynamic>? statement;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final dio = await payrollDio();
      final res = await dio
          .get('/api/v1/reports/employee-statement/${widget.employeeId}');
      if (!mounted) return;
      setState(() {
        statement = Map<String, dynamic>.from(res.data as Map);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  @override
  Widget build(BuildContext context) {
    final employee =
        Map<String, dynamic>.from((statement?['employee'] ?? {}) as Map);
    final totals =
        Map<String, dynamic>.from((statement?['totals'] ?? {}) as Map);
    final rows = asList(statement?['rows'] ?? []);

    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('كشف حساب عامل'),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh))
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: load,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    AlshaariPageHeader(
                      title: '${employee['name'] ?? 'عامل'}',
                      subtitle:
                          'الأجور، السلف، التسويات، والدفعات المرتبطة بالعامل.',
                      icon: Icons.manage_search,
                    ),
                    const SizedBox(height: 12),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final cards = [
                          AlshaariStatCard(
                            title: 'إجمالي المستحق',
                            value: formatMoney(totals['total_net_due']),
                            icon: Icons.request_quote_outlined,
                            color: AlshaariColors.deepGreen,
                          ),
                          AlshaariStatCard(
                            title: 'السلف',
                            value: formatMoney(totals['total_advances']),
                            icon: Icons.assignment_ind_outlined,
                            color: AlshaariColors.warning,
                          ),
                          AlshaariStatCard(
                            title: 'المدفوع',
                            value: formatMoney(totals['total_paid']),
                            icon: Icons.payments_outlined,
                            color: AlshaariColors.success,
                          ),
                          AlshaariStatCard(
                            title: 'الرصيد',
                            value: formatMoney(totals['balance']),
                            icon: Icons.account_balance_wallet_outlined,
                            color: AlshaariColors.copper,
                          ),
                        ];
                        if (constraints.maxWidth < 720) {
                          return Column(
                            children: cards
                                .map((card) => Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: card))
                                .toList(),
                          );
                        }
                        return GridView.count(
                          crossAxisCount: 4,
                          childAspectRatio: 2.2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                          children: cards,
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    AlshaariSectionCard(
                      title: 'حركة العامل',
                      icon: Icons.list_alt,
                      child: rows.isEmpty
                          ? const Text('لا توجد حركة لهذا العامل.')
                          : Column(
                              children: rows.map((row) {
                                final debit = row['debit'] ?? 0;
                                final credit = row['credit'] ?? 0;
                                return Card(
                                  child: ListTile(
                                    title: Text(
                                        '${row['description'] ?? row['source_type']}'),
                                    subtitle: Text(
                                        '${row['date'] ?? ''} | ${row['source_type'] ?? ''}'),
                                    leading: const Icon(Icons.receipt_long),
                                    trailing: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.end,
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        if ((debit is num
                                                ? debit
                                                : num.tryParse('$debit') ?? 0) >
                                            0)
                                          Text('مدين ${formatMoney(debit)}',
                                              style: const TextStyle(
                                                  color: AlshaariColors
                                                      .deepGreen)),
                                        if ((credit is num
                                                ? credit
                                                : num.tryParse('$credit') ??
                                                    0) >
                                            0)
                                          Text('دائن ${formatMoney(credit)}',
                                              style: const TextStyle(
                                                  color:
                                                      AlshaariColors.copper)),
                                      ],
                                    ),
                                  ),
                                );
                              }).toList(),
                            ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
