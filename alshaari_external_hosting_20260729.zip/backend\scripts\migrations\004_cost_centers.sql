CREATE TABLE IF NOT EXISTS cost_centers (
    id INTEGER PRIMARY KEY,
    code VARCHAR(40) NOT NULL UNIQUE,
    name VARCHAR(150) NOT NULL,
    parent_id INTEGER NULL,
    type VARCHAR(40) DEFAULT 'production',
    project_id INTEGER NULL,
    responsible_user_id INTEGER NULL,
    allocation_method VARCHAR(40) DEFAULT 'direct',
    allocation_base VARCHAR(40) NULL,
    budget_amount NUMERIC(14,2) DEFAULT 0,
    is_postable BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    notes TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

ALTER TABLE transactions ADD COLUMN IF NOT EXISTS cost_center_id INTEGER;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS settlement_type VARCHAR(40);
ALTER TABLE journal_entry_lines ADD COLUMN IF NOT EXISTS cost_center_id INTEGER;
ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS cost_center_id INTEGER;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS cost_center_id INTEGER;
ALTER TABLE expenses ADD COLUMN IF NOT EXISTS cost_center_id INTEGER;
ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS project_id INTEGER;
ALTER TABLE cost_centers ADD COLUMN IF NOT EXISTS created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP;
