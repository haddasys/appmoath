from sqlalchemy import inspect, text
from sqlalchemy.orm import Session


CURRENCIES = [
    ("YER", "ريال يمني"),
    ("SAR", "ريال سعودي"),
    ("USD", "دولار"),
]

CASH_CUSTODIANS = [
    ("10111", "أنس الشعري"),
    ("10121", "معاذ الشعري"),
    ("10131", "مراد الحواش"),
]

BANK_WALLETS = [
    ("10202", "شركة الرحاب"),
    ("10204", "محفظة جيب"),
    ("10205", "جوالي"),
    ("10206", "فلوسك"),
    ("10201", "بنك الكريمي"),
    ("10207", "موبايل موني"),
]

DEFAULT_ACCOUNTS = [
    ("10100", "النقدية لدى الصناديق", "asset", "YER", None),
    ("10101", "الصندوق العام - ريال يمني", "cash", "YER", "10100"),
    ("10102", "الصندوق العام - ريال سعودي", "cash", "SAR", "10100"),
    ("10103", "الصندوق العام - دولار", "cash", "USD", "10100"),
    ("10104", "عهدة نقدية مؤقتة", "asset", "YER", "10100"),
    ("10200", "النقدية لدى البنوك والمحافظ", "asset", "YER", None),
    ("10203", "حوالات قيد التحصيل", "asset", "YER", "10200"),
    ("10301", "العملاء", "asset", "YER", None),
    ("10302", "دفعات عملاء مقدمة", "liability", "YER", None),
    ("10601", "دفعات مقدمة للموردين", "asset", "YER", None),
]

DEFAULT_POSTING_RULES = [
    ("receipt_from_customer", "10101", "10301", "قبض من عميل"),
    ("customer_advance", "10101", "10302", "دفعة مقدمة من عميل"),
    ("general_payment", "60301", "10101", "صرف عام"),
    ("project_expense", "50303", "10101", "مصروف مرتبط بمشروع"),
    ("material_purchase", "10401", "10101", "شراء مواد نقدا"),
    ("material_issue_to_project", "50101", "10401", "صرف مواد لمشروع"),
    ("customer_invoice", "10301", "40101", "فاتورة عميل"),
    ("supplier_invoice", "10401", "20101", "فاتورة مورد"),
    ("supplier_payment", "20101", "10101", "دفعة مورد"),
    ("supplier_advance", "10601", "10101", "دفعة مقدمة لمورد"),
    ("worker_wage", "50201", "10101", "أجر عامل"),
    ("advance_payment", "20203", "10101", "عهدة عامل"),
    ("advance_settlement", "60301", "20203", "تسوية عهدة"),
    ("cash_transfer", "10201", "10101", "تحويل بين صناديق"),
]


def _cash_code(base_code: str, currency_index: int) -> str:
    if currency_index == 1:
        return base_code
    return f"{base_code}{currency_index:02d}"


def _insert_account(db: Session, code: str, name: str, account_type: str, currency: str, parent_code: str | None) -> None:
    db.execute(
        text(
            """
            INSERT INTO accounts (code, name, type, currency, balance, parent_code, is_active)
            VALUES (:code, :name, :type, :currency, 0, :parent_code, TRUE)
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                type = EXCLUDED.type,
                currency = EXCLUDED.currency,
                parent_code = EXCLUDED.parent_code,
                is_active = TRUE
            """
        ),
        {
            "code": code,
            "name": name,
            "type": account_type,
            "currency": currency,
            "parent_code": parent_code,
        },
    )


def _table_has_column(db: Session, table_name: str, column_name: str) -> bool:
    inspector = inspect(db.get_bind())
    if not inspector.has_table(table_name):
        return True
    return column_name in {column["name"] for column in inspector.get_columns(table_name)}


def _add_column_if_missing(db: Session, table_name: str, column_name: str, definition: str) -> None:
    if not _table_has_column(db, table_name, column_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def _insert_cash_account(
    db: Session,
    code: str,
    name: str,
    currency: str,
    account_type: str = "cash",
    holder_name: str | None = None,
) -> None:
    db.execute(
        text(
            """
            INSERT INTO cash_accounts (
                code, name, account_code, type, holder_name, currency,
                opening_balance, balance, current_balance, is_active
            )
            VALUES (
                :code, :name, :code, :account_type, :holder_name, :currency,
                0, 0, 0, TRUE
            )
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                account_code = EXCLUDED.account_code,
                type = EXCLUDED.type,
                holder_name = EXCLUDED.holder_name,
                currency = EXCLUDED.currency,
                current_balance = COALESCE(cash_accounts.balance, cash_accounts.current_balance, 0),
                is_active = TRUE
            """
        ),
        {
            "code": code,
            "name": name,
            "currency": currency,
            "account_type": account_type,
            "holder_name": holder_name,
        },
    )


def _seed_cash_and_bank_accounts(db: Session) -> None:
    for code, name, account_type, currency, parent_code in DEFAULT_ACCOUNTS:
        _insert_account(db, code, name, account_type, currency, parent_code)

    for code, name, currency in [
        ("10101", "الصندوق العام - ريال يمني", "YER"),
        ("10102", "الصندوق العام - ريال سعودي", "SAR"),
        ("10103", "الصندوق العام - دولار", "USD"),
    ]:
        _insert_cash_account(db, code, name, currency, "cash")

    for base_code, custodian in CASH_CUSTODIANS:
        for index, (currency, label) in enumerate(CURRENCIES, start=1):
            code = _cash_code(base_code, index)
            name = f"صندوق {custodian} - {label}"
            _insert_account(db, code, name, "cash", currency, "10100")
            _insert_cash_account(db, code, name, currency, "cash", custodian)

    for base_code, wallet in BANK_WALLETS:
        for index, (currency, label) in enumerate(CURRENCIES, start=1):
            code = _cash_code(base_code, index)
            name = f"{wallet} - {label}"
            _insert_account(db, code, name, "bank", currency, "10200")
            _insert_cash_account(db, code, name, currency, "bank", wallet)


def ensure_accounting_defaults(db: Session) -> None:
    _add_column_if_missing(db, "transactions", "cash_account_id", "INTEGER")
    _add_column_if_missing(db, "transactions", "from_cash_account_id", "INTEGER")
    _add_column_if_missing(db, "transactions", "to_cash_account_id", "INTEGER")
    _add_column_if_missing(db, "cash_accounts", "account_code", "VARCHAR(30)")
    _add_column_if_missing(db, "cash_accounts", "type", "VARCHAR(40) DEFAULT 'cash'")
    _add_column_if_missing(db, "cash_accounts", "holder_name", "VARCHAR(150)")
    _add_column_if_missing(db, "cash_accounts", "current_balance", "NUMERIC(14, 2) DEFAULT 0")
    _add_column_if_missing(db, "cash_accounts", "created_at", "TIMESTAMP")

    _seed_cash_and_bank_accounts(db)

    db.execute(
        text(
            """
            UPDATE cash_accounts
            SET current_balance = COALESCE(balance, current_balance, 0),
                created_at = COALESCE(created_at, CURRENT_TIMESTAMP)
            """
        )
    )

    for operation_type, debit, credit, description in DEFAULT_POSTING_RULES:
        db.execute(
            text(
                """
                INSERT INTO posting_rules (
                    operation_type,
                    debit_account_code,
                    credit_account_code,
                    description,
                    is_active
                )
                VALUES (
                    :operation_type,
                    :debit,
                    :credit,
                    :description,
                    TRUE
                )
                ON CONFLICT (operation_type) DO UPDATE SET
                    debit_account_code = EXCLUDED.debit_account_code,
                    credit_account_code = EXCLUDED.credit_account_code,
                    description = EXCLUDED.description,
                    is_active = TRUE
                """
            ),
            {
                "operation_type": operation_type,
                "debit": debit,
                "credit": credit,
                "description": description,
            },
        )

    db.commit()
