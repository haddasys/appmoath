import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

class DeviceIdentity {
  static const _deviceIdKey = 'alshaari_device_id';
  static const _deviceNameKey = 'alshaari_device_name';

  Future<String> getOrCreateDeviceId() async {
    final prefs = await SharedPreferences.getInstance();
    final existing = prefs.getString(_deviceIdKey);
    if (existing != null && existing.trim().isNotEmpty) {
      return existing;
    }

    final random = _safeRandomHex();
    final value =
        'device-${DateTime.now().microsecondsSinceEpoch.toRadixString(16)}-$random';
    await prefs.setString(_deviceIdKey, value);
    return value;
  }

  Future<String> getDeviceName() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getString(_deviceNameKey) ?? 'Alshaari Mobile';
  }

  Future<void> setDeviceName(String value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_deviceNameKey, value.trim());
  }
}

String _safeRandomHex() {
  final random = Random.secure();
  final high = random.nextInt(0x10000).toRadixString(16).padLeft(4, '0');
  final low = random.nextInt(0x10000).toRadixString(16).padLeft(4, '0');
  return '$high$low';
}

final deviceIdentity = DeviceIdentity();
