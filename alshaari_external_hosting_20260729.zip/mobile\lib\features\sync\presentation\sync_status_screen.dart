import 'dart:convert';
import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../core/local_db/local_database.dart';
import '../../../core/network/connectivity_service.dart';
import '../../../core/offline_queue/sync_queue_item.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/widgets/alshaari_ui.dart';

class SyncStatusScreen extends StatefulWidget {
  const SyncStatusScreen({super.key});

  @override
  State<SyncStatusScreen> createState() => _SyncStatusScreenState();
}

class _SyncStatusScreenState extends State<SyncStatusScreen> {
  bool loading = true;
  bool syncing = false;
  String? error;
  int pending = 0;
  int syncingCount = 0;
  int failed = 0;
  int conflict = 0;
  DateTime? lastSyncAt;
  List<SyncQueueItem> queue = [];
  ConnectivitySnapshot? connection;

  final dateFormat = DateFormat('yyyy/MM/dd HH:mm');

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final status = await syncService.localStatus();
      final connectionStatus = await connectivityService.status();
      final rows = await localDatabase.syncQueue();
      if (!mounted) return;
      setState(() {
        pending = status.pending;
        syncingCount = status.syncing;
        failed = status.failed;
        conflict = status.conflict;
        lastSyncAt = status.lastSyncAt;
        queue = rows.reversed.toList();
        connection = connectionStatus;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = 'تعذر تحميل حالة المزامنة: $e';
        loading = false;
      });
    }
  }

  Future<void> syncNow() async {
    setState(() {
      syncing = true;
      error = null;
    });
    try {
      final connectionStatus = await connectivityService.status();
      if (!connectionStatus.canUseServer) {
        if (!mounted) return;
        setState(() => connection = connectionStatus);
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(connectionStatus.message)),
        );
        return;
      }
      final result = await syncService.pushPending();
      if (!mounted) return;
      final message = result.hasWork
          ? 'تمت المحاولة: ${result.attempted}، تمت المزامنة: ${result.synced}، فشل: ${result.failed}، تعارض: ${result.conflict}'
          : 'لا توجد عمليات بانتظار المزامنة.';
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(message)));
      await load();
    } catch (e) {
      if (!mounted) return;
      setState(() => error = 'فشلت المزامنة: $e');
    } finally {
      if (mounted) setState(() => syncing = false);
    }
  }

  Color statusColor(String status) {
    switch (status) {
      case 'synced':
        return AlshaariColors.success;
      case 'failed':
        return AlshaariColors.danger;
      case 'conflict':
        return AlshaariColors.warning;
      case 'syncing':
        return AlshaariColors.info;
      default:
        return AlshaariColors.copper;
    }
  }

  String statusLabel(String status) {
    switch (status) {
      case 'synced':
        return 'تمت المزامنة';
      case 'failed':
        return 'فشل';
      case 'conflict':
        return 'تعارض';
      case 'syncing':
        return 'جارية';
      default:
        return 'بانتظار المزامنة';
    }
  }

  String entityLabel(String entityType) {
    switch (entityType) {
      case 'transaction':
      case 'transactions':
        return 'مستند مالي';
      case 'attendance':
      case 'attendances':
        return 'حضور عامل';
      case 'attendance_bulk':
      case 'bulk_attendance':
        return 'حضور جماعي';
      case 'attachment':
      case 'attachments':
        return 'مرفق';
      default:
        return entityType;
    }
  }

  String operationLabelText(String operation) {
    switch (operation) {
      case 'create':
        return 'إنشاء';
      case 'update':
        return 'تحديث';
      case 'approve':
        return 'اعتماد';
      case 'delete':
        return 'حذف';
      default:
        return operation;
    }
  }

  String queueTitle(SyncQueueItem item) {
    final payload = payloadOf(item);
    final type = payload['type']?.toString() ?? entityLabel(item.entityType);
    final tempNo = payload['temporary_document_no']?.toString();
    return tempNo == null ? type : '$tempNo - $type';
  }

  Map<String, dynamic> payloadOf(SyncQueueItem item) {
    try {
      final decoded = jsonDecode(item.payloadJson);
      if (decoded is Map) return Map<String, dynamic>.from(decoded);
    } catch (_) {
      return const {};
    }
    return const {};
  }

  String queueSubtitle(SyncQueueItem item) {
    final payload = payloadOf(item);
    final parts = <String>[
      'النوع: ${entityLabel(item.entityType)}',
      'العملية: ${operationLabelText(item.operation)}',
      'المحاولات: ${item.retryCount}',
    ];
    final amount = payload['amount'];
    if (amount != null) parts.add('المبلغ: $amount');
    final date = payload['date'];
    if (date != null) parts.add('التاريخ: $date');
    return parts.join(' | ');
  }

  Widget statCard(String title, String value, IconData icon, Color color) {
    return AlshaariStatCard(
      title: title,
      value: value,
      subtitle: '',
      icon: icon,
      color: color,
    );
  }

  String connectionTitle() {
    final status = connection?.status;
    return switch (status) {
      ConnectionStatus.online => 'متصل بالسيرفر',
      ConnectionStatus.offline => 'بدون اتصال',
      ConnectionStatus.serverUnreachable => 'السيرفر غير متاح',
      ConnectionStatus.syncing => 'جاري المزامنة',
      null => 'حالة الاتصال غير معروفة',
    };
  }

  Color connectionColor() {
    final status = connection?.status;
    return switch (status) {
      ConnectionStatus.online => AlshaariColors.success,
      ConnectionStatus.offline => AlshaariColors.warning,
      ConnectionStatus.serverUnreachable => AlshaariColors.danger,
      ConnectionStatus.syncing => AlshaariColors.info,
      null => AlshaariColors.slate,
    };
  }

  IconData connectionIcon() {
    final status = connection?.status;
    return switch (status) {
      ConnectionStatus.online => Icons.cloud_done_outlined,
      ConnectionStatus.offline => Icons.cloud_off_outlined,
      ConnectionStatus.serverUnreachable => Icons.dns_outlined,
      ConnectionStatus.syncing => Icons.sync_outlined,
      null => Icons.help_outline,
    };
  }

  Widget connectionCard() {
    final color = connectionColor();
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: .35)),
      ),
      child: Row(
        children: [
          Icon(connectionIcon(), color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  connectionTitle(),
                  style: TextStyle(
                    color: color,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  connection?.message ??
                      'إذا كان السيرفر غير متاح فسيتم حفظ المسودات محليًا.',
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget queueCard(SyncQueueItem item) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: AlshaariColors.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  queueTitle(item),
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: AlshaariColors.ink,
                  ),
                ),
              ),
              AlshaariStatusBadge.bySyncStatus(item.status),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            queueSubtitle(item),
            style: const TextStyle(color: AlshaariColors.slate),
          ),
          if (item.errorMessage != null && item.errorMessage!.isNotEmpty) ...[
            const SizedBox(height: 8),
            Text(
              item.errorMessage!,
              style: const TextStyle(
                color: AlshaariColors.danger,
                fontWeight: FontWeight.w700,
              ),
            ),
          ],
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('حالة المزامنة')),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: load,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    AlshaariPageHeader(
                      title: 'حالة المزامنة',
                      subtitle:
                          'متابعة المستندات المحفوظة محليًا والعمليات بانتظار الإرسال إلى الخادم.',
                      icon: Icons.sync_outlined,
                      trailing: ElevatedButton.icon(
                        onPressed: syncing ? null : syncNow,
                        icon: syncing
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : const Icon(Icons.sync),
                        label: const Text('مزامنة الآن'),
                      ),
                    ),
                    if (pending + failed + conflict > 0) ...[
                      const SizedBox(height: 12),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: AlshaariColors.copper.withValues(alpha: .10),
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: AlshaariColors.copper.withValues(alpha: .28),
                          ),
                        ),
                        child: Row(
                          children: [
                            const Icon(
                              Icons.info_outline,
                              color: AlshaariColors.copper,
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                'توجد عمليات محلية محفوظة على هذا الجهاز. لن يتم حذفها عند فشل المزامنة، ويمكن إعادة المحاولة من زر مزامنة الآن.',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(fontWeight: FontWeight.w700),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                    const SizedBox(height: 12),
                    connectionCard(),
                    const SizedBox(height: 12),
                    if (error != null)
                      AlshaariErrorState(message: error!, onRetry: load),
                    LayoutBuilder(
                      builder: (context, constraints) {
                        final cards = [
                          statCard(
                            'بانتظار المزامنة',
                            '$pending',
                            Icons.schedule_outlined,
                            AlshaariColors.copper,
                          ),
                          statCard(
                            'جارية المزامنة',
                            '$syncingCount',
                            Icons.sync_outlined,
                            AlshaariColors.info,
                          ),
                          statCard(
                            'فاشلة',
                            '$failed',
                            Icons.error_outline,
                            AlshaariColors.danger,
                          ),
                          statCard(
                            'تعارضات',
                            '$conflict',
                            Icons.warning_amber_outlined,
                            AlshaariColors.warning,
                          ),
                          statCard(
                            'آخر مزامنة',
                            lastSyncAt == null
                                ? 'لم تتم بعد'
                                : dateFormat.format(lastSyncAt!),
                            Icons.history_outlined,
                            AlshaariColors.info,
                          ),
                        ];
                        if (constraints.maxWidth < 720) {
                          return Column(
                            children: cards
                                .map(
                                  (card) => Padding(
                                    padding: const EdgeInsets.only(bottom: 8),
                                    child: card,
                                  ),
                                )
                                .toList(),
                          );
                        }
                        return GridView.count(
                          crossAxisCount: 5,
                          childAspectRatio: 2.3,
                          crossAxisSpacing: 8,
                          mainAxisSpacing: 8,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          children: cards,
                        );
                      },
                    ),
                    const SizedBox(height: 12),
                    AlshaariSectionCard(
                      title: 'قائمة العمليات المحلية',
                      subtitle:
                          'لا يتم حذف العمليات الفاشلة؛ تبقى محفوظة لإعادة المحاولة أو مراجعة التعارض.',
                      icon: Icons.list_alt_outlined,
                      child: queue.isEmpty
                          ? const AlshaariEmptyState(
                              title: 'لا توجد عمليات محلية',
                              subtitle:
                                  'كل المستندات الحالية محفوظة على الخادم.',
                              icon: Icons.cloud_done_outlined,
                            )
                          : Column(children: queue.map(queueCard).toList()),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
