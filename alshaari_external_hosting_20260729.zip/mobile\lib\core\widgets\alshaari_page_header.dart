import 'package:flutter/material.dart';
import '../../../app/theme.dart';

class AlshaariPageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;

  const AlshaariPageHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AlshaariColors.matteBlack,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 48,
            height: 48,
            decoration: BoxDecoration(
              color: AlshaariColors.copper.withOpacity(0.15),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AlshaariColors.copper, width: 1.5),
            ),
            child: Icon(icon, color: AlshaariColors.copper, size: 26),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(color: Colors.white, fontSize: 18)),
                const SizedBox(height: 2),
                Text(subtitle, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AlshaariColors.pearlWhite.withOpacity(0.7))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}