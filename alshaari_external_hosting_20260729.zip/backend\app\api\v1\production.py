from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.database import get_db
from app.models.models import (
    AuditLog,
    ProductionOrder,
    Project,
    ProjectCost,
    ProjectStage,
    Transaction,
)
from app.schemas.schemas import (
    ProductionOrderCreate,
    ProductionOrderUpdate,
    ProjectStageCreate,
    ProjectStageUpdate,
)
from app.services.document_sequence import next_document_no

router = APIRouter(prefix="/api/v1/production", tags=["Production"])

DEFAULT_STAGES = [
    ("design", "التصميم والاعتماد"),
    ("cutting", "تقطيع وتجهيز المواد"),
    ("carpentry", "النجارة والتجميع"),
    ("cnc", "CNC والتفريز"),
    ("sanding", "الصنفرة والمعالجة"),
    ("paint", "الدهان والتشطيب السطحي"),
    ("finishing", "التشطيب النهائي"),
    ("installation", "التركيب والتسليم"),
]

VALID_STATUSES = {"not_started", "in_progress", "done", "blocked", "cancelled"}
VALID_ORDER_STATUSES = {"planned", "released", "in_progress", "done", "blocked", "cancelled"}
VALID_PRIORITIES = {"low", "normal", "high", "urgent"}

STATUS_LABELS = {
    "not_started": "لم تبدأ",
    "in_progress": "قيد التنفيذ",
    "done": "مكتملة",
    "blocked": "متعطلة",
    "cancelled": "ملغاة",
}

PROJECT_STATUS_LABELS = {
    "new": "جديد",
    "active": "نشط",
    "in_production": "قيد الإنتاج",
    "ready_for_delivery": "جاهز للتسليم",
    "blocked": "متعطل",
    "delivered": "مسلم",
    "financially_closed": "مغلق ماليًا",
    "closed": "مغلق",
    "cancelled": "ملغى",
}

ORDER_STATUS_LABELS = {
    "planned": "مخطط",
    "released": "معتمد للتنفيذ",
    "in_progress": "قيد التشغيل",
    "done": "مكتمل",
    "blocked": "متعطل",
    "cancelled": "ملغى",
}

PRIORITY_LABELS = {
    "low": "منخفضة",
    "normal": "عادية",
    "high": "عالية",
    "urgent": "عاجلة",
}

MATERIAL_TYPES = {"material_issue_to_project", "material_purchase"}
LABOR_TYPES = {"worker_wage"}
OVERHEAD_TYPES = {"project_expense", "general_payment"}


def ensure_production_tables():
    # Kept as a compatibility hook for endpoints added before migration 003.
    # Schema changes must be applied through backend/scripts/migrations.
    return None


def _num(value):
    if value is None:
        return 0.0
    return float(value)


def _date(value):
    return value.isoformat() if value else None


def status_label(status: str | None):
    return STATUS_LABELS.get(status or "not_started", status or "لم تبدأ")


def project_status_label(status: str | None):
    return PROJECT_STATUS_LABELS.get(status or "new", status or "جديد")


def order_status_label(status: str | None):
    return ORDER_STATUS_LABELS.get(status or "planned", status or "مخطط")


def priority_label(priority: str | None):
    return PRIORITY_LABELS.get(priority or "normal", priority or "عادية")


def _order_payload(db: Session, order: ProductionOrder):
    project = db.query(Project).filter(Project.id == order.project_id).first()
    stage = db.query(ProjectStage).filter(ProjectStage.id == order.stage_id).first() if order.stage_id else None
    return {
        "id": order.id,
        "order_no": order.order_no,
        "project_id": order.project_id,
        "project_code": project.project_code if project else None,
        "project_name": project.name if project else None,
        "stage_id": order.stage_id,
        "stage_name": stage.name if stage else None,
        "item_description": order.item_description,
        "qty": _num(order.qty),
        "unit": order.unit,
        "priority": order.priority,
        "priority_label": priority_label(order.priority),
        "status": order.status,
        "status_label": order_status_label(order.status),
        "planned_start_date": _date(order.planned_start_date),
        "planned_end_date": _date(order.planned_end_date),
        "actual_start_date": _date(order.actual_start_date),
        "actual_end_date": _date(order.actual_end_date),
        "notes": order.notes,
        "is_late": bool(
            order.planned_end_date
            and order.planned_end_date < date.today()
            and order.status not in {"done", "cancelled"}
        ),
    }


def _stage_payload(stage: ProjectStage):
    return {
        "id": stage.id,
        "project_id": stage.project_id,
        "stage_order": stage.stage_order,
        "stage_code": stage.stage_code,
        "name": stage.name,
        "status": stage.status,
        "status_label": status_label(stage.status),
        "progress_percent": stage.progress_percent or 0,
        "planned_start_date": _date(stage.planned_start_date),
        "planned_end_date": _date(stage.planned_end_date),
        "actual_start_date": _date(stage.actual_start_date),
        "actual_end_date": _date(stage.actual_end_date),
        "responsible_id": stage.responsible_id,
        "notes": stage.notes,
        "is_late": bool(
            stage.planned_end_date
            and stage.planned_end_date < date.today()
            and stage.status not in {"done", "cancelled"}
        ),
    }


def _sum_transactions(db: Session, project_id: int, types: set[str]) -> float:
    value = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.project_id == project_id,
            Transaction.status == "approved",
            Transaction.type.in_(types),
        )
        .scalar()
    )
    return _num(value)


def _sum_project_costs(db: Session, project_id: int, keywords: tuple[str, ...]) -> float:
    query = db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).filter(
        ProjectCost.project_id == project_id
    )
    if keywords:
        conditions = [ProjectCost.category.ilike(f"%{keyword}%") for keyword in keywords]
        query = query.filter(conditions[0] if len(conditions) == 1 else conditions[0] | conditions[1])
        for condition in conditions[2:]:
            query = query.filter(condition | condition)
    return _num(query.scalar())


def _project_cost_breakdown(db: Session, project_id: int):
    material_transactions = _sum_transactions(db, project_id, MATERIAL_TYPES)
    labor_transactions = _sum_transactions(db, project_id, LABOR_TYPES)
    overhead_transactions = _sum_transactions(db, project_id, OVERHEAD_TYPES)

    # ProjectCost is used for operational costing entries that may not originate
    # from approved cash transactions.
    project_costs_total = _num(
        db.query(func.coalesce(func.sum(ProjectCost.amount), 0))
        .filter(ProjectCost.project_id == project_id)
        .scalar()
    )

    by_category_rows = (
        db.query(ProjectCost.category, func.coalesce(func.sum(ProjectCost.amount), 0))
        .filter(ProjectCost.project_id == project_id)
        .group_by(ProjectCost.category)
        .all()
    )
    by_category = [
        {"category": category or "غير مصنف", "amount": _num(amount)}
        for category, amount in by_category_rows
    ]

    direct_total = material_transactions + labor_transactions + overhead_transactions
    total = direct_total + project_costs_total
    return {
        "materials": material_transactions,
        "labor": labor_transactions,
        "overhead": overhead_transactions,
        "direct_transactions_total": direct_total,
        "manual_project_costs": project_costs_total,
        "total": total,
        "by_category": by_category,
    }


def _project_payload(db: Session, project: Project):
    stages = (
        db.query(ProjectStage)
        .filter(ProjectStage.project_id == project.id)
        .order_by(ProjectStage.stage_order.asc(), ProjectStage.id.asc())
        .all()
    )
    cost_breakdown = _project_cost_breakdown(db, project.id)
    orders = (
        db.query(ProductionOrder)
        .filter(ProductionOrder.project_id == project.id)
        .order_by(ProductionOrder.id.desc())
        .limit(20)
        .all()
    )
    contract_value = _num(project.contract_value)
    total_cost = cost_breakdown["total"]
    expected_profit = contract_value - total_cost
    margin = (expected_profit / contract_value * 100) if contract_value else 0

    return {
        "id": project.id,
        "project_code": project.project_code,
        "name": project.name,
        "customer_id": project.customer_id,
        "project_type": project.project_type,
        "contract_value": contract_value,
        "status": project.status,
        "status_label": project_status_label(project.status),
        "progress_percent": project.progress_percent or 0,
        "start_date": _date(project.start_date),
        "expected_end_date": _date(project.expected_end_date),
        "actual_cost": total_cost,
        "expected_profit": expected_profit,
        "profit_margin_percent": round(margin, 2),
        "cost_breakdown": cost_breakdown,
        "stages_count": len(stages),
        "done_stages": len([stage for stage in stages if stage.status == "done"]),
        "blocked_stages": len([stage for stage in stages if stage.status == "blocked"]),
        "late_stages": len(
            [
                stage
                for stage in stages
                if stage.planned_end_date
                and stage.planned_end_date < date.today()
                and stage.status not in {"done", "cancelled"}
            ]
        ),
        "orders_count": len(orders),
        "open_orders": len([order for order in orders if order.status not in {"done", "cancelled"}]),
        "late_orders": len(
            [
                order
                for order in orders
                if order.planned_end_date
                and order.planned_end_date < date.today()
                and order.status not in {"done", "cancelled"}
            ]
        ),
        "orders": [_order_payload(db, order) for order in orders],
        "stages": [_stage_payload(stage) for stage in stages],
    }


def _sync_project_progress(db: Session, project_id: int):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return

    stages = db.query(ProjectStage).filter(ProjectStage.project_id == project_id).all()
    if not stages:
        return

    progress = round(sum((stage.progress_percent or 0) for stage in stages) / len(stages))
    project.progress_percent = max(0, min(100, progress))

    if all(stage.status == "done" for stage in stages):
        project.status = "ready_for_delivery"
    elif any(stage.status == "blocked" for stage in stages):
        project.status = "blocked"
    elif any(stage.status == "in_progress" for stage in stages):
        project.status = "in_production"
    elif project.status in {"new", "active", None}:
        project.status = "active"


def _ensure_project(db: Session, project_id: int):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return project


def _validate_stage_payload(status: str | None, progress: int | None):
    if status is not None and status not in VALID_STATUSES:
        raise HTTPException(status_code=400, detail="حالة المرحلة غير صحيحة")
    if progress is not None and not 0 <= progress <= 100:
        raise HTTPException(status_code=400, detail="نسبة الإنجاز يجب أن تكون بين 0 و 100")


def _validate_order_payload(
    db: Session,
    project_id: int,
    stage_id: int | None,
    status: str | None,
    priority: str | None,
    qty,
):
    if status is not None and status not in VALID_ORDER_STATUSES:
        raise HTTPException(status_code=400, detail="حالة أمر التشغيل غير صحيحة")
    if priority is not None and priority not in VALID_PRIORITIES:
        raise HTTPException(status_code=400, detail="أولوية أمر التشغيل غير صحيحة")
    if qty is not None and _num(qty) <= 0:
        raise HTTPException(status_code=400, detail="كمية أمر التشغيل يجب أن تكون أكبر من صفر")
    if stage_id is not None:
        stage = db.query(ProjectStage).filter(ProjectStage.id == stage_id).first()
        if not stage or stage.project_id != project_id:
            raise HTTPException(status_code=400, detail="المرحلة لا تتبع المشروع المحدد")


@router.get("/summary")
def production_summary(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    stages = db.query(ProjectStage).all()
    orders = db.query(ProductionOrder).all()
    today = date.today()
    projects_in_production = (
        db.query(Project)
        .filter(Project.status.in_(["active", "in_production", "blocked"]))
        .count()
    )
    return {
        "projects_in_production": projects_in_production,
        "total_stages": len(stages),
        "in_progress": len([stage for stage in stages if stage.status == "in_progress"]),
        "blocked": len([stage for stage in stages if stage.status == "blocked"]),
        "done": len([stage for stage in stages if stage.status == "done"]),
        "open_orders": len([order for order in orders if order.status not in {"done", "cancelled"}]),
        "late_orders": len(
            [
                order
                for order in orders
                if order.planned_end_date
                and order.planned_end_date < today
                and order.status not in {"done", "cancelled"}
            ]
        ),
        "late": len(
            [
                stage
                for stage in stages
                if stage.planned_end_date
                and stage.planned_end_date < today
                and stage.status not in {"done", "cancelled"}
            ]
        ),
    }


@router.get("/projects")
def production_projects(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    projects = (
        db.query(Project)
        .filter(Project.status.notin_(["financially_closed", "closed", "cancelled"]))
        .order_by(Project.id.desc())
        .limit(100)
        .all()
    )
    return [_project_payload(db, project) for project in projects]


@router.get("/projects/{project_id}")
def production_project(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    project = _ensure_project(db, project_id)
    return _project_payload(db, project)


@router.get("/projects/{project_id}/costs")
def production_project_costs(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    _ensure_project(db, project_id)
    return _project_cost_breakdown(db, project_id)


@router.post("/projects/{project_id}/stages/bootstrap")
def bootstrap_project_stages(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    project = _ensure_project(db, project_id)
    existing = {
        stage.stage_code
        for stage in db.query(ProjectStage).filter(ProjectStage.project_id == project_id).all()
    }

    created = 0
    for index, (code, name) in enumerate(DEFAULT_STAGES, start=1):
        if code in existing:
            continue
        db.add(
            ProjectStage(
                project_id=project_id,
                stage_order=index,
                stage_code=code,
                name=name,
                status="not_started",
                progress_percent=0,
                created_by=user.id,
            )
        )
        created += 1

    project.status = "active" if project.status in {"new", None} else project.status
    db.add(
        AuditLog(
            user_id=user.id,
            action="bootstrap_stages",
            entity="project",
            entity_id=project_id,
            details=f"created={created}",
        )
    )
    db.commit()
    _sync_project_progress(db, project_id)
    db.commit()
    return _project_payload(db, project)


@router.get("/projects/{project_id}/stages")
def project_stages(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    _ensure_project(db, project_id)
    stages = (
        db.query(ProjectStage)
        .filter(ProjectStage.project_id == project_id)
        .order_by(ProjectStage.stage_order.asc(), ProjectStage.id.asc())
        .all()
    )
    return [_stage_payload(stage) for stage in stages]


@router.post("/stages")
def create_stage(data: ProjectStageCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    _ensure_project(db, data.project_id)
    _validate_stage_payload(data.status, data.progress_percent)

    stage = ProjectStage(**data.model_dump(exclude_unset=True), created_by=user.id)
    db.add(stage)
    db.flush()
    _sync_project_progress(db, data.project_id)
    db.add(
        AuditLog(
            user_id=user.id,
            action="create_stage",
            entity="project_stage",
            entity_id=stage.id,
            details=stage.name,
        )
    )
    db.commit()
    db.refresh(stage)
    return _stage_payload(stage)


@router.patch("/stages/{stage_id}")
def update_stage(stage_id: int, data: ProjectStageUpdate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_production_tables()
    stage = db.query(ProjectStage).filter(ProjectStage.id == stage_id).first()
    if not stage:
        raise HTTPException(status_code=404, detail="مرحلة الإنتاج غير موجودة")

    payload = data.model_dump(exclude_unset=True)
    _validate_stage_payload(payload.get("status"), payload.get("progress_percent"))

    if payload.get("status") == "done":
        payload["progress_percent"] = 100
        payload["actual_end_date"] = payload.get("actual_end_date") or date.today()
    elif payload.get("status") == "in_progress":
        payload["actual_start_date"] = payload.get("actual_start_date") or stage.actual_start_date or date.today()
        if payload.get("progress_percent") in (None, 0):
            payload["progress_percent"] = max(stage.progress_percent or 0, 10)
    elif payload.get("status") == "not_started":
        payload["progress_percent"] = 0

    for key, value in payload.items():
        setattr(stage, key, value)

    db.add(
        AuditLog(
            user_id=user.id,
            action="update_stage",
            entity="project_stage",
            entity_id=stage.id,
            details=stage.name,
        )
    )
    _sync_project_progress(db, stage.project_id)
    db.commit()
    db.refresh(stage)
    return _stage_payload(stage)


@router.get("/orders")
def production_orders(
    project_id: int | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_production_tables()
    query = db.query(ProductionOrder).order_by(ProductionOrder.id.desc())
    if project_id is not None:
        query = query.filter(ProductionOrder.project_id == project_id)
    return [_order_payload(db, order) for order in query.limit(200).all()]


@router.post("/orders")
def create_production_order(
    data: ProductionOrderCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_production_tables()
    _ensure_project(db, data.project_id)
    _validate_order_payload(
        db,
        data.project_id,
        data.stage_id,
        data.status,
        data.priority,
        data.qty,
    )

    order = ProductionOrder(
        order_no=next_document_no(db, "production_order"),
        project_id=data.project_id,
        stage_id=data.stage_id,
        item_description=data.item_description.strip(),
        qty=data.qty,
        unit=data.unit,
        priority=data.priority,
        status=data.status,
        planned_start_date=data.planned_start_date,
        planned_end_date=data.planned_end_date,
        notes=data.notes,
        created_by=user.id,
    )
    db.add(order)
    db.flush()
    db.add(
        AuditLog(
            user_id=user.id,
            action="create_production_order",
            entity="production_order",
            entity_id=order.id,
            details=order.order_no,
        )
    )
    db.commit()
    db.refresh(order)
    return _order_payload(db, order)


@router.patch("/orders/{order_id}")
def update_production_order(
    order_id: int,
    data: ProductionOrderUpdate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    ensure_production_tables()
    order = db.query(ProductionOrder).filter(ProductionOrder.id == order_id).first()
    if not order:
        raise HTTPException(status_code=404, detail="أمر التشغيل غير موجود")

    payload = data.model_dump(exclude_unset=True)
    project_id = order.project_id
    stage_id = payload.get("stage_id", order.stage_id)
    _validate_order_payload(
        db,
        project_id,
        stage_id,
        payload.get("status"),
        payload.get("priority"),
        payload.get("qty"),
    )

    if payload.get("status") == "in_progress":
        payload["actual_start_date"] = payload.get("actual_start_date") or order.actual_start_date or date.today()
    elif payload.get("status") == "done":
        payload["actual_end_date"] = payload.get("actual_end_date") or date.today()

    for key, value in payload.items():
        if key == "item_description" and value is not None:
            value = value.strip()
        setattr(order, key, value)

    db.add(
        AuditLog(
            user_id=user.id,
            action="update_production_order",
            entity="production_order",
            entity_id=order.id,
            details=order.order_no,
        )
    )
    db.commit()
    db.refresh(order)
    return _order_payload(db, order)
