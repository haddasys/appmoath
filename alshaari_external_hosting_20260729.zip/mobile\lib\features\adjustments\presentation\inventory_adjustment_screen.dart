import 'package:flutter/material.dart';

import '../../inventory/presentation/inventory_screen.dart';

class InventoryAdjustmentScreen extends StatelessWidget {
  const InventoryAdjustmentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const InventoryScreen();
  }
}
