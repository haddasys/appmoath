from datetime import date
from decimal import Decimal

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from sqlalchemy import text

from app.core.deps import get_current_user
from app.db.database import get_db

router = APIRouter(prefix="/api/v1/accounting", tags=["Accounting"])


def _decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _money(value) -> str:
    return str(_decimal(value).quantize(Decimal("0.01")))


def _account_level(code: str) -> int:
    length = len(code or "")
    if length <= 1:
        return 1
    if length <= 3:
        return 2
    if length <= 5:
        return 3
    return 4


def _infer_parent(code: str, known_codes: set[str], parent_code: str | None) -> str | None:
    if parent_code:
        return parent_code
    for index in range(len(code) - 1, 0, -1):
        candidate = code[:index]
        if candidate in known_codes:
            return candidate
    return None


def _source_label_expr() -> str:
    return """
        CASE
            WHEN je.source_type = 'adjustment_voucher' THEN 'سند تسوية'
            WHEN je.source_type = 'settlement_voucher' THEN 'سند تسوية'
            WHEN je.source_type = 'transaction' THEN 'مستند مالي'
            WHEN je.source_type = 'supplier_invoice' THEN 'فاتورة مورد'
            WHEN je.source_type = 'supplier_payment' THEN 'سند دفع مورد'
            WHEN je.source_type = 'customer_invoice' THEN 'فاتورة عميل'
            WHEN je.source_type = 'inventory_adjustment' THEN 'تسوية مخزون'
            WHEN je.source_type = 'direct_project_purchase' THEN 'شراء مباشر لمشروع'
            WHEN je.source_type = 'payroll' THEN 'كشف راتب'
            WHEN je.source_type = 'payroll_payment' THEN 'دفع راتب'
            ELSE COALESCE(je.source_type, '-')
        END
    """


def _source_no_expr() -> str:
    return """
        COALESCE(
            av.voucher_no,
            tx.voucher_no,
            tx.document_no,
            si.internal_invoice_no,
            sp.payment_no,
            p.payroll_no,
            CAST(je.source_id AS TEXT)
        )
    """


@router.get("/journal-entries")
def journal_entries(
    from_date: date | None = None,
    to_date: date | None = None,
    period_id: int | None = Query(None, ge=1),
    status: str | None = Query(None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    conditions = []
    params: dict[str, object] = {}
    period_from, period_to, _period = _period_dates(db, period_id)
    if period_from and period_to:
        from_date = period_from
        to_date = period_to
    if from_date:
        conditions.append("je.entry_date >= :from_date")
        params["from_date"] = from_date
    if to_date:
        conditions.append("je.entry_date <= :to_date")
        params["to_date"] = to_date
    if status:
        conditions.append("je.status = :status")
        params["status"] = status
    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    entries = db.execute(
        text(f"""
            SELECT
                je.id,
                je.entry_no,
                je.entry_date,
                je.source_type,
                je.source_id,
                {_source_label_expr()} AS source_label,
                {_source_no_expr()} AS source_no,
                je.description,
                je.status,
                je.total_debit,
                je.total_credit,
                je.created_by,
                je.created_at
            FROM journal_entries je
            LEFT JOIN adjustment_vouchers av
              ON je.source_type IN ('adjustment_voucher', 'settlement_voucher')
             AND av.id = je.source_id
            LEFT JOIN transactions tx
              ON je.source_type = 'transaction'
             AND tx.id = je.source_id
            LEFT JOIN supplier_invoices si
              ON je.source_type = 'supplier_invoice'
             AND si.id = je.source_id
            LEFT JOIN supplier_payments sp
              ON je.source_type = 'supplier_payment'
             AND sp.id = je.source_id
            LEFT JOIN payrolls p
              ON je.source_type IN ('payroll', 'payroll_payment')
             AND p.id = je.source_id
            {where_clause}
            ORDER BY je.id DESC
            LIMIT 200
        """),
        params,
    ).mappings().all()

    return [dict(row) for row in entries]


def _period_dates(db: Session, period_id: int | None) -> tuple[date | None, date | None, dict | None]:
    if period_id is None:
        return None, None, None
    row = db.execute(
        text(
            """
            SELECT id, year, month, start_date, end_date, status
            FROM accounting_periods
            WHERE id = :period_id
            """
        ),
        {"period_id": period_id},
    ).mappings().first()
    if not row:
        return None, None, None
    return row["start_date"], row["end_date"], dict(row)


@router.get("/journal-entries/{entry_id}")
def journal_entry_details(entry_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    entry = db.execute(
        text("""
            SELECT *
            FROM journal_entries je
            WHERE je.id = :entry_id
        """),
        {"entry_id": entry_id},
    ).mappings().first()

    lines = db.execute(
        text("""
            SELECT *
            FROM journal_entry_lines
            WHERE journal_entry_id = :entry_id
            ORDER BY id
        """),
        {"entry_id": entry_id},
    ).mappings().all()

    return {
        "entry": dict(entry) if entry else None,
        "lines": [dict(row) for row in lines],
    }


@router.get("/trial-balance")
def trial_balance(
    from_date: date | None = None,
    to_date: date | None = None,
    period_id: int | None = Query(None, ge=1),
    level: int | None = Query(None, ge=1, le=4),
    include_zero: bool = True,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    conditions = ["je.status = 'posted'"]
    params: dict[str, object] = {}
    period = None

    period_from, period_to, period = _period_dates(db, period_id)
    if period_from and period_to:
        from_date = period_from
        to_date = period_to

    if from_date:
        conditions.append("je.entry_date >= :from_date")
        params["from_date"] = from_date
    if to_date:
        conditions.append("je.entry_date <= :to_date")
        params["to_date"] = to_date

    movement_where = f"WHERE {' AND '.join(conditions)}"
    movements = db.execute(
        text(
            f"""
            SELECT
                jel.account_code,
                COALESCE(SUM(jel.debit), 0) AS total_debit,
                COALESCE(SUM(jel.credit), 0) AS total_credit
            FROM journal_entry_lines jel
            JOIN journal_entries je ON je.id = jel.journal_entry_id
            {movement_where}
            GROUP BY jel.account_code
            """
        ),
        params,
    ).mappings().all()

    accounts = db.execute(
        text("""
            SELECT code, name, type, parent_code
            FROM accounts
            WHERE COALESCE(is_active, TRUE) = TRUE
            ORDER BY code
        """)
    ).mappings().all()

    movement_by_code = {
        row["account_code"]: {
            "total_debit": _decimal(row["total_debit"]),
            "total_credit": _decimal(row["total_credit"]),
        }
        for row in movements
    }

    known_codes = {row["code"] for row in accounts}
    nodes = {}
    for account in accounts:
        code = account["code"]
        nodes[code] = {
            "account_code": code,
            "account_name": account["name"],
            "account_type": account["type"],
            "parent_code": _infer_parent(code, known_codes, account["parent_code"]),
            "account_level": _account_level(code),
            "total_debit": movement_by_code.get(code, {}).get("total_debit", Decimal("0")),
            "total_credit": movement_by_code.get(code, {}).get("total_credit", Decimal("0")),
        }

    for code in sorted(nodes.keys(), key=len, reverse=True):
        parent_code = nodes[code]["parent_code"]
        if parent_code in nodes:
            nodes[parent_code]["total_debit"] += nodes[code]["total_debit"]
            nodes[parent_code]["total_credit"] += nodes[code]["total_credit"]

    rows = []
    for node in sorted(nodes.values(), key=lambda item: item["account_code"]):
        if level is not None and node["account_level"] > level:
            continue

        debit = node["total_debit"]
        credit = node["total_credit"]
        if not include_zero and debit == 0 and credit == 0:
            continue

        rows.append(
            {
                "account_code": node["account_code"],
                "account_name": node["account_name"],
                "account_type": node["account_type"],
                "parent_code": node["parent_code"],
                "account_level": node["account_level"],
                "total_debit": _money(debit),
                "total_credit": _money(credit),
                "balance": _money(debit - credit),
            }
        )

    total_debit = sum(_decimal(row["total_debit"]) for row in movements)
    total_credit = sum(_decimal(row["total_credit"]) for row in movements)

    return {
        "rows": rows,
        "totals": {
            "total_debit": _money(total_debit),
            "total_credit": _money(total_credit),
        },
        "filters": {
            "from_date": from_date.isoformat() if from_date else None,
            "to_date": to_date.isoformat() if to_date else None,
            "period_id": period_id,
            "period": period,
            "level": level,
            "include_zero": include_zero,
        },
        "is_balanced": total_debit == total_credit,
    }


@router.get("/ledger/{account_code}")
def account_ledger(
    account_code: str,
    from_date: date | None = None,
    to_date: date | None = None,
    period_id: int | None = Query(None, ge=1),
    status: str | None = Query(None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    conditions = ["jel.account_code = :account_code"]
    params: dict[str, object] = {"account_code": account_code}

    period_from, period_to, _period = _period_dates(db, period_id)
    if period_from and period_to:
        from_date = period_from
        to_date = period_to

    if from_date:
        conditions.append("je.entry_date >= :from_date")
        params["from_date"] = from_date
    if to_date:
        conditions.append("je.entry_date <= :to_date")
        params["to_date"] = to_date
    if status:
        conditions.append("je.status = :status")
        params["status"] = status

    where_clause = f"WHERE {' AND '.join(conditions)}"
    rows = db.execute(
        text(f"""
            SELECT
                jel.id,
                je.entry_no,
                je.entry_date,
                je.source_type,
                je.source_id,
                {_source_label_expr()} AS source_label,
                {_source_no_expr()} AS source_no,
                je.status,
                je.description AS entry_description,
                jel.account_code,
                jel.account_name,
                jel.debit,
                jel.credit,
                jel.project_id,
                jel.party_type,
                jel.party_id,
                jel.description
            FROM journal_entry_lines jel
            JOIN journal_entries je ON je.id = jel.journal_entry_id
            LEFT JOIN adjustment_vouchers av
              ON je.source_type IN ('adjustment_voucher', 'settlement_voucher')
             AND av.id = je.source_id
            LEFT JOIN transactions tx
              ON je.source_type = 'transaction'
             AND tx.id = je.source_id
            LEFT JOIN supplier_invoices si
              ON je.source_type = 'supplier_invoice'
             AND si.id = je.source_id
            LEFT JOIN supplier_payments sp
              ON je.source_type = 'supplier_payment'
             AND sp.id = je.source_id
            LEFT JOIN payrolls p
              ON je.source_type IN ('payroll', 'payroll_payment')
             AND p.id = je.source_id
            {where_clause}
            ORDER BY je.entry_date, je.id, jel.id
        """),
        params,
    ).mappings().all()

    return [dict(row) for row in rows]
