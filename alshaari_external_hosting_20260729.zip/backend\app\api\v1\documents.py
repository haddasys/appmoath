from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_approval_role
from app.db.database import get_db
from app.models.models import Transaction
from app.schemas.schemas import TransactionCreate, TransactionReverseRequest
from app.services.transaction_service import (
    approve_transaction,
    create_transaction,
    delete_transaction_draft,
    reject_transaction,
    reverse_transaction,
    update_transaction_draft,
)


router = APIRouter(prefix="/api/v1/documents", tags=["Documents"])


DOCUMENT_TYPE_LABELS = {
    "receipt_from_customer": "سند قبض من عميل",
    "customer_advance": "دفعة مقدمة من عميل",
    "general_payment": "سند صرف عام",
    "project_expense": "مصروف مشروع",
    "material_purchase": "شراء مواد",
    "material_issue_to_project": "صرف مواد لمشروع",
    "customer_invoice": "فاتورة عميل",
    "supplier_invoice": "فاتورة مورد",
    "supplier_payment": "سند دفع مورد",
    "supplier_advance": "دفعة مقدمة لمورد",
    "worker_wage": "أجر عامل",
    "advance_payment": "صرف سلفة / عهدة عامل",
    "advance_settlement": "تسوية عهدة / سلفة",
    "cash_transfer": "تحويل داخلي بين حسابات نقدية",
}


def document_dict(document: Transaction) -> dict:
    data = {c.name: getattr(document, c.name) for c in document.__table__.columns}
    data.update(
        {
            "document_id": document.id,
            "document_no": document.voucher_no or document.document_no or f"DOC-{document.id:06d}",
            "voucher_no": document.voucher_no or document.document_no or f"DOC-{document.id:06d}",
            "document_type": document.type,
            "document_type_label": DOCUMENT_TYPE_LABELS.get(
                document.type, "مستند مالي"
            ),
            "source_type": "transaction",
            "source_id": document.id,
        }
    )
    return data


@router.get("")
def list_documents(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(Transaction).order_by(Transaction.id.desc()).limit(500).all()
    return [document_dict(row) for row in rows]


@router.get("/types")
def list_document_types(user=Depends(get_current_user)):
    return [
        {"value": value, "label": label}
        for value, label in DOCUMENT_TYPE_LABELS.items()
    ]


@router.post("")
def add_document(
    data: TransactionCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return document_dict(create_transaction(db, data, user.id))


@router.put("/{document_id}")
def update_document(
    document_id: int,
    data: TransactionCreate,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return document_dict(update_transaction_draft(db, document_id, data, user.id))


@router.delete("/{document_id}")
def delete_document(
    document_id: int,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return delete_transaction_draft(db, document_id, user.id)


@router.patch("/{document_id}/approve")
def approve_document(
    document_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_approval_role),
):
    return document_dict(approve_transaction(db, document_id, user.id))


@router.patch("/{document_id}/reject")
def reject_document(
    document_id: int,
    db: Session = Depends(get_db),
    user=Depends(require_approval_role),
):
    return document_dict(reject_transaction(db, document_id, user.id))


@router.post("/{document_id}/reverse")
def reverse_document(
    document_id: int,
    data: TransactionReverseRequest,
    db: Session = Depends(get_db),
    user=Depends(require_approval_role),
):
    return document_dict(reverse_transaction(db, document_id, user.id, data.reason))
