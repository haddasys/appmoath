from datetime import datetime
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.models import Transaction, Account, AuditLog, StockMovement, Item, ProjectCost, CostCenter, CashAccount
from app.services.document_sequence import document_type_for_transaction, next_document_no
from app.services.posting_engine import (
    create_journal_entry_for_transaction,
    create_reversal_journal_entry_for_transaction,
    validate_transaction_posting_ready,
)
from app.services.operation_policy import (
    validate_operation_policy,
    should_apply_cash,
    should_apply_inventory,
    should_apply_project_cost,
)

CASH_ACCOUNT_CODE = "10101"


def log(db: Session, user_id, action, entity, entity_id=None, details=None):
    db.add(
        AuditLog(
            user_id=user_id,
            action=action,
            entity=entity,
            entity_id=entity_id,
            details=details,
        )
    )


def create_transaction(db: Session, data, user_id: int):
    local_uuid = getattr(data, "local_uuid", None)
    if local_uuid:
        existing = db.query(Transaction).filter(Transaction.local_uuid == local_uuid).first()
        if existing:
            log(
                db,
                user_id,
                "sync_duplicate_ignored",
                "transaction",
                existing.id,
                f"تم تجاهل إعادة إرسال المستند المحلي {local_uuid}",
            )
            db.commit()
            return existing

    document_no = next_document_no(
        db,
        document_type_for_transaction(data.type),
        document_date=data.date,
    )
    payload = data.model_dump()
    if payload.get("local_uuid"):
        payload["sync_status"] = payload.get("sync_status") or "synced"
        payload["created_offline"] = bool(payload.get("created_offline", True))
        payload["server_version"] = payload.get("server_version") or 1

    tx = Transaction(
        **payload,
        document_no=document_no,
        voucher_no=document_no,
        status="draft",
        created_by=user_id,
        updated_at=datetime.utcnow(),
    )

    validate_transaction(tx)
    validate_transaction_references(db, tx)

    db.add(tx)
    db.commit()
    db.refresh(tx)

    action = "sync_create_draft" if local_uuid else "create_draft"
    log(db, user_id, action, "transaction", tx.id, tx.type)
    db.commit()

    return tx


def _blocked_approved_change(db: Session, user_id: int, tx: Transaction, action: str):
    log(
        db,
        user_id,
        action,
        "transaction",
        tx.id,
        f"محاولة محظورة على مستند معتمد: {tx.document_no or tx.id}",
    )
    db.commit()


def update_transaction_draft(db: Session, tx_id: int, data, user_id: int):
    tx = db.query(Transaction).filter(Transaction.id == tx_id).first()

    if not tx:
        raise HTTPException(status_code=404, detail="المستند غير موجود")

    if tx.status == "approved":
        _blocked_approved_change(db, user_id, tx, "blocked_update_approved")
        raise HTTPException(
            status_code=400,
            detail="لا يمكن تعديل مستند معتمد. استخدم سند عكسي أو سند تسوية للتصحيح.",
        )

    if tx.status in {"reversed", "reversal"}:
        _blocked_approved_change(db, user_id, tx, "blocked_update_reversed")
        raise HTTPException(status_code=400, detail="لا يمكن تعديل مستند عكسي أو مستند تم عكسه")

    if tx.status not in {"draft", "submitted", "pending", "pending_approval", "rejected"}:
        raise HTTPException(status_code=400, detail=f"لا يمكن تعديل مستند بحالة: {tx.status}")

    payload = data.model_dump()
    for field, value in payload.items():
        if field in {"id", "status", "created_by", "approved_by", "approved_at", "created_at"}:
            continue
        if hasattr(tx, field):
            setattr(tx, field, value)

    validate_transaction(tx)
    validate_transaction_references(db, tx)
    log(db, user_id, "update_draft", "transaction", tx.id, tx.type)
    db.commit()
    db.refresh(tx)
    return tx


def delete_transaction_draft(db: Session, tx_id: int, user_id: int):
    tx = db.query(Transaction).filter(Transaction.id == tx_id).first()

    if not tx:
        raise HTTPException(status_code=404, detail="المستند غير موجود")

    if tx.status == "approved":
        _blocked_approved_change(db, user_id, tx, "delete_attempt")
        raise HTTPException(
            status_code=400,
            detail="لا يمكن حذف مستند معتمد. استخدم سند عكسي أو سند تسوية للتصحيح.",
        )

    if tx.status in {"reversed", "reversal"}:
        _blocked_approved_change(db, user_id, tx, "delete_attempt")
        raise HTTPException(status_code=400, detail="لا يمكن حذف مستند عكسي أو مستند تم عكسه")

    existing_entry = db.execute(
        text(
            """
            SELECT id
            FROM journal_entries
            WHERE source_type = 'transaction'
              AND source_id = :source_id
            LIMIT 1
            """
        ),
        {"source_id": tx.id},
    ).first()
    if existing_entry:
        _blocked_approved_change(db, user_id, tx, "delete_attempt")
        raise HTTPException(status_code=400, detail="لا يمكن حذف مستند له قيد محاسبي")

    log(db, user_id, "delete_draft", "transaction", tx.id, tx.type)
    db.delete(tx)
    db.commit()
    return {"ok": True, "deleted_id": tx_id}


def _decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _default_cash_account_code(tx: Transaction) -> str:
    if getattr(tx, "currency", None) == "SAR":
        return "10102"
    if getattr(tx, "currency", None) == "USD":
        return "10103"
    return CASH_ACCOUNT_CODE


def _cash_account_by_id(db: Session, cash_account_id: int | None, currency: str | None, label: str = "حساب النقدية"):
    if not cash_account_id:
        raise HTTPException(status_code=400, detail=f"{label} مطلوب")

    cash_account = (
        db.query(CashAccount)
        .filter(CashAccount.id == cash_account_id, CashAccount.is_active == True)
        .first()
    )
    if not cash_account:
        raise HTTPException(status_code=400, detail=f"{label} غير موجود أو غير نشط")
    if currency and cash_account.currency != currency:
        raise HTTPException(status_code=400, detail=f"عملة {label} لا تطابق عملة السند")
    return cash_account


def _account_for_cash_account(db: Session, cash_account: CashAccount):
    account_code = getattr(cash_account, "account_code", None) or cash_account.code

    acc = db.query(Account).filter(Account.code == account_code).first()

    if not acc:
        acc = Account(
            code=account_code,
            name=cash_account.name,
            type=getattr(cash_account, "type", None) or "cash",
            currency=getattr(cash_account, "currency", "YER"),
            balance=0,
        )
        db.add(acc)
        db.flush()

    return acc


def _cash_account(db: Session, tx: Transaction):
    cash_account_id = getattr(tx, "cash_account_id", None)

    if not cash_account_id:
        raise HTTPException(
            status_code=400,
            detail="العملية النقدية تتطلب اختيار الصندوق أو المحفظة أو الحساب البنكي",
        )

    cash_account = _cash_account_by_id(db, cash_account_id, getattr(tx, "currency", None))
    return _account_for_cash_account(db, cash_account)


def _apply_cash_account_delta(db: Session, cash_account_id: int | None, amount: Decimal, currency: str | None, label: str):
    cash_account = _cash_account_by_id(db, cash_account_id, currency, label)
    account = _account_for_cash_account(db, cash_account)
    account.balance = _decimal(account.balance) + amount
    cash_account.balance = _decimal(cash_account.balance) + amount
    cash_account.current_balance = _decimal(getattr(cash_account, "current_balance", 0)) + amount
    return cash_account, account


def validate_transaction(tx: Transaction):
    validate_operation_policy(tx)


def validate_transaction_references(db: Session, tx: Transaction):
    cost_center_id = getattr(tx, "cost_center_id", None)
    if cost_center_id:
        cost_center = (
            db.query(CostCenter)
            .filter(CostCenter.id == cost_center_id, CostCenter.is_active == True)
            .first()
        )
        if not cost_center:
            raise HTTPException(status_code=400, detail="مركز التكلفة غير موجود أو غير نشط")
        if getattr(cost_center, "is_postable", True) is False:
            raise HTTPException(
                status_code=400,
                detail="لا يمكن الترحيل على مركز تكلفة تجميعي. اختر مركزا فرعيا قابلا للترحيل",
            )

    cash_effect = should_apply_cash(tx)
    if cash_effect in ["increase", "decrease"]:
        _cash_account(db, tx)
    elif cash_effect == "transfer":
        from_cash = _cash_account_by_id(
            db,
            getattr(tx, "from_cash_account_id", None),
            getattr(tx, "currency", None),
            "حساب النقدية المحول منه",
        )
        to_cash = _cash_account_by_id(
            db,
            getattr(tx, "to_cash_account_id", None),
            getattr(tx, "currency", None),
            "حساب النقدية المحول إليه",
        )
        if from_cash.id == to_cash.id:
            raise HTTPException(status_code=400, detail="لا يمكن التحويل بين نفس حساب النقدية")


def apply_cash_effect(db: Session, tx: Transaction):
    effect = should_apply_cash(tx)

    if effect == "none":
        return

    amount = _decimal(tx.amount)

    if effect == "transfer":
        _apply_cash_account_delta(
            db,
            getattr(tx, "from_cash_account_id", None),
            -amount,
            getattr(tx, "currency", None),
            "حساب النقدية المحول منه",
        )
        _apply_cash_account_delta(
            db,
            getattr(tx, "to_cash_account_id", None),
            amount,
            getattr(tx, "currency", None),
            "حساب النقدية المحول إليه",
        )
        return

    cash = _cash_account(db, tx)
    balance = _decimal(cash.balance)

    if effect == "increase":
        cash.balance = balance + amount
        if getattr(tx, "cash_account_id", None):
            cash_account = db.query(CashAccount).filter(CashAccount.id == tx.cash_account_id).first()
            if cash_account:
                cash_account.balance = _decimal(cash_account.balance) + amount
                cash_account.current_balance = _decimal(getattr(cash_account, "current_balance", 0)) + amount

    elif effect == "decrease":
        cash.balance = balance - amount
        if getattr(tx, "cash_account_id", None):
            cash_account = db.query(CashAccount).filter(CashAccount.id == tx.cash_account_id).first()
            if cash_account:
                cash_account.balance = _decimal(cash_account.balance) - amount
                cash_account.current_balance = _decimal(getattr(cash_account, "current_balance", 0)) - amount

    else:
        raise HTTPException(
            status_code=400,
            detail=f"أثر الصندوق غير معروف: {effect}",
        )


def apply_material_purchase(db: Session, tx: Transaction):
    item = db.query(Item).filter(Item.id == tx.item_id).first()

    if not item:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    qty = _decimal(tx.qty)
    amount = _decimal(tx.amount)
    unit_cost = _decimal(getattr(tx, "unit_cost", 0))

    if qty <= 0:
        raise HTTPException(status_code=400, detail="كمية الشراء يجب أن تكون أكبر من صفر")

    if unit_cost <= 0:
        unit_cost = amount / qty

    old_qty = _decimal(item.current_qty)
    old_avg = _decimal(item.avg_cost)

    new_qty = old_qty + qty

    if new_qty > 0:
        new_avg = ((old_qty * old_avg) + (qty * unit_cost)) / new_qty
    else:
        new_avg = old_avg

    item.current_qty = new_qty
    item.avg_cost = new_avg

    movement = StockMovement(
        date=tx.date,
        item_id=tx.item_id,
        movement_type="in",
        qty=qty,
        unit_cost=unit_cost,
        project_id=tx.project_id,
        cost_center_id=getattr(tx, "cost_center_id", None),
        transaction_id=tx.id,
        notes=tx.description,
    )

    db.add(movement)


def apply_material_issue_to_project(db: Session, tx: Transaction):
    item = db.query(Item).filter(Item.id == tx.item_id).first()

    if not item:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    qty = _decimal(tx.qty)
    current_qty = _decimal(item.current_qty)

    if qty <= 0:
        raise HTTPException(status_code=400, detail="كمية الصرف يجب أن تكون أكبر من صفر")

    if qty > current_qty:
        raise HTTPException(
            status_code=400,
            detail=f"الكمية المطلوبة أكبر من رصيد المخزون. الرصيد الحالي: {current_qty}",
        )

    unit_cost = _decimal(getattr(tx, "unit_cost", 0))

    if unit_cost <= 0:
        unit_cost = _decimal(item.avg_cost)

    item.current_qty = current_qty - qty

    movement = StockMovement(
        date=tx.date,
        item_id=tx.item_id,
        movement_type="out",
        qty=qty,
        unit_cost=unit_cost,
        project_id=tx.project_id,
        cost_center_id=getattr(tx, "cost_center_id", None),
        transaction_id=tx.id,
        notes=tx.description,
    )

    db.add(movement)


def apply_project_cost_effect(db: Session, tx: Transaction):
    effect = should_apply_project_cost(tx)

    if effect == "none":
        return

    if effect == "optional" and not tx.project_id:
        return

    if effect in ["increase", "optional"] and not tx.project_id:
        raise HTTPException(status_code=400, detail="يجب تحديد المشروع لتسجيل التكلفة")

    existing = (
        db.query(ProjectCost)
        .filter(
            ProjectCost.source_type == "transaction",
            ProjectCost.source_id == tx.id,
        )
        .first()
    )

    if existing:
        return

    amount = _decimal(tx.amount)

    if amount <= 0:
        raise HTTPException(status_code=400, detail="تكلفة المشروع يجب أن تكون أكبر من صفر")

    db.add(
        ProjectCost(
            project_id=tx.project_id,
            cost_center_id=getattr(tx, "cost_center_id", None),
            date=tx.date,
            category=tx.cost_category or tx.type,
            amount=amount,
            source_type="transaction",
            source_id=tx.id,
            notes=tx.description,
        )
    )


def reverse_cash_effect(db: Session, tx: Transaction):
    effect = should_apply_cash(tx)

    if effect == "none":
        return

    amount = _decimal(tx.amount)

    if effect == "transfer":
        _apply_cash_account_delta(
            db,
            getattr(tx, "from_cash_account_id", None),
            amount,
            getattr(tx, "currency", None),
            "حساب النقدية المحول منه",
        )
        _apply_cash_account_delta(
            db,
            getattr(tx, "to_cash_account_id", None),
            -amount,
            getattr(tx, "currency", None),
            "حساب النقدية المحول إليه",
        )
        return

    cash = _cash_account(db, tx)
    balance = _decimal(cash.balance)

    if effect == "increase":
        cash.balance = balance - amount
        if getattr(tx, "cash_account_id", None):
            cash_account = db.query(CashAccount).filter(CashAccount.id == tx.cash_account_id).first()
            if cash_account:
                cash_account.balance = _decimal(cash_account.balance) - amount
                cash_account.current_balance = _decimal(getattr(cash_account, "current_balance", 0)) - amount
    elif effect == "decrease":
        cash.balance = balance + amount
        if getattr(tx, "cash_account_id", None):
            cash_account = db.query(CashAccount).filter(CashAccount.id == tx.cash_account_id).first()
            if cash_account:
                cash_account.balance = _decimal(cash_account.balance) + amount
                cash_account.current_balance = _decimal(getattr(cash_account, "current_balance", 0)) + amount
    else:
        raise HTTPException(status_code=400, detail=f"أثر الصندوق غير معروف: {effect}")


def reverse_inventory_effect(db: Session, tx: Transaction):
    inventory_effect = should_apply_inventory(tx)

    if inventory_effect == "none":
        return

    item = db.query(Item).filter(Item.id == tx.item_id).first()

    if not item:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    qty = _decimal(tx.qty)
    current_qty = _decimal(item.current_qty)
    unit_cost = _decimal(getattr(tx, "unit_cost", 0))

    if unit_cost <= 0:
        unit_cost = _decimal(item.avg_cost)

    if inventory_effect == "increase":
        if qty > current_qty:
            raise HTTPException(
                status_code=400,
                detail=f"لا يمكن عكس شراء المواد لأن الرصيد الحالي أقل من الكمية. الرصيد الحالي: {current_qty}",
            )
        item.current_qty = current_qty - qty
        movement_type = "purchase_reversal"

    elif inventory_effect == "decrease":
        item.current_qty = current_qty + qty
        movement_type = "issue_reversal"

    else:
        return

    db.add(
        StockMovement(
            date=tx.date,
            item_id=tx.item_id,
            movement_type=movement_type,
            qty=qty,
            unit_cost=unit_cost,
            project_id=tx.project_id,
            cost_center_id=getattr(tx, "cost_center_id", None),
            transaction_id=tx.id,
            notes=f"عكس الحركة: {tx.description or tx.id}",
        )
    )


def reverse_project_cost_effect(db: Session, tx: Transaction):
    effect = should_apply_project_cost(tx)

    if effect == "none":
        return

    if effect == "optional" and not tx.project_id:
        return

    existing = (
        db.query(ProjectCost)
        .filter(
            ProjectCost.source_type == "transaction_reversal",
            ProjectCost.source_id == tx.id,
        )
        .first()
    )

    if existing:
        return

    db.add(
        ProjectCost(
            project_id=tx.project_id,
            cost_center_id=getattr(tx, "cost_center_id", None),
            date=tx.date,
            category=tx.cost_category or tx.type,
            amount=-_decimal(tx.amount),
            source_type="transaction_reversal",
            source_id=tx.id,
            notes=f"عكس تكلفة الحركة: {tx.description or tx.id}",
        )
    )


def apply_transaction_effect(db: Session, tx: Transaction):
    validate_transaction(tx)
    validate_transaction_references(db, tx)

    apply_cash_effect(db, tx)

    inventory_effect = should_apply_inventory(tx)

    if inventory_effect == "increase":
        apply_material_purchase(db, tx)

    elif inventory_effect == "decrease":
        apply_material_issue_to_project(db, tx)

    apply_project_cost_effect(db, tx)


def approve_transaction(db: Session, tx_id: int, user_id: int):
    try:
        tx = db.query(Transaction).filter(Transaction.id == tx_id).first()

        if not tx:
            raise HTTPException(status_code=404, detail="المستند غير موجود")

        if tx.status == "approved":
            raise HTTPException(status_code=400, detail="المستند معتمد مسبقًا")

        if tx.status == "rejected":
            raise HTTPException(status_code=400, detail="لا يمكن اعتماد مستند مرفوض")

        if tx.status not in {"draft", "submitted", "pending", "pending_approval"}:
            raise HTTPException(status_code=400, detail=f"لا يمكن اعتماد مستند بحالة: {tx.status}")

        validate_transaction(tx)
        validate_transaction_references(db, tx)
        validate_transaction_posting_ready(db, tx, user_id)

        apply_transaction_effect(db, tx)

        create_journal_entry_for_transaction(db, tx, user_id)

        tx.status = "approved"
        tx.approved_by = user_id

        if hasattr(tx, "approved_at"):
            tx.approved_at = datetime.utcnow()

        log(db, user_id, "approve", "transaction", tx.id, tx.type)

        db.commit()
        db.refresh(tx)

        return tx
    except Exception:
        db.rollback()
        raise


def reverse_transaction(db: Session, tx_id: int, user_id: int, reason: str):
    try:
        tx = db.query(Transaction).filter(Transaction.id == tx_id).first()

        if not tx:
            raise HTTPException(status_code=404, detail="المستند غير موجود")

        if tx.status != "approved":
            raise HTTPException(status_code=400, detail="لا يمكن عكس مستند غير معتمد")

        if tx.reversed_by_id:
            raise HTTPException(status_code=400, detail="تم عكس هذا المستند مسبقًا")

        if not reason or len(reason.strip()) < 5:
            raise HTTPException(status_code=400, detail="سبب العكس مطلوب ويجب أن يكون واضحًا")

        reverse_cash_effect(db, tx)
        reverse_inventory_effect(db, tx)
        reverse_project_cost_effect(db, tx)

        reversal_document_no = next_document_no(
            db,
            document_type_for_transaction(tx.type),
            document_date=datetime.utcnow().date(),
        )
        reversal_tx = Transaction(
            date=datetime.utcnow().date(),
            type=tx.type,
            amount=tx.amount,
            currency=tx.currency,
            payment_method=tx.payment_method,
            cash_account_id=getattr(tx, "cash_account_id", None),
            from_cash_account_id=getattr(tx, "from_cash_account_id", None),
            to_cash_account_id=getattr(tx, "to_cash_account_id", None),
            related_account_type=tx.related_account_type,
            related_id=tx.related_id,
            project_id=tx.project_id,
            cost_center_id=getattr(tx, "cost_center_id", None),
            settlement_type=getattr(tx, "settlement_type", None),
            cost_category=tx.cost_category,
            item_id=tx.item_id,
            qty=tx.qty,
            unit_cost=tx.unit_cost,
            description=f"عكس المستند {tx.document_no or tx.id}: {reason.strip()}",
            document_no=reversal_document_no,
            voucher_no=reversal_document_no,
            status="reversal",
            created_by=user_id,
            approved_by=user_id,
            approved_at=datetime.utcnow(),
            reversal_of_id=tx.id,
            void_reason=reason.strip(),
        )
        db.add(reversal_tx)
        db.flush()

        create_reversal_journal_entry_for_transaction(db, tx, reversal_tx, user_id)

        tx.status = "reversed"
        tx.reversed_by_id = reversal_tx.id
        tx.void_reason = reason.strip()

        log(db, user_id, "reverse", "transaction", tx.id, reason.strip())

        db.commit()
        db.refresh(reversal_tx)

        return reversal_tx
    except Exception:
        db.rollback()
        raise


def reject_transaction(db: Session, tx_id: int, user_id: int):
    tx = db.query(Transaction).filter(Transaction.id == tx_id).first()

    if not tx:
        raise HTTPException(status_code=404, detail="المستند غير موجود")

    if tx.status == "approved":
        raise HTTPException(status_code=400, detail="لا يمكن رفض مستند معتمد")

    if tx.status == "rejected":
        raise HTTPException(status_code=400, detail="المستند مرفوض مسبقًا")

    if tx.status in {"reversed", "reversal"}:
        raise HTTPException(status_code=400, detail="لا يمكن رفض مستند عكسي أو مستند تم عكسه")

    tx.status = "rejected"
    tx.approved_by = user_id

    log(db, user_id, "reject", "transaction", tx.id, tx.type)

    db.commit()
    db.refresh(tx)

    return tx
