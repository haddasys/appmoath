from decimal import Decimal
from fastapi import HTTPException


def _has_value(value):
    if value is None:
        return False
    if value == "":
        return False
    if value == 0:
        return False
    if value == 0.0:
        return False
    if str(value) in ["0", "0.0", "0.00", "None", "null"]:
        return False
    return True


FIELD_LABELS = {
    "amount": "المبلغ",
    "payment_method": "طريقة الدفع",
    "description": "البيان/الوصف",
    "related_id": "الطرف المرتبط",
    "related_account_type": "نوع الحساب المرتبط",
    "project_id": "المشروع",
    "item_id": "الصنف",
    "qty": "الكمية",
    "unit_cost": "تكلفة الوحدة",
    "cost_category": "بند التكلفة",
    "cash_account_id": "الصندوق / الحساب البنكي",
    "cost_center_id": "مركز التكلفة",
    "from_cash_account_id": "من حساب (المصدر)",
    "to_cash_account_id": "إلى حساب (المستلم)",
    "currency": "العملة",
    "settlement_type": "نوع التسوية",
}


def _decimal(value):
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


OPERATION_POLICIES = {
    "receipt_from_customer": {
        "label": "قبض من عميل",
        "required": ["amount", "payment_method", "cash_account_id", "description", "related_id"],
        "required_party_type": "customer",
        "optional": ["project_id"],
        "forbidden": ["item_id", "qty", "unit_cost", "cost_category"],
        "cash_effect": "increase",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "customer_advance": {
        "label": "دفعة مقدمة من عميل",
        "required": ["amount", "payment_method", "cash_account_id", "description", "related_id"],
        "required_party_type": "customer",
        "optional": ["project_id"],
        "forbidden": ["item_id", "qty", "unit_cost", "cost_category"],
        "cash_effect": "increase",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "general_payment": {
        "label": "صرف عام",
        "required": ["amount", "payment_method", "cash_account_id", "cost_category", "description"],
        "required_party_type": None,
        "optional": [],
        "forbidden": [
            "related_account_type",
            "related_id",
            "project_id",
            "item_id",
            "qty",
            "unit_cost",
        ],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "project_expense": {
        "label": "مصروف مرتبط بمشروع",
        "required": ["amount", "payment_method", "cash_account_id", "project_id", "cost_category", "cost_center_id", "description"],
        "required_party_type": None,
        "optional": ["related_account_type", "related_id"],
        "forbidden": ["item_id", "qty", "unit_cost"],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "increase",
    },

    "material_purchase": {
        "label": "شراء مواد نقدا",
        "required": [
            "amount",
            "payment_method",
            "cash_account_id",
            "related_id",
            "item_id",
            "qty",
            "cost_category",
            "cost_center_id",
            "description",
        ],
        "required_party_type": "supplier",
        "optional": ["unit_cost"],
        "forbidden": ["project_id"],
        "cash_effect": "decrease",
        "inventory_effect": "increase",
        "project_cost_effect": "none",
    },

    "supplier_invoice": {
        "label": "فاتورة مورد آجل",
        "required": ["amount", "related_id", "description"],
        "required_party_type": "supplier",
        "optional": ["project_id", "cost_category", "item_id", "qty", "unit_cost"],
        "forbidden": ["payment_method", "cash_account_id"],
        "cash_effect": "none",
        "inventory_effect": "optional",
        "project_cost_effect": "optional",
    },

    "supplier_payment": {
        "label": "دفعة مورد",
        "required": ["amount", "payment_method", "cash_account_id", "related_id", "description"],
        "required_party_type": "supplier",
        "optional": [],
        "forbidden": ["project_id", "item_id", "qty", "unit_cost", "cost_category"],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "supplier_advance": {
        "label": "دفعة مقدمة لمورد",
        "required": ["amount", "payment_method", "cash_account_id", "related_id", "description"],
        "required_party_type": "supplier",
        "optional": [],
        "forbidden": ["project_id", "item_id", "qty", "unit_cost", "cost_category"],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "material_issue_to_project": {
        "label": "صرف مواد لمشروع",
        "required": ["amount", "project_id", "item_id", "qty", "cost_category", "cost_center_id", "description"],
        "required_party_type": None,
        "optional": ["unit_cost"],
        "forbidden": ["payment_method", "cash_account_id", "related_account_type", "related_id"],
        "cash_effect": "none",
        "inventory_effect": "decrease",
        "project_cost_effect": "increase",
    },

    "worker_wage": {
        "label": "أجر عامل",
        "required": ["amount", "payment_method", "cash_account_id", "related_id", "cost_category", "cost_center_id", "description"],
        "required_party_type": "worker",
        "optional": ["project_id"],
        "forbidden": ["item_id", "qty", "unit_cost"],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "optional",
    },

    "advance_payment": {
        "label": "سلفة / عهدة عامل",
        "required": ["amount", "payment_method", "cash_account_id", "related_id", "description"],
        "required_party_type": "worker",
        "optional": [],
        "forbidden": [
            "project_id",
            "cost_center_id",
            "cost_category",
            "settlement_type",
            "item_id",
            "qty",
            "unit_cost",
        ],
        "cash_effect": "decrease",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "advance_settlement": {
        "label": "تسوية عهدة",
        "required": ["amount", "related_id", "settlement_type", "description"],
        "required_party_type": "worker",
        "optional": ["project_id", "cost_center_id", "cost_category", "payment_method"],
        "forbidden": ["item_id", "qty", "unit_cost"],
        "cash_effect": "none",
        "inventory_effect": "none",
        "project_cost_effect": "optional",
    },

    "customer_invoice": {
        "label": "فاتورة عميل",
        "required": ["amount", "related_id", "project_id", "description"],
        "required_party_type": "customer",
        "optional": [],
        "forbidden": ["payment_method", "cash_account_id", "item_id", "qty", "unit_cost", "cost_category"],
        "cash_effect": "none",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },

    "cash_transfer": {
        "label": "تحويل بين صناديق",
        "required": ["amount", "description", "from_cash_account_id", "to_cash_account_id"],
        "required_party_type": None,
        "optional": ["payment_method"],
        "forbidden": [
            "cash_account_id",
            "related_account_type",
            "related_id",
            "project_id",
            "item_id",
            "qty",
            "unit_cost",
            "cost_category",
        ],
        "cash_effect": "transfer",
        "inventory_effect": "none",
        "project_cost_effect": "none",
    },
}


def get_operation_policy(operation_type: str):
    if operation_type in {"customer_invoice", "supplier_invoice"}:
        raise HTTPException(
            status_code=400,
            detail="الفواتير تسجل من شاشة الفواتير والذمم، وليس من شاشة السندات المالية",
        )

    policy = OPERATION_POLICIES.get(operation_type)

    if not policy:
        raise HTTPException(
            status_code=400,
            detail=f"نوع العملية غير معتمد: {operation_type}",
        )

    return policy


def get_field_value(tx, field_name: str):
    return getattr(tx, field_name, None)


def validate_operation_policy(tx):
    policy = get_operation_policy(tx.type)

    amount = _decimal(getattr(tx, "amount", 0))
    if amount <= 0:
        raise HTTPException(
            status_code=400,
            detail="المبلغ يجب أن يكون أكبر من صفر",
        )

    required_party_type = policy.get("required_party_type")
    if required_party_type:
        if getattr(tx, "related_account_type", None) != required_party_type:
            raise HTTPException(
                status_code=400,
                detail=f"{policy['label']} تتطلب طرفا من نوع {required_party_type}",
            )

    for field in policy["required"]:
        value = get_field_value(tx, field)

        if not _has_value(value):
            label = FIELD_LABELS.get(field, field)
            raise HTTPException(
                status_code=400,
                detail=f"يرجى إدخال ({label})، هذا الحقل مطلوب لإتمام العملية",
            )

    for field in policy["forbidden"]:
        value = get_field_value(tx, field)

        if _has_value(value):
            label = FIELD_LABELS.get(field, field)
            raise HTTPException(
                status_code=400,
                detail=f"لا يمكن استخدام حقل ({label}) في عملية {policy['label']}",
            )

    if "qty" in policy["required"]:
        qty = _decimal(getattr(tx, "qty", 0))
        if qty <= 0:
            raise HTTPException(
                status_code=400,
                detail="الكمية يجب أن تكون أكبر من صفر",
            )

    if tx.type == "advance_settlement":
        validate_advance_settlement(tx)

    if tx.type == "worker_wage":
        validate_worker_wage(tx)

    if tx.type == "cash_transfer":
        validate_cash_transfer(tx)

    if getattr(tx, "description", None):
        if len(str(tx.description).strip()) < 3:
            raise HTTPException(
                status_code=400,
                detail="البيان قصير جدا وغير كاف للمراجعة",
            )

    return True


def validate_advance_settlement(tx):
    settlement_type = getattr(tx, "settlement_type", None)
    allowed = {
        "wage_project",
        "wage_general",
        "expense_project",
        "cash_return",
        "salary_deduction",
    }

    if settlement_type not in allowed:
        raise HTTPException(
            status_code=400,
            detail="نوع التسوية غير صحيح. اختر: أجر مشروع، أجر عام، مصروف مشروع، إرجاع نقدي، أو خصم من الراتب",
        )

    project_id = getattr(tx, "project_id", None)
    cost_center_id = getattr(tx, "cost_center_id", None)
    cost_category = getattr(tx, "cost_category", None)
    payment_method = getattr(tx, "payment_method", None)
    cash_account_id = getattr(tx, "cash_account_id", None)

    if settlement_type == "wage_project":
        if _has_value(payment_method):
            raise HTTPException(status_code=400, detail="تسوية أجر مشروع لا تستخدم طريقة دفع لأنها لا تؤثر على الصندوق")
        if _has_value(cash_account_id):
            raise HTTPException(status_code=400, detail="تسوية أجر مشروع لا تستخدم حساب نقدية")
        if not _has_value(project_id) or not _has_value(cost_center_id):
            raise HTTPException(status_code=400, detail="تسوية أجر مشروع تتطلب مشروعًا ومركز تكلفة")
        if cost_category != "labor":
            raise HTTPException(status_code=400, detail="تسوية أجر مشروع يجب أن يكون بند التكلفة فيها labor")

    elif settlement_type == "wage_general":
        if _has_value(payment_method):
            raise HTTPException(status_code=400, detail="تسوية أجر عام لا تستخدم طريقة دفع لأنها لا تؤثر على الصندوق")
        if _has_value(cash_account_id):
            raise HTTPException(status_code=400, detail="تسوية أجر عام لا تستخدم حساب نقدية")
        if _has_value(project_id):
            raise HTTPException(status_code=400, detail="تسوية أجر عام لا ترتبط بمشروع")
        if not _has_value(cost_center_id):
            raise HTTPException(status_code=400, detail="تسوية أجر عام تتطلب مركز تكلفة")
        if cost_category != "labor":
            raise HTTPException(status_code=400, detail="تسوية أجر عام يجب أن يكون بند التكلفة فيها labor")

    elif settlement_type == "expense_project":
        if _has_value(payment_method):
            raise HTTPException(status_code=400, detail="تسوية مصروف مشروع لا تستخدم طريقة دفع لأنها لا تؤثر على الصندوق")
        if _has_value(cash_account_id):
            raise HTTPException(status_code=400, detail="تسوية مصروف مشروع لا تستخدم حساب نقدية")
        if not _has_value(project_id) or not _has_value(cost_center_id) or not _has_value(cost_category):
            raise HTTPException(status_code=400, detail="تسوية مصروف مشروع تتطلب مشروعًا ومركز تكلفة وبند تكلفة")

    elif settlement_type == "cash_return":
        if not _has_value(payment_method):
            raise HTTPException(status_code=400, detail="إرجاع النقدية يتطلب طريقة دفع")
        if not _has_value(getattr(tx, "cash_account_id", None)):
            raise HTTPException(status_code=400, detail="إرجاع النقدية يتطلب اختيار الصندوق أو المحفظة المستلمة")
        if _has_value(project_id) or _has_value(cost_center_id) or _has_value(cost_category):
            raise HTTPException(status_code=400, detail="إرجاع النقدية لا يرتبط بمشروع أو مركز تكلفة أو بند تكلفة")

    elif settlement_type == "salary_deduction":
        if _has_value(payment_method):
            raise HTTPException(status_code=400, detail="خصم الراتب لا يستخدم طريقة دفع لأنه تسوية غير نقدية")
        if _has_value(cash_account_id):
            raise HTTPException(status_code=400, detail="خصم الراتب لا يستخدم حساب نقدية")
        if _has_value(project_id) or _has_value(cost_center_id) or _has_value(cost_category):
            raise HTTPException(status_code=400, detail="خصم الراتب لا يرتبط بمشروع أو مركز تكلفة أو بند تكلفة")


def validate_worker_wage(tx):
    if getattr(tx, "cost_category", None) != "labor":
        raise HTTPException(status_code=400, detail="أجر العامل يجب أن يكون بند التكلفة فيه labor")
    if getattr(tx, "project_id", None) and not getattr(tx, "cost_center_id", None):
        raise HTTPException(status_code=400, detail="أجر المشروع يتطلب مركز تكلفة")


def validate_cash_transfer(tx):
    from_id = getattr(tx, "from_cash_account_id", None)
    to_id = getattr(tx, "to_cash_account_id", None)

    if not _has_value(from_id) or not _has_value(to_id):
        raise HTTPException(status_code=400, detail="التحويل يتطلب تحديد حساب النقدية المحول منه والمحول إليه")
    if str(from_id) == str(to_id):
        raise HTTPException(status_code=400, detail="لا يمكن التحويل بين نفس حساب النقدية")


def should_apply_cash(tx):
    if tx.type == "advance_settlement":
        return "increase" if getattr(tx, "settlement_type", None) == "cash_return" else "none"
    policy = get_operation_policy(tx.type)
    return policy["cash_effect"]


def should_apply_inventory(tx):
    policy = get_operation_policy(tx.type)
    return policy["inventory_effect"]


def should_apply_project_cost(tx):
    if tx.type == "advance_settlement":
        return "increase" if getattr(tx, "settlement_type", None) in {"wage_project", "expense_project"} else "none"
    if tx.type == "worker_wage":
        return "increase" if getattr(tx, "project_id", None) else "none"
    policy = get_operation_policy(tx.type)
    return policy["project_cost_effect"]


def allowed_ui_fields(operation_type: str):
    policy = get_operation_policy(operation_type)

    base_fields = set(["type", "amount", "currency", "description"])
    allowed = base_fields | set(policy["required"]) | set(policy["optional"])

    return {
        "label": policy["label"],
        "allowed": sorted(list(allowed)),
        "required": policy["required"],
        "forbidden": policy["forbidden"],
        "cash_effect": policy["cash_effect"],
        "inventory_effect": policy["inventory_effect"],
        "project_cost_effect": policy["project_cost_effect"],
        "settlement_types": [
            "wage_project",
            "wage_general",
            "expense_project",
            "cash_return",
            "salary_deduction",
        ] if operation_type == "advance_settlement" else [],
    }
