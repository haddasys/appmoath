import 'dart:convert';
import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../core/local_db/local_database.dart';
import '../../../core/local_db/local_entities.dart';
import '../../../core/network/connectivity_service.dart';
import '../../../core/offline_queue/offline_queue.dart';
import '../../../core/widgets/alshaari_ui.dart';
import 'payroll_api.dart';

class AttendanceScreen extends StatefulWidget {
  final int? initialEmployeeId;

  const AttendanceScreen({super.key, this.initialEmployeeId});

  @override
  State<AttendanceScreen> createState() => _AttendanceScreenState();
}

class _AttendanceScreenState extends State<AttendanceScreen> {
  final _dateFormat = DateFormat('yyyy-MM-dd');
  final projectId = TextEditingController();
  final costCenterId = TextEditingController();

  bool loading = true;
  bool saving = false;
  DateTime selectedDate = DateTime.now();
  List<Map<String, dynamic>> workers = [];
  final Map<int, String> selectedStatuses = {};
  final Map<int, TextEditingController> notesControllers = {};

  static const statusLabels = {
    'present': 'حاضر',
    'absent': 'غائب',
    'half_day': 'نصف يوم',
    'leave': 'إجازة',
    'friday_paid': 'جمعة / إضافي',
  };

  static const statusIcons = {
    'present': Icons.check_circle_outline,
    'absent': Icons.cancel_outlined,
    'half_day': Icons.timelapse_outlined,
    'leave': Icons.event_busy_outlined,
    'friday_paid': Icons.add_circle_outline,
  };

  static const statusColors = {
    'present': AlshaariColors.success,
    'absent': AlshaariColors.danger,
    'half_day': AlshaariColors.warning,
    'leave': AlshaariColors.slate,
    'friday_paid': AlshaariColors.info,
  };

  @override
  void initState() {
    super.initState();
    loadDailyAttendance();
  }

  @override
  void dispose() {
    projectId.dispose();
    costCenterId.dispose();
    for (final controller in notesControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  String get selectedDateIso => _dateFormat.format(selectedDate);

  Future<void> loadDailyAttendance() async {
    setState(() => loading = true);
    try {
      final dio = await payrollDio();
      final response = await dio.get(
        '/api/v1/attendance/daily',
        queryParameters: {'date': selectedDateIso},
      );
      final rows = asList(response.data);
      if (!mounted) return;

      await cacheWorkers(rows);
      applyRows(rows);
    } catch (e) {
      if (!mounted) return;
      final cachedRows = await loadCachedWorkers();
      if (!mounted) return;
      if (cachedRows.isNotEmpty) {
        applyRows(cachedRows);
      } else {
        setState(() => loading = false);
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            cachedRows.isEmpty
                ? errorMessage(e)
                : 'السيرفر غير متاح. تم تحميل العمال من النسخة المحلية.',
          ),
        ),
      );
    }
  }

  void applyRows(List<Map<String, dynamic>> rows) {
    for (final row in rows) {
      final employeeId = row['employee_id'] as int?;
      if (employeeId == null) continue;
      notesControllers.putIfAbsent(
        employeeId,
        () => TextEditingController(),
      );
      notesControllers[employeeId]!.text = '${row['notes'] ?? ''}';
    }

    setState(() {
      workers = rows;
      selectedStatuses
        ..clear()
        ..addEntries(
          rows.map((row) {
            final employeeId = row['employee_id'] as int;
            final status = '${row['status'] ?? 'not_set'}';
            return MapEntry(
              employeeId,
              status == 'not_set' ? 'present' : status,
            );
          }),
        );
      if (widget.initialEmployeeId != null) {
        selectedStatuses.updateAll(
          (employeeId, status) =>
              employeeId == widget.initialEmployeeId ? status : 'absent',
        );
      }
      loading = false;
    });
  }

  Future<void> cacheWorkers(List<Map<String, dynamic>> rows) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    for (final row in rows) {
      final employeeId = row['employee_id'] as int?;
      if (employeeId == null) continue;
      await localDatabase.upsertLocalMasterData(
        LocalMasterDataRecord(
          entityType: 'employee',
          serverId: employeeId,
          name: '${row['employee_name'] ?? 'عامل'}',
          code: row['employee_code']?.toString(),
          payloadJson: jsonEncode(row),
          updatedAt: now,
        ),
      );
    }
  }

  Future<List<Map<String, dynamic>>> loadCachedWorkers() async {
    final records = await localDatabase.localMasterData(entityType: 'employee');
    final attendanceRows = await localDatabase.localAttendance();
    final localByEmployee = <int, LocalAttendanceDraft>{};
    for (final row in attendanceRows) {
      if (row.attendanceDate == selectedDateIso) {
        localByEmployee[row.employeeId] = row;
      }
    }
    return records.map((record) {
      final payload = jsonDecode(record.payloadJson);
      final row = payload is Map
          ? Map<String, dynamic>.from(payload)
          : <String, dynamic>{};
      row['employee_id'] = record.serverId;
      row['employee_name'] = row['employee_name'] ?? record.name;
      final localAttendance = localByEmployee[record.serverId];
      if (localAttendance != null) {
        row['status'] = localAttendance.status;
        row['notes'] = localAttendance.notes;
      } else {
        row['status'] = 'not_set';
      }
      return row;
    }).toList();
  }

  Future<void> pickDate() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: selectedDate,
      firstDate: DateTime(2020),
      lastDate: DateTime(2035),
    );
    if (picked == null) return;
    setState(() => selectedDate = picked);
    await loadDailyAttendance();
  }

  void setAll(String status) {
    setState(() {
      for (final worker in workers) {
        final id = worker['employee_id'] as int?;
        if (id != null) selectedStatuses[id] = status;
      }
    });
  }

  void clearSelection() {
    setState(() {
      for (final worker in workers) {
        final id = worker['employee_id'] as int?;
        if (id != null) selectedStatuses[id] = 'present';
      }
    });
  }

  Future<void> saveAttendance() async {
    if (workers.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لا يوجد عمال نشطون لتسجيل الحضور')),
      );
      return;
    }

    final project = int.tryParse(projectId.text.trim());
    final costCenter = int.tryParse(costCenterId.text.trim());
    if (project != null && costCenter == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('عند ربط الحضور بمشروع يجب تحديد مركز التكلفة'),
        ),
      );
      return;
    }

    final records = buildAttendanceRecords();
    final payload = buildAttendancePayload(
      project: project,
      costCenter: costCenter,
      records: records,
    );

    setState(() => saving = true);
    try {
      final connection = await connectivityService.status();
      if (!connection.canUseServer) {
        final temporaryNo = await saveOfflineAttendance(payload);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'تم حفظ حضور العمال محليًا برقم $temporaryNo بانتظار المزامنة.',
            ),
          ),
        );
        return;
      }

      final dio = await payrollDio();
      final response = await dio.post('/api/v1/attendance/bulk', data: payload);
      await cacheSyncedAttendance(payload, response.data);
      if (!mounted) return;
      final data = response.data is Map
          ? Map<String, dynamic>.from(response.data as Map)
          : <String, dynamic>{};
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '${data['message'] ?? 'تم حفظ حضور العمال بنجاح'}'
            ' - إنشاء: ${data['created_count'] ?? 0}'
            ' - تحديث: ${data['updated_count'] ?? 0}',
          ),
        ),
      );
      await loadDailyAttendance();
    } catch (e) {
      if (!mounted) return;
      if (isConnectionFailure(e)) {
        final temporaryNo = await saveOfflineAttendance(payload);
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'تعذر الاتصال بالخادم. تم حفظ حضور العمال محليًا برقم $temporaryNo بانتظار المزامنة.',
            ),
          ),
        );
        return;
      }
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(errorMessage(e))),
      );
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  List<Map<String, dynamic>> buildAttendanceRecords() {
    return workers.map((worker) {
      final id = worker['employee_id'] as int;
      final note = notesControllers[id]?.text.trim();
      return {
        'employee_id': id,
        'status': selectedStatuses[id] ?? 'present',
        'notes': note == null || note.isEmpty ? null : note,
      };
    }).toList();
  }

  Map<String, dynamic> buildAttendancePayload({
    required int? project,
    required int? costCenter,
    required List<Map<String, dynamic>> records,
  }) {
    return {
      'date': selectedDateIso,
      'project_id': project,
      'cost_center_id': costCenter,
      'records': records,
    };
  }

  Future<String> saveOfflineAttendance(Map<String, dynamic> payload) async {
    final result = await offlineQueue.enqueueCreate(
      entityType: 'attendance_bulk',
      documentType: 'attendance_bulk',
      temporaryPrefix: 'LOCAL-ATT',
      payload: payload,
    );
    return result.temporaryNo;
  }

  Future<void> cacheSyncedAttendance(
    Map<String, dynamic> payload,
    dynamic responseData,
  ) async {
    final response = responseData is Map
        ? Map<String, dynamic>.from(responseData)
        : <String, dynamic>{};
    await offlineQueue.cacheSyncedCreate(
      entityType: 'attendance_bulk',
      documentType: 'attendance_bulk',
      temporaryPrefix: 'LOCAL-ATT',
      payload: payload,
      serverResponse: response,
    );
  }

  bool isConnectionFailure(Object error) {
    if (error is! DioException) return false;
    return error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout;
  }

  Widget _statusButton(int employeeId, String status) {
    final selected = selectedStatuses[employeeId] == status;
    final color = statusColors[status] ?? AlshaariColors.copper;
    return ChoiceChip(
      selected: selected,
      avatar: Icon(
        statusIcons[status] ?? Icons.circle_outlined,
        size: 16,
        color: selected ? Colors.white : color,
      ),
      label: Text(statusLabels[status] ?? status),
      selectedColor: color,
      labelStyle: TextStyle(
        color: selected ? Colors.white : AlshaariColors.ink,
        fontWeight: FontWeight.w800,
      ),
      onSelected: (_) => setState(() => selectedStatuses[employeeId] = status),
    );
  }

  Widget _workerCard(Map<String, dynamic> worker) {
    final employeeId = worker['employee_id'] as int;
    final name = '${worker['employee_name'] ?? 'عامل'}';
    final jobTitle = '${worker['job_title'] ?? 'عامل'}';
    final wage = formatMoney(worker['daily_wage']);
    final fridayIncluded = worker['friday_included'] == true;
    final controller = notesControllers.putIfAbsent(
      employeeId,
      () => TextEditingController(text: '${worker['notes'] ?? ''}'),
    );

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                CircleAvatar(
                  backgroundColor: AlshaariColors.copper.withValues(alpha: .12),
                  foregroundColor: AlshaariColors.copper,
                  child: const Icon(Icons.person_outline),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        name,
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          fontSize: 16,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text('$jobTitle | الأجر اليومي: $wage'),
                    ],
                  ),
                ),
                AlshaariStatusBadge(
                  label: fridayIncluded ? 'الجمعة مشمولة' : 'الجمعة عند الحضور',
                  color: fridayIncluded
                      ? AlshaariColors.deepGreen
                      : AlshaariColors.slate,
                  icon: Icons.calendar_month_outlined,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: statusLabels.keys
                  .map((status) => _statusButton(employeeId, status))
                  .toList(),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: controller,
              decoration: const InputDecoration(
                labelText: 'ملاحظة اختيارية',
                prefixIcon: Icon(Icons.notes_outlined),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _filtersSection() {
    return AlshaariSectionCard(
      title: 'بيانات اليوم',
      subtitle: 'اختر التاريخ واربط الحضور بمشروع أو مركز تكلفة عند الحاجة.',
      icon: Icons.today_outlined,
      child: Column(
        children: [
          OutlinedButton.icon(
            onPressed: pickDate,
            icon: const Icon(Icons.date_range),
            label: Text(selectedDateIso),
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: projectId,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'رقم المشروع اختياري',
                    prefixIcon: Icon(Icons.work_outline),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextField(
                  controller: costCenterId,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'مركز التكلفة اختياري',
                    prefixIcon: Icon(Icons.account_tree_outlined),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _quickSelection() {
    return AlshaariSectionCard(
      title: 'تحديد سريع',
      subtitle: 'استخدمها لتسجيل حضور جميع العمال خلال أقل من دقيقة.',
      icon: Icons.bolt_outlined,
      child: Column(
        children: [
          FilledButton.icon(
            onPressed: () => setAll('present'),
            icon: const Icon(Icons.check_circle_outline),
            label: const Text('تحديد الكل حاضر'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: () => setAll('absent'),
            icon: const Icon(Icons.cancel_outlined),
            label: const Text('تحديد الكل غائب'),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            onPressed: clearSelection,
            icon: const Icon(Icons.restart_alt_outlined),
            label: const Text('مسح التحديد'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('تسجيل حضور العمال'),
          actions: [
            IconButton(
              tooltip: 'تحديث',
              onPressed: loadDailyAttendance,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل العمال...')
            : RefreshIndicator(
                onRefresh: loadDailyAttendance,
                child: ListView(
                  padding: const EdgeInsets.fromLTRB(16, 16, 16, 96),
                  children: [
                    const AlshaariPageHeader(
                      title: 'تسجيل حضور العمال',
                      subtitle:
                          'سجل حضور جميع العمال من شاشة واحدة. الحضور يؤثر لاحقًا على الرواتب وتكلفة العمالة حسب المشروع.',
                      icon: Icons.event_available_outlined,
                    ),
                    const SizedBox(height: 12),
                    _filtersSection(),
                    const SizedBox(height: 12),
                    _quickSelection(),
                    const SizedBox(height: 12),
                    AlshaariSectionCard(
                      title: 'قائمة العمال',
                      subtitle: workers.isEmpty
                          ? 'لا يوجد عمال نشطون لتسجيل الحضور'
                          : 'عدد العمال النشطين: ${workers.length}',
                      icon: Icons.groups_2_outlined,
                      child: workers.isEmpty
                          ? const AlshaariEmptyState(
                              title: 'لا يوجد عمال نشطون',
                              subtitle:
                                  'أضف العمال من شاشة العمال ثم ارجع لتسجيل الحضور.',
                              icon: Icons.person_off_outlined,
                            )
                          : Column(
                              children: workers.map(_workerCard).toList(),
                            ),
                    ),
                  ],
                ),
              ),
        bottomNavigationBar: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: FilledButton.icon(
              onPressed: saving ? null : saveAttendance,
              icon: saving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: Text(saving ? 'جاري حفظ الحضور...' : 'حفظ الحضور'),
            ),
          ),
        ),
      ),
    );
  }
}
