from datetime import date

from sqlalchemy import func

from app.db.database import SessionLocal
from app.models.models import (
    Account,
    AuditLog,
    Customer,
    JournalEntry,
    JournalEntryLine,
    Project,
    ProjectCost,
    StockMovement,
    Transaction,
)
from app.schemas.schemas import TransactionCreate
from app.services.transaction_service import (
    approve_transaction,
    create_transaction,
    reverse_transaction,
)


def main():
    db = SessionLocal()
    try:
        customer = Customer(name="عميل تحقق محاسبي مؤقت", phone="700000000")
        db.add(customer)
        db.flush()

        project = Project(
            project_code="TMP-REVERSAL-CHECK",
            name="مشروع تحقق محاسبي مؤقت",
            customer_id=customer.id,
            contract_value=100000,
            status="active",
        )
        db.add(project)
        db.flush()

        tx = create_transaction(
            db,
            TransactionCreate(
                date=date.today(),
                type="receipt_from_customer",
                amount=10000,
                currency="YER",
                payment_method="cash",
                related_account_type="customer",
                related_id=customer.id,
                project_id=project.id,
                description="اختبار اعتماد وعكس حركة",
            ),
            1,
        )
        approved = approve_transaction(db, tx.id, 1)
        reversal = reverse_transaction(db, tx.id, 1, "اختبار القيد العكسي قبل التشغيل")

        debit = db.query(func.coalesce(func.sum(JournalEntryLine.debit), 0)).scalar()
        credit = db.query(func.coalesce(func.sum(JournalEntryLine.credit), 0)).scalar()
        cash = db.query(Account).filter(Account.code == "10101").first()

        print(
            {
                "approved_status": approved.status,
                "reversal_status": reversal.status,
                "document_no": tx.document_no,
                "balanced": str(debit) == str(credit),
                "cash_balance": str(cash.balance if cash else 0),
            }
        )

        tx_ids = [tx.id, reversal.id]
        entry_ids = [
            row[0]
            for row in db.query(JournalEntry.id)
            .filter(
                JournalEntry.source_type.in_(["transaction", "transaction_reversal"]),
                JournalEntry.source_id == tx.id,
            )
            .all()
        ]

        if entry_ids:
            db.query(JournalEntryLine).filter(JournalEntryLine.journal_entry_id.in_(entry_ids)).delete(synchronize_session=False)
            db.query(JournalEntry).filter(JournalEntry.id.in_(entry_ids)).delete(synchronize_session=False)

        db.query(ProjectCost).filter(ProjectCost.source_id == tx.id).delete()
        db.query(StockMovement).filter(StockMovement.transaction_id == tx.id).delete()
        db.query(AuditLog).filter(AuditLog.entity == "transaction", AuditLog.entity_id.in_(tx_ids)).delete(synchronize_session=False)
        db.query(Transaction).filter(Transaction.id.in_(tx_ids)).delete(synchronize_session=False)
        db.query(Project).filter(Project.id == project.id).delete()
        db.query(Customer).filter(Customer.id == customer.id).delete()
        if cash:
            cash.balance = 0
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    main()
