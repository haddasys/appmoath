from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.db.database import engine
from app.models.models import (
    DocumentSequence,
    GoodsReceipt,
    GoodsReceiptLine,
    PurchaseOrder,
    PurchaseOrderLine,
    PurchaseRequest,
    PurchaseRequestLine,
    SupplierInvoice,
    SupplierInvoiceLine,
    SupplierPayment,
)


PURCHASE_SEQUENCES = [
    ("purchase_request", "ASH-PR", 4),
    ("purchase_order", "ASH-PO", 4),
    ("goods_receipt", "ASH-GRN", 4),
    ("supplier_invoice", "ASH-SINV", 4),
    ("supplier_payment", "ASH-SPV", 4),
]

PURCHASE_ACCOUNTS = [
    ("10401", "مخزون المواد", "asset", "YER", None),
    ("20101", "الموردون", "liability", "YER", None),
    ("20102", "مواد مستلمة غير مفوترة GRNI", "liability", "YER", None),
    ("10601", "دفعات مقدمة للموردين", "asset", "YER", None),
    ("50303", "تكاليف مشاريع أخرى", "cost", "YER", None),
    ("60301", "مصروفات إدارية وعمومية", "expense", "YER", None),
]


def _table_has_column(table_name: str, column_name: str) -> bool:
    inspector = inspect(engine)
    if not inspector.has_table(table_name):
        return True
    return column_name in {column["name"] for column in inspector.get_columns(table_name)}


def _add_column_if_missing(db: Session, table_name: str, column_name: str, definition: str) -> None:
    if not _table_has_column(table_name, column_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def _insert_account(db: Session, code: str, name: str, account_type: str, currency: str, parent_code: str | None) -> None:
    db.execute(
        text(
            """
            INSERT INTO accounts (code, name, type, currency, balance, parent_code, is_active)
            VALUES (:code, :name, :type, :currency, 0, :parent_code, TRUE)
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                type = EXCLUDED.type,
                currency = EXCLUDED.currency,
                parent_code = EXCLUDED.parent_code,
                is_active = TRUE
            """
        ),
        {
            "code": code,
            "name": name,
            "type": account_type,
            "currency": currency,
            "parent_code": parent_code,
        },
    )


def ensure_purchase_schema(db: Session) -> None:
    for model in [
        PurchaseRequest,
        PurchaseRequestLine,
        PurchaseOrder,
        PurchaseOrderLine,
        GoodsReceipt,
        GoodsReceiptLine,
        SupplierInvoice,
        SupplierInvoiceLine,
        SupplierPayment,
    ]:
        model.__table__.create(bind=engine, checkfirst=True)

    _add_column_if_missing(db, "supplier_invoices", "paid_amount", "NUMERIC(14, 2) DEFAULT 0")

    for code, name, account_type, currency, parent_code in PURCHASE_ACCOUNTS:
        _insert_account(db, code, name, account_type, currency, parent_code)

    for document_type, prefix, padding in PURCHASE_SEQUENCES:
        if not db.query(DocumentSequence).filter(DocumentSequence.document_type == document_type).first():
            db.add(
                DocumentSequence(
                    document_type=document_type,
                    prefix=prefix,
                    next_number=1,
                    padding=padding,
                    is_active=True,
                )
            )

    db.commit()
