import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/theme.dart';
import '../../../core/config.dart';
import '../../../core/permissions.dart';
import '../../../core/printing/official_print.dart';
import '../../../core/printing/print_document.dart';
import '../../../core/widgets/alshaari_settlement_button.dart';
import '../../../core/widgets/alshaari_ui.dart';

class TransactionsReviewScreen extends StatefulWidget {
  const TransactionsReviewScreen({super.key});

  @override
  State<TransactionsReviewScreen> createState() =>
      _TransactionsReviewScreenState();
}

class _TransactionsReviewScreenState extends State<TransactionsReviewScreen> {
  bool loading = true;
  bool actionLoading = false;
  String selectedStatus = 'all';
  String selectedType = 'all';
  final searchController = TextEditingController();

  List<dynamic> documents = [];
  List<dynamic> adjustmentVouchers = [];
  List<dynamic> costCenters = [];
  List<dynamic> cashAccounts = [];
  List<dynamic> accountingPeriods = [];
  Set<String> permissions = {};

  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ),
  );

  final statuses = const [
    {'value': 'all', 'label': 'الكل'},
    {'value': 'draft', 'label': 'مسودة'},
    {'value': 'approved', 'label': 'معتمدة'},
    {'value': 'rejected', 'label': 'مرفوضة'},
  ];

  final typeFilters = const [
    {'value': 'all', 'label': 'كل الأنواع'},
    {'value': 'receipt_from_customer', 'label': 'سند قبض'},
    {'value': 'general_payment', 'label': 'سند صرف'},
    {'value': 'advance_payment', 'label': 'صرف سلفة'},
    {'value': 'advance_settlement', 'label': 'تسوية سلفة'},
    {'value': 'worker_wage', 'label': 'أجر عامل'},
    {'value': 'material_issue_to_project', 'label': 'صرف مواد'},
    {'value': 'project_expense', 'label': 'مصروف مشروع'},
    {'value': 'cash_transfer', 'label': 'تحويل صندوق'},
    {'value': 'adjustment_journal', 'label': 'قيد تسوية'},
  ];

  @override
  void initState() {
    super.initState();
    configureAndLoad();
  }

  @override
  void dispose() {
    searchController.dispose();
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ??
        prefs.getString('access_token') ??
        prefs.getString('auth_token');

    if (token != null && token.isNotEmpty) {
      dio.options.headers['Authorization'] = 'Bearer $token';
    }

    permissions = await AlshaariPermissions.currentPermissions();
    await loadReviewData();
  }

  bool can(String permission) {
    return AlshaariPermissions.hasPermission(permissions, permission);
  }

  Future<void> loadReviewData() async {
    setState(() => loading = true);
    await Future.wait([
      loadTransactions(),
      loadAdjustmentVouchers(),
      loadCostCenters(),
      loadCashAccounts(),
      loadAccountingPeriods(),
    ]);
    if (mounted) setState(() => loading = false);
  }

  Future<Response?> tryGet(List<String> endpoints) async {
    for (final endpoint in endpoints) {
      try {
        return await dio.get(endpoint);
      } catch (_) {
        continue;
      }
    }
    return null;
  }

  String errorMessage(Object error, String fallback) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (data is String && data.trim().isNotEmpty) return data;
      if (error.message != null && error.message!.trim().isNotEmpty) {
        return error.message!;
      }
    }
    return fallback;
  }

  Future<String?> tryPatch(List<String> endpoints) async {
    String? lastError;
    for (final endpoint in endpoints) {
      try {
        await dio.patch(endpoint);
        return null;
      } catch (e) {
        lastError = errorMessage(e, 'تعذر تنفيذ العملية');
      }
    }
    return lastError ?? 'تعذر تنفيذ العملية';
  }

  Future<void> loadTransactions() async {
    try {
      final res = await tryGet([
        '/api/v1/documents',
        '/api/v1/transactions',
        '/transactions',
      ]);
      if (!mounted) return;
      if (res == null) {
        documents = [];
        showMsg('لم يتم العثور على مسار المستندات المالية في واجهة الربط');
        return;
      }
      if (res.data is List) {
        documents = res.data as List<dynamic>;
      } else if (res.data is Map && res.data['items'] is List) {
        documents = res.data['items'] as List<dynamic>;
      } else if (res.data is Map && res.data['data'] is List) {
        documents = res.data['data'] as List<dynamic>;
      } else {
        documents = [];
      }
    } catch (e) {
      if (!mounted) return;
      showMsg('فشل تحميل المستندات: ${errorMessage(e, 'تعذر التحميل')}');
    }
  }

  Future<void> loadAdjustmentVouchers() async {
    try {
      Response<dynamic> res;
      try {
        res = await dio.get('/api/v1/settlement-vouchers');
      } catch (_) {
        res = await dio.get('/api/v1/adjustment-vouchers');
      }
      if (!mounted) return;
      adjustmentVouchers = res.data is List ? res.data as List<dynamic> : [];
    } catch (_) {
      adjustmentVouchers = [];
    }
  }

  Future<void> loadCostCenters() async {
    try {
      final res = await dio.get('/api/v1/cost-centers');
      if (!mounted) return;
      costCenters = res.data is List ? res.data as List<dynamic> : [];
    } catch (_) {
      costCenters = [];
    }
  }

  Future<void> loadCashAccounts() async {
    try {
      final res = await dio.get('/api/v1/cash-accounts');
      if (!mounted) return;
      cashAccounts = res.data is List ? res.data as List<dynamic> : [];
    } catch (_) {
      cashAccounts = [];
    }
  }

  Future<void> loadAccountingPeriods() async {
    try {
      final res = await dio.get('/api/v1/accounting-periods');
      if (!mounted) return;
      accountingPeriods = res.data is List ? res.data as List<dynamic> : [];
    } catch (_) {
      accountingPeriods = [];
    }
  }

  void showMsg(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  String typeLabel(String? type) {
    switch (type) {
      case 'receipt_from_customer':
        return 'سند قبض من عميل';
      case 'customer_advance':
        return 'دفعة مقدمة من عميل';
      case 'general_payment':
        return 'سند صرف عام';
      case 'project_expense':
        return 'مصروف مشروع';
      case 'material_purchase':
        return 'شراء مواد';
      case 'material_issue_to_project':
        return 'صرف مواد لمشروع';
      case 'customer_invoice':
        return 'فاتورة عميل';
      case 'supplier_invoice':
        return 'فاتورة مورد';
      case 'supplier_payment':
        return 'سند صرف لمورد';
      case 'supplier_advance':
        return 'دفعة مقدمة لمورد';
      case 'worker_wage':
        return 'أجر عامل';
      case 'advance_payment':
        return 'صرف سلفة / عهدة عامل';
      case 'advance_settlement':
        return 'تسوية عهدة';
      case 'cash_transfer':
        return 'تحويل بين صناديق';
      default:
        return type ?? 'مستند مالي';
    }
  }

  String settlementTypeLabel(dynamic value) {
    switch ('$value') {
      case 'wage_project':
        return 'تسوية كأجر مشروع';
      case 'wage_general':
        return 'تسوية كأجر عام';
      case 'expense_project':
        return 'تسوية كمصروف مشروع';
      case 'cash_return':
        return 'إرجاع نقدي';
      case 'salary_deduction':
        return 'خصم من الراتب';
      default:
        return '$value';
    }
  }

  String statusLabel(String? status) {
    switch (status) {
      case 'approved':
        return 'معتمدة';
      case 'rejected':
        return 'مرفوضة';
      case 'reversed':
        return 'معكوسة';
      default:
        return 'مسودة';
    }
  }

  String partyLabel(Map<String, dynamic> tx) {
    final type = tx['related_account_type'];
    final id = tx['related_id'];
    if (type == null && id == null) return '-';
    switch (type?.toString()) {
      case 'customer':
        return 'عميل #$id';
      case 'supplier':
        return 'مورد #$id';
      case 'worker':
        return 'عامل #$id';
      default:
        return '${type ?? '-'} / ${id ?? '-'}';
    }
  }

  String money(dynamic amount, dynamic currency) {
    return '${amount ?? 0} ${currency ?? 'YER'}';
  }

  String voucherNumber(Map<String, dynamic> tx) {
    return '${tx['voucher_no'] ?? tx['document_no'] ?? '#${tx['id'] ?? ''}'}';
  }

  String voucherPrintTitle(Map<String, dynamic> tx) {
    final type = '${tx['type'] ?? ''}';
    if (type == 'receipt_from_customer' || type == 'customer_advance') {
      return 'سند قبض';
    }
    if (type == 'cash_transfer') return 'سند تحويل داخلي';
    return 'سند صرف';
  }

  String debitPrintSide(Map<String, dynamic> tx) {
    final type = '${tx['type'] ?? ''}';
    switch (type) {
      case 'receipt_from_customer':
      case 'customer_advance':
        return cashAccountLabel(tx['cash_account_id']);
      case 'supplier_payment':
        return partyLabel(tx);
      case 'supplier_advance':
        return 'دفعات مقدمة للموردين';
      case 'advance_payment':
        return 'عهد وسلف العمال';
      case 'worker_wage':
        return tx['project_id'] == null
            ? 'مصروف أجور عام'
            : 'أجور مباشرة للمشاريع';
      case 'project_expense':
        return 'تكلفة مشروع / ${costCenterLabel(tx['cost_center_id'])}';
      case 'cash_transfer':
        return cashAccountLabel(tx['to_cash_account_id']);
      default:
        return tx['cost_category'] == null
            ? 'مصروفات عامة'
            : 'بند تكلفة: ${tx['cost_category']}';
    }
  }

  String creditPrintSide(Map<String, dynamic> tx) {
    final type = '${tx['type'] ?? ''}';
    switch (type) {
      case 'receipt_from_customer':
        return partyLabel(tx);
      case 'customer_advance':
        return 'دفعات مقدمة من العملاء';
      case 'cash_transfer':
        return cashAccountLabel(tx['from_cash_account_id']);
      default:
        return cashAccountLabel(tx['cash_account_id']);
    }
  }

  String printableVoucherHtml(
    CompanyPrintProfile profile,
    Map<String, dynamic> tx,
  ) {
    final title = voucherPrintTitle(tx);
    final number = voucherNumber(tx);
    final amount = money(tx['amount'], tx['currency']);
    final description = '${tx['description'] ?? ''}'.trim();
    final html = StringBuffer(
      officialPrintHeader(
        profile,
        title,
        subtitle: 'رقم السند: $number',
      ),
    );
    html.write('''
    <div class="grid">
      <div class="box"><b>رقم السند</b><span>${printHtmlEscape(number)}</span></div>
      <div class="box"><b>تاريخ السند</b><span>${printHtmlEscape(tx['date'] ?? '-')}</span></div>
      <div class="box"><b>الحالة</b><span class="ok">${printHtmlEscape(statusLabel('${tx['status'] ?? ''}'))}</span></div>
      <div class="box"><b>نوع المستند</b><span>${printHtmlEscape(typeLabel('${tx['type'] ?? ''}'))}</span></div>
      <div class="box"><b>المبلغ</b><span>${printHtmlEscape(amount)}</span></div>
      <div class="box"><b>طريقة الدفع</b><span>${printHtmlEscape(tx['payment_method'] ?? '-')}</span></div>
    </div>
    <table>
      <thead>
        <tr>
          <th>الطرف</th>
          <th>الحساب النقدي / المرجع</th>
          <th>مركز التكلفة</th>
          <th>المشروع</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${printHtmlEscape(partyLabel(tx))}</td>
          <td>${printHtmlEscape(cashAccountLabel(tx['cash_account_id']))}</td>
          <td>${printHtmlEscape(costCenterLabel(tx['cost_center_id']))}</td>
          <td>${printHtmlEscape(tx['project_id'] ?? '-')}</td>
        </tr>
      </tbody>
    </table>
    <h3 style="margin-top:18px">الأثر المحاسبي</h3>
    <table>
      <thead>
        <tr>
          <th>مدين</th>
          <th>دائن</th>
          <th class="amount">المبلغ</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${printHtmlEscape(debitPrintSide(tx))}</td>
          <td>${printHtmlEscape(creditPrintSide(tx))}</td>
          <td class="amount">${printHtmlEscape(amount)}</td>
        </tr>
      </tbody>
    </table>
    <div class="notes"><b>البيان:</b><br>${printHtmlEscape(description.isEmpty ? '-' : description)}</div>
    <div class="footer">
      <div class="sign">توقيع المستلم / المستفيد</div>
      <div class="sign">توقيع المحاسب / المدير</div>
    </div>
  </div>
</body>
</html>
''');
    return html.toString();
  }

  Future<void> printVoucher(Map<String, dynamic> tx) async {
    if ('${tx['status']}' != 'approved') {
      showMsg('يمكن طباعة السند بعد الاعتماد والترحيل فقط');
      return;
    }
    final profile = await loadCompanyPrintProfile();
    await openPrintDocument(
      title: voucherPrintTitle(tx),
      content: standardVoucherPrintHtml(profile, tx),
    );
  }

  String standardVoucherPrintHtml(
    CompanyPrintProfile profile,
    Map<String, dynamic> tx,
  ) {
    final title = voucherPrintTitle(tx);
    final number = voucherNumber(tx);
    final amount = money(tx['amount'], tx['currency']);
    final description = '${tx['description'] ?? ''}'.trim();
    final type = '${tx['type'] ?? ''}';
    final cashReference = type == 'cash_transfer'
        ? 'من ${cashAccountLabel(tx['from_cash_account_id'])} إلى ${cashAccountLabel(tx['to_cash_account_id'])}'
        : cashAccountLabel(tx['cash_account_id']);

    return '''
${officialPrintHeader(profile, title, subtitle: 'رقم السند: $number')}
    <div class="grid">
      <div class="box"><b>رقم السند</b><span>${printHtmlEscape(number)}</span></div>
      <div class="box"><b>تاريخ السند</b><span>${printHtmlEscape(tx['date'] ?? '-')}</span></div>
      <div class="box"><b>الحالة</b><span class="ok">${printHtmlEscape(statusLabel('${tx['status'] ?? ''}'))}</span><br><span class="stamp">مرحّل</span></div>
      <div class="box"><b>نوع المستند</b><span>${printHtmlEscape(typeLabel(type))}</span></div>
      <div class="box"><b>المبلغ</b><span>${printHtmlEscape(amount)}</span></div>
      <div class="box"><b>طريقة الدفع</b><span>${printHtmlEscape(tx['payment_method'] ?? '-')}</span></div>
    </div>

    <h3>بيانات المستند</h3>
    <table>
      <thead>
        <tr>
          <th>الطرف</th>
          <th>الحساب النقدي / المرجع</th>
          <th>مركز التكلفة</th>
          <th>المشروع</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${printHtmlEscape(partyLabel(tx))}</td>
          <td>${printHtmlEscape(cashReference)}</td>
          <td>${printHtmlEscape(costCenterLabel(tx['cost_center_id']))}</td>
          <td>${printHtmlEscape(tx['project_id'] ?? '-')}</td>
        </tr>
      </tbody>
    </table>

    <h3>الأثر المحاسبي</h3>
    <table>
      <thead>
        <tr>
          <th>مدين</th>
          <th>دائن</th>
          <th class="amount">المبلغ</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td>${printHtmlEscape(debitPrintSide(tx))}</td>
          <td>${printHtmlEscape(creditPrintSide(tx))}</td>
          <td class="amount">${printHtmlEscape(amount)}</td>
        </tr>
      </tbody>
    </table>

    <div class="total"><span>الإجمالي</span><span>${printHtmlEscape(amount)}</span></div>
    <div class="notes"><b>البيان:</b><br>${printHtmlEscape(description.isEmpty ? '-' : description)}</div>
    <div class="footer">
      <div class="sign">توقيع المستلم / المستفيد</div>
      <div class="sign">توقيع المحاسب</div>
      <div class="sign">توقيع المدير / الختم</div>
    </div>
  </div>
  <script>window.addEventListener('load', () => window.print());</script>
</body>
</html>
''';
  }

  Future<void> promptPrintAfterPosting(Map<String, dynamic> tx) async {
    if (!mounted) return;
    final shouldPrint = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تم ترحيل السند'),
        content: Text(
          'تم اعتماد ${voucherPrintTitle(tx)} رقم ${voucherNumber(tx)} وإنشاء القيد المحاسبي. هل تريد طباعة السند الآن؟',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('لاحقًا'),
          ),
          FilledButton.icon(
            onPressed: () => Navigator.pop(context, true),
            icon: const Icon(Icons.print_outlined),
            label: const Text('طباعة الآن'),
          ),
        ],
      ),
    );
    if (shouldPrint == true) {
      await printVoucher(tx);
    }
  }

  String costCenterLabel(dynamic id) {
    if (id == null) return '-';
    for (final raw in costCenters) {
      final item = Map<String, dynamic>.from(raw as Map);
      if ('${item['id']}' == '$id') {
        return '${item['code'] ?? ''} - ${item['name'] ?? ''}';
      }
    }
    return 'مركز #$id';
  }

  String cashAccountLabel(dynamic id) {
    if (id == null) return '-';
    for (final raw in cashAccounts) {
      final item = Map<String, dynamic>.from(raw as Map);
      if ('${item['id']}' == '$id') {
        final code = item['code'] ?? item['account_code'] ?? '';
        final name = item['name'] ?? '';
        final currency = item['currency'] ?? '';
        return '$code - $name | $currency';
      }
    }
    return 'حساب نقدية #$id';
  }

  Map<String, dynamic>? accountingPeriodFor(dynamic dateValue) {
    final rawDate = '${dateValue ?? ''}';
    if (rawDate.length < 10) return null;
    final documentDate = DateTime.tryParse(rawDate.substring(0, 10));
    if (documentDate == null) return null;
    for (final raw in accountingPeriods) {
      final row = Map<String, dynamic>.from(raw as Map);
      final start = DateTime.tryParse('${row['start_date'] ?? ''}');
      final end = DateTime.tryParse('${row['end_date'] ?? ''}');
      if (start == null || end == null) continue;
      if (!documentDate.isBefore(start) && !documentDate.isAfter(end)) {
        return row;
      }
    }
    return null;
  }

  String periodName(Map<String, dynamic> period) {
    return '${period['year'] ?? ''}-${period['month'] ?? ''}';
  }

  Widget periodWarning(dynamic dateValue) {
    final period = accountingPeriodFor(dateValue);
    if (period == null || period['status'] != 'closed') {
      return const SizedBox.shrink();
    }
    return Padding(
      padding: const EdgeInsets.only(top: 8),
      child: Text(
        'تنبيه: تاريخ هذا المستند يقع داخل الفترة المالية المغلقة ${periodName(period)}.',
        style: const TextStyle(
          color: Colors.red,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  String? closedPeriodMessage(dynamic dateValue) {
    final period = accountingPeriodFor(dateValue);
    if (period == null || period['status'] != 'closed') return null;
    return 'تاريخ هذا المستند يقع داخل الفترة المالية المغلقة ${periodName(period)}. قد يرفض النظام الاعتماد إلا بصلاحية خاصة.';
  }

  List<Map<String, dynamic>> filteredItems() {
    final query = searchController.text.trim();
    final normalItems = documents.where((raw) {
      final tx = Map<String, dynamic>.from(raw as Map);
      final statusMatches =
          selectedStatus == 'all' || '${tx['status']}' == selectedStatus;
      final typeMatches =
          selectedType == 'all' || '${tx['type']}' == selectedType;
      final searchMatches = query.isEmpty ||
          '${tx['document_no'] ?? ''}'.contains(query) ||
          '${tx['description'] ?? ''}'.contains(query) ||
          '${tx['id'] ?? ''}'.contains(query);
      return statusMatches && typeMatches && searchMatches;
    }).map((raw) => {'kind': 'transaction', 'data': raw});

    final adjustmentItems = adjustmentVouchers.where((raw) {
      final voucher = Map<String, dynamic>.from(raw as Map);
      final statusMatches =
          selectedStatus == 'all' || '${voucher['status']}' == selectedStatus;
      final typeMatches =
          selectedType == 'all' || selectedType == 'adjustment_journal';
      final searchMatches = query.isEmpty ||
          '${voucher['voucher_no'] ?? ''}'.contains(query) ||
          '${voucher['description'] ?? ''}'.contains(query) ||
          '${voucher['id'] ?? ''}'.contains(query);
      return statusMatches && typeMatches && searchMatches;
    }).map((raw) => {'kind': 'adjustment', 'data': raw});

    return [...normalItems, ...adjustmentItems].toList();
  }

  int countStatus(String status) {
    final documentCount =
        documents.where((tx) => (tx as Map)['status'] == status).length;
    final adjustmentCount = adjustmentVouchers
        .where((voucher) => (voucher as Map)['status'] == status)
        .length;
    return documentCount + adjustmentCount;
  }

  Future<void> changeStatus({
    required int id,
    required String action,
    Map<String, dynamic>? tx,
  }) async {
    setState(() => actionLoading = true);
    final error = await tryPatch([
      '/api/v1/documents/$id/$action',
      '/api/v1/transactions/$id/$action',
      '/transactions/$id/$action',
    ]);

    if (!mounted) return;
    setState(() => actionLoading = false);

    if (error == null) {
      showMsg(action == 'approve'
          ? 'تم اعتماد المستند وإنشاء القيد المحاسبي'
          : 'تم رفض المستند');
      if (action == 'approve' && tx != null) {
        final printable = Map<String, dynamic>.from(tx);
        printable['status'] = 'approved';
        await promptPrintAfterPosting(printable);
      }
      await loadReviewData();
    } else {
      showMsg(action == 'approve'
          ? 'فشل اعتماد المستند: $error'
          : 'فشل رفض المستند: $error');
    }
  }

  Future<void> confirmApprove(int id, Map<String, dynamic> tx) async {
    final periodMessage = closedPeriodMessage(tx['date']);
    final confirmed = await showAlshaariConfirmDialog(
      context: context,
      title: 'تأكيد الاعتماد',
      message: [
        if (periodMessage != null) periodMessage,
        'بعد الاعتماد سيتم إنشاء قيد محاسبي ولا يمكن تعديل المستند إلا بقيد عكسي. هل تريد اعتماد المستند رقم $id؟',
      ].join('\n\n'),
      confirmLabel: 'اعتماد',
    );
    if (confirmed) await changeStatus(id: id, action: 'approve', tx: tx);
  }

  Future<void> confirmReject(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد الرفض'),
        content: Text('هل تريد رفض المستند رقم $id؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          OutlinedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('رفض'),
          ),
        ],
      ),
    );
    if (confirmed == true) {
      await changeStatus(id: id, action: 'reject');
    }
  }

  Future<void> approveAdjustmentVoucher(
      int id, Map<String, dynamic> voucher) async {
    final periodMessage = closedPeriodMessage(voucher['date']);
    final confirmed = await showAlshaariConfirmDialog(
      context: context,
      title: 'تأكيد اعتماد سند التسوية',
      message: [
        if (periodMessage != null) periodMessage,
        'بعد اعتماد سند التسوية سيتم إنشاء قيد محاسبي ولا يمكن تعديله إلا بسند عكسي.',
      ].join('\n\n'),
      confirmLabel: 'اعتماد',
    );
    if (!confirmed) return;
    setState(() => actionLoading = true);
    try {
      try {
        await dio.post('/api/v1/settlement-vouchers/$id/approve');
      } catch (_) {
        await dio.post('/api/v1/adjustment-vouchers/$id/approve');
      }
      if (!mounted) return;
      showMsg('تم اعتماد سند التسوية وإنشاء القيد المحاسبي');
      await loadReviewData();
    } catch (e) {
      if (!mounted) return;
      showMsg('فشل اعتماد سند التسوية: ${errorMessage(e, 'تعذر الاعتماد')}');
    } finally {
      if (mounted) setState(() => actionLoading = false);
    }
  }

  Future<void> rejectAdjustmentVoucher(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('تأكيد الرفض'),
        content: Text('هل تريد رفض سند التسوية رقم $id؟'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء'),
          ),
          OutlinedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('رفض'),
          ),
        ],
      ),
    );
    if (confirmed != true) return;
    setState(() => actionLoading = true);
    try {
      try {
        await dio.post('/api/v1/settlement-vouchers/$id/reject', data: {});
      } catch (_) {
        await dio.post('/api/v1/adjustment-vouchers/$id/reject', data: {});
      }
      if (!mounted) return;
      showMsg('تم رفض سند التسوية');
      await loadReviewData();
    } catch (e) {
      if (!mounted) return;
      showMsg('فشل رفض سند التسوية: ${errorMessage(e, 'تعذر الرفض')}');
    } finally {
      if (mounted) setState(() => actionLoading = false);
    }
  }

  Widget summaryCards() {
    final cards = [
      AlshaariStatCard(
        title: 'مسودة',
        value: '${countStatus('draft')}',
        icon: Icons.edit_note,
        color: AlshaariColors.warning,
      ),
      AlshaariStatCard(
        title: 'معتمدة',
        value: '${countStatus('approved')}',
        icon: Icons.verified,
        color: AlshaariColors.success,
      ),
      AlshaariStatCard(
        title: 'مرفوضة',
        value: '${countStatus('rejected')}',
        icon: Icons.block,
        color: Colors.red,
      ),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 720) {
          return Column(
            children: cards
                .map((card) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: card,
                    ))
                .toList(),
          );
        }
        return GridView.count(
          crossAxisCount: 3,
          childAspectRatio: 2.8,
          crossAxisSpacing: 8,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: cards,
        );
      },
    );
  }

  Widget filters() {
    return AlshaariSectionCard(
      title: 'البحث والفلترة',
      icon: Icons.filter_alt_outlined,
      child: Column(
        children: [
          TextField(
            controller: searchController,
            decoration: const InputDecoration(
              labelText: 'بحث برقم المستند أو البيان',
              prefixIcon: Icon(Icons.search),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  initialValue: selectedStatus,
                  decoration: const InputDecoration(labelText: 'الحالة'),
                  items: statuses
                      .map((item) => DropdownMenuItem<String>(
                            value: item['value'],
                            child: Text(item['label']!),
                          ))
                      .toList(),
                  onChanged: (v) => setState(() => selectedStatus = v ?? 'all'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<String>(
                  initialValue: selectedType,
                  decoration: const InputDecoration(labelText: 'نوع المستند'),
                  items: typeFilters
                      .map((item) => DropdownMenuItem<String>(
                            value: item['value'],
                            child: Text(item['label']!),
                          ))
                      .toList(),
                  onChanged: (v) => setState(() => selectedType = v ?? 'all'),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget transactionCard(Map<String, dynamic> tx) {
    final id = int.tryParse('${tx['id'] ?? 0}') ?? 0;
    final type = '${tx['type'] ?? ''}';
    final status = '${tx['status'] ?? 'draft'}';
    final description = '${tx['description'] ?? ''}'.trim();

    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${tx['document_no'] ?? '#$id'} - ${typeLabel(type)}',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                AlshaariStatusBadge.byStatus(status),
              ],
            ),
            const SizedBox(height: 8),
            Text('المبلغ: ${money(tx['amount'], tx['currency'])}'),
            Text('التاريخ: ${tx['date'] ?? '-'}'),
            if (type == 'cash_transfer') ...[
              Text('من: ${cashAccountLabel(tx['from_cash_account_id'])}'),
              Text('إلى: ${cashAccountLabel(tx['to_cash_account_id'])}'),
            ],
            if (tx['payment_method'] != null &&
                type != 'material_issue_to_project' &&
                type != 'cash_transfer' &&
                (type != 'advance_settlement' ||
                    tx['settlement_type'] == 'cash_return'))
              Text('طريقة الدفع: ${tx['payment_method'] ?? '-'}'),
            if (tx['settlement_type'] != null)
              Text(
                  'نوع التسوية: ${settlementTypeLabel(tx['settlement_type'])}'),
            if (tx['cost_center_id'] != null && type != 'advance_payment')
              Text('مركز التكلفة: ${costCenterLabel(tx['cost_center_id'])}'),
            if (tx['related_id'] != null &&
                const {
                  'receipt_from_customer',
                  'customer_invoice',
                  'material_purchase',
                  'supplier_invoice',
                  'supplier_payment',
                  'worker_wage',
                  'advance_payment',
                  'advance_settlement',
                }.contains(type))
              Text('الطرف: ${partyLabel(tx)}'),
            if (tx['project_id'] != null &&
                const {
                  'receipt_from_customer',
                  'customer_invoice',
                  'project_expense',
                  'material_issue_to_project',
                  'worker_wage',
                  'advance_settlement',
                }.contains(type))
              Text('رقم المشروع: ${tx['project_id']}'),
            if (type == 'material_purchase' ||
                type == 'material_issue_to_project') ...[
              if (tx['item_id'] != null) Text('المادة: ${tx['item_id']}'),
              if (tx['qty'] != null &&
                  '${tx['qty']}' != '0' &&
                  '${tx['qty']}' != '0.0')
                Text('الكمية: ${tx['qty']}'),
              if (tx['unit_cost'] != null &&
                  '${tx['unit_cost']}' != '0' &&
                  '${tx['unit_cost']}' != '0.0')
                Text('تكلفة الوحدة: ${tx['unit_cost']}'),
            ],
            if (tx['cost_category'] != null && type != 'advance_payment')
              Text('بند التكلفة: ${tx['cost_category']}'),
            if (description.isNotEmpty) Text('البيان: $description'),
            periodWarning(tx['date']),
            const SizedBox(height: 12),
            if (status == 'draft' && can('transactions.approve'))
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: actionLoading || id == 0
                          ? null
                          : () => confirmApprove(id, tx),
                      icon: const Icon(Icons.check),
                      label: const Text('اعتماد'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: actionLoading || id == 0
                          ? null
                          : () => confirmReject(id),
                      icon: const Icon(Icons.close),
                      label: const Text('رفض'),
                    ),
                  ),
                ],
              ),
            if (status == 'approved') ...[
              const SizedBox(height: 8),
              OutlinedButton.icon(
                onPressed: () => printVoucher(tx),
                icon: const Icon(Icons.print_outlined),
                label: const Text('طباعة السند'),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget adjustmentCard(Map<String, dynamic> voucher) {
    final id = int.tryParse('${voucher['id'] ?? 0}') ?? 0;
    final status = '${voucher['status'] ?? 'draft'}';
    final lines =
        voucher['lines'] is List ? voucher['lines'] as List : const [];
    return Card(
      elevation: 1,
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${voucher['voucher_no'] ?? '#$id'} - سند تسوية حسابية',
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 16,
                    ),
                  ),
                ),
                AlshaariStatusBadge.byStatus(status),
              ],
            ),
            const SizedBox(height: 8),
            Text('السبب: ${voucher['reason'] ?? '-'}'),
            Text('التاريخ: ${voucher['date'] ?? '-'}'),
            Text('إجمالي المدين: ${money(voucher['total_debit'], 'YER')}'),
            Text('إجمالي الدائن: ${money(voucher['total_credit'], 'YER')}'),
            if ('${voucher['description'] ?? ''}'.trim().isNotEmpty)
              Text('البيان: ${voucher['description']}'),
            periodWarning(voucher['date']),
            const SizedBox(height: 8),
            if (lines.isEmpty)
              const Text('لا توجد سطور قيد')
            else
              ...lines.take(4).map((line) {
                final row = Map<String, dynamic>.from(line as Map);
                return Text(
                  '${row['account_code'] ?? '-'} - مدين ${row['debit'] ?? 0} / دائن ${row['credit'] ?? 0}',
                );
              }),
            if (lines.length > 4) Text('و ${lines.length - 4} سطور أخرى'),
            const SizedBox(height: 12),
            if (status == 'draft' && can('approve_adjustment_journal'))
              Row(
                children: [
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: actionLoading || id == 0
                          ? null
                          : () => approveAdjustmentVoucher(id, voucher),
                      icon: const Icon(Icons.check),
                      label: const Text('اعتماد'),
                    ),
                  ),
                  const SizedBox(width: 8),
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: actionLoading || id == 0
                          ? null
                          : () => rejectAdjustmentVoucher(id),
                      icon: const Icon(Icons.close),
                      label: const Text('رفض'),
                    ),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }

  Widget reviewList() {
    final items = filteredItems();
    if (items.isEmpty) {
      return const AlshaariEmptyState(
        title: 'لا توجد مستندات للمراجعة',
        subtitle: 'غيّر الفلتر أو أضف مستندًا جديدًا ليظهر هنا.',
        icon: Icons.fact_check_outlined,
      );
    }
    return Column(
      children: items.map((item) {
        final data = Map<String, dynamic>.from(item['data'] as Map);
        return item['kind'] == 'adjustment'
            ? adjustmentCard(data)
            : transactionCard(data);
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('مراجعة واعتماد المستندات'),
          actions: [
            const Padding(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: AlshaariSettlementButton(contextType: 'approvals'),
            ),
            IconButton(
              onPressed: loadReviewData,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل المستندات...')
            : RefreshIndicator(
                onRefresh: loadReviewData,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    const AlshaariPageHeader(
                      title: 'اعتماد المستندات المالية',
                      subtitle:
                          'راجع أثر كل مستند قبل الاعتماد. بعد الاعتماد يتم إنشاء القيد المحاسبي.',
                      icon: Icons.fact_check_outlined,
                    ),
                    const SizedBox(height: 12),
                    summaryCards(),
                    const SizedBox(height: 12),
                    filters(),
                    const SizedBox(height: 12),
                    reviewList(),
                  ],
                ),
              ),
      ),
    );
  }
}
