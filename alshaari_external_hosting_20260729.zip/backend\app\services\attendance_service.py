from calendar import monthrange
from datetime import date

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session


ATTENDANCE_STATUSES = {
    "present",
    "absent",
    "half_day",
    "friday_paid",
    "overtime",
    "leave",
    "unpaid_leave",
}

LOCKED_PAYROLL_STATUSES = {"approved", "paid", "closed"}
MANAGER_ROLES = {"manager", "admin", "accountant_admin"}


def _dict(row):
    return dict(row) if row else None


def _status_label(status: str) -> str:
    labels = {
        "present": "حاضر",
        "absent": "غائب",
        "half_day": "نصف يوم",
        "leave": "إجازة",
        "unpaid_leave": "إجازة بدون أجر",
        "friday_paid": "جمعة محسوبة",
        "overtime": "إضافي",
    }
    return labels.get(status, status)


def _validate_status(status: str) -> None:
    if status not in ATTENDANCE_STATUSES:
        raise HTTPException(status_code=400, detail="حالة الحضور غير معتمدة")


def _validate_project_rule(status: str, project_id, cost_center_id) -> None:
    if status in {"present", "half_day", "overtime", "friday_paid"}:
        if project_id and not cost_center_id:
            raise HTTPException(
                status_code=400,
                detail="عند ربط الحضور بمشروع يجب اختيار مركز تكلفة",
            )


def _user_role(db: Session, user_id: int | None) -> str:
    if not user_id:
        return ""
    row = db.execute(
        text("SELECT role FROM users WHERE id = :id"),
        {"id": user_id},
    ).mappings().first()
    return str(row["role"] if row else "").strip()


def check_payroll_period_not_approved(db: Session, attendance_date: date, user_id: int | None = None) -> None:
    period = db.execute(
        text(
            """
            SELECT id, status
            FROM payroll_periods
            WHERE year = :year AND month = :month
            LIMIT 1
            """
        ),
        {"year": attendance_date.year, "month": attendance_date.month},
    ).mappings().first()
    if not period or period["status"] not in LOCKED_PAYROLL_STATUSES:
        return

    if _user_role(db, user_id) in MANAGER_ROLES:
        return

    raise HTTPException(
        status_code=400,
        detail="لا يمكن تعديل حضور فترة تم اعتماد راتبها إلا بصلاحية المدير",
    )


def audit_attendance_change(
    db: Session,
    user_id: int,
    action: str,
    attendance_id: int | None,
    details: str,
) -> None:
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, :action, 'attendance', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {
            "user_id": user_id,
            "action": action,
            "entity_id": attendance_id,
            "details": details,
        },
    )


def _active_employee(db: Session, employee_id: int):
    row = db.execute(
        text(
            """
            SELECT *
            FROM employees
            WHERE id = :id AND COALESCE(is_active, TRUE) = TRUE
            """
        ),
        {"id": employee_id},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail=f"العامل غير موجود أو غير نشط: {employee_id}")
    return row


def _upsert_attendance(
    db: Session,
    *,
    employee_id: int,
    attendance_date: date,
    status: str,
    project_id,
    cost_center_id,
    notes,
    user_id: int,
) -> tuple[dict, bool]:
    _validate_status(status)
    _validate_project_rule(status, project_id, cost_center_id)
    _active_employee(db, employee_id)

    existing = db.execute(
        text(
            """
            SELECT id
            FROM attendance
            WHERE employee_id = :employee_id AND date = :date
            """
        ),
        {"employee_id": employee_id, "date": attendance_date},
    ).mappings().first()

    if existing:
        row = db.execute(
            text(
                """
                UPDATE attendance
                SET status = :status,
                    project_id = :project_id,
                    cost_center_id = :cost_center_id,
                    notes = :notes,
                    updated_at = CURRENT_TIMESTAMP
                WHERE id = :id
                RETURNING *
                """
            ),
            {
                "id": existing["id"],
                "status": status,
                "project_id": project_id if status != "absent" else None,
                "cost_center_id": cost_center_id if status != "absent" else None,
                "notes": notes,
            },
        ).mappings().first()
        audit_attendance_change(
            db,
            user_id,
            "update_attendance",
            row["id"],
            f"{attendance_date} - عامل {employee_id} - {_status_label(status)}",
        )
        return dict(row), False

    row = db.execute(
        text(
            """
            INSERT INTO attendance (
                employee_id, date, status, project_id, cost_center_id,
                notes, created_by, created_at
            )
            VALUES (
                :employee_id, :date, :status, :project_id, :cost_center_id,
                :notes, :created_by, CURRENT_TIMESTAMP
            )
            RETURNING *
            """
        ),
        {
            "employee_id": employee_id,
            "date": attendance_date,
            "status": status,
            "project_id": project_id if status != "absent" else None,
            "cost_center_id": cost_center_id if status != "absent" else None,
            "notes": notes,
            "created_by": user_id,
        },
    ).mappings().first()
    audit_attendance_change(
        db,
        user_id,
        "create_attendance",
        row["id"],
        f"{attendance_date} - عامل {employee_id} - {_status_label(status)}",
    )
    return dict(row), True


def get_daily_attendance(db: Session, attendance_date: date):
    rows = db.execute(
        text(
            """
            SELECT
                e.id AS employee_id,
                e.name AS employee_name,
                e.job_title,
                e.daily_wage,
                e.friday_included,
                e.is_active,
                a.id AS attendance_id,
                a.date,
                COALESCE(a.status, 'not_set') AS status,
                a.project_id,
                a.cost_center_id,
                a.notes,
                a.created_at,
                a.updated_at
            FROM employees e
            LEFT JOIN attendance a
              ON a.employee_id = e.id
             AND a.date = :date
            WHERE COALESCE(e.is_active, TRUE) = TRUE
            ORDER BY e.name
            """
        ),
        {"date": attendance_date},
    ).mappings().all()
    return [dict(row) for row in rows]


def bulk_save_attendance(
    db: Session,
    attendance_date: date,
    records,
    project_id,
    cost_center_id,
    user_id: int,
):
    check_payroll_period_not_approved(db, attendance_date, user_id)
    if not records:
        raise HTTPException(status_code=400, detail="لا توجد سجلات حضور للحفظ")

    created_count = 0
    updated_count = 0
    present_count = 0
    absent_count = 0
    half_day_count = 0
    saved = []

    for record in records:
        status = record.status
        record_project_id = record.project_id if record.project_id is not None else project_id
        record_cost_center_id = (
            record.cost_center_id if record.cost_center_id is not None else cost_center_id
        )
        row, created = _upsert_attendance(
            db,
            employee_id=record.employee_id,
            attendance_date=attendance_date,
            status=status,
            project_id=record_project_id,
            cost_center_id=record_cost_center_id,
            notes=record.notes,
            user_id=user_id,
        )
        saved.append(row)
        created_count += 1 if created else 0
        updated_count += 0 if created else 1
        present_count += 1 if status in {"present", "friday_paid", "overtime"} else 0
        absent_count += 1 if status in {"absent", "unpaid_leave"} else 0
        half_day_count += 1 if status == "half_day" else 0

    audit_attendance_change(
        db,
        user_id,
        "bulk_save_attendance",
        None,
        f"{attendance_date} - إجمالي {len(records)} - إنشاء {created_count} - تحديث {updated_count}",
    )
    db.commit()
    return {
        "message": "تم حفظ حضور العمال بنجاح",
        "total_records": len(records),
        "created_count": created_count,
        "updated_count": updated_count,
        "present_count": present_count,
        "absent_count": absent_count,
        "half_day_count": half_day_count,
        "records": saved,
    }


def create_attendance(db: Session, data, user_id: int):
    check_payroll_period_not_approved(db, data.date, user_id)
    row, _created = _upsert_attendance(
        db,
        employee_id=data.employee_id,
        attendance_date=data.date,
        status=data.status,
        project_id=data.project_id,
        cost_center_id=data.cost_center_id,
        notes=data.notes,
        user_id=user_id,
    )
    db.commit()
    return row


def update_attendance(db: Session, attendance_id: int, data, user_id: int):
    check_payroll_period_not_approved(db, data.date, user_id)
    _validate_status(data.status)
    _validate_project_rule(data.status, data.project_id, data.cost_center_id)
    _active_employee(db, data.employee_id)

    duplicate = db.execute(
        text(
            """
            SELECT id
            FROM attendance
            WHERE employee_id = :employee_id
              AND date = :date
              AND id <> :id
            """
        ),
        {"employee_id": data.employee_id, "date": data.date, "id": attendance_id},
    ).mappings().first()
    if duplicate:
        raise HTTPException(status_code=400, detail="يوجد سجل حضور آخر لنفس العامل والتاريخ")

    row = db.execute(
        text(
            """
            UPDATE attendance
            SET employee_id = :employee_id,
                date = :date,
                status = :status,
                project_id = :project_id,
                cost_center_id = :cost_center_id,
                notes = :notes,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
            RETURNING *
            """
        ),
        {
            "id": attendance_id,
            "employee_id": data.employee_id,
            "date": data.date,
            "status": data.status,
            "project_id": data.project_id if data.status != "absent" else None,
            "cost_center_id": data.cost_center_id if data.status != "absent" else None,
            "notes": data.notes,
        },
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="سجل الحضور غير موجود")
    audit_attendance_change(
        db,
        user_id,
        "update_attendance",
        attendance_id,
        f"{data.date} - عامل {data.employee_id} - {_status_label(data.status)}",
    )
    db.commit()
    return dict(row)


def get_monthly_attendance(
    db: Session, year: int, month: int, employee_id: int | None = None
):
    start_date = date(year, month, 1)
    end_date = date(year, month, monthrange(year, month)[1])
    params = {"employee_id": employee_id, "start_date": start_date, "end_date": end_date}
    employee_filter = "AND a.employee_id = :employee_id" if employee_id else ""
    rows = db.execute(
        text(
            f"""
            SELECT a.*, e.name AS employee_name, e.daily_wage, e.friday_included
            FROM attendance a
            JOIN employees e ON e.id = a.employee_id
            WHERE a.date >= :start_date
              AND a.date <= :end_date
              {employee_filter}
            ORDER BY a.date DESC, e.name
            """
        ),
        params,
    ).mappings().all()
    return [dict(row) for row in rows]
