from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.db.database import engine
from app.models.models import Attachment, Warehouse


INVENTORY_ACCOUNTS = [
    ("10401", "مخزون المواد", "asset", "YER", None),
    ("50101", "تكلفة مواد مباشرة للمشاريع", "cost", "YER", None),
    ("60301", "مصروفات إدارية وعمومية", "expense", "YER", None),
    ("49999", "فروقات تسوية مخزون دائنة", "revenue", "YER", None),
]


def _has_column(table_name: str, column_name: str) -> bool:
    inspector = inspect(engine)
    if not inspector.has_table(table_name):
        return True
    return column_name in {column["name"] for column in inspector.get_columns(table_name)}


def _add_column_if_missing(db: Session, table_name: str, column_name: str, definition: str) -> None:
    if not _has_column(table_name, column_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def _insert_account(db: Session, code: str, name: str, account_type: str, currency: str, parent_code: str | None) -> None:
    db.execute(
        text(
            """
            INSERT INTO accounts (code, name, type, currency, balance, parent_code, is_active)
            VALUES (:code, :name, :type, :currency, 0, :parent_code, TRUE)
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                type = EXCLUDED.type,
                currency = EXCLUDED.currency,
                parent_code = EXCLUDED.parent_code,
                is_active = TRUE
            """
        ),
        {"code": code, "name": name, "type": account_type, "currency": currency, "parent_code": parent_code},
    )


def ensure_inventory_schema(db: Session) -> None:
    Warehouse.__table__.create(bind=engine, checkfirst=True)
    Attachment.__table__.create(bind=engine, checkfirst=True)

    for table_name in ["inventory_movements", "stock_movements"]:
        _add_column_if_missing(db, table_name, "warehouse_id", "INTEGER")
        _add_column_if_missing(db, table_name, "cost_center_id", "INTEGER")
        _add_column_if_missing(db, table_name, "supplier_invoice_id", "INTEGER")
        _add_column_if_missing(db, table_name, "goods_receipt_id", "INTEGER")
        _add_column_if_missing(db, table_name, "attachment_id", "INTEGER")
        _add_column_if_missing(db, table_name, "movement_source", "VARCHAR(80)")
        _add_column_if_missing(db, table_name, "movement_reference", "VARCHAR(120)")

    _add_column_if_missing(db, "attachments", "file_path", "VARCHAR(500)")
    _add_column_if_missing(db, "attachments", "file_type", "VARCHAR(80)")
    _add_column_if_missing(db, "attachments", "entity_type", "VARCHAR(80)")

    db.execute(
        text(
            """
            INSERT INTO warehouses (code, name, type, project_id, is_active)
            VALUES ('WH-GEN-001', 'المخزن العام', 'general', NULL, TRUE)
            ON CONFLICT (code) DO UPDATE SET
                name = EXCLUDED.name,
                type = EXCLUDED.type,
                is_active = TRUE
            """
        )
    )
    for code, name, account_type, currency, parent_code in INVENTORY_ACCOUNTS:
        _insert_account(db, code, name, account_type, currency, parent_code)
    db.commit()
