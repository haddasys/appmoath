﻿from sqlalchemy import text
from app.db.database import engine

RULES = [
    ("receipt_from_customer", "10101", "10301", "قبض من عميل"),
    ("general_payment", "60301", "10101", "صرف عام"),
    ("project_expense", "50303", "10101", "مصروف مرتبط بمشروع"),
    ("material_purchase", "10401", "10101", "شراء مواد نقدًا"),
    ("supplier_invoice", "10401", "20101", "فاتورة مورد آجل"),
    ("supplier_payment", "20101", "10101", "دفعة مورد"),
    ("material_issue_to_project", "50101", "10401", "صرف مواد لمشروع"),
    ("worker_wage", "50201", "10101", "أجر عامل"),
    ("advance_payment", "20203", "10101", "سلفة / عهدة عامل"),
    ("advance_settlement", "60301", "20203", "تسوية عهدة"),
    ("customer_invoice", "10301", "40101", "فاتورة عميل"),
    ("cash_transfer", "10201", "10101", "تحويل بين صناديق"),
]

def main():
    with engine.begin() as conn:
        for operation_type, debit, credit, description in RULES:
            conn.execute(
                text("""
                    INSERT INTO posting_rules (
                        operation_type,
                        debit_account_code,
                        credit_account_code,
                        description,
                        is_active
                    )
                    VALUES (
                        :operation_type,
                        :debit,
                        :credit,
                        :description,
                        TRUE
                    )
                    ON CONFLICT (operation_type) DO UPDATE SET
                        debit_account_code = EXCLUDED.debit_account_code,
                        credit_account_code = EXCLUDED.credit_account_code,
                        description = EXCLUDED.description,
                        is_active = TRUE
                """),
                {
                    "operation_type": operation_type,
                    "debit": debit,
                    "credit": credit,
                    "description": description,
                },
            )

    print("Accounting posting rules updated successfully.")

if __name__ == "__main__":
    main()
