import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/permissions.dart';
import '../../../core/widgets/alshaari_ui.dart';

class AccountingPeriodsScreen extends StatefulWidget {
  const AccountingPeriodsScreen({super.key});

  @override
  State<AccountingPeriodsScreen> createState() =>
      _AccountingPeriodsScreenState();
}

class _AccountingPeriodsScreenState extends State<AccountingPeriodsScreen> {
  bool loading = true;
  String? error;
  String statusFilter = 'all';
  List<dynamic> periods = [];
  Set<String> permissions = {};

  @override
  void initState() {
    super.initState();
    loadPeriods();
  }

  Future<void> loadPeriods() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await apiClient.loadToken();
      final loadedPermissions = await AlshaariPermissions.currentPermissions();
      final res = await apiClient.dio.get('/accounting-periods');
      if (!mounted) return;
      setState(() {
        periods = (res.data as List?) ?? [];
        permissions = loadedPermissions;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = friendlyError(e);
        loading = false;
      });
    }
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.response?.statusCode == 403) {
        return 'لا تملك صلاحية إدارة الفترات المالية';
      }
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم. تأكد أن خدمة النظام تعمل.';
      }
    }
    return 'تعذر تحميل الفترات المالية';
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  bool can(String permission) {
    return AlshaariPermissions.hasPermission(permissions, permission);
  }

  List<dynamic> visiblePeriods() {
    if (statusFilter == 'all') return periods;
    return periods.where((raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return '${row['status'] ?? ''}' == statusFilter;
    }).toList();
  }

  int countByStatus(String status) {
    return periods.where((raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return '${row['status'] ?? ''}' == status;
    }).length;
  }

  String statusLabel(String? status) {
    switch (status) {
      case 'closed':
        return 'مغلقة';
      case 'open':
        return 'مفتوحة';
      default:
        return status ?? '-';
    }
  }

  Color statusColor(String? status) {
    return status == 'closed' ? AlshaariColors.danger : AlshaariColors.success;
  }

  String monthLabel(Object? month) {
    final value = int.tryParse('${month ?? ''}') ?? 0;
    const labels = [
      '',
      'يناير',
      'فبراير',
      'مارس',
      'أبريل',
      'مايو',
      'يونيو',
      'يوليو',
      'أغسطس',
      'سبتمبر',
      'أكتوبر',
      'نوفمبر',
      'ديسمبر',
    ];
    if (value < 1 || value > 12) return '${month ?? '-'}';
    return labels[value];
  }

  Future<void> changeStatus(Map<String, dynamic> row, String action) async {
    final periodId = row['id'];
    final isClose = action == 'close';
    final confirmed = await showAlshaariConfirmDialog(
      context: context,
      title: isClose ? 'إقفال الفترة المالية' : 'فتح الفترة المالية',
      message: isClose
          ? 'بعد إقفال الفترة لن يمكن ترحيل أو اعتماد مستندات داخلها إلا بصلاحية خاصة.'
          : 'فتح الفترة يسمح بترحيل واعتماد المستندات داخلها مرة أخرى.',
      confirmLabel: isClose ? 'إقفال' : 'فتح',
    );
    if (!confirmed) return;
    try {
      await apiClient.loadToken();
      await apiClient.dio.post('/accounting-periods/$periodId/$action');
      showMessage(
          isClose ? 'تم إقفال الفترة المالية' : 'تم فتح الفترة المالية');
      await loadPeriods();
    } catch (e) {
      showMessage(friendlyError(e));
    }
  }

  Future<void> createCurrentMonth() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, 1);
    final end = DateTime(now.year, now.month + 1, 0);
    try {
      await apiClient.loadToken();
      await apiClient.dio.post(
        '/accounting-periods',
        data: {
          'year': now.year,
          'month': now.month,
          'start_date': start.toIso8601String().substring(0, 10),
          'end_date': end.toIso8601String().substring(0, 10),
          'status': 'open',
        },
      );
      showMessage('تم إنشاء أو تحديث فترة الشهر الحالي');
      await loadPeriods();
    } catch (e) {
      showMessage(friendlyError(e));
    }
  }

  Widget summaryCards() {
    return LayoutBuilder(
      builder: (context, constraints) {
        final cards = [
          AlshaariStatCard(
            title: 'إجمالي الفترات',
            value: '${periods.length}',
            icon: Icons.calendar_month_outlined,
            color: AlshaariColors.copper,
          ),
          AlshaariStatCard(
            title: 'الفترات المفتوحة',
            value: '${countByStatus('open')}',
            icon: Icons.lock_open_outlined,
            color: AlshaariColors.success,
          ),
          AlshaariStatCard(
            title: 'الفترات المغلقة',
            value: '${countByStatus('closed')}',
            icon: Icons.lock_outline,
            color: AlshaariColors.danger,
          ),
        ];
        if (constraints.maxWidth < 720) {
          return Column(
            children: cards
                .map((card) => Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: card,
                    ))
                .toList(),
          );
        }
        return Row(
          children: cards
              .map((card) => Expanded(
                    child: Padding(
                      padding: const EdgeInsetsDirectional.only(end: 8),
                      child: card,
                    ),
                  ))
              .toList(),
        );
      },
    );
  }

  Widget filterBar() {
    final filters = const [
      ('all', 'الكل'),
      ('open', 'مفتوحة'),
      ('closed', 'مغلقة'),
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: filters.map((item) {
        final selected = statusFilter == item.$1;
        return FilterChip(
          selected: selected,
          label: Text(item.$2),
          checkmarkColor: AlshaariColors.copper,
          selectedColor: AlshaariColors.copper.withOpacity(.14),
          onSelected: (_) => setState(() => statusFilter = item.$1),
        );
      }).toList(),
    );
  }

  Widget periodCard(Map<String, dynamic> row) {
    final status = '${row['status'] ?? 'open'}';
    final color = statusColor(status);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: color.withOpacity(.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    status == 'closed'
                        ? Icons.lock_outline
                        : Icons.lock_open_outlined,
                    color: color,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${monthLabel(row['month'])} ${row['year']}',
                        style: const TextStyle(
                          color: AlshaariColors.ink,
                          fontWeight: FontWeight.w900,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${row['start_date']} - ${row['end_date']}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                AlshaariStatusBadge(
                  label: statusLabel(status),
                  color: color,
                  icon: status == 'closed'
                      ? Icons.lock_outline
                      : Icons.lock_open_outlined,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Text(
              status == 'closed'
                  ? 'هذه الفترة مغلقة. أي ترحيل داخلها يحتاج صلاحية خاصة.'
                  : 'هذه الفترة مفتوحة ويمكن اعتماد وترحيل المستندات داخلها.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            if ((status == 'closed' && can('open_closed_period')) ||
                (status != 'closed' && can('close_period')))
              Align(
                alignment: AlignmentDirectional.centerEnd,
                child: SizedBox(
                  width: 170,
                  child: status == 'closed'
                      ? OutlinedButton.icon(
                          onPressed: () => changeStatus(row, 'open'),
                          icon: const Icon(Icons.lock_open_outlined),
                          label: const Text('فتح الفترة'),
                        )
                      : FilledButton.icon(
                          onPressed: () => changeStatus(row, 'close'),
                          icon: const Icon(Icons.lock_outline),
                          label: const Text('إقفال الفترة'),
                        ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = visiblePeriods();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('الفترات المالية'),
            ],
          ),
          actions: [
            IconButton(onPressed: loadPeriods, icon: const Icon(Icons.refresh)),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل الفترات المالية...')
            : error != null
                ? AlshaariErrorState(message: error!, onRetry: loadPeriods)
                : RefreshIndicator(
                    onRefresh: loadPeriods,
                    child: ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        AlshaariPageHeader(
                          title: 'الإقفال المالي',
                          subtitle:
                              'تحكم في فتح وإقفال الفترات لمنع الترحيل بعد الاعتماد الشهري.',
                          icon: Icons.event_available_outlined,
                          trailing: SizedBox(
                            width: 170,
                            child: FilledButton.icon(
                              onPressed: createCurrentMonth,
                              icon: const Icon(Icons.add),
                              label: const Text('الشهر الحالي'),
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        summaryCards(),
                        const SizedBox(height: 8),
                        AlshaariSectionCard(
                          title: 'فلترة الفترات',
                          subtitle:
                              'اعرض الفترات المفتوحة أو المغلقة حسب الحاجة.',
                          icon: Icons.filter_list,
                          child: filterBar(),
                        ),
                        const SizedBox(height: 8),
                        if (visible.isEmpty)
                          const AlshaariEmptyState(
                            title: 'لا توجد فترات مالية',
                            subtitle:
                                'أنشئ فترة الشهر الحالي كبداية، ثم أضف بقية الشهور لاحقًا.',
                            icon: Icons.calendar_today_outlined,
                          )
                        else
                          ...visible.map((raw) {
                            final row = Map<String, dynamic>.from(raw as Map);
                            return periodCard(row);
                          }),
                      ],
                    ),
                  ),
      ),
    );
  }
}
