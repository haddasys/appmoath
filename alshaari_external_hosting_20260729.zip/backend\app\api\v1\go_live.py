from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.database import get_db
from app.models.models import (
    Account,
    Customer,
    Item,
    JournalEntry,
    PostingRule,
    Project,
    Supplier,
    Transaction,
    Worker,
)

router = APIRouter(prefix="/api/v1/go-live", tags=["Go Live"])


def _count(db: Session, model) -> int:
    return db.query(func.count(model.id)).scalar() or 0


@router.get("/readiness")
def readiness(db: Session = Depends(get_db), user=Depends(get_current_user)):
    accounts_count = _count(db, Account)
    posting_rules_count = _count(db, PostingRule)
    draft_transactions = db.query(Transaction).filter(Transaction.status == "draft").count()
    approved_transactions = db.query(Transaction).filter(Transaction.status == "approved").count()
    opening_account_balance = db.query(func.coalesce(func.sum(Account.balance), 0)).scalar()

    checks = [
        {
            "key": "chart_of_accounts",
            "ok": accounts_count > 0,
            "message": "دليل الحسابات موجود" if accounts_count > 0 else "دليل الحسابات غير موجود",
        },
        {
            "key": "posting_rules",
            "ok": posting_rules_count > 0,
            "message": "قواعد الترحيل موجودة" if posting_rules_count > 0 else "قواعد الترحيل غير موجودة",
        },
        {
            "key": "no_draft_transactions",
            "ok": draft_transactions == 0,
            "message": "لا توجد حركات غير معتمدة" if draft_transactions == 0 else f"توجد حركات غير معتمدة: {draft_transactions}",
        },
        {
            "key": "clean_operational_start",
            "ok": approved_transactions == 0 and _count(db, JournalEntry) == 0,
            "message": "قاعدة تشغيل نظيفة" if approved_transactions == 0 else "توجد حركات معتمدة قبل التشغيل",
        },
    ]

    return {
        "ready": all(item["ok"] for item in checks),
        "checks": checks,
        "counts": {
            "accounts": accounts_count,
            "posting_rules": posting_rules_count,
            "customers": _count(db, Customer),
            "suppliers": _count(db, Supplier),
            "workers": _count(db, Worker),
            "projects": _count(db, Project),
            "items": _count(db, Item),
            "draft_transactions": draft_transactions,
            "approved_transactions": approved_transactions,
        },
        "opening_account_balance": float(opening_account_balance or 0),
    }
