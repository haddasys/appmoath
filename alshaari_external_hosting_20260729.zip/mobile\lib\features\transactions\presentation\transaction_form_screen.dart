import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/theme.dart';
import '../../../core/config.dart';
import '../../../core/network/connectivity_service.dart';
import '../../../core/offline_queue/offline_queue.dart';
import '../../../core/widgets/alshaari_ui.dart';

class TransactionFormScreen extends StatefulWidget {
  final String? initialType;

  const TransactionFormScreen({super.key, this.initialType});

  @override
  State<TransactionFormScreen> createState() => _TransactionFormScreenState();
}

class _TransactionFormScreenState extends State<TransactionFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ),
  );

  bool loading = true;
  bool saving = false;

  List<dynamic> customers = [];
  List<dynamic> suppliers = [];
  List<dynamic> employees = [];
  List<dynamic> workers = [];
  List<dynamic> projects = [];
  List<dynamic> items = [];
  List<dynamic> costCenters = [];
  List<dynamic> cashAccounts = [];
  List<dynamic> accounts = [];

  String? transactionType;
  String currency = 'YER';
  String paymentMethod = 'cash';
  String? costCategory;
  String? settlementType;
  bool workerWageForProject = true;

  int? relatedId;
  int? projectId;
  int? itemId;
  int? costCenterId;
  int? cashAccountId;
  int? fromCashAccountId;
  int? toCashAccountId;

  final amountController = TextEditingController();
  final qtyController = TextEditingController();
  final unitCostController = TextEditingController();
  final descriptionController = TextEditingController();

  static const allTransactionTypes = [
    {'value': 'receipt_from_customer', 'label': 'قبض من عميل'},
    {'value': 'customer_advance', 'label': 'دفعة مقدمة من عميل'},
    {'value': 'general_payment', 'label': 'صرف عام'},
    {'value': 'supplier_payment', 'label': 'دفع مورد'},
    {'value': 'supplier_advance', 'label': 'دفعة مقدمة لمورد'},
    {'value': 'project_expense', 'label': 'مصروف مشروع'},
    {'value': 'material_purchase', 'label': 'شراء مواد نقدي'},
    {'value': 'material_issue_to_project', 'label': 'صرف مواد لمشروع'},
    {'value': 'worker_wage', 'label': 'صرف أجر عامل'},
    {'value': 'advance_payment', 'label': 'صرف سلفة / عهدة'},
    {'value': 'advance_settlement', 'label': 'تسوية سلفة / عهدة'},
    {'value': 'cash_transfer', 'label': 'تحويل بين الصناديق'},
  ];

  static const receiptTypes = [
    {'value': 'receipt_from_customer', 'label': 'قبض من عميل'},
    {'value': 'customer_advance', 'label': 'دفعة مقدمة من عميل'},
  ];

  static const paymentTypes = [
    {'value': 'general_payment', 'label': 'مصروف تشغيلي / إداري'},
  ];

  static const transferTypes = [
    {'value': 'cash_transfer', 'label': 'تحويل بين الصناديق'},
  ];

  static const currencies = [
    {'value': 'YER', 'label': 'ريال يمني'},
    {'value': 'SAR', 'label': 'ريال سعودي'},
    {'value': 'USD', 'label': 'دولار'},
  ];

  static const paymentMethods = [
    {'value': 'cash', 'label': 'نقد'},
    {'value': 'bank', 'label': 'بنك / حوالة'},
    {'value': 'wallet', 'label': 'محفظة إلكترونية'},
    {'value': 'transfer', 'label': 'حوالة'},
  ];

  static const costCategories = [
    {'value': 'qat', 'label': 'قات'},
    {'value': 'transport', 'label': 'مواصلات'},
    {'value': 'lunch', 'label': 'غداء'},
    {'value': 'wood', 'label': 'خشب'},
    {'value': 'paint', 'label': 'دهان'},
    {'value': 'accessories', 'label': 'إكسسوارات'},
    {'value': 'glass', 'label': 'زجاج وألمنيوم'},
    {'value': 'upholstery', 'label': 'تنجيد وإسفنج'},
    {'value': 'labor', 'label': 'أجور'},
    {'value': 'installation', 'label': 'تركيب'},
    {'value': 'maintenance', 'label': 'صيانة'},
    {'value': 'electricity', 'label': 'كهرباء'},
    {'value': 'diesel', 'label': 'ديزل'},
    {'value': 'rent', 'label': 'إيجار'},
    {'value': 'marketing', 'label': 'تسويق'},
    {'value': 'admin', 'label': 'مصروف إداري'},
    {'value': 'general', 'label': 'مصروف عام'},
  ];

  static const expenseCategories = [
    {'value': 'qat', 'label': 'قات'},
    {'value': 'transport', 'label': 'مواصلات'},
    {'value': 'lunch', 'label': 'غداء'},
    {'value': 'maintenance', 'label': 'صيانة'},
    {'value': 'electricity', 'label': 'كهرباء'},
    {'value': 'diesel', 'label': 'ديزل'},
    {'value': 'rent', 'label': 'إيجار'},
    {'value': 'marketing', 'label': 'تسويق'},
    {'value': 'admin', 'label': 'مصروف إداري'},
    {'value': 'general', 'label': 'مصروف عام'},
  ];

  static const settlementTypes = [
    {'value': 'wage_project', 'label': 'تسوية كأجر مشروع'},
    {'value': 'wage_general', 'label': 'تسوية كأجر عام'},
    {'value': 'expense_project', 'label': 'تسوية كمصروف مشروع'},
    {'value': 'cash_return', 'label': 'إرجاع نقدي'},
    {'value': 'salary_deduction', 'label': 'خصم من الراتب'},
  ];

  @override
  void initState() {
    super.initState();
    transactionType = widget.initialType;
    configureTokenAndLoad();
  }

  @override
  void dispose() {
    amountController.dispose();
    qtyController.dispose();
    unitCostController.dispose();
    descriptionController.dispose();
    super.dispose();
  }

  bool get isReceiptVoucher =>
      widget.initialType == 'receipt_from_customer' ||
      transactionType == 'receipt_from_customer' ||
      transactionType == 'customer_advance';

  bool get isReceiptVoucherRoute =>
      widget.initialType == 'receipt_from_customer';
  bool get isPaymentVoucherRoute => widget.initialType == 'general_payment';
  bool get isTransferVoucherRoute => widget.initialType == 'cash_transfer';

  bool get isPaymentVoucher =>
      widget.initialType == 'general_payment' ||
      transactionType == 'general_payment' ||
      transactionType == 'supplier_payment' ||
      transactionType == 'supplier_advance' ||
      transactionType == 'project_expense' ||
      transactionType == 'worker_wage' ||
      transactionType == 'advance_payment' ||
      transactionType == 'material_purchase';

  Color get voucherAccentColor => isCashTransfer()
      ? AlshaariColors.info
      : isReceiptVoucher
          ? AlshaariColors.success
          : AlshaariColors.copper;

  Color get voucherSoftColor => isCashTransfer()
      ? AlshaariColors.info.withOpacity(.10)
      : isReceiptVoucher
          ? AlshaariColors.success.withOpacity(.09)
          : AlshaariColors.copper.withOpacity(.10);

  String get voucherDirectionLabel => isCashTransfer()
      ? 'تحويل داخلي'
      : isReceiptVoucher
          ? 'وارد إلى الصندوق'
          : 'صادر من الصندوق';

  Future<void> configureTokenAndLoad() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ??
        prefs.getString('access_token') ??
        prefs.getString('auth_token');
    if (token != null && token.isNotEmpty) {
      dio.options.headers['Authorization'] = 'Bearer $token';
    }
    await loadLookups();
  }

  Future<List<dynamic>> getList(List<String> paths) async {
    for (final path in paths) {
      try {
        final res = await dio.get(path);
        if (res.data is List) return res.data as List<dynamic>;
        if (res.data is Map && res.data['items'] is List) {
          return res.data['items'] as List<dynamic>;
        }
      } catch (_) {
        continue;
      }
    }
    return [];
  }

  Future<void> loadLookups() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        getList(['/api/v1/customers', '/customers']),
        getList(['/api/v1/suppliers', '/suppliers']),
        getList(['/api/v1/employees', '/employees']),
        getList(['/workers']),
        getList(['/api/v1/projects', '/projects']),
        getList(['/api/v1/inventory-items', '/api/v1/items', '/items']),
        getList(['/api/v1/cost-centers']),
        getList(['/api/v1/cash-accounts']),
        getList(['/api/v1/accounts', '/accounts']),
      ]);
      if (!mounted) return;
      setState(() {
        customers = result[0];
        suppliers = result[1];
        employees = result[2];
        workers = result[3];
        projects = result[4];
        items = result[5];
        costCenters = result[6].where((raw) {
          final item = Map<String, dynamic>.from(raw as Map);
          return item['is_active'] != false &&
              item['is_active'] != 0 &&
              item['is_postable'] != false &&
              item['is_postable'] != 0;
        }).toList();
        cashAccounts = result[7];
        accounts = result[8];
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMsg('فشل تحميل القوائم: $e');
    }
  }

  void showMsg(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  DropdownMenuItem<String> stringItem(Map<String, String> item) {
    return DropdownMenuItem(
      value: item['value'],
      child: Text(item['label'] ?? item['value'] ?? ''),
    );
  }

  int? idOf(dynamic item) {
    if (item is! Map) return null;
    final raw = item['id'];
    if (raw is int) return raw;
    return int.tryParse('$raw');
  }

  String nameOf(dynamic item) {
    if (item is! Map) return '';
    return '${item['name'] ?? item['title'] ?? item['label'] ?? item['code'] ?? item['id'] ?? ''}';
  }

  Widget lookupDropdown({
    required String title,
    required List<dynamic> data,
    required int? value,
    required ValueChanged<int?> onChanged,
    bool requiredField = false,
    String Function(Map<String, dynamic>)? labelBuilder,
  }) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: InputDecoration(labelText: title),
      items: data.map((raw) {
        final item = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
          value: idOf(item),
          child: Text(labelBuilder?.call(item) ?? nameOf(item)),
        );
      }).toList(),
      validator: (v) {
        if (requiredField && v == null) return title;
        return null;
      },
      onChanged: onChanged,
    );
  }

  bool requiresCustomer() =>
      transactionType == 'receipt_from_customer' ||
      transactionType == 'customer_advance';
  bool requiresSupplier() =>
      transactionType == 'supplier_payment' ||
      transactionType == 'supplier_advance';
  bool requiresWorker() =>
      transactionType == 'worker_wage' ||
      transactionType == 'advance_payment' ||
      transactionType == 'advance_settlement';
  bool requiresParty() =>
      requiresCustomer() || requiresSupplier() || requiresWorker();
  bool isCashTransfer() => transactionType == 'cash_transfer';
  bool requiresCashAccount() =>
      transactionType != null &&
      transactionType != 'material_issue_to_project' &&
      !isCashTransfer() &&
      !(transactionType == 'advance_settlement' &&
          settlementType != 'cash_return');
  bool requiresProject() {
    if (transactionType == 'project_expense' ||
        transactionType == 'material_issue_to_project') {
      return true;
    }
    if (transactionType == 'advance_settlement') {
      return settlementType == 'wage_project' ||
          settlementType == 'expense_project';
    }
    if (transactionType == 'worker_wage') return workerWageForProject;
    return false;
  }

  bool requiresCostCenter() =>
      transactionType == 'project_expense' ||
      transactionType == 'worker_wage' ||
      transactionType == 'material_issue_to_project' ||
      (transactionType == 'advance_settlement' &&
          settlementType != null &&
          settlementType != 'cash_return' &&
          settlementType != 'salary_deduction');
  bool requiresCostCategory() =>
      transactionType == 'general_payment' ||
      transactionType == 'project_expense' ||
      transactionType == 'worker_wage' ||
      (transactionType == 'advance_settlement' &&
          (settlementType == 'wage_project' ||
              settlementType == 'wage_general' ||
              settlementType == 'expense_project'));
  bool requiresItem() =>
      transactionType == 'material_purchase' ||
      transactionType == 'material_issue_to_project';
  bool requiresUnitCost() => transactionType == 'material_purchase';

  List<Map<String, String>> availableTypes() {
    if (widget.initialType == 'receipt_from_customer') return receiptTypes;
    if (widget.initialType == 'general_payment') return paymentTypes;
    if (widget.initialType == 'cash_transfer') return transferTypes;
    return allTransactionTypes;
  }

  List<dynamic> partyList() {
    if (requiresCustomer()) return customers;
    if (requiresSupplier()) return suppliers;
    if (requiresWorker()) return employees.isNotEmpty ? employees : workers;
    return [];
  }

  String partyLabel() {
    if (requiresCustomer()) return 'العميل';
    if (requiresSupplier()) return 'المورد';
    if (requiresWorker()) return 'العامل';
    return 'الطرف';
  }

  String? partyType() {
    if (requiresCustomer()) return 'customer';
    if (requiresSupplier()) return 'supplier';
    if (requiresWorker()) return 'worker';
    return null;
  }

  List<dynamic> filteredCashAccounts() {
    return cashAccounts.where((raw) {
      final item = Map<String, dynamic>.from(raw as Map);
      return item['is_active'] != false &&
          item['is_active'] != 0 &&
          (item['currency'] == null ||
              '${item['currency']}'.isEmpty ||
              item['currency'] == currency);
    }).toList();
  }

  String cashLabel(Map<String, dynamic> item) {
    final code = item['code'] ?? '';
    final name = item['name'] ?? '';
    final itemCurrency = item['currency'] ?? '';
    return '$code - $name | $itemCurrency';
  }

  String selectedPartyName() {
    final id = relatedId;
    if (id == null) return 'الطرف المختار';
    for (final raw in partyList()) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (idOf(item) == id) return nameOf(item);
    }
    return 'الطرف المختار';
  }

  String selectedCashAccountName() {
    final id = cashAccountId;
    if (id == null) return 'حساب النقدية أو البنك المختار';
    for (final raw in cashAccounts) {
      if (raw is! Map) continue;
      final item = Map<String, dynamic>.from(raw);
      if (idOf(item) == id) return cashLabel(item);
    }
    return 'حساب النقدية أو البنك المختار';
  }

  String advanceSettlementDebitPreview() {
    switch (settlementType) {
      case 'wage_project':
        return '50201 - أجور مباشرة للمشاريع';
      case 'wage_general':
        return '60301 - مصروف أجور عام';
      case 'expense_project':
        return '50303 - مصروفات مشروع أخرى';
      case 'cash_return':
        return selectedCashAccountName();
      case 'salary_deduction':
        return '20201 - أجور مستحقة للعمال';
      default:
        return 'اختر نوع التسوية لعرض الحساب المدين';
    }
  }

  String advanceSettlementCreditPreview() {
    return '20203 - عهد وسلف العمال (${selectedPartyName()})';
  }

  String operationSectionTitle() {
    if (isCashTransfer()) return 'نوع التحويل';
    return isReceiptVoucher ? 'نوع القبض' : 'نوع الصرف';
  }

  String operationSectionSubtitle() {
    if (isCashTransfer()) {
      return 'التحويل الداخلي ينقل الرصيد بين صندوقين أو محافظ ولا يعتبر مصروفًا أو إيرادًا.';
    }
    return isReceiptVoucher
        ? 'حدد هل المبلغ تحصيل فاتورة أو دفعة مقدمة من العميل.'
        : isPaymentVoucherRoute
            ? 'هذه الشاشة مخصصة للمصروفات التشغيلية والإدارية فقط، ولا تعرض بنود تكلفة المشاريع.'
            : 'حدد نوع العملية المالية المطلوبة.';
  }

  String operationFieldLabel() {
    if (isCashTransfer()) return 'اختر نوع التحويل';
    return isReceiptVoucher ? 'اختر نوع القبض' : 'اختر نوع الصرف';
  }

  String financialSectionTitle() {
    if (isCashTransfer()) return 'بيانات التحويل';
    return isReceiptVoucher ? 'بيانات القبض' : 'بيانات الصرف';
  }

  String financialSectionSubtitle() {
    if (isCashTransfer()) {
      return 'حدد المبلغ والصندوق المحول منه والصندوق المحول إليه. هذا لا يغيّر الإيرادات أو المصروفات.';
    }
    return isReceiptVoucher
        ? 'المبلغ الوارد وحساب الإيداع الذي ستزيد أرصدته.'
        : 'المبلغ الخارج وحساب الصرف الذي ستنقص أرصدته.';
  }

  String amountFieldLabel() {
    if (isCashTransfer()) return 'مبلغ التحويل';
    return isReceiptVoucher ? 'مبلغ القبض' : 'مبلغ الصرف';
  }

  String paymentMethodLabel() {
    if (isCashTransfer()) return 'طريقة التحويل';
    return isReceiptVoucher ? 'طريقة القبض' : 'طريقة الدفع';
  }

  List<Map<String, String>> categoryOptions() {
    if (transactionType == 'general_payment') {
      final expenseAccounts = accounts
          .where((raw) {
            if (raw is! Map) return false;
            final account = Map<String, dynamic>.from(raw);
            final type = '${account['type'] ?? ''}'.toLowerCase();
            final active = account['is_active'];
            return type == 'expense' && active != false && active != 0;
          })
          .map((raw) {
            final account = Map<String, dynamic>.from(raw as Map);
            final code = '${account['code'] ?? ''}'.trim();
            final name = '${account['name'] ?? ''}'.trim();
            return {
              'value': code,
              'label': name.isEmpty ? code : '$code - $name',
            };
          })
          .where((item) => (item['value'] ?? '').isNotEmpty)
          .toList();
      if (expenseAccounts.isNotEmpty) return expenseAccounts;
      return expenseCategories;
    }
    return costCategories;
  }

  bool hasExpenseAccountsFromChart() {
    return accounts.any((raw) {
      if (raw is! Map) return false;
      final account = Map<String, dynamic>.from(raw);
      final type = '${account['type'] ?? ''}'.toLowerCase();
      final active = account['is_active'];
      return type == 'expense' && active != false && active != 0;
    });
  }

  String categoryFieldLabel() {
    if (transactionType == 'general_payment') return 'اختر بند المصروف';
    return 'اختر بند التكلفة';
  }

  String projectCostSectionTitle() {
    if (transactionType == 'general_payment') return 'بند المصروف';
    return 'التكلفة والمشروع';
  }

  String projectCostSectionSubtitle() {
    if (transactionType == 'general_payment') {
      return 'سند الصرف العام يعرض المصروفات التشغيلية والإدارية فقط، ولا يحمّل تكلفة على مشروع.';
    }
    return 'تظهر هذه البيانات فقط عندما تؤثر العملية على تكلفة مشروع أو قسم.';
  }

  String accountingHint() {
    switch (transactionType) {
      case 'receipt_from_customer':
        return 'سند القبض يسدد ذمة العميل أو فاتورة قائمة، ولا ينشئ إيرادًا جديدًا إذا كانت الفاتورة مرحلة مسبقًا.';
      case 'customer_advance':
        return 'الدفعة المقدمة من العميل تسجل كالتزام حتى تتم الفوترة.';
      case 'general_payment':
        return 'سند الصرف العام يحتاج بند مصروف وحساب نقدية، ولا يرتبط بمشروع أو مخزون.';
      case 'supplier_payment':
        return 'دفع المورد يسدد الالتزام ولا يزيد المخزون ولا يسجل شراء جديد.';
      case 'supplier_advance':
        return 'الدفعة المقدمة للمورد أصل مؤقت، وليست مصروفًا حتى تصل الفاتورة أو تتم التسوية.';
      case 'advance_payment':
        return 'صرف السلفة لا يعتبر مصروفًا ولا يحمل على مشروع، بل يسجل كذمة على العامل.';
      case 'worker_wage':
        return 'الأجر المباشر يحمل على المشروع عند اختيار مشروع، أو على مركز تكلفة عام عند عدم ربطه بمشروع.';
      case 'material_purchase':
        return 'استخدم هذا الخيار للشراء النقدي المباشر فقط، وليس لفاتورة مورد آجلة.';
      default:
        return '';
    }
  }

  String temporaryPrefix() {
    switch (transactionType) {
      case 'receipt_from_customer':
      case 'customer_advance':
        return 'LOCAL-RCV';
      case 'advance_payment':
        return 'LOCAL-ADV';
      case 'advance_settlement':
        return 'LOCAL-SET';
      case 'cash_transfer':
        return 'LOCAL-TRF';
      case 'material_issue_to_project':
        return 'LOCAL-ISS';
      default:
        return 'LOCAL-PAY';
    }
  }

  Map<String, dynamic> buildPayload({
    required double amount,
    double? qty,
    double? unitCost,
  }) {
    final payload = <String, dynamic>{
      'date': DateTime.now().toIso8601String().substring(0, 10),
      'type': transactionType,
      'amount': amount,
      'currency': currency,
      'description': descriptionController.text.trim(),
      'status': 'draft',
    };

    if (requiresCashAccount()) {
      payload['payment_method'] = paymentMethod;
      payload['cash_account_id'] = cashAccountId;
    }
    if (isCashTransfer()) {
      payload['from_cash_account_id'] = fromCashAccountId;
      payload['to_cash_account_id'] = toCashAccountId;
      payload['payment_method'] = paymentMethod;
    }
    if (requiresParty()) {
      payload['related_account_type'] = partyType();
      payload['related_id'] = relatedId;
    }
    if (requiresProject()) payload['project_id'] = projectId;
    if (requiresCostCenter()) payload['cost_center_id'] = costCenterId;
    if (requiresCostCategory()) payload['cost_category'] = costCategory;
    if (transactionType == 'advance_settlement') {
      payload['settlement_type'] = settlementType;
    }
    if (requiresItem()) {
      payload['item_id'] = itemId;
      payload['qty'] = qty;
      if (unitCost != null) payload['unit_cost'] = unitCost;
    }
    return payload;
  }

  Future<Map<String, dynamic>> postDocument(
      Map<String, dynamic> payload) async {
    try {
      final response = await dio.post('/api/v1/transactions', data: payload);
      return _responseMap(response.data);
    } catch (_) {
      final response = await dio.post('/transactions', data: payload);
      return _responseMap(response.data);
    }
  }

  Map<String, dynamic> _responseMap(dynamic data) {
    if (data is Map<String, dynamic>) return data;
    if (data is Map) return Map<String, dynamic>.from(data);
    return const {};
  }

  bool supportsOfflineDraft() {
    return transactionType == 'general_payment' ||
        transactionType == 'receipt_from_customer' ||
        transactionType == 'customer_advance' ||
        transactionType == 'advance_payment';
  }

  String offlineBlockedMessage() {
    return 'هذا المستند يحتاج اتصالًا بالخادم في هذه المرحلة حتى تتم مراجعته محاسبيًا بدون تكرار أو تعارض.';
  }

  bool isConnectionFailure(Object e) {
    if (e is! DioException) return false;
    return e.type == DioExceptionType.connectionError ||
        e.type == DioExceptionType.connectionTimeout ||
        e.type == DioExceptionType.receiveTimeout ||
        e.type == DioExceptionType.sendTimeout;
  }

  Future<String> saveOfflineDraft(Map<String, dynamic> payload) async {
    final result = await offlineQueue.enqueueCreate(
      entityType: 'transaction',
      documentType: transactionType ?? 'transaction',
      temporaryPrefix: temporaryPrefix(),
      payload: payload,
    );
    return result.temporaryNo;
  }

  Future<void> cacheSyncedDraft(
    Map<String, dynamic> payload,
    Map<String, dynamic> serverResponse,
  ) async {
    await offlineQueue.cacheSyncedCreate(
      entityType: 'transaction',
      documentType: transactionType ?? 'transaction',
      temporaryPrefix: temporaryPrefix(),
      payload: payload,
      serverResponse: serverResponse,
    );
  }

  void resetFormAfterSave() {
    amountController.clear();
    qtyController.clear();
    unitCostController.clear();
    descriptionController.clear();
    setState(() {
      relatedId = null;
      projectId = null;
      itemId = null;
      costCenterId = null;
      cashAccountId = null;
      fromCashAccountId = null;
      toCashAccountId = null;
      costCategory = transactionType == 'worker_wage' ? 'labor' : null;
      settlementType = null;
    });
  }

  Future<void> submit() async {
    if (!_formKey.currentState!.validate()) return;
    if (isCashTransfer()) {
      if (fromCashAccountId == null || toCashAccountId == null) {
        showMsg('اختر الصندوق المحول منه والصندوق المحول إليه.');
        return;
      }
      if (fromCashAccountId == toCashAccountId) {
        showMsg('لا يمكن التحويل بين نفس الصندوق. اختر صندوقين مختلفين.');
        return;
      }
    }
    final amount = double.tryParse(amountController.text.trim()) ?? 0;
    final qty = double.tryParse(qtyController.text.trim());
    final unitCost = double.tryParse(unitCostController.text.trim());

    setState(() => saving = true);
    try {
      final payload =
          buildPayload(amount: amount, qty: qty, unitCost: unitCost);
      final connection = await connectivityService.status();
      if (!connection.canUseServer) {
        if (!supportsOfflineDraft()) {
          showMsg(offlineBlockedMessage());
          return;
        }
        final temporaryNo = await saveOfflineDraft(payload);
        if (!mounted) return;
        showMsg(
          'أنت تعمل بدون إنترنت. تم حفظ المستند محليًا برقم $temporaryNo بانتظار المزامنة.',
        );
        resetFormAfterSave();
        return;
      }

      final response = await postDocument(payload);
      await cacheSyncedDraft(payload, response);
      if (!mounted) return;
      showMsg('تم حفظ المستند كمسودة. راجعه من شاشة اعتماد المستندات.');
      resetFormAfterSave();
    } catch (e) {
      if (!mounted) return;
      if (isConnectionFailure(e)) {
        if (!supportsOfflineDraft()) {
          showMsg(offlineBlockedMessage());
          return;
        }
        final payload =
            buildPayload(amount: amount, qty: qty, unitCost: unitCost);
        final temporaryNo = await saveOfflineDraft(payload);
        if (!mounted) return;
        showMsg(
          'أنت تعمل بدون إنترنت. تم حفظ المستند محليًا برقم $temporaryNo بانتظار المزامنة.',
        );
        resetFormAfterSave();
        return;
      }
      showMsg('فشل حفظ المستند: $e');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget directionBanner() {
    final incoming = isReceiptVoucher;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: voucherSoftColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: voucherAccentColor.withOpacity(.35)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              DecoratedBox(
                decoration: BoxDecoration(
                  color: voucherAccentColor,
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Icon(
                    isCashTransfer()
                        ? Icons.swap_horiz
                        : incoming
                            ? Icons.call_received
                            : Icons.call_made,
                    color: Colors.white,
                  ),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      voucherDirectionLabel,
                      style: TextStyle(
                        color: voucherAccentColor,
                        fontWeight: FontWeight.w900,
                        fontSize: 15,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      incoming
                          ? 'سند القبض يثبت مبلغًا مستلمًا ويزيد حساب الإيداع أو الصندوق المختار.'
                          : isCashTransfer()
                              ? 'التحويل الداخلي ينقل الرصيد بين صندوقين أو محافظ ولا يسجل كمصروف أو إيراد.'
                              : 'سند الصرف يثبت مبلغًا مدفوعًا ويخفض حساب الصرف أو الصندوق المختار.',
                      style: const TextStyle(fontWeight: FontWeight.w700),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            decoration: BoxDecoration(
              color: Colors.white.withOpacity(.72),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Text(
              incoming
                  ? 'الترتيب هنا يبدأ بالعميل ثم بيانات القبض، لأن القرار الأساسي هو: من دفع؟ وأين دخل المبلغ؟'
                  : isCashTransfer()
                      ? 'اختر أولًا الصندوق المحول منه ثم الصندوق المحول إليه. لا يمكن اختيار نفس الصندوق في الطرفين.'
                      : 'الترتيب هنا يبدأ ببيانات الصرف ثم المستفيد، لأن القرار الأساسي هو: من أي صندوق خرج المبلغ؟ ولماذا؟',
              style: const TextStyle(
                color: AlshaariColors.slate,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget operationSection() {
    return AlshaariSectionCard(
      title: operationSectionTitle(),
      subtitle: operationSectionSubtitle(),
      icon: isReceiptVoucher
          ? Icons.receipt_long_outlined
          : isCashTransfer()
              ? Icons.swap_horiz_outlined
              : Icons.payments_outlined,
      child: DropdownButtonFormField<String>(
        initialValue: transactionType,
        decoration: InputDecoration(
          labelText: operationFieldLabel(),
        ),
        items: availableTypes().map(stringItem).toList(),
        validator: (v) => v == null ? operationFieldLabel() : null,
        onChanged: (v) {
          setState(() {
            transactionType = v;
            relatedId = null;
            projectId = null;
            itemId = null;
            costCenterId = null;
            cashAccountId = null;
            fromCashAccountId = null;
            toCashAccountId = null;
            settlementType = null;
            costCategory = v == 'worker_wage' ? 'labor' : null;
          });
        },
      ),
    );
  }

  Widget partySection() {
    if (!requiresParty()) return const SizedBox.shrink();
    return AlshaariSectionCard(
      title: isReceiptVoucher ? 'بيانات العميل' : 'الطرف المستفيد',
      subtitle: isReceiptVoucher
          ? 'اختر العميل الذي سيتم إثبات القبض على حسابه.'
          : 'اختر المورد أو العامل عند وجود ذمة أو مستحق مرتبط بالصرف.',
      icon: isReceiptVoucher
          ? Icons.person_search_outlined
          : Icons.badge_outlined,
      child: lookupDropdown(
        title: 'اختر ${partyLabel()}',
        data: partyList(),
        value: relatedId,
        requiredField: true,
        onChanged: (v) => setState(() => relatedId = v),
      ),
    );
  }

  Widget financialSection() {
    return AlshaariSectionCard(
      title: financialSectionTitle(),
      subtitle: financialSectionSubtitle(),
      icon: isCashTransfer()
          ? Icons.swap_horiz_outlined
          : isReceiptVoucher
              ? Icons.call_received
              : Icons.call_made,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          TextFormField(
            controller: amountController,
            keyboardType: TextInputType.number,
            decoration: InputDecoration(
              labelText: amountFieldLabel(),
            ),
            validator: (v) {
              final value = double.tryParse((v ?? '').trim());
              if (value == null || value <= 0) return 'أدخل مبلغًا صحيحًا';
              return null;
            },
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            initialValue: currency,
            decoration: const InputDecoration(labelText: 'العملة'),
            items: currencies.map(stringItem).toList(),
            onChanged: (v) => setState(() {
              currency = v ?? 'YER';
              cashAccountId = null;
              fromCashAccountId = null;
              toCashAccountId = null;
            }),
          ),
          if (requiresCashAccount() || isCashTransfer()) ...[
            const SizedBox(height: 12),
            DropdownButtonFormField<String>(
              initialValue: paymentMethod,
              decoration: InputDecoration(
                labelText: paymentMethodLabel(),
              ),
              items: paymentMethods.map(stringItem).toList(),
              onChanged: (v) => setState(() => paymentMethod = v ?? 'cash'),
            ),
          ],
          if (isCashTransfer()) ...[
            const SizedBox(height: 12),
            if (filteredCashAccounts().isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AlshaariColors.warning.withOpacity(.10),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AlshaariColors.warning.withOpacity(.35),
                  ),
                ),
                child: const Text(
                  'لا توجد صناديق أو محافظ نشطة لهذه العملة. أضف أو فعّل حسابًا نقديًا أولًا.',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              )
            else ...[
              lookupDropdown(
                title: 'من صندوق / حساب',
                data: filteredCashAccounts(),
                value: fromCashAccountId,
                requiredField: true,
                onChanged: (v) => setState(() => fromCashAccountId = v),
                labelBuilder: cashLabel,
              ),
              const SizedBox(height: 12),
              lookupDropdown(
                title: 'إلى صندوق / حساب',
                data: filteredCashAccounts(),
                value: toCashAccountId,
                requiredField: true,
                onChanged: (v) => setState(() => toCashAccountId = v),
                labelBuilder: cashLabel,
              ),
            ],
          ],
          if (requiresCashAccount() && filteredCashAccounts().isNotEmpty) ...[
            const SizedBox(height: 12),
            lookupDropdown(
              title: isReceiptVoucher
                  ? 'حساب الإيداع / الصندوق المستلم'
                  : 'حساب الصرف / الصندوق الدافع',
              data: filteredCashAccounts(),
              value: cashAccountId,
              requiredField: true,
              onChanged: (v) => setState(() => cashAccountId = v),
              labelBuilder: cashLabel,
            ),
          ],
        ],
      ),
    );
  }

  Widget accountingHintBox() {
    final hint = accountingHint();
    if (hint.isEmpty) return const SizedBox.shrink();
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFF1F4D45).withOpacity(.08),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE5D9C8)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, size: 20, color: Color(0xFF1F4D45)),
          const SizedBox(width: 8),
          Expanded(child: Text(hint)),
        ],
      ),
    );
  }

  String debitPreview() {
    switch (transactionType) {
      case 'receipt_from_customer':
      case 'customer_advance':
        return 'حساب النقدية أو البنك المختار';
      case 'cash_transfer':
        return 'الصندوق / الحساب المحول إليه';
      case 'supplier_payment':
        return 'حساب المورد';
      case 'supplier_advance':
        return 'دفعات مقدمة للموردين';
      case 'advance_payment':
        return 'عهد وسلف العمال';
      case 'advance_settlement':
        return advanceSettlementDebitPreview();
      case 'worker_wage':
        return workerWageForProject ? 'أجور مباشرة للمشاريع' : 'مصروف أجور عام';
      case 'project_expense':
        return 'تكلفة المشروع / مركز التكلفة';
      case 'material_purchase':
        return 'مشتريات أو مخزون حسب السياسة';
      case 'general_payment':
        return 'بند المصروف المختار';
      default:
        return 'الحساب المدين حسب نوع المستند';
    }
  }

  String creditPreview() {
    switch (transactionType) {
      case 'receipt_from_customer':
        return 'ذمة العميل أو الفاتورة';
      case 'customer_advance':
        return 'دفعات مقدمة من العملاء';
      case 'cash_transfer':
        return 'الصندوق / الحساب المحول منه';
      case 'supplier_payment':
      case 'supplier_advance':
      case 'advance_payment':
      case 'worker_wage':
      case 'project_expense':
      case 'material_purchase':
      case 'general_payment':
        return 'حساب النقدية أو البنك المختار';
      case 'advance_settlement':
        return advanceSettlementCreditPreview();
      default:
        return 'الحساب الدائن حسب نوع المستند';
    }
  }

  Widget journalPreviewSection() {
    if (transactionType == null) {
      return const SizedBox.shrink();
    }
    return AlshaariSectionCard(
      title: isCashTransfer()
          ? 'الأثر المحاسبي للتحويل'
          : isReceiptVoucher
              ? 'الأثر المحاسبي للقبض'
              : 'الأثر المحاسبي للصرف',
      subtitle: 'معاينة مبسطة للقيد المتوقع قبل الحفظ والاعتماد.',
      icon: Icons.account_balance_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _journalPreviewRow(
            label: 'مدين',
            value: debitPreview(),
            color: AlshaariColors.success,
          ),
          const SizedBox(height: 10),
          _journalPreviewRow(
            label: 'دائن',
            value: creditPreview(),
            color: AlshaariColors.copper,
          ),
        ],
      ),
    );
  }

  Widget _journalPreviewRow({
    required String label,
    required String value,
    required Color color,
  }) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: color.withOpacity(.22)),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 58,
            child: Text(
              label,
              style: TextStyle(color: color, fontWeight: FontWeight.w900),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
          ),
        ],
      ),
    );
  }

  Widget workerWageModeSection() {
    if (transactionType != 'worker_wage') return const SizedBox.shrink();
    return AlshaariSectionCard(
      title: 'طريقة تحميل الأجر',
      subtitle: 'حدد هل الأجر مرتبط بمشروع أم بمركز تكلفة عام.',
      icon: Icons.engineering_outlined,
      child: SwitchListTile(
        contentPadding: EdgeInsets.zero,
        title: const Text('الأجر مرتبط بمشروع'),
        subtitle: Text(workerWageForProject
            ? 'سيتم تحميل الأجر على تكلفة المشروع'
            : 'سيتم تحميل الأجر على مركز تكلفة عام'),
        value: workerWageForProject,
        onChanged: (v) => setState(() {
          workerWageForProject = v;
          projectId = null;
          costCategory = 'labor';
        }),
      ),
    );
  }

  Widget projectAndCostSection() {
    final showProject = requiresProject();
    final showCostCenter = requiresCostCenter() && costCenters.isNotEmpty;
    final showCostCategory = requiresCostCategory();
    if (!showProject && !showCostCenter && !showCostCategory) {
      return const SizedBox.shrink();
    }
    return AlshaariSectionCard(
      title: projectCostSectionTitle(),
      subtitle: projectCostSectionSubtitle(),
      icon: Icons.account_tree_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          if (showProject)
            lookupDropdown(
              title: 'اختر المشروع',
              data: projects,
              value: projectId,
              requiredField: true,
              onChanged: (v) => setState(() => projectId = v),
              labelBuilder: (item) {
                final code = item['project_code'] ?? item['code'] ?? '';
                final name = item['name'] ?? item['title'] ?? '';
                return '$code - $name';
              },
            ),
          if (showCostCenter) ...[
            if (showProject) const SizedBox(height: 12),
            lookupDropdown(
              title: 'اختر مركز التكلفة',
              data: costCenters,
              value: costCenterId,
              requiredField: true,
              onChanged: (v) => setState(() => costCenterId = v),
              labelBuilder: (item) {
                final code = item['code'] ?? '';
                final name = item['name'] ?? '';
                final type = item['type'] ?? '';
                return '$code - $name | $type';
              },
            ),
          ],
          if (showCostCategory) ...[
            if (showProject || showCostCenter) const SizedBox(height: 12),
            if (transactionType == 'general_payment' &&
                !hasExpenseAccountsFromChart()) ...[
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: AlshaariColors.warning.withOpacity(.10),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(
                    color: AlshaariColors.warning.withOpacity(.35),
                  ),
                ),
                child: const Text(
                  'لم يتم العثور على حسابات مصروفات نشطة في دليل الحسابات، لذلك يتم عرض قائمة مصروفات احتياطية.',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              const SizedBox(height: 12),
            ],
            DropdownButtonFormField<String>(
              initialValue: costCategory,
              decoration: InputDecoration(labelText: categoryFieldLabel()),
              items: categoryOptions().map(stringItem).toList(),
              validator: (v) => v == null ? categoryFieldLabel() : null,
              onChanged: transactionType == 'worker_wage'
                  ? null
                  : (v) => setState(() => costCategory = v),
            ),
          ],
        ],
      ),
    );
  }

  Widget inventorySection() {
    if (!requiresItem()) return const SizedBox.shrink();
    return AlshaariSectionCard(
      title: 'بيانات المخزون',
      subtitle: 'تظهر عند شراء المواد أو صرفها لمشروع.',
      icon: Icons.inventory_2_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          lookupDropdown(
            title: 'اختر المادة',
            data: items,
            value: itemId,
            requiredField: true,
            onChanged: (v) => setState(() => itemId = v),
            labelBuilder: (item) {
              final code = item['code'] ?? '';
              final name = item['name'] ?? '';
              final qty = item['current_qty'] ?? item['quantity'] ?? '';
              final unit = item['unit'] ?? '';
              return '$code - $name | الرصيد: $qty $unit';
            },
          ),
          const SizedBox(height: 12),
          TextFormField(
            controller: qtyController,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(labelText: 'الكمية'),
            validator: (v) {
              final value = double.tryParse((v ?? '').trim());
              if (requiresItem() && (value == null || value <= 0)) {
                return 'أدخل كمية صحيحة';
              }
              return null;
            },
          ),
          if (requiresUnitCost()) ...[
            const SizedBox(height: 12),
            TextFormField(
              controller: unitCostController,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'تكلفة الوحدة'),
            ),
          ],
        ],
      ),
    );
  }

  Widget descriptionSection() {
    return AlshaariSectionCard(
      title: isReceiptVoucher ? 'بيان القبض' : 'بيان الصرف',
      subtitle: 'اكتب وصفًا واضحًا يساعد المراجعة والاعتماد.',
      icon: Icons.notes_outlined,
      child: TextFormField(
        controller: descriptionController,
        maxLines: 3,
        decoration: InputDecoration(
          labelText:
              isReceiptVoucher ? 'مثال: دفعة من العميل' : 'مثال: سبب الصرف',
        ),
        validator: (v) {
          if ((v ?? '').trim().length < 3) return 'أدخل بيانًا واضحًا';
          return null;
        },
      ),
    );
  }

  String pageTitle() {
    switch (widget.initialType) {
      case 'receipt_from_customer':
        return 'سند قبض';
      case 'general_payment':
        return 'سند صرف';
      case 'advance_payment':
        return 'صرف سلفة / عهدة';
      case 'cash_transfer':
        return 'تحويل بين الصناديق';
      default:
        return 'إضافة مستند مالي';
    }
  }

  String pageSubtitle() {
    if (widget.initialType == 'receipt_from_customer') {
      return 'مستند وارد لإثبات مبلغ مستلم من عميل أو دفعة مقدمة.';
    }
    if (widget.initialType == 'general_payment') {
      return 'مستند صادر للمصروفات التشغيلية والإدارية فقط. تكاليف المشاريع والمواد لها مستندات مستقلة.';
    }
    if (widget.initialType == 'cash_transfer') {
      return 'مستند داخلي لنقل الرصيد بين صندوقين أو محافظ بدون اعتباره مصروفًا أو إيرادًا.';
    }
    return 'أدخل البيانات المطلوبة فقط. سيتم حفظ المستند كمسودة قبل الاعتماد.';
  }

  IconData pageIcon() {
    if (widget.initialType == 'receipt_from_customer') {
      return Icons.call_received_outlined;
    }
    if (widget.initialType == 'general_payment') {
      return Icons.call_made_outlined;
    }
    if (widget.initialType == 'cash_transfer') {
      return Icons.swap_horiz_outlined;
    }
    return Icons.receipt_long_outlined;
  }

  Color headerColor() {
    if (widget.initialType == 'receipt_from_customer') {
      return AlshaariColors.success;
    }
    if (widget.initialType == 'general_payment') {
      return AlshaariColors.copper;
    }
    if (widget.initialType == 'cash_transfer') {
      return AlshaariColors.info;
    }
    return AlshaariColors.info;
  }

  String submitLabel() {
    if (isReceiptVoucherRoute) return 'حفظ سند القبض كمسودة';
    if (isPaymentVoucherRoute) return 'حفظ سند الصرف كمسودة';
    if (isTransferVoucherRoute) return 'حفظ التحويل كمسودة';
    if (transactionType == 'receipt_from_customer' ||
        transactionType == 'customer_advance') {
      return 'حفظ مستند القبض كمسودة';
    }
    return 'حفظ المستند كمسودة';
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        backgroundColor: isReceiptVoucherRoute
            ? const Color(0xFFF4FBF7)
            : isPaymentVoucherRoute
                ? AlshaariColors.pearl
                : isTransferVoucherRoute
                    ? const Color(0xFFF5F9FB)
                    : null,
        appBar: AppBar(
          title: Text(pageTitle()),
          backgroundColor: headerColor(),
          foregroundColor: Colors.white,
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل بيانات المستند...')
            : Form(
                key: _formKey,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    AlshaariPageHeader(
                      title: pageTitle(),
                      subtitle: pageSubtitle(),
                      icon: pageIcon(),
                    ),
                    const SizedBox(height: 12),
                    directionBanner(),
                    const SizedBox(height: 12),
                    operationSection(),
                    const SizedBox(height: 12),
                    accountingHintBox(),
                    const SizedBox(height: 12),
                    journalPreviewSection(),
                    const SizedBox(height: 12),
                    if (isReceiptVoucher) ...[
                      partySection(),
                      const SizedBox(height: 12),
                      financialSection(),
                    ] else ...[
                      financialSection(),
                      const SizedBox(height: 12),
                      partySection(),
                    ],
                    const SizedBox(height: 12),
                    workerWageModeSection(),
                    const SizedBox(height: 12),
                    projectAndCostSection(),
                    const SizedBox(height: 12),
                    inventorySection(),
                    const SizedBox(height: 12),
                    descriptionSection(),
                    const SizedBox(height: 18),
                    SizedBox(
                      height: 52,
                      child: FilledButton.icon(
                        onPressed: saving ? null : submit,
                        style: FilledButton.styleFrom(
                          backgroundColor: voucherAccentColor,
                          foregroundColor: Colors.white,
                        ),
                        icon: saving
                            ? const SizedBox(
                                width: 18,
                                height: 18,
                                child:
                                    CircularProgressIndicator(strokeWidth: 2),
                              )
                            : Icon(isReceiptVoucher
                                ? Icons.call_received
                                : isCashTransfer()
                                    ? Icons.swap_horiz
                                    : Icons.call_made),
                        label: Text(
                          saving ? 'جاري الحفظ...' : submitLabel(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
      ),
    );
  }
}
