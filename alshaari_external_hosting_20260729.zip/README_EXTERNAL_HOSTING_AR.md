﻿# نسخة الاستضافة الخارجية - نظام الشعري المالي والتشغيلي

هذه نسخة نظيفة مخصصة للاستضافة الخارجية ولا تؤثر على النسخة المحلية.

## محتويات الحزمة

- `backend/`: FastAPI API جاهز للاستضافة.
- `mobile/`: Flutter source لبناء Web أو APK برابط API خارجي.
- `render.yaml`: قالب Render بدون أسرار.
- `docs/`: أدلة Supabase والتصفية والتوصية.
- `build_external_app.ps1`: سكربت بناء Web/APK بعد معرفة رابط السيرفر الخارجي.

## ما تم استبعاده عمدًا

- `.env`
- قاعدة SQLite المحلية `alshaari.db`
- `backend/venv`
- `mobile/build`
- `.dart_tool`
- logs
- backups
- dist القديمة
- keystore/key.properties

## الخطوات لجعل التطبيق يعمل من أي جهاز

### 1. إنشاء قاعدة Supabase

أنشئ مشروع Supabase وخذ رابط PostgreSQL Pooler بصيغة SQLAlchemy:

```text
postgresql+psycopg://postgres.PROJECT_REF:PASSWORD@aws-0-REGION.pooler.supabase.com:6543/postgres?sslmode=require
```

### 2. نشر Backend على Render

استخدم إعدادات:

```text
Root Directory: backend
Build Command: pip install -r requirements.txt
Start Command: uvicorn app.main:app --host 0.0.0.0 --port $PORT
Health Check Path: /health
```

متغيرات البيئة في Render:

```text
APP_ENV=production
DATABASE_URL=<Supabase DATABASE_URL>
SECRET_KEY=<strong random secret>
ACCESS_TOKEN_EXPIRE_MINUTES=1440
ALLOWED_ORIGINS=https://YOUR_RENDER_SERVICE.onrender.com
ALLOWED_ORIGIN_REGEX=
DB_DISABLE_PREPARED_STATEMENTS=true
DB_POOL_SIZE=5
DB_MAX_OVERFLOW=10
DB_POOL_RECYCLE_SECONDS=1800
```

### 3. اختبار السيرفر

افتح:

```text
https://YOUR_RENDER_SERVICE.onrender.com/health
https://YOUR_RENDER_SERVICE.onrender.com/ready
```

### 4. إنشاء مدير أول

من Shell آمن في Render أو جهازك مع متغير `DATABASE_URL`:

```powershell
$env:INITIAL_ADMIN_NAME="اسم المدير"
$env:INITIAL_ADMIN_PHONE="رقم الهاتف"
$env:INITIAL_ADMIN_PASSWORD="كلمة مرور قوية"
python backend/scripts/create_initial_admin.py
```

لا تستخدم كلمة المرور التجريبية في الاستضافة الخارجية.

### 5. بناء التطبيق برابط السيرفر

من داخل هذه الحزمة:

```powershell
.\build_external_app.ps1 -ApiBaseUrl "https://YOUR_RENDER_SERVICE.onrender.com"
```

لبناء APK أيضًا:

```powershell
.\build_external_app.ps1 -ApiBaseUrl "https://YOUR_RENDER_SERVICE.onrender.com" -BuildApk
```

### 6. فتح التطبيق من أي جهاز

- للويب: ارفع محتوى `mobile/build/web` إلى استضافة Static.
- للجوال: ثبت APK الناتج.
- يجب أن يكون `API_BASE_URL` هو رابط Render الخارجي وليس localhost.

## تنبيه مهم

هذه نسخة استضافة تجريبية. لا تستخدمها كإنتاج مالي حقيقي قبل تفعيل النسخ الاحتياطي، حماية `/docs`، وضبط صلاحيات المستخدمين، ومراجعة خطة قاعدة البيانات.
