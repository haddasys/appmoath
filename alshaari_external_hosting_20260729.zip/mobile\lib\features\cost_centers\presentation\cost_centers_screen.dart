import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/widgets/alshaari_ui.dart';

class CostCentersScreen extends StatefulWidget {
  const CostCentersScreen({super.key});

  @override
  State<CostCentersScreen> createState() => _CostCentersScreenState();
}

class _CostCentersScreenState extends State<CostCentersScreen> {
  bool loading = true;
  String? error;
  String typeFilter = 'all';
  List<dynamic> costCenters = [];

  final filters = const [
    {'value': 'all', 'label': 'الكل'},
    {'value': 'production', 'label': 'إنتاجي'},
    {'value': 'admin', 'label': 'إداري'},
    {'value': 'project', 'label': 'مشروع'},
  ];

  @override
  void initState() {
    super.initState();
    loadCostCenters();
  }

  Future<void> loadCostCenters() async {
    setState(() {
      loading = true;
      error = null;
    });

    try {
      await apiClient.loadToken();
      final res = await apiClient.dio.get('/cost-centers');
      if (!mounted) return;
      setState(() {
        costCenters = (res.data as List?) ?? [];
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = friendlyError(e);
        loading = false;
      });
    }
  }

  String friendlyError(Object e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (e.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم. تأكد أن خدمة النظام تعمل.';
      }
    }
    return 'حدث خطأ أثناء تحميل مراكز التكلفة.';
  }

  List<dynamic> visibleCostCenters() {
    if (typeFilter == 'all') return costCenters;
    return costCenters.where((raw) {
      final row = Map<String, dynamic>.from(raw as Map);
      return '${row['type'] ?? ''}' == typeFilter;
    }).toList();
  }

  String typeLabel(String? type) {
    switch (type) {
      case 'production':
        return 'إنتاجي';
      case 'admin':
        return 'إداري';
      case 'project':
        return 'مشروع';
      default:
        return type ?? '-';
    }
  }

  Color typeColor(String? type) {
    switch (type) {
      case 'production':
        return AlshaariColors.deepGreen;
      case 'admin':
        return AlshaariColors.copper;
      case 'project':
        return AlshaariColors.gold;
      default:
        return AlshaariColors.slate;
    }
  }

  Widget filterBar() {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: filters.map((item) {
        final selected = typeFilter == item['value'];
        return FilterChip(
          selected: selected,
          label: Text(item['label']!),
          onSelected: (_) => setState(() => typeFilter = item['value']!),
          selectedColor: AlshaariColors.copper.withOpacity(.14),
          checkmarkColor: AlshaariColors.copper,
        );
      }).toList(),
    );
  }

  Widget costCenterCard(Map<String, dynamic> row) {
    final active = row['is_active'] != false;
    final color = typeColor(row['type']?.toString());

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: color.withOpacity(.12),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.account_tree_outlined, color: color),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${row['code'] ?? ''}',
                        style: const TextStyle(
                          fontWeight: FontWeight.w900,
                          color: AlshaariColors.ink,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        '${row['name'] ?? ''}',
                        style: const TextStyle(color: AlshaariColors.slate),
                      ),
                    ],
                  ),
                ),
                Chip(
                  label: Text(active ? 'نشط' : 'موقوف'),
                  backgroundColor:
                      (active ? AlshaariColors.success : AlshaariColors.danger)
                          .withOpacity(.12),
                  labelStyle: TextStyle(
                    color:
                        active ? AlshaariColors.success : AlshaariColors.danger,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
            const Divider(height: 22),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(
                  label: Text('النوع: ${typeLabel(row['type']?.toString())}'),
                  backgroundColor: color.withOpacity(.10),
                  labelStyle: TextStyle(color: color),
                ),
                if (row['project_id'] != null)
                  Chip(label: Text('المشروع: ${row['project_id']}')),
                if (row['is_postable'] != null)
                  Chip(
                    label: Text(row['is_postable'] == false
                        ? 'تجميعي'
                        : 'قابل للترحيل'),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget emptyState() {
    return const AlshaariEmptyState(
      title: 'لا توجد مراكز تكلفة مطابقة للفلتر الحالي',
      subtitle: 'جرّب فلترًا آخر أو أضف مركز تكلفة من البيانات الأساسية.',
      icon: Icons.account_tree_outlined,
    );
  }

  Widget errorState() {
    return AlshaariErrorState(
      message: error ?? 'تعذر تحميل مراكز التكلفة',
      onRetry: loadCostCenters,
    );
  }

  @override
  Widget build(BuildContext context) {
    final visible = visibleCostCenters();

    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('مراكز التكلفة'),
            ],
          ),
          actions: [
            IconButton(
                onPressed: loadCostCenters, icon: const Icon(Icons.refresh)),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل مراكز التكلفة...')
            : error != null
                ? errorState()
                : RefreshIndicator(
                    onRefresh: loadCostCenters,
                    child: ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        AlshaariSectionCard(
                          title: 'تصنيف وتحميل التكاليف',
                          subtitle:
                              'استخدم مراكز التكلفة لفصل تكاليف الإنتاج والإدارة والمشاريع قبل اعتماد المستندات.',
                          icon: Icons.account_tree_outlined,
                          child: filterBar(),
                        ),
                        const SizedBox(height: 8),
                        if (visible.isEmpty)
                          emptyState()
                        else
                          ...visible.map((raw) {
                            final row = Map<String, dynamic>.from(raw as Map);
                            return costCenterCard(row);
                          }),
                      ],
                    ),
                  ),
      ),
    );
  }
}
