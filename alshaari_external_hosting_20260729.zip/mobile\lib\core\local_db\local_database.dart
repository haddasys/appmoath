import 'dart:convert';
import 'dart:math';

import 'package:shared_preferences/shared_preferences.dart';

import '../offline_queue/sync_queue_item.dart';
import 'local_entities.dart';
import 'local_record.dart';

class LocalDatabase {
  static const _recordsKey = 'alshaari_local_records';
  static const _queueKey = 'alshaari_sync_queue';
  static const _transactionsKey = 'alshaari_local_transactions';
  static const _attendanceKey = 'alshaari_local_attendance';
  static const _attachmentsKey = 'alshaari_local_attachments';
  static const _masterDataKey = 'alshaari_local_master_data';

  Future<List<LocalRecord>> localRecords() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_recordsKey);
    if (raw == null || raw.isEmpty) return [];
    final rows = jsonDecode(raw) as List;
    return rows
        .map((item) => LocalRecord.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  Future<List<SyncQueueItem>> syncQueue() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_queueKey);
    if (raw == null || raw.isEmpty) return [];
    final rows = jsonDecode(raw) as List;
    return rows
        .map((item) => SyncQueueItem.fromJson(Map<String, dynamic>.from(item)))
        .toList();
  }

  Future<List<LocalTransactionDraft>> localTransactions() async {
    final rows = await _readJsonList(_transactionsKey);
    return rows.map(LocalTransactionDraft.fromJson).toList();
  }

  Future<List<LocalAttendanceDraft>> localAttendance() async {
    final rows = await _readJsonList(_attendanceKey);
    return rows.map(LocalAttendanceDraft.fromJson).toList();
  }

  Future<List<LocalAttachmentDraft>> localAttachments() async {
    final rows = await _readJsonList(_attachmentsKey);
    return rows.map(LocalAttachmentDraft.fromJson).toList();
  }

  Future<List<LocalMasterDataRecord>> localMasterData({
    String? entityType,
  }) async {
    final rows = await _readJsonList(_masterDataKey);
    final data = rows.map(LocalMasterDataRecord.fromJson);
    if (entityType == null) return data.toList();
    return data.where((item) => item.entityType == entityType).toList();
  }

  Future<List<SyncQueueItem>> pendingQueue() async {
    final rows = await syncQueue();
    return rows
        .where(
          (item) =>
              item.status == 'pending' ||
              item.status == 'failed' ||
              item.status == 'syncing',
        )
        .toList();
  }

  Future<LocalRecord?> findLocalRecord(String localUuid) async {
    final rows = await localRecords();
    for (final row in rows) {
      if (row.localUuid == localUuid) return row;
    }
    return null;
  }

  Future<void> upsertLocalRecord(LocalRecord record) async {
    final rows = await localRecords();
    final index = rows.indexWhere((item) => item.localUuid == record.localUuid);
    if (index >= 0) {
      rows[index] = record;
    } else {
      rows.add(record);
    }
    await _saveRecords(rows);
  }

  Future<void> upsertQueueItem(SyncQueueItem item) async {
    final rows = await syncQueue();
    final index = rows.indexWhere((row) => row.id == item.id);
    if (index >= 0) {
      rows[index] = item;
    } else {
      rows.add(item);
    }
    await _saveQueue(rows);
  }

  Future<void> upsertLocalTransaction(LocalTransactionDraft record) async {
    final rows = await localTransactions();
    final index = rows.indexWhere((item) => item.localUuid == record.localUuid);
    if (index >= 0) {
      rows[index] = record;
    } else {
      rows.add(record);
    }
    await _saveJsonList(
      _transactionsKey,
      rows.map((item) => item.toJson()).toList(),
    );
  }

  Future<void> upsertLocalAttendance(LocalAttendanceDraft record) async {
    final rows = await localAttendance();
    final index = rows.indexWhere((item) => item.localUuid == record.localUuid);
    if (index >= 0) {
      rows[index] = record;
    } else {
      rows.add(record);
    }
    await _saveJsonList(
      _attendanceKey,
      rows.map((item) => item.toJson()).toList(),
    );
  }

  Future<void> upsertLocalAttachment(LocalAttachmentDraft record) async {
    final rows = await localAttachments();
    final index = rows.indexWhere((item) => item.localUuid == record.localUuid);
    if (index >= 0) {
      rows[index] = record;
    } else {
      rows.add(record);
    }
    await _saveJsonList(
      _attachmentsKey,
      rows.map((item) => item.toJson()).toList(),
    );
  }

  Future<void> upsertLocalMasterData(LocalMasterDataRecord record) async {
    final rows = await localMasterData();
    final index = rows.indexWhere(
      (item) =>
          item.entityType == record.entityType &&
          item.serverId == record.serverId,
    );
    if (index >= 0) {
      rows[index] = record;
    } else {
      rows.add(record);
    }
    await _saveJsonList(
      _masterDataKey,
      rows.map((item) => item.toJson()).toList(),
    );
  }

  Future<String> nextTemporaryNo(String documentType, String prefix) async {
    final year = DateTime.now().year;
    final prefs = await SharedPreferences.getInstance();
    final key = 'alshaari_local_seq_${documentType}_$year';
    final next = (prefs.getInt(key) ?? 0) + 1;
    await prefs.setInt(key, next);
    final normalizedPrefix = prefix.startsWith('LOCAL-')
        ? prefix.substring('LOCAL-'.length)
        : prefix;
    return 'LOCAL-$normalizedPrefix-$year-${next.toString().padLeft(4, '0')}';
  }

  String newLocalUuid(String entityType) {
    final random = _safeRandomHex();
    return '$entityType-${DateTime.now().microsecondsSinceEpoch}-$random';
  }

  Future<void> _saveRecords(List<LocalRecord> rows) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _recordsKey,
      jsonEncode(rows.map((item) => item.toJson()).toList()),
    );
  }

  Future<void> _saveQueue(List<SyncQueueItem> rows) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(
      _queueKey,
      jsonEncode(rows.map((item) => item.toJson()).toList()),
    );
  }

  Future<List<Map<String, dynamic>>> _readJsonList(String key) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(key);
    if (raw == null || raw.isEmpty) return [];
    final rows = jsonDecode(raw) as List;
    return rows.map((item) => Map<String, dynamic>.from(item as Map)).toList();
  }

  Future<void> _saveJsonList(
    String key,
    List<Map<String, dynamic>> rows,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(key, jsonEncode(rows));
  }
}

String _safeRandomHex() {
  final random = Random.secure();
  final high = random.nextInt(0x10000).toRadixString(16).padLeft(4, '0');
  final low = random.nextInt(0x10000).toRadixString(16).padLeft(4, '0');
  return '$high$low';
}

final localDatabase = LocalDatabase();
