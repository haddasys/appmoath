import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../../app/theme.dart';
import '../../../../core/network/api_client.dart';
import '../../../../core/permissions.dart';
import '../../../../core/widgets/alshaari_ui.dart';

class _SupplierInvoiceDraftLine {
  _SupplierInvoiceDraftLine({this.itemId}) {
    qty.text = '1';
    unitPrice.text = '0';
  }

  int? itemId;
  int? projectId;
  int? costCenterId;
  final qty = TextEditingController();
  final unitPrice = TextEditingController();
  final description = TextEditingController();

  double get total {
    return (double.tryParse(qty.text) ?? 0) *
        (double.tryParse(unitPrice.text) ?? 0);
  }

  void dispose() {
    qty.dispose();
    unitPrice.dispose();
    description.dispose();
  }
}

class PurchaseCycleScreen extends StatefulWidget {
  const PurchaseCycleScreen({super.key});

  @override
  State<PurchaseCycleScreen> createState() => _PurchaseCycleScreenState();
}

class _PurchaseCycleScreenState extends State<PurchaseCycleScreen> {
  bool loading = true;
  String? error;

  List<dynamic> requests = [];
  List<dynamic> orders = [];
  List<dynamic> receipts = [];
  List<dynamic> invoices = [];
  List<dynamic> payments = [];
  List<dynamic> suppliers = [];
  List<dynamic> items = [];
  List<dynamic> projects = [];
  List<dynamic> costCenters = [];
  Set<String> permissions = {};

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      await apiClient.loadToken();
      final loadedPermissions = await AlshaariPermissions.currentPermissions();
      final result = await Future.wait([
        apiClient.dio.get('/purchase-requests'),
        apiClient.dio.get('/purchase-orders'),
        apiClient.dio.get('/goods-receipts'),
        apiClient.dio.get('/supplier-invoices'),
        apiClient.dio.get('/supplier-payments'),
        apiClient.dio.get('/suppliers'),
        apiClient.dio.get('/items'),
        apiClient.dio.get('/projects'),
        apiClient.dio.get('/cost-centers'),
      ]);
      if (!mounted) return;
      setState(() {
        requests = asList(result[0].data);
        orders = asList(result[1].data);
        receipts = asList(result[2].data);
        invoices = asList(result[3].data);
        payments = asList(result[4].data);
        suppliers = asList(result[5].data);
        items = asList(result[6].data);
        projects = asList(result[7].data);
        costCenters = asList(result[8].data);
        permissions = loadedPermissions;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = arabicError(e);
        loading = false;
      });
    }
  }

  List<dynamic> asList(dynamic data) => data is List ? data : <dynamic>[];

  bool can(String permission) {
    return AlshaariPermissions.hasPermission(permissions, permission);
  }

  String arabicError(Object e) {
    if (e is DioException) {
      final data = e.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
    }
    return 'تعذر الاتصال بالخادم. تحقق من تشغيل الباكند ثم أعد المحاولة.';
  }

  String money(dynamic value) =>
      '${double.tryParse('${value ?? 0}')?.toStringAsFixed(2) ?? '0.00'} YER';

  String textValue(Map<String, dynamic> row, List<String> keys,
      [String fallback = '-']) {
    for (final key in keys) {
      final value = row[key];
      if (value != null && '$value'.trim().isNotEmpty) return '$value';
    }
    return fallback;
  }

  String nameById(List<dynamic> list, dynamic id) {
    for (final raw in list) {
      final row = Map<String, dynamic>.from(raw as Map);
      if ('${row['id']}' == '$id') return '${row['name'] ?? row['code'] ?? id}';
    }
    return id == null ? '-' : '$id';
  }

  String statusLabel(String? status) {
    switch (status) {
      case 'submitted':
        return 'مرسل';
      case 'approved':
        return 'معتمد';
      case 'issued':
        return 'مصدر';
      case 'partially_received':
        return 'مستلم جزئيا';
      case 'received':
        return 'مستلم';
      case 'partially_paid':
        return 'مدفوع جزئيا';
      case 'paid':
        return 'مدفوع';
      case 'rejected':
        return 'مرفوض';
      case 'cancelled':
        return 'ملغي';
      case 'closed':
        return 'مغلق';
      default:
        return 'مسودة';
    }
  }

  Color statusColor(String? status) {
    switch (status) {
      case 'approved':
      case 'issued':
      case 'received':
      case 'paid':
      case 'closed':
        return AlshaariColors.success;
      case 'rejected':
      case 'cancelled':
        return AlshaariColors.danger;
      default:
        return AlshaariColors.warning;
    }
  }

  void snack(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> postAction(String path, String success) async {
    try {
      await apiClient.dio.post(path);
      snack(success);
      await load();
    } catch (e) {
      snack(arabicError(e));
    }
  }

  Future<bool> confirm(String title, String message) {
    return showAlshaariConfirmDialog(
      context: context,
      title: title,
      message: message,
      confirmLabel: 'تأكيد',
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: DefaultTabController(
        length: 6,
        child: Scaffold(
          backgroundColor: AlshaariColors.pearl,
          appBar: AppBar(
            backgroundColor: AlshaariColors.matteBlack,
            foregroundColor: Colors.white,
            title: const Text('دورة المشتريات'),
            actions: [
              IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
            ],
            bottom: const TabBar(
              isScrollable: true,
              labelColor: AlshaariColors.copper,
              unselectedLabelColor: Color(0xFFE8DDC8),
              indicatorColor: AlshaariColors.copper,
              tabs: [
                Tab(text: 'طلبات الشراء'),
                Tab(text: 'أوامر الشراء'),
                Tab(text: 'استلام المواد'),
                Tab(text: 'فواتير الموردين'),
                Tab(text: 'دفعات الموردين'),
                Tab(text: 'كشف المورد'),
              ],
            ),
          ),
          body: loading
              ? const AlshaariLoading(label: 'تحميل دورة المشتريات')
              : error != null
                  ? AlshaariErrorState(message: error!, onRetry: load)
                  : RefreshIndicator(
                      onRefresh: load,
                      child: TabBarView(
                        children: [
                          tabContent(
                            title: 'طلبات الشراء',
                            subtitle:
                                'طلب داخلي لا يؤثر على الحسابات أو المخزون',
                            icon: Icons.assignment_outlined,
                            actionLabel: 'طلب شراء',
                            onAdd: showPurchaseRequestDialog,
                            children: requests.map(requestCard).toList(),
                            emptyTitle: 'لم يتم إنشاء طلبات شراء بعد',
                            emptySubtitle:
                                'ابدأ الدورة من طلب شراء داخلي. هذه المرحلة لا تنشئ قيدا ولا تؤثر على المخزون.',
                          ),
                          tabContent(
                            title: 'أوامر الشراء',
                            subtitle:
                                'التزام إداري تجاه المورد ولا ينشئ قيدا محاسبيا',
                            icon: Icons.description_outlined,
                            actionLabel: 'أمر شراء',
                            onAdd: showPurchaseOrderDialog,
                            children: orders.map(orderCard).toList(),
                            emptyTitle: 'لا توجد أوامر شراء',
                            emptySubtitle:
                                'اعتمد طلب شراء ثم حوّله إلى أمر شراء، أو أنشئ أمر شراء مباشر لمورد معتمد.',
                          ),
                          tabContent(
                            title: 'استلام المواد',
                            subtitle: 'يزيد المخزون ويثبت GRNI عند الاعتماد',
                            icon: Icons.inventory_2_outlined,
                            actionLabel: 'سند استلام',
                            onAdd: showGoodsReceiptDialog,
                            children: receipts.map(receiptCard).toList(),
                            emptyTitle: 'لا توجد سندات استلام مواد',
                            emptySubtitle:
                                'بعد اعتماد أمر الشراء يمكنك تسجيل وصول المواد إلى المخزن أو الورشة.',
                          ),
                          tabContent(
                            title: 'فواتير الموردين',
                            subtitle:
                                'تثبت الاستحقاق على المورد ولا تنقص الصندوق',
                            icon: Icons.receipt_long_outlined,
                            actionLabel: 'فاتورة مورد',
                            onAdd: showSupplierInvoiceDialog,
                            children: invoices.map(invoiceCard).toList(),
                            emptyTitle: 'لا توجد فواتير موردين',
                            emptySubtitle:
                                'فاتورة المورد تثبت الاستحقاق ولا تعني الدفع. اربطها بسند الاستلام عند شراء مواد.',
                          ),
                          tabContent(
                            title: 'دفعات الموردين',
                            subtitle:
                                'تسدد الالتزام ولا تسجل شراء أو مخزون مرة أخرى',
                            icon: Icons.payments_outlined,
                            actionLabel: 'دفعة مورد',
                            onAdd: showSupplierPaymentDialog,
                            children: payments.map(paymentCard).toList(),
                            emptyTitle: 'لا توجد دفعات موردين',
                            emptySubtitle:
                                'الدفع يسدد فاتورة معتمدة أو يسجل دفعة مقدمة، ولا يزيد المخزون مرة أخرى.',
                          ),
                          supplierStatementTab(),
                        ],
                      ),
                    ),
        ),
      ),
    );
  }

  Widget tabContent({
    required String title,
    required String subtitle,
    required IconData icon,
    required String actionLabel,
    required VoidCallback onAdd,
    required List<Widget> children,
    String emptyTitle = 'لا توجد مستندات حاليا',
    String? emptySubtitle,
  }) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        purchaseHeader(
          title: title,
          subtitle: subtitle,
          icon: icon,
          trailing: FilledButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.add),
            label: Text(actionLabel),
          ),
        ),
        const SizedBox(height: 12),
        if (children.isEmpty)
          purchaseEmptyState(
            title: emptyTitle,
            subtitle:
                emptySubtitle ?? 'ابدأ بإنشاء $actionLabel من الزر العلوي.',
            actionLabel: actionLabel,
            onAdd: onAdd,
          )
        else
          ...children,
      ],
    );
  }

  Widget purchaseEmptyState({
    required String title,
    required String subtitle,
    required String actionLabel,
    required VoidCallback onAdd,
  }) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AlshaariColors.border),
      ),
      child: Column(
        children: [
          Container(
            width: 58,
            height: 58,
            decoration: BoxDecoration(
              color: AlshaariColors.copper.withOpacity(.12),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Icon(Icons.shopping_cart_checkout,
                color: AlshaariColors.copper, size: 30),
          ),
          const SizedBox(height: 12),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17),
          ),
          const SizedBox(height: 6),
          Text(
            subtitle,
            textAlign: TextAlign.center,
            style: const TextStyle(
                color: AlshaariColors.slate, fontWeight: FontWeight.w600),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: onAdd,
            icon: const Icon(Icons.add),
            label: Text(actionLabel),
          ),
        ],
      ),
    );
  }

  Widget purchaseHeader({
    required String title,
    required String subtitle,
    required IconData icon,
    Widget? trailing,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AlshaariColors.border),
        boxShadow: [
          BoxShadow(
            color: AlshaariColors.matteBlack.withOpacity(.06),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: AlshaariColors.copper.withOpacity(.12),
              borderRadius: BorderRadius.circular(14),
            ),
            child: Icon(icon, color: AlshaariColors.copper),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        color: AlshaariColors.matteBlack,
                        fontWeight: FontWeight.w900,
                      ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: AlshaariColors.slate,
                        fontWeight: FontWeight.w600,
                      ),
                ),
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            trailing,
          ],
        ],
      ),
    );
  }

  Widget statusBadge(Map<String, dynamic> row) {
    final status = '${row['status'] ?? 'draft'}';
    return AlshaariStatusBadge(
      label: statusLabel(status),
      color: statusColor(status),
    );
  }

  Widget detail(String label, dynamic value) {
    return Padding(
      padding: const EdgeInsets.only(top: 6),
      child: Row(
        children: [
          Text('$label: ', style: const TextStyle(fontWeight: FontWeight.w800)),
          Expanded(
              child: Text('${value ?? '-'}', overflow: TextOverflow.ellipsis)),
        ],
      ),
    );
  }

  Widget documentCard({
    required String title,
    required String subtitle,
    required Map<String, dynamic> row,
    required List<Widget> details,
    List<Widget> actions = const [],
  }) {
    return AlshaariSectionCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(title,
                        style: const TextStyle(
                            fontWeight: FontWeight.w900, fontSize: 16)),
                    const SizedBox(height: 4),
                    Text(subtitle,
                        style: const TextStyle(color: AlshaariColors.slate)),
                  ],
                ),
              ),
              statusBadge(row),
            ],
          ),
          const Divider(height: 20),
          ...details,
          if (actions.isNotEmpty) ...[
            const SizedBox(height: 12),
            Wrap(spacing: 8, runSpacing: 8, children: actions),
          ],
        ],
      ),
    );
  }

  Widget requestCard(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    return documentCard(
      title: '${row['request_no'] ?? ''}',
      subtitle: textValue(row, ['description'], 'طلب شراء'),
      row: row,
      details: [
        detail('النوع', row['request_type']),
        detail('الأولوية', row['priority']),
        detail('المشروع', nameById(projects, row['project_id'])),
        detail('التكلفة التقديرية', money(row['estimated_total'])),
      ],
      actions: [
        if ((row['status'] == 'submitted' || row['status'] == 'draft') &&
            can('transactions.approve'))
          OutlinedButton.icon(
            onPressed: () async {
              if (await confirm('اعتماد طلب الشراء',
                  'طلب الشراء لا ينشئ قيدا ولا يؤثر على المخزون.')) {
                await postAction('/purchase-requests/${row['id']}/approve',
                    'تم اعتماد طلب الشراء');
              }
            },
            icon: const Icon(Icons.verified_outlined),
            label: const Text('اعتماد'),
          ),
        if (row['status'] == 'approved' && can('purchases.write'))
          FilledButton.icon(
            onPressed: () => showPurchaseOrderDialog(request: row),
            icon: const Icon(Icons.turn_right_outlined),
            label: const Text('تحويل لأمر شراء'),
          ),
      ],
    );
  }

  Widget orderCard(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    return documentCard(
      title: '${row['po_no'] ?? ''}',
      subtitle: 'المورد: ${nameById(suppliers, row['supplier_id'])}',
      row: row,
      details: [
        detail('القيمة', money(row['total'])),
        detail('المشروع', nameById(projects, row['project_id'])),
        detail('تاريخ التسليم المتوقع', row['expected_delivery_date']),
      ],
      actions: [
        if (row['status'] == 'draft' && can('transactions.approve'))
          OutlinedButton.icon(
            onPressed: () async {
              if (await confirm('اعتماد أمر الشراء',
                  'أمر الشراء لا ينشئ قيدا محاسبيا ولا يزيد المخزون.')) {
                await postAction('/purchase-orders/${row['id']}/approve',
                    'تم اعتماد أمر الشراء');
              }
            },
            icon: const Icon(Icons.verified_outlined),
            label: const Text('اعتماد'),
          ),
        if ((row['status'] == 'issued' ||
                row['status'] == 'partially_received') &&
            can('inventory.write'))
          FilledButton.icon(
            onPressed: () => showGoodsReceiptDialog(order: row),
            icon: const Icon(Icons.inventory_2_outlined),
            label: const Text('استلام'),
          ),
      ],
    );
  }

  Widget receiptCard(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    return documentCard(
      title: '${row['grn_no'] ?? ''}',
      subtitle: 'المورد: ${nameById(suppliers, row['supplier_id'])}',
      row: row,
      details: [
        detail('أمر الشراء', row['po_id'] ?? '-'),
        detail('التاريخ', row['date']),
        detail('ملاحظات', row['notes']),
      ],
      actions: [
        if (row['status'] == 'draft' && can('transactions.approve'))
          FilledButton.icon(
            onPressed: () async {
              if (await confirm('اعتماد الاستلام',
                  'سيتم تحديث المخزون وإنشاء قيد GRNI إذا كان الاستلام مرتبطا بأمر شراء.')) {
                await postAction('/goods-receipts/${row['id']}/approve',
                    'تم اعتماد سند الاستلام');
              }
            },
            icon: const Icon(Icons.done_all),
            label: const Text('اعتماد الاستلام'),
          ),
        if (row['status'] == 'received' && can('purchases.write'))
          OutlinedButton.icon(
            onPressed: () => showSupplierInvoiceDialog(grn: row),
            icon: const Icon(Icons.receipt_long_outlined),
            label: const Text('فاتورة مرتبطة'),
          ),
      ],
    );
  }

  Widget invoiceCard(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    final match = row['three_way_match'] is Map
        ? Map<String, dynamic>.from(row['three_way_match'] as Map)
        : <String, dynamic>{};
    final warnings = asList(match['warnings']);
    return documentCard(
      title: '${row['internal_invoice_no'] ?? ''}',
      subtitle: 'المورد: ${nameById(suppliers, row['supplier_id'])}',
      row: row,
      details: [
        detail('رقم فاتورة المورد', row['supplier_invoice_no']),
        detail('الصافي', money(row['net_amount'])),
        detail('الرصيد', money(row['open_balance'])),
        detail('المطابقة الثلاثية', match['status'] ?? '-'),
        if (warnings.isNotEmpty)
          Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(
              warnings.join('، '),
              style: const TextStyle(
                  color: AlshaariColors.warning, fontWeight: FontWeight.w800),
            ),
          ),
      ],
      actions: [
        if (row['status'] == 'draft' && can('approve_supplier_invoice'))
          FilledButton.icon(
            onPressed: () async {
              final isInventoryInvoice = row['invoice_type'] == 'inventory';
              final message = isInventoryInvoice
                  ? 'سيتم إدخال أصناف الفاتورة إلى المخزون العام، وتحديث متوسط التكلفة، وإنشاء قيد محاسبي متوازن: مدين مخزون / دائن مورد. لا يوجد أثر نقدي.'
                  : 'سيتم إثبات الاستحقاق على المورد وإنشاء قيد محاسبي متوازن حسب نوع الفاتورة. لا يوجد أثر نقدي.';
              if (await confirm('اعتماد وترحيل فاتورة المورد', message)) {
                await postAction('/supplier-invoices/${row['id']}/approve',
                    'تم اعتماد فاتورة المورد وترحيلها محاسبيًا');
              }
            },
            icon: const Icon(Icons.verified_outlined),
            label: const Text('اعتماد وترحيل'),
          ),
        if ((row['status'] == 'approved' ||
                row['status'] == 'partially_paid') &&
            can('purchases.write'))
          OutlinedButton.icon(
            onPressed: () => showSupplierPaymentDialog(invoice: row),
            icon: const Icon(Icons.payments_outlined),
            label: const Text('دفع'),
          ),
      ],
    );
  }

  Widget paymentCard(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    return documentCard(
      title: '${row['payment_no'] ?? ''}',
      subtitle: 'المورد: ${nameById(suppliers, row['supplier_id'])}',
      row: row,
      details: [
        detail('المبلغ', money(row['amount'])),
        detail('طريقة الدفع', row['payment_method']),
        detail('الفاتورة', row['invoice_id'] ?? 'دفعة مقدمة'),
      ],
      actions: [
        if (row['status'] == 'draft' && can('approve_supplier_payment'))
          FilledButton.icon(
            onPressed: () async {
              if (await confirm('اعتماد دفعة المورد',
                  'سيتم تخفيض الصندوق أو البنك وسداد التزام المورد، ولن يزيد المخزون.')) {
                await postAction('/supplier-payments/${row['id']}/approve',
                    'تم اعتماد دفعة المورد');
              }
            },
            icon: const Icon(Icons.verified_outlined),
            label: const Text('اعتماد'),
          ),
      ],
    );
  }

  Widget supplierStatementTab() {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        purchaseHeader(
          title: 'كشف المورد',
          subtitle: 'الفواتير والدفعات والرصيد حسب دورة المشتريات الجديدة',
          icon: Icons.account_balance_wallet_outlined,
        ),
        const SizedBox(height: 12),
        ...suppliers.map((raw) {
          final supplier = Map<String, dynamic>.from(raw as Map);
          final supplierInvoices = invoices.where((item) =>
              '${(item as Map)['supplier_id']}' == '${supplier['id']}');
          final supplierPayments = payments.where((item) =>
              '${(item as Map)['supplier_id']}' == '${supplier['id']}');
          final invoiceTotal = supplierInvoices.fold<double>(0, (sum, item) {
            final row = Map<String, dynamic>.from(item as Map);
            return sum + (double.tryParse('${row['net_amount'] ?? 0}') ?? 0);
          });
          final paymentTotal = supplierPayments.fold<double>(0, (sum, item) {
            final row = Map<String, dynamic>.from(item as Map);
            return sum +
                (row['status'] == 'approved'
                    ? (double.tryParse('${row['amount'] ?? 0}') ?? 0)
                    : 0);
          });
          return AlshaariStatCard(
            title: '${supplier['name'] ?? '-'}',
            value: money(invoiceTotal - paymentTotal),
            subtitle:
                'فواتير ${money(invoiceTotal)} | دفعات ${money(paymentTotal)}',
            icon: Icons.local_shipping_outlined,
            color: invoiceTotal - paymentTotal > 0
                ? AlshaariColors.warning
                : AlshaariColors.success,
          );
        }),
      ],
    );
  }

  DropdownMenuItem<int> menuItem(dynamic raw) {
    final row = Map<String, dynamic>.from(raw as Map);
    return DropdownMenuItem<int>(
      value: row['id'] as int,
      child: Text(
          '${row['name'] ?? row['item_name'] ?? row['code'] ?? row['id']}'),
    );
  }

  Future<void> showPurchaseRequestDialog() async {
    final description = TextEditingController();
    final itemName = TextEditingController();
    final qtyCtl = TextEditingController(text: '1');
    final costCtl = TextEditingController(text: '0');
    String requestType = 'materials';
    String priority = 'normal';
    int? itemId;
    int? projectId;
    int? costCenterId;
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('طلب شراء جديد'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                field(description, 'البيان'),
                selectString(
                    'نوع الطلب',
                    requestType,
                    {
                      'materials': 'مواد',
                      'service': 'خدمة',
                      'tools': 'أدوات',
                      'maintenance': 'صيانة',
                      'admin': 'إداري'
                    },
                    (v) => setLocal(() => requestType = v)),
                selectString(
                    'الأولوية',
                    priority,
                    {'normal': 'عادي', 'urgent': 'عاجل', 'critical': 'حرج'},
                    (v) => setLocal(() => priority = v)),
                selectInt('مادة من المخزون', itemId, items,
                    (v) => setLocal(() => itemId = v),
                    optional: true),
                field(itemName, 'اسم المادة أو الخدمة'),
                field(qtyCtl, 'الكمية', number: true),
                field(costCtl, 'التكلفة التقديرية للوحدة', number: true),
                selectInt('المشروع', projectId, projects,
                    (v) => setLocal(() => projectId = v),
                    optional: true),
                selectInt('مركز التكلفة', costCenterId, costCenters,
                    (v) => setLocal(() => costCenterId = v),
                    optional: true),
              ],
            ),
          ),
          actions: dialogActions(() async {
            await apiClient.dio.post('/purchase-requests', data: {
              'date': DateTime.now().toIso8601String().substring(0, 10),
              'description': description.text,
              'request_type': requestType,
              'priority': priority,
              'project_id': projectId,
              'cost_center_id': costCenterId,
              'lines': [
                {
                  'item_id': itemId,
                  'item_name': itemName.text,
                  'qty': double.tryParse(qtyCtl.text) ?? 0,
                  'estimated_unit_cost': double.tryParse(costCtl.text) ?? 0,
                }
              ],
            });
            if (context.mounted) Navigator.pop(context, true);
          }),
        ),
      ),
    );
    if (saved == true) {
      snack('تم حفظ طلب الشراء');
      await load();
    }
  }

  Future<void> showPurchaseOrderDialog({Map<String, dynamic>? request}) async {
    final description = TextEditingController(
        text: request == null ? '' : '${request['description'] ?? ''}');
    final qtyCtl = TextEditingController(text: '1');
    final priceCtl = TextEditingController(text: '0');
    int? supplierId =
        suppliers.isEmpty ? null : (suppliers.first as Map)['id'] as int?;
    int? itemId = items.isEmpty ? null : (items.first as Map)['id'] as int?;
    int? projectId = request?['project_id'] as int?;
    int? costCenterId = request?['cost_center_id'] as int?;
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: Text(
              request == null ? 'أمر شراء جديد' : 'تحويل طلب شراء إلى أمر'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                selectInt('المورد', supplierId, suppliers,
                    (v) => setLocal(() => supplierId = v)),
                selectInt(
                    'المادة', itemId, items, (v) => setLocal(() => itemId = v)),
                field(qtyCtl, 'الكمية المطلوبة', number: true),
                field(priceCtl, 'سعر الوحدة', number: true),
                selectInt('المشروع', projectId, projects,
                    (v) => setLocal(() => projectId = v),
                    optional: true),
                selectInt('مركز التكلفة', costCenterId, costCenters,
                    (v) => setLocal(() => costCenterId = v),
                    optional: true),
                field(description, 'البيان'),
              ],
            ),
          ),
          actions: dialogActions(() async {
            final payload = {
              'supplier_id': supplierId,
              'purchase_request_id': request?['id'],
              'date': DateTime.now().toIso8601String().substring(0, 10),
              'project_id': projectId,
              'cost_center_id': costCenterId,
              'description': description.text,
              'lines': [
                {
                  'item_id': itemId,
                  'qty_ordered': double.tryParse(qtyCtl.text) ?? 0,
                  'unit_price': double.tryParse(priceCtl.text) ?? 0,
                }
              ],
            };
            if (request == null) {
              await apiClient.dio.post('/purchase-orders', data: payload);
            } else {
              await apiClient.dio.post(
                  '/purchase-requests/${request['id']}/convert-to-po',
                  data: payload);
            }
            if (context.mounted) Navigator.pop(context, true);
          }),
        ),
      ),
    );
    if (saved == true) {
      snack('تم حفظ أمر الشراء');
      await load();
    }
  }

  Future<void> showGoodsReceiptDialog({Map<String, dynamic>? order}) async {
    int? poId = order?['id'] as int? ??
        (orders.isEmpty ? null : (orders.first as Map)['id'] as int?);
    int? supplierId = order?['supplier_id'] as int?;
    int? itemId;
    int? poLineId;
    final qtyCtl = TextEditingController(text: '1');
    final notes = TextEditingController();
    void syncOrder() {
      Map<String, dynamic>? po;
      for (final raw in orders) {
        final candidate = Map<String, dynamic>.from(raw as Map);
        if ('${candidate['id']}' == '$poId') {
          po = candidate;
          break;
        }
      }
      supplierId = po?['supplier_id'] as int?;
      final lines = asList(po?['lines']);
      if (lines.isNotEmpty) {
        final line = Map<String, dynamic>.from(lines.first as Map);
        poLineId = line['id'] as int?;
        itemId = line['item_id'] as int?;
      }
    }

    syncOrder();
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('سند استلام مواد'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                selectInt(
                    'أمر الشراء',
                    poId,
                    orders,
                    (v) => setLocal(() {
                          poId = v;
                          syncOrder();
                        })),
                selectInt(
                    'المادة', itemId, items, (v) => setLocal(() => itemId = v)),
                field(qtyCtl, 'الكمية المستلمة', number: true),
                field(notes, 'ملاحظات'),
              ],
            ),
          ),
          actions: dialogActions(() async {
            await apiClient.dio.post('/goods-receipts', data: {
              'po_id': poId,
              'supplier_id': supplierId,
              'date': DateTime.now().toIso8601String().substring(0, 10),
              'notes': notes.text,
              'lines': [
                {
                  'po_line_id': poLineId,
                  'item_id': itemId,
                  'qty_received': double.tryParse(qtyCtl.text) ?? 0,
                }
              ],
            });
            if (context.mounted) Navigator.pop(context, true);
          }),
        ),
      ),
    );
    if (saved == true) {
      snack('تم حفظ سند الاستلام كمسودة');
      await load();
    }
  }

  Future<void> showSupplierInvoiceDialog({Map<String, dynamic>? grn}) async {
    int? supplierId = grn?['supplier_id'] as int? ??
        (suppliers.isEmpty ? null : (suppliers.first as Map)['id'] as int?);
    int? grnId = grn?['id'] as int?;
    int? poId = grn?['po_id'] as int?;
    String invoiceType = 'inventory';
    final supplierNo = TextEditingController();
    final description = TextEditingController();
    String accountCode = invoiceType == 'inventory' ? '10401' : '60301';
    final lines = <_SupplierInvoiceDraftLine>[
      _SupplierInvoiceDraftLine(
          itemId: items.isEmpty ? null : (items.first as Map)['id'] as int?),
    ];
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('فاتورة مورد'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                selectString('نوع الفاتورة', invoiceType, {
                  'inventory': 'مواد مخزون',
                  'project_service': 'خدمة مشروع',
                  'admin_expense': 'مصروف إداري',
                  'asset': 'أصل',
                  'mixed': 'مختلطة'
                }, (v) {
                  setLocal(() {
                    invoiceType = v;
                    accountCode = v == 'inventory'
                        ? '10401'
                        : v == 'project_service'
                            ? '50303'
                            : '60301';
                    if (invoiceType != 'project_service') {
                      for (final line in lines) {
                        line.projectId = null;
                        line.costCenterId = null;
                      }
                    }
                  });
                }),
                selectInt('المورد', supplierId, suppliers,
                    (v) => setLocal(() => supplierId = v)),
                selectInt('سند الاستلام', grnId, receipts,
                    (v) => setLocal(() => grnId = v),
                    optional: true),
                field(supplierNo, 'رقم فاتورة المورد'),
                field(description, 'البيان'),
                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerRight,
                  child: Text('الأصناف',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                          fontWeight: FontWeight.w800,
                          color: AlshaariColors.ink)),
                ),
                const SizedBox(height: 8),
                ...lines.asMap().entries.map((entry) {
                  final index = entry.key;
                  final line = entry.value;
                  return Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: AlshaariColors.pearl,
                      border: Border.all(color: AlshaariColors.border),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Expanded(
                              child: Text('صنف ${index + 1}',
                                  style: const TextStyle(
                                      fontWeight: FontWeight.w800)),
                            ),
                            if (lines.length > 1)
                              IconButton(
                                tooltip: 'حذف السطر',
                                onPressed: () => setLocal(() {
                                  lines.removeAt(index).dispose();
                                }),
                                icon: const Icon(Icons.delete_outline),
                              ),
                          ],
                        ),
                        if (invoiceType == 'inventory')
                          selectInt('الصنف', line.itemId, items,
                              (v) => setLocal(() => line.itemId = v)),
                        if (invoiceType == 'project_service') ...[
                          selectInt('المشروع', line.projectId, projects,
                              (v) => setLocal(() => line.projectId = v)),
                          selectInt(
                              'مركز التكلفة',
                              line.costCenterId,
                              costCenters,
                              (v) => setLocal(() => line.costCenterId = v)),
                        ],
                        field(line.qty, 'الكمية', number: true),
                        field(line.unitPrice, 'سعر الوحدة', number: true),
                        field(line.description, 'بيان السطر'),
                        Align(
                          alignment: Alignment.centerLeft,
                          child: Text(
                            'الإجمالي: ${line.total.toStringAsFixed(2)}',
                            style: const TextStyle(
                                fontWeight: FontWeight.w800,
                                color: AlshaariColors.copper),
                          ),
                        ),
                      ],
                    ),
                  );
                }),
                OutlinedButton.icon(
                  onPressed: () => setLocal(() {
                    lines.add(_SupplierInvoiceDraftLine(
                        itemId: items.isEmpty
                            ? null
                            : (items.first as Map)['id'] as int?));
                  }),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة صنف'),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    'إجمالي الفاتورة: ${lines.fold<double>(0, (sum, line) => sum + line.total).toStringAsFixed(2)}',
                    style: const TextStyle(
                        fontWeight: FontWeight.w900,
                        color: AlshaariColors.matteBlack),
                  ),
                ),
              ],
            ),
          ),
          actions: dialogActions(() async {
            final amount =
                lines.fold<double>(0, (sum, line) => sum + line.total);
            await apiClient.dio.post('/supplier-invoices', data: {
              'supplier_invoice_no': supplierNo.text,
              'supplier_id': supplierId,
              'po_id': poId,
              'grn_id': grnId,
              'invoice_date': DateTime.now().toIso8601String().substring(0, 10),
              'invoice_type': invoiceType,
              'net_amount': amount,
              'description': description.text,
              'lines': lines
                  .map((line) => {
                        'item_id': line.itemId,
                        'description': line.description.text.isEmpty
                            ? (description.text.isEmpty
                                ? 'فاتورة مورد'
                                : description.text)
                            : line.description.text,
                        'qty': double.tryParse(line.qty.text) ?? 0,
                        'unit_price': double.tryParse(line.unitPrice.text) ?? 0,
                        'account_code': accountCode,
                        'project_id': line.projectId,
                        'cost_center_id': line.costCenterId,
                      })
                  .toList(),
            });
            for (final line in lines) {
              line.dispose();
            }
            if (context.mounted) Navigator.pop(context, true);
          }),
        ),
      ),
    );
    if (saved != true) {
      for (final line in lines) {
        line.dispose();
      }
    }
    if (saved == true) {
      snack('تم حفظ فاتورة المورد كمسودة');
      await load();
    }
  }

  Future<void> showSupplierPaymentDialog(
      {Map<String, dynamic>? invoice}) async {
    int? supplierId = invoice?['supplier_id'] as int? ??
        (suppliers.isEmpty ? null : (suppliers.first as Map)['id'] as int?);
    int? invoiceId = invoice?['id'] as int?;
    final amountCtl =
        TextEditingController(text: '${invoice?['open_balance'] ?? ''}');
    final description = TextEditingController();
    String paymentMethod = 'cash';
    final saved = await showDialog<bool>(
      context: context,
      builder: (_) => StatefulBuilder(
        builder: (context, setLocal) => AlertDialog(
          title: const Text('دفعة مورد'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                selectInt('المورد', supplierId, suppliers,
                    (v) => setLocal(() => supplierId = v)),
                selectInt('الفاتورة', invoiceId, invoices,
                    (v) => setLocal(() => invoiceId = v),
                    optional: true),
                field(amountCtl, 'المبلغ', number: true),
                selectString(
                    'طريقة الدفع',
                    paymentMethod,
                    {
                      'cash': 'صندوق',
                      'bank': 'بنك / محفظة',
                      'transfer': 'حوالة'
                    },
                    (v) => setLocal(() => paymentMethod = v)),
                field(description, 'البيان'),
              ],
            ),
          ),
          actions: dialogActions(() async {
            await apiClient.dio.post('/supplier-payments', data: {
              'supplier_id': supplierId,
              'invoice_id': invoiceId,
              'payment_date': DateTime.now().toIso8601String().substring(0, 10),
              'amount': double.tryParse(amountCtl.text) ?? 0,
              'payment_method': paymentMethod,
              'cash_account_code': '10101',
              'description': description.text,
            });
            if (context.mounted) Navigator.pop(context, true);
          }),
        ),
      ),
    );
    if (saved == true) {
      snack('تم حفظ دفعة المورد كمسودة');
      await load();
    }
  }

  List<Widget> dialogActions(Future<void> Function() onSave) => [
        TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('إلغاء')),
        FilledButton(
          onPressed: () async {
            try {
              await onSave();
            } catch (e) {
              snack(arabicError(e));
            }
          },
          child: const Text('حفظ'),
        ),
      ];

  Widget field(TextEditingController controller, String label,
      {bool number = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: controller,
        keyboardType: number ? TextInputType.number : TextInputType.text,
        decoration: InputDecoration(
            labelText: label, border: const OutlineInputBorder()),
      ),
    );
  }

  Widget selectInt(String label, int? value, List<dynamic> source,
      ValueChanged<int?> onChanged,
      {bool optional = false}) {
    final validValue =
        source.any((raw) => (raw as Map)['id'] == value) ? value : null;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DropdownButtonFormField<int>(
        initialValue: validValue,
        decoration: InputDecoration(
            labelText: label, border: const OutlineInputBorder()),
        items: [
          if (optional)
            const DropdownMenuItem<int>(value: null, child: Text('بدون')),
          ...source.map(menuItem),
        ],
        onChanged: onChanged,
      ),
    );
  }

  Widget selectString(String label, String value, Map<String, String> options,
      ValueChanged<String> onChanged) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: DropdownButtonFormField<String>(
        initialValue: value,
        decoration: InputDecoration(
            labelText: label, border: const OutlineInputBorder()),
        items: options.entries
            .map((entry) =>
                DropdownMenuItem(value: entry.key, child: Text(entry.value)))
            .toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      ),
    );
  }
}
