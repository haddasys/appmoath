import 'package:dio/dio.dart';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';

import '../../../core/network/api_client.dart';
import '../../../core/offline_queue/offline_attachment_service.dart';
import '../../../core/widgets/alshaari_settlement_button.dart';
import '../../../core/widgets/alshaari_ui.dart';

class InventoryScreen extends StatefulWidget {
  const InventoryScreen({super.key});

  @override
  State<InventoryScreen> createState() => _InventoryScreenState();
}

class _InventoryScreenState extends State<InventoryScreen> {
  final money = NumberFormat('#,##0.##', 'en_US');

  bool loading = true;
  bool saving = false;
  String search = '';
  Map<String, dynamic> summary = {};
  List<dynamic> items = [];
  List<dynamic> projects = [];
  List<dynamic> suppliers = [];
  List<dynamic> warehouses = [];
  List<dynamic> costCenters = [];

  final categories = const [
    'خشب MDF',
    'أبلاكاش',
    'دهانات',
    'إكسسوارات',
    'زجاج',
    'ألمنيوم',
    'إسفنج',
    'قماش',
    'مستلزمات تركيب',
    'أدوات ومستهلكات',
  ];

  final costCategories = const [
    'materials',
    'wood',
    'paint',
    'accessories',
    'glass',
    'aluminum',
    'installation_supplies',
  ];

  @override
  void initState() {
    super.initState();
    loadData();
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        apiClient.dio.get('/inventory/summary'),
        apiClient.dio.get('/inventory/items'),
        apiClient.dio.get('/projects'),
        apiClient.dio.get('/suppliers'),
        apiClient.dio.get('/warehouses'),
        apiClient.dio.get('/cost-centers'),
      ]);

      if (!mounted) return;
      setState(() {
        summary = Map<String, dynamic>.from(result[0].data as Map);
        items = listFrom(result[1].data);
        projects = listFrom(result[2].data);
        suppliers = listFrom(result[3].data);
        warehouses = listFrom(result[4].data);
        costCenters = listFrom(result[5].data);
      });
    } catch (e) {
      showError(e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  List<dynamic> listFrom(dynamic data) {
    if (data is List) return data;
    if (data is Map && data['items'] is List) {
      return data['items'] as List<dynamic>;
    }
    return [];
  }

  double asDouble(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  String today() => DateTime.now().toIso8601String().substring(0, 10);

  List<Map<String, dynamic>> filteredItems() {
    final q = search.trim().toLowerCase();
    return items
        .map((raw) => Map<String, dynamic>.from(raw as Map))
        .where((item) {
      if (q.isEmpty) return true;
      final text =
          '${item['code']} ${item['name']} ${item['category']}'.toLowerCase();
      return text.contains(q);
    }).toList();
  }

  Color statusColor(String? status) {
    switch (status) {
      case 'out':
        return const Color(0xFFB3261E);
      case 'low':
        return const Color(0xFFB87E62);
      case 'no_cost':
        return const Color(0xFF805600);
      default:
        return const Color(0xFF1B7F4B);
    }
  }

  IconData statusIcon(String? status) {
    switch (status) {
      case 'out':
        return Icons.remove_shopping_cart_outlined;
      case 'low':
        return Icons.warning_amber_rounded;
      case 'no_cost':
        return Icons.price_change_outlined;
      default:
        return Icons.check_circle_outline;
    }
  }

  InputDecoration inputDecoration(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon == null ? null : Icon(icon),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      filled: true,
      fillColor: Colors.white,
    );
  }

  Future<void> saveItem() async {
    final formKey = GlobalKey<FormState>();
    final code = TextEditingController();
    final name = TextEditingController();
    final unit = TextEditingController(text: 'pcs');
    final qty = TextEditingController(text: '0');
    final avgCost = TextEditingController(text: '0');
    final reorder = TextEditingController(text: '0');
    String? category = categories.first;

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          return Directionality(
            textDirection: ui.TextDirection.rtl,
            child: AlertDialog(
              title: const Text('إضافة مادة مخزون'),
              content: SizedBox(
                width: 520,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextFormField(
                          controller: code,
                          decoration: inputDecoration('كود المادة',
                              icon: Icons.qr_code_2),
                          validator: requiredText,
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          controller: name,
                          decoration: inputDecoration('اسم المادة',
                              icon: Icons.inventory_2_outlined),
                          validator: requiredText,
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: category,
                          decoration: inputDecoration('تصنيف المادة',
                              icon: Icons.category_outlined),
                          items: categories
                              .map((value) => DropdownMenuItem(
                                  value: value, child: Text(value)))
                              .toList(),
                          onChanged: (value) =>
                              setLocal(() => category = value),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: unit,
                                decoration: inputDecoration('الوحدة'),
                                validator: requiredText,
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextFormField(
                                controller: reorder,
                                keyboardType: TextInputType.number,
                                decoration: inputDecoration('حد إعادة الطلب'),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: qty,
                                keyboardType: TextInputType.number,
                                decoration: inputDecoration('الرصيد الافتتاحي'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextFormField(
                                controller: avgCost,
                                keyboardType: TextInputType.number,
                                decoration: inputDecoration('متوسط التكلفة'),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء')),
                FilledButton.icon(
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('حفظ المادة'),
                  onPressed: saving
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          await runSave(
                            dialogContext,
                            () => apiClient.dio.post('/items', data: {
                              'code': code.text.trim(),
                              'name': name.text.trim(),
                              'category': category,
                              'unit': unit.text.trim(),
                              'current_qty': asDouble(qty.text),
                              'avg_cost': asDouble(avgCost.text),
                              'reorder_level': asDouble(reorder.text),
                            }),
                            success: 'تمت إضافة المادة',
                          );
                        },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> savePurchase([Map<String, dynamic>? initialItem]) async {
    final formKey = GlobalKey<FormState>();
    int? itemId = initialItem?['id'] as int?;
    int? supplierId;
    String? costCategory = costCategories.first;
    final qty = TextEditingController();
    final unitCost =
        TextEditingController(text: '${initialItem?['avg_cost'] ?? ''}');
    final date = TextEditingController(text: today());
    final description = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          return Directionality(
            textDirection: ui.TextDirection.rtl,
            child: AlertDialog(
              title: const Text('شراء مواد نقدي'),
              content: SizedBox(
                width: 560,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        warningBox(
                            'سيتم حفظ شراء المواد كمسودة. يظهر أثر المخزون والقيد المحاسبي بعد الاعتماد من شاشة مراجعة المستندات.'),
                        const SizedBox(height: 12),
                        itemDropdown(itemId, (value) {
                          setLocal(() {
                            itemId = value;
                            final item = findById(items, value);
                            if (item != null && unitCost.text.trim().isEmpty) {
                              unitCost.text = '${item['avg_cost'] ?? 0}';
                            }
                          });
                        }),
                        const SizedBox(height: 10),
                        supplierDropdown(supplierId,
                            (value) => setLocal(() => supplierId = value)),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(child: numberField(qty, 'الكمية')),
                            const SizedBox(width: 10),
                            Expanded(
                                child: numberField(unitCost, 'تكلفة الوحدة')),
                          ],
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: costCategory,
                          decoration: inputDecoration('بند التكلفة',
                              icon: Icons.account_tree_outlined),
                          items: costCategories
                              .map((value) => DropdownMenuItem(
                                  value: value,
                                  child: Text(labelForCost(value))))
                              .toList(),
                          onChanged: (value) =>
                              setLocal(() => costCategory = value),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                            controller: date,
                            decoration: inputDecoration('التاريخ'),
                            validator: requiredText),
                        const SizedBox(height: 10),
                        TextFormField(
                            controller: description,
                            minLines: 2,
                            maxLines: 3,
                            decoration: inputDecoration('الوصف')),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء')),
                FilledButton.icon(
                  icon: const Icon(Icons.add_shopping_cart_outlined),
                  label: const Text('حفظ كمسودة'),
                  onPressed: saving
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          final amount =
                              asDouble(qty.text) * asDouble(unitCost.text);
                          await runSave(
                            dialogContext,
                            () => apiClient.dio.post('/transactions', data: {
                              'date': date.text.trim(),
                              'type': 'material_purchase',
                              'amount': amount,
                              'currency': 'YER',
                              'payment_method': 'cash',
                              'related_account_type':
                                  supplierId == null ? null : 'supplier',
                              'related_id': supplierId,
                              'item_id': itemId,
                              'qty': asDouble(qty.text),
                              'unit_cost': asDouble(unitCost.text),
                              'cost_category': costCategory,
                              'description': description.text.trim().isEmpty
                                  ? 'شراء مواد للمخزون'
                                  : description.text.trim(),
                            }),
                            success: 'تم حفظ شراء المواد كمسودة',
                          );
                        },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> saveIssue([Map<String, dynamic>? initialItem]) async {
    final formKey = GlobalKey<FormState>();
    int? itemId = initialItem?['id'] as int?;
    int? projectId;
    String? costCategory = 'materials';
    final qty = TextEditingController();
    final unitCost =
        TextEditingController(text: '${initialItem?['avg_cost'] ?? ''}');
    final date = TextEditingController(text: today());
    final description = TextEditingController();

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          final selectedItem = findById(items, itemId);
          final availableQty = asDouble(selectedItem?['current_qty']);
          final averageCost = asDouble(selectedItem?['avg_cost']);
          return Directionality(
            textDirection: ui.TextDirection.rtl,
            child: AlertDialog(
              title: const Text('صرف مواد لمشروع'),
              content: SizedBox(
                width: 560,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        warningBox(
                            'صرف المواد يحمل تكلفة فعلية على المشروع ويخفض المخزون بعد الاعتماد فقط.'),
                        const SizedBox(height: 12),
                        itemDropdown(itemId, (value) {
                          setLocal(() {
                            itemId = value;
                            final item = findById(items, value);
                            unitCost.text = '${item?['avg_cost'] ?? 0}';
                          });
                        }),
                        if (selectedItem != null) ...[
                          const SizedBox(height: 10),
                          warningBox(
                              'المتاح: ${money.format(availableQty)} ${selectedItem['unit'] ?? ''} | متوسط التكلفة: ${money.format(averageCost)} YER'),
                        ],
                        const SizedBox(height: 10),
                        projectDropdown(projectId,
                            (value) => setLocal(() => projectId = value)),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                                child: numberField(qty, 'الكمية المصروفة')),
                            const SizedBox(width: 10),
                            Expanded(
                                child: numberField(unitCost, 'تكلفة الوحدة')),
                          ],
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: costCategory,
                          decoration: inputDecoration('بند تكلفة المشروع',
                              icon: Icons.account_tree_outlined),
                          items: costCategories
                              .map((value) => DropdownMenuItem(
                                  value: value,
                                  child: Text(labelForCost(value))))
                              .toList(),
                          onChanged: (value) =>
                              setLocal(() => costCategory = value),
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                            controller: date,
                            decoration: inputDecoration('التاريخ'),
                            validator: requiredText),
                        const SizedBox(height: 10),
                        TextFormField(
                            controller: description,
                            minLines: 2,
                            maxLines: 3,
                            decoration: inputDecoration('ملاحظات الصرف')),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء')),
                FilledButton.icon(
                  icon: const Icon(Icons.outbox_outlined),
                  label: const Text('حفظ كمسودة'),
                  onPressed: saving
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          final issueQty = asDouble(qty.text);
                          final selectedItem = findById(items, itemId);
                          final availableQty =
                              asDouble(selectedItem?['current_qty']);
                          if (issueQty > availableQty) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    'لا يمكن صرف كمية أكبر من المتاح. المتاح حاليًا: ${money.format(availableQty)}'),
                                backgroundColor: const Color(0xFFB3261E),
                              ),
                            );
                            return;
                          }
                          final amount =
                              asDouble(qty.text) * asDouble(unitCost.text);
                          final confirmed = await showAlshaariConfirmDialog(
                            context: context,
                            title: 'اعتماد صرف مواد لمشروع',
                            message:
                                'سيتم تحميل تكلفة المواد على المشروع بقيمة ${money.format(amount)} YER، مع إنشاء قيد محاسبي عند الاعتماد: مدين تكلفة مواد المشروع / دائن المخزون.',
                            confirmLabel: 'متابعة',
                          );
                          if (!confirmed) return;
                          await runSave(
                            dialogContext,
                            () => apiClient.dio.post('/transactions', data: {
                              'date': date.text.trim(),
                              'type': 'material_issue_to_project',
                              'amount': amount,
                              'currency': 'YER',
                              'project_id': projectId,
                              'item_id': itemId,
                              'qty': asDouble(qty.text),
                              'unit_cost': asDouble(unitCost.text),
                              'cost_category': costCategory,
                              'description': description.text.trim().isEmpty
                                  ? 'صرف مواد على مشروع'
                                  : description.text.trim(),
                            }),
                            success: 'تم حفظ صرف المواد كمسودة',
                          );
                        },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<int?> uploadAttachment(XFile? file, String entity) async {
    if (file == null) return null;
    try {
      final bytes = await file.readAsBytes();
      final formData = FormData.fromMap({
        'file': MultipartFile.fromBytes(bytes, filename: file.name),
      });
      final response = await apiClient.dio.post(
        '/attachments/upload',
        queryParameters: {'entity': entity, 'entity_id': 0},
        data: formData,
        options: Options(contentType: 'multipart/form-data'),
      );
      final data = response.data;
      if (data is Map && data['id'] != null) {
        return int.tryParse('${data['id']}');
      }
    } on DioException catch (error) {
      if (!isConnectionFailure(error)) rethrow;
      final result = await offlineAttachmentService.enqueueUpload(
        file: file,
        entityType: entity,
        entityLocalUuid: 'pending-$entity',
      );
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'تم حفظ المرفق محليًا برقم ${result.temporaryNo} بانتظار المزامنة.',
            ),
          ),
        );
      }
    }
    return null;
  }

  bool isConnectionFailure(Object error) {
    if (error is! DioException) return false;
    return error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout;
  }

  Future<void> saveStandardInventoryMovement(
      [Map<String, dynamic>? initialItem]) async {
    final formKey = GlobalKey<FormState>();
    String movementType = 'purchase_to_general_warehouse';
    String adjustmentType = 'increase';
    int? itemId = initialItem?['id'] as int?;
    int? supplierId;
    int? projectId;
    int? costCenterId;
    int? warehouseId =
        warehouses.isEmpty ? null : (warehouses.first as Map)['id'] as int?;
    XFile? pickedFile;
    final qty = TextEditingController();
    final unitCost =
        TextEditingController(text: '${initialItem?['avg_cost'] ?? ''}');
    final description = TextEditingController();

    bool needsSupplier() =>
        movementType == 'purchase_to_general_warehouse' ||
        movementType == 'direct_purchase_to_project';
    bool needsProject() =>
        movementType == 'reserve_stock_for_project' ||
        movementType == 'issue_stock_to_project' ||
        movementType == 'direct_purchase_to_project';
    bool needsCostCenter() =>
        movementType == 'issue_stock_to_project' ||
        movementType == 'direct_purchase_to_project';
    bool needsUnitCost() =>
        movementType == 'purchase_to_general_warehouse' ||
        movementType == 'direct_purchase_to_project' ||
        movementType == 'inventory_adjustment';
    bool needsInvoiceImage() => movementType == 'direct_purchase_to_project';

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          final selectedItem = findById(items, itemId);
          final availableQty = asDouble(selectedItem?['current_qty']);
          final averageCost = asDouble(selectedItem?['avg_cost']);
          return Directionality(
            textDirection: ui.TextDirection.rtl,
            child: AlertDialog(
              title: const Text('مستند مخزون معياري'),
              content: SizedBox(
                width: 620,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        DropdownButtonFormField<String>(
                          initialValue: movementType,
                          decoration: inputDecoration('نوع إدخال المخزون',
                              icon: Icons.sync_alt),
                          items: const [
                            DropdownMenuItem(
                                value: 'purchase_to_general_warehouse',
                                child: Text('إلى المخزن العام')),
                            DropdownMenuItem(
                                value: 'reserve_stock_for_project',
                                child: Text('مرتبط بمشروع / حجز')),
                            DropdownMenuItem(
                                value: 'direct_purchase_to_project',
                                child: Text('شراء مباشر لمشروع')),
                            DropdownMenuItem(
                                value: 'issue_stock_to_project',
                                child: Text('صرف من المخزن إلى مشروع')),
                            DropdownMenuItem(
                                value: 'inventory_adjustment',
                                child: Text('تسوية مخزون')),
                          ],
                          onChanged: (value) => setLocal(
                              () => movementType = value ?? movementType),
                        ),
                        const SizedBox(height: 10),
                        warningBox(inventoryPolicyMessage(movementType)),
                        const SizedBox(height: 12),
                        if (needsSupplier()) ...[
                          supplierDropdown(supplierId,
                              (value) => setLocal(() => supplierId = value)),
                          const SizedBox(height: 10),
                        ],
                        itemDropdown(itemId, (value) {
                          setLocal(() {
                            itemId = value;
                            final item = findById(items, value);
                            if (item != null) {
                              unitCost.text = '${item['avg_cost'] ?? 0}';
                            }
                          });
                        }),
                        if (movementType == 'issue_stock_to_project' &&
                            selectedItem != null) ...[
                          const SizedBox(height: 10),
                          warningBox(
                              'المتاح: ${money.format(availableQty)} ${selectedItem['unit'] ?? ''} | متوسط التكلفة: ${money.format(averageCost)} YER'),
                        ],
                        const SizedBox(height: 10),
                        if (movementType != 'direct_purchase_to_project') ...[
                          warehouseDropdown(warehouseId,
                              (value) => setLocal(() => warehouseId = value)),
                          const SizedBox(height: 10),
                        ],
                        if (needsProject()) ...[
                          projectDropdown(projectId,
                              (value) => setLocal(() => projectId = value)),
                          const SizedBox(height: 10),
                        ],
                        if (needsCostCenter()) ...[
                          costCenterDropdown(costCenterId,
                              (value) => setLocal(() => costCenterId = value)),
                          const SizedBox(height: 10),
                        ],
                        Row(
                          children: [
                            Expanded(child: numberField(qty, 'الكمية')),
                            if (needsUnitCost()) ...[
                              const SizedBox(width: 10),
                              Expanded(
                                  child: numberField(unitCost, 'تكلفة الوحدة')),
                            ],
                          ],
                        ),
                        const SizedBox(height: 10),
                        if (movementType == 'inventory_adjustment') ...[
                          DropdownButtonFormField<String>(
                            initialValue: adjustmentType,
                            decoration: inputDecoration('نوع التسوية'),
                            items: const [
                              DropdownMenuItem(
                                  value: 'increase', child: Text('زيادة')),
                              DropdownMenuItem(
                                  value: 'decrease', child: Text('نقص')),
                            ],
                            onChanged: (value) => setLocal(
                                () => adjustmentType = value ?? 'increase'),
                          ),
                          const SizedBox(height: 10),
                        ],
                        TextFormField(
                          controller: description,
                          minLines: 2,
                          maxLines: 3,
                          decoration: inputDecoration(
                              movementType == 'inventory_adjustment'
                                  ? 'سبب التسوية'
                                  : 'البيان'),
                          validator: requiredText,
                        ),
                        const SizedBox(height: 10),
                        OutlinedButton.icon(
                          onPressed: () async {
                            final file = await ImagePicker().pickImage(
                                source: ImageSource.gallery, imageQuality: 82);
                            setLocal(() => pickedFile = file);
                          },
                          icon: const Icon(Icons.attach_file),
                          label: Text(pickedFile == null
                              ? (needsInvoiceImage()
                                  ? 'إرفاق صورة الفاتورة - إلزامي'
                                  : 'إرفاق صورة / PDF اختياري')
                              : pickedFile!.name),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('إلغاء')),
                FilledButton.icon(
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('حفظ المستند'),
                  onPressed: saving
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          if (movementType == 'issue_stock_to_project') {
                            final issueQty = asDouble(qty.text);
                            final selectedItem = findById(items, itemId);
                            final availableQty =
                                asDouble(selectedItem?['current_qty']);
                            if (issueQty > availableQty) {
                              ScaffoldMessenger.of(context).showSnackBar(
                                SnackBar(
                                  content: Text(
                                      'لا يمكن صرف كمية أكبر من المتاح. المتاح حاليًا: ${money.format(availableQty)}'),
                                  backgroundColor: const Color(0xFFB3261E),
                                ),
                              );
                              return;
                            }
                            final amount =
                                issueQty * asDouble(selectedItem?['avg_cost']);
                            final confirmed = await showAlshaariConfirmDialog(
                              context: context,
                              title: 'اعتماد صرف مواد لمشروع',
                              message:
                                  'سيتم تخفيض المخزون وتحميل تكلفة مواد على المشروع بقيمة ${money.format(amount)} YER، وإنشاء قيد: مدين تكلفة مواد المشروع / دائن المخزون.',
                              confirmLabel: 'متابعة',
                            );
                            if (!confirmed) return;
                          }
                          if (needsInvoiceImage() && pickedFile == null) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                    'الشراء المباشر لمشروع يتطلب إرفاق صورة الفاتورة'),
                                backgroundColor: Color(0xFFB3261E),
                              ),
                            );
                            return;
                          }
                          final attachmentId = await uploadAttachment(
                              pickedFile, 'inventory_movement');
                          if (!mounted || !dialogContext.mounted) return;
                          final payload = <String, dynamic>{
                            'item_id': itemId,
                            'qty': asDouble(qty.text),
                            'unit_cost': asDouble(unitCost.text),
                            'warehouse_id': warehouseId,
                            'supplier_id': supplierId,
                            'project_id': projectId,
                            'cost_center_id': costCenterId,
                            'attachment_id': attachmentId,
                            'description': description.text.trim(),
                            'reason': description.text.trim(),
                            'adjustment_type': adjustmentType,
                          };
                          payload.removeWhere(
                              (key, value) => value == null || value == '');
                          final endpoint = switch (movementType) {
                            'purchase_to_general_warehouse' =>
                              '/inventory/purchase-to-general',
                            'reserve_stock_for_project' =>
                              '/inventory/reserve-for-project',
                            'issue_stock_to_project' =>
                              '/inventory/issue-to-project',
                            'direct_purchase_to_project' =>
                              '/inventory/direct-purchase-to-project',
                            _ => '/inventory/adjustment',
                          };
                          await runSave(
                            dialogContext,
                            () => apiClient.dio.post(endpoint, data: payload),
                            success: 'تم حفظ مستند المخزون',
                          );
                        },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Future<void> showMovements(Map<String, dynamic> item) async {
    try {
      final response =
          await apiClient.dio.get('/inventory/items/${item['id']}/movements');
      final movementRows = listFrom(response.data);
      if (!mounted) return;

      showModalBottomSheet(
        context: context,
        isScrollControlled: true,
        showDragHandle: true,
        builder: (_) => Directionality(
          textDirection: ui.TextDirection.rtl,
          child: SizedBox(
            height: MediaQuery.of(context).size.height * .72,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('حركة المادة: ${item['name']}',
                      style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 12),
                  Expanded(
                    child: movementRows.isEmpty
                        ? emptyState(
                            'لا توجد حركات معتمدة لهذه المادة حتى الآن.')
                        : ListView.separated(
                            itemCount: movementRows.length,
                            separatorBuilder: (_, __) =>
                                const Divider(height: 1),
                            itemBuilder: (_, index) {
                              final row = Map<String, dynamic>.from(
                                  movementRows[index] as Map);
                              final isOut =
                                  '${row['movement_type']}'.contains('out');
                              return ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: (isOut
                                          ? const Color(0xFFB3261E)
                                          : const Color(0xFF1B7F4B))
                                      .withOpacity(.12),
                                  child: Icon(
                                      isOut
                                          ? Icons.call_made
                                          : Icons.call_received,
                                      color: isOut
                                          ? const Color(0xFFB3261E)
                                          : const Color(0xFF1B7F4B)),
                                ),
                                title: Text(
                                    '${movementTypeLabel(row['movement_type'])} | ${money.format(asDouble(row['qty']))} ${item['unit'] ?? ''}'),
                                subtitle: Text(
                                    '${row['date'] ?? ''} | ${row['project_name'] ?? row['document_no'] ?? '-'}'),
                                trailing: Text(
                                    '${money.format(asDouble(row['total_cost']))} YER'),
                              );
                            },
                          ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    } catch (e) {
      showError(e);
    }
  }

  Future<void> runSave(
      BuildContext dialogContext, Future<Response<dynamic>> Function() action,
      {required String success}) async {
    setState(() => saving = true);
    final navigator = Navigator.of(dialogContext);
    try {
      await action();
      if (navigator.canPop()) navigator.pop();
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(success)));
      await loadData();
    } catch (e) {
      showError(e);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  String? requiredText(String? value) {
    if (value == null || value.trim().isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }

  TextFormField numberField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      keyboardType: TextInputType.number,
      decoration: inputDecoration(label),
      validator: (value) {
        final number = asDouble(value);
        if (number <= 0) return 'أدخل رقمًا أكبر من صفر';
        return null;
      },
    );
  }

  Map<String, dynamic>? findById(List<dynamic> source, int? id) {
    if (id == null) return null;
    for (final raw in source) {
      final row = Map<String, dynamic>.from(raw as Map);
      if (row['id'] == id) return row;
    }
    return null;
  }

  DropdownButtonFormField<int> itemDropdown(
      int? value, ValueChanged<int?> onChanged) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: inputDecoration('المادة', icon: Icons.inventory_2_outlined),
      items: items.map((raw) {
        final item = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
          value: item['id'] as int,
          child: Text(
              '${item['code'] ?? ''} - ${item['name'] ?? ''} | رصيد ${money.format(asDouble(item['current_qty']))}'),
        );
      }).toList(),
      validator: (value) => value == null ? 'اختر المادة' : null,
      onChanged: onChanged,
    );
  }

  DropdownButtonFormField<int> supplierDropdown(
      int? value, ValueChanged<int?> onChanged) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: inputDecoration('المورد', icon: Icons.storefront_outlined),
      items: suppliers.map((raw) {
        final supplier = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
            value: supplier['id'] as int,
            child: Text('${supplier['name'] ?? ''}'));
      }).toList(),
      onChanged: onChanged,
    );
  }

  DropdownButtonFormField<int> projectDropdown(
      int? value, ValueChanged<int?> onChanged) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: inputDecoration('المشروع', icon: Icons.foundation_outlined),
      items: projects.map((raw) {
        final project = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
            value: project['id'] as int,
            child: Text(
                '${project['project_code'] ?? ''} - ${project['name'] ?? ''}'));
      }).toList(),
      validator: (value) => value == null ? 'اختر المشروع' : null,
      onChanged: onChanged,
    );
  }

  DropdownButtonFormField<int> warehouseDropdown(
      int? value, ValueChanged<int?> onChanged) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: inputDecoration('المخزن', icon: Icons.warehouse_outlined),
      items: warehouses.map((raw) {
        final warehouse = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
          value: warehouse['id'] as int,
          child:
              Text('${warehouse['code'] ?? ''} - ${warehouse['name'] ?? ''}'),
        );
      }).toList(),
      validator: (value) => value == null ? 'اختر المخزن' : null,
      onChanged: onChanged,
    );
  }

  DropdownButtonFormField<int> costCenterDropdown(
      int? value, ValueChanged<int?> onChanged) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration:
          inputDecoration('مركز التكلفة', icon: Icons.account_tree_outlined),
      items: costCenters.map((raw) {
        final center = Map<String, dynamic>.from(raw as Map);
        return DropdownMenuItem<int>(
          value: center['id'] as int,
          child: Text('${center['code'] ?? ''} - ${center['name'] ?? ''}'),
        );
      }).toList(),
      validator: (value) => value == null ? 'اختر مركز التكلفة' : null,
      onChanged: onChanged,
    );
  }

  String inventoryPolicyMessage(String type) {
    switch (type) {
      case 'purchase_to_general_warehouse':
        return 'شراء مواد للمخزن العام يزيد المخزون ولا يحمل على مشروع مباشرة.';
      case 'reserve_stock_for_project':
        return 'حجز المواد لمشروع لا ينشئ تكلفة ولا قيد مشروع حتى يتم الصرف الفعلي.';
      case 'issue_stock_to_project':
        return 'صرف المواد للمشروع ينقص المخزون ويحمل تكلفة مواد مباشرة على المشروع.';
      case 'direct_purchase_to_project':
        return 'الشراء المباشر لمشروع لا يدخل المخزن العام، ويتطلب صورة فاتورة، ويظهر في تكلفة المشروع.';
      case 'inventory_adjustment':
        return 'تسوية المخزون تحتاج سبب واضح، وتؤثر محاسبيا عند الزيادة أو النقص.';
      default:
        return '';
    }
  }

  Widget warningBox(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF9F7F1),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFB87E62).withOpacity(.4)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: Color(0xFFB87E62)),
          const SizedBox(width: 8),
          Expanded(child: Text(text)),
        ],
      ),
    );
  }

  String labelForCost(String value) {
    const labels = {
      'materials': 'مواد مباشرة',
      'wood': 'خشب',
      'paint': 'دهانات',
      'accessories': 'إكسسوارات',
      'glass': 'زجاج',
      'aluminum': 'ألمنيوم',
      'installation_supplies': 'مستلزمات تركيب',
    };
    return labels[value] ?? value;
  }

  String movementTypeLabel(dynamic value) {
    switch ('$value') {
      case 'in':
        return 'إدخال مخزون';
      case 'out':
        return 'صرف مخزون';
      case 'purchase_reversal':
        return 'عكس شراء';
      case 'issue_reversal':
        return 'عكس صرف';
      case 'return':
        return 'مرتجع';
      case 'adjustment':
        return 'تسوية';
      default:
        return '$value';
    }
  }

  Future<void> showProjectCostSummary() async {
    int? projectId =
        projects.isEmpty ? null : (projects.first as Map)['id'] as int?;
    Map<String, dynamic>? costs;
    bool loadingCosts = false;

    Future<void> fetchCosts(StateSetter setLocal) async {
      if (projectId == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('اختر المشروع أولًا')),
        );
        return;
      }
      setLocal(() => loadingCosts = true);
      try {
        final response = await apiClient.dio.get('/projects/$projectId/costs');
        final data = response.data;
        if (data is Map) {
          setLocal(() => costs = Map<String, dynamic>.from(data));
        }
      } catch (error) {
        showError(error);
      } finally {
        setLocal(() => loadingCosts = false);
      }
    }

    await showDialog(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (dialogContext, setLocal) {
          final categories = costs?['by_category'] is List
              ? List<dynamic>.from(costs!['by_category'] as List)
              : <dynamic>[];
          return Directionality(
            textDirection: ui.TextDirection.rtl,
            child: AlertDialog(
              title: const Text('تكلفة المشروع'),
              content: SizedBox(
                width: 560,
                child: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      projectDropdown(projectId, (value) {
                        setLocal(() {
                          projectId = value;
                          costs = null;
                        });
                      }),
                      const SizedBox(height: 12),
                      FilledButton.icon(
                        onPressed:
                            loadingCosts ? null : () => fetchCosts(setLocal),
                        icon: const Icon(Icons.analytics_outlined),
                        label: const Text('عرض التكلفة'),
                      ),
                      const SizedBox(height: 16),
                      if (loadingCosts)
                        const Center(child: CircularProgressIndicator())
                      else if (costs == null)
                        warningBox(
                            'اختر مشروعًا ثم اضغط عرض التكلفة لمراجعة أثر المواد المصروفة والتكاليف المرتبطة.')
                      else ...[
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            metric('إجمالي التكلفة',
                                '${money.format(asDouble(costs!['total']))} YER'),
                            metric('تكاليف مباشرة',
                                '${money.format(asDouble(costs!['direct_transactions_total']))} YER'),
                            metric('تكاليف تشغيلية',
                                '${money.format(asDouble(costs!['manual_project_costs']))} YER'),
                            metric('مواد',
                                '${money.format(asDouble(costs!['materials']))} YER'),
                            metric('عمالة',
                                '${money.format(asDouble(costs!['labor']))} YER'),
                          ],
                        ),
                        const SizedBox(height: 14),
                        Text(
                          'التصنيف',
                          style: Theme.of(context)
                              .textTheme
                              .titleMedium
                              ?.copyWith(fontWeight: FontWeight.w800),
                        ),
                        const SizedBox(height: 8),
                        if (categories.isEmpty)
                          warningBox('لا توجد تكاليف مصنفة لهذا المشروع بعد.')
                        else
                          ...categories.map((raw) {
                            final row = Map<String, dynamic>.from(raw as Map);
                            return ListTile(
                              dense: true,
                              leading: const Icon(Icons.label_outline),
                              title: Text('${row['category'] ?? 'غير مصنف'}'),
                              trailing: Text(
                                '${money.format(asDouble(row['amount']))} YER',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w800,
                                  color: Color(0xFFB87E62),
                                ),
                              ),
                            );
                          }),
                      ],
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('إغلاق'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void showError(Object error) {
    if (!mounted) return;
    var message = 'تعذر تنفيذ العملية';
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) {
        message = '${data['detail']}';
      } else if (error.message != null) {
        message = error.message!;
      }
    }
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text(message), backgroundColor: const Color(0xFFB3261E)));
  }

  @override
  Widget build(BuildContext context) {
    final rows = filteredItems();

    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        backgroundColor: const Color(0xFFF9F7F1),
        appBar: AppBar(
          backgroundColor: const Color(0xFF1C1C1C),
          foregroundColor: Colors.white,
          title: const Text('المخزون والمواد'),
          actions: [
            IconButton(
              tooltip: 'مراجعة المستندات',
              onPressed: () => context.go('/transactions-review'),
              icon: const Icon(Icons.fact_check_outlined),
            ),
            IconButton(
              tooltip: 'تحديث',
              onPressed: loadData,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: loadData,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    header(),
                    const SizedBox(height: 14),
                    summaryGrid(),
                    const SizedBox(height: 14),
                    actionBar(),
                    const SizedBox(height: 14),
                    TextField(
                      decoration: inputDecoration(
                          'بحث باسم المادة أو الكود أو التصنيف',
                          icon: Icons.search),
                      onChanged: (value) => setState(() => search = value),
                    ),
                    const SizedBox(height: 14),
                    if (rows.isEmpty)
                      emptyState('لا توجد مواد مطابقة.')
                    else
                      ...rows.map(itemCard),
                  ],
                ),
              ),
      ),
    );
  }

  Widget header() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1C1C1C),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Container(
            width: 54,
            height: 54,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: const Color(0xFFB87E62), width: 2),
            ),
            child: const Icon(Icons.inventory_2_outlined,
                color: Color(0xFFB87E62), size: 30),
          ),
          const SizedBox(width: 14),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('إدارة مخزون الشعري',
                    style: TextStyle(
                        color: Colors.white,
                        fontSize: 19,
                        fontWeight: FontWeight.w800)),
                SizedBox(height: 4),
                Text('شراء المواد وصرفها للمشاريع مع الاعتماد المحاسبي',
                    style: TextStyle(color: Color(0xFFE7DED4))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget summaryGrid() {
    final cards = [
      (
        'عدد المواد',
        summary['total_items'] ?? 0,
        Icons.category_outlined,
        const Color(0xFF4F4F4F)
      ),
      (
        'قيمة المخزون',
        '${money.format(asDouble(summary['stock_value']))} YER',
        Icons.account_balance_wallet_outlined,
        const Color(0xFF1B7F4B)
      ),
      (
        'مواد ناقصة',
        summary['low_stock'] ?? 0,
        Icons.warning_amber_rounded,
        const Color(0xFFB87E62)
      ),
      (
        'نفد المخزون',
        summary['out_of_stock'] ?? 0,
        Icons.remove_circle_outline,
        const Color(0xFFB3261E)
      ),
    ];

    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth > 760;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: wide ? 4 : 2,
          childAspectRatio: wide ? 2.3 : 1.45,
          crossAxisSpacing: 10,
          mainAxisSpacing: 10,
          children: cards
              .map((card) => statCard(card.$1, card.$2, card.$3, card.$4))
              .toList(),
        );
      },
    );
  }

  Widget statCard(String title, Object value, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(.22)),
      ),
      child: Row(
        children: [
          CircleAvatar(
              backgroundColor: color.withOpacity(.12),
              child: Icon(icon, color: color)),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(title, style: const TextStyle(color: Color(0xFF4F4F4F))),
                const SizedBox(height: 4),
                Text('$value',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget actionBar() {
    return Wrap(
      spacing: 10,
      runSpacing: 10,
      children: [
        const AlshaariSettlementButton(
          contextType: 'inventory',
          primary: false,
          expand: false,
        ),
        FilledButton.icon(
            onPressed: () => saveStandardInventoryMovement(),
            icon: const Icon(Icons.rule_folder_outlined),
            label: const Text('مستند مخزون معياري')),
        FilledButton.icon(
            onPressed: saveItem,
            icon: const Icon(Icons.add_box_outlined),
            label: const Text('إضافة مادة')),
        FilledButton.icon(
            onPressed: () => savePurchase(),
            icon: const Icon(Icons.add_shopping_cart_outlined),
            label: const Text('شراء مواد')),
        FilledButton.icon(
            onPressed: () => saveIssue(),
            icon: const Icon(Icons.outbox_outlined),
            label: const Text('صرف لمشروع')),
        OutlinedButton.icon(
            onPressed: showProjectCostSummary,
            icon: const Icon(Icons.analytics_outlined),
            label: const Text('تكلفة مشروع')),
        OutlinedButton.icon(
            onPressed: () => context.go('/master-data/suppliers'),
            icon: const Icon(Icons.storefront_outlined),
            label: const Text('إضافة مورد')),
      ],
    );
  }

  Widget itemCard(Map<String, dynamic> item) {
    final color = statusColor(item['status'] as String?);
    final stockValue = asDouble(item['stock_value']);

    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(8),
        side: BorderSide(color: color.withOpacity(.28)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                    backgroundColor: color.withOpacity(.12),
                    child: Icon(statusIcon(item['status'] as String?),
                        color: color)),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${item['code'] ?? ''} - ${item['name'] ?? ''}',
                          style: const TextStyle(
                              fontWeight: FontWeight.w800, fontSize: 16)),
                      const SizedBox(height: 3),
                      Text(
                          '${item['category'] ?? 'غير مصنف'} | ${item['unit'] ?? ''}',
                          style: const TextStyle(color: Color(0xFF4F4F4F))),
                    ],
                  ),
                ),
                Chip(
                  label: Text('${item['status_label'] ?? ''}'),
                  side: BorderSide(color: color.withOpacity(.35)),
                  backgroundColor: color.withOpacity(.09),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 10,
              runSpacing: 10,
              children: [
                metric('الرصيد',
                    '${money.format(asDouble(item['current_qty']))} ${item['unit'] ?? ''}'),
                metric('متوسط التكلفة',
                    '${money.format(asDouble(item['avg_cost']))} YER'),
                metric('حد الطلب',
                    money.format(asDouble(item['reorder_level']))),
                metric('قيمة الرصيد', '${money.format(stockValue)} YER'),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                    onPressed: () => showMovements(item),
                    icon: const Icon(Icons.history),
                    label: const Text('الحركة')),
                OutlinedButton.icon(
                    onPressed: () => savePurchase(item),
                    icon: const Icon(Icons.add_shopping_cart_outlined),
                    label: const Text('شراء')),
                OutlinedButton.icon(
                    onPressed: () => saveIssue(item),
                    icon: const Icon(Icons.outbox_outlined),
                    label: const Text('صرف')),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget metric(String label, String value) {
    return Container(
      width: 170,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFF9F7F1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label,
              style: const TextStyle(color: Color(0xFF4F4F4F), fontSize: 12)),
          const SizedBox(height: 3),
          Text(value,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget emptyState(String text) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(26),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE6DED2)),
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const Icon(Icons.inventory_2_outlined,
              size: 44, color: Color(0xFFB87E62)),
          const SizedBox(height: 10),
          Text(text, textAlign: TextAlign.center),
        ],
      ),
    );
  }
}
