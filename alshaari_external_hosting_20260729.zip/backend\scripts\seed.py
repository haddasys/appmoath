from datetime import date
from app.db.database import SessionLocal, Base, engine
from app.models.models import User, Account, Customer, Supplier, Worker, Project, Item, Invoice
from app.core.security import hash_password

Base.metadata.create_all(bind=engine)
db = SessionLocal()
try:
    if not db.query(User).filter(User.phone=="777017187").first():
        db.add(User(name="معاذ الشعري", phone="777017187", password_hash=hash_password("12345678"), role="manager"))
    if not db.query(Account).filter(Account.code=="10101").first():
        db.add(Account(code="10101", name="صندوق يمني", type="cash", currency="YER", balance=0))
    if not db.query(Customer).first():
        db.add(Customer(name="عميل تجريبي", phone="777000000"))
    if not db.query(Supplier).first():
        db.add(Supplier(name="مورد خشب تجريبي", phone="778000000", category="خشب"))
    if not db.query(Worker).first():
        db.add(Worker(name="شوقي العريقي", phone="", daily_wage=15000))
    db.commit()
    customer = db.query(Customer).first()
    if not db.query(Project).first():
        db.add(Project(project_code="PRJ-2026-001", name="غرفة نوم تجريبية", customer_id=customer.id, contract_value=2500000, status="active", progress_percent=20, start_date=date.today()))
    if not db.query(Item).first():
        db.add_all([
            Item(code="MDF-18", name="MDF 18mm", unit="لوح", current_qty=10, avg_cost=45000, reorder_level=3),
            Item(code="PAINT-BASE", name="دهان أساس", unit="علبة", current_qty=5, avg_cost=25000, reorder_level=2),
        ])
    db.commit()
    print("تم إدخال البيانات التجريبية")
finally:
    db.close()
