from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.models.models import Base


SYNC_TABLES = [
    "transactions",
    "settlement_vouchers",
    "adjustment_vouchers",
    "supplier_invoices",
    "customer_invoices",
    "invoices",
    "purchase_requests",
    "purchase_orders",
    "goods_receipts",
    "supplier_payments",
    "inventory_movements",
    "stock_movements",
    "attachments",
    "attendance",
    "payrolls",
]


SYNC_COLUMNS = {
    "local_uuid": "VARCHAR(120)",
    "device_id": "VARCHAR(120)",
    "sync_status": "VARCHAR(30)",
    "created_offline": "BOOLEAN DEFAULT FALSE",
    "server_version": "INTEGER DEFAULT 1",
    "updated_at": "TIMESTAMP",
}


def _safe_identifier(name: str) -> str:
    if not name.replace("_", "").isalnum():
        raise ValueError(f"Unsafe identifier: {name}")
    return name


def ensure_offline_sync_schema(db: Session) -> None:
    """Create offline sync foundation without deleting or rebuilding data."""

    Base.metadata.create_all(
        bind=db.bind,
        tables=[
            Base.metadata.tables["devices"],
            Base.metadata.tables["sync_logs"],
        ],
        checkfirst=True,
    )

    inspector = inspect(db.bind)
    existing_tables = set(inspector.get_table_names())

    for table in SYNC_TABLES:
        if table not in existing_tables:
            continue

        safe_table = _safe_identifier(table)
        existing_columns = {column["name"] for column in inspector.get_columns(table)}

        for column_name, column_type in SYNC_COLUMNS.items():
            if column_name not in existing_columns:
                safe_column = _safe_identifier(column_name)
                db.execute(
                    text(
                        f"ALTER TABLE {safe_table} "
                        f"ADD COLUMN {safe_column} {column_type}"
                    )
                )

        if "local_uuid" not in existing_columns:
            existing_columns.add("local_uuid")

        index_name = _safe_identifier(f"ux_{safe_table}_local_uuid")
        db.execute(
            text(
                f"CREATE UNIQUE INDEX IF NOT EXISTS {index_name} "
                f"ON {safe_table}(local_uuid) WHERE local_uuid IS NOT NULL"
            )
        )

    db.commit()
