import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/printing/print_document.dart';

class AuditReadinessScreen extends StatefulWidget {
  const AuditReadinessScreen({super.key});

  @override
  State<AuditReadinessScreen> createState() => _AuditReadinessScreenState();
}

class _AuditReadinessScreenState extends State<AuditReadinessScreen>
    with SingleTickerProviderStateMixin {
  late final TabController controller;

  bool loading = true;
  Map<String, dynamic> audit = {};
  Map<String, dynamic> readiness = {};

  String? selectedEntity;
  String? selectedAction;

  final entityLabels = const {
    'transaction': 'المستندات المالية',
    'invoice': 'الفواتير',
    'user': 'المستخدمون',
    'role': 'الأدوار',
    'account': 'الحسابات',
    'item': 'المخزون',
  };

  final actionLabels = const {
    'create_transaction': 'إنشاء مستند',
    'approve_transaction': 'اعتماد مستند',
    'reject_transaction': 'رفض مستند',
    'reverse_transaction': 'عكس مستند',
    'create_invoice': 'إنشاء فاتورة',
    'post_invoice': 'ترحيل فاتورة',
    'create_user': 'إنشاء مستخدم',
    'update_user': 'تعديل مستخدم',
    'update_user_password': 'تغيير كلمة مرور',
    'update_role_permissions': 'تعديل صلاحيات',
    'update_account': 'تعديل حساب',
    'set_opening_balance': 'رصيد افتتاحي',
    'update_item': 'تعديل مادة',
  };

  @override
  void initState() {
    super.initState();
    controller = TabController(length: 2, vsync: this);
    configureAndLoad();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadData();
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.response?.statusCode == 403) {
        return 'لا تملك صلاحية عرض سجل المراجعة';
      }
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
    }
    return 'حدث خطأ غير متوقع';
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      final query = <String, dynamic>{'limit': 300};
      if (selectedEntity != null) query['entity'] = selectedEntity;
      if (selectedAction != null) query['action'] = selectedAction;

      final result = await Future.wait([
        apiClient.dio.get('/audit/logs', queryParameters: query),
        apiClient.dio.get('/go-live/readiness'),
      ]);

      if (!mounted) return;
      setState(() {
        audit = Map<String, dynamic>.from(result[0].data as Map);
        readiness = Map<String, dynamic>.from(result[1].data as Map);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل السجل الرقابي: ${friendlyError(e)}');
    }
  }

  String labelEntity(String? entity) => entityLabels[entity] ?? entity ?? '-';

  String labelAction(String? action) => actionLabels[action] ?? action ?? '-';

  String htmlEscape(Object? value) {
    return '${value ?? ''}'
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
  }

  String printHeader(String title) {
    return '''
<!doctype html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="utf-8">
  <title>${htmlEscape(title)}</title>
  <style>
    @page { size: A4; margin: 14mm; }
    * { box-sizing: border-box; }
    body { margin: 0; font-family: Cairo, Tahoma, Arial, sans-serif; color: #1C1C1C; background: #F9F7F1; }
    .page { min-height: 100vh; padding: 28px; background: #fffdf8; border: 1px solid #E5D9C8; }
    .head { display: flex; justify-content: space-between; gap: 24px; border-bottom: 3px solid #B87E62; padding-bottom: 18px; margin-bottom: 24px; }
    .brand { display: flex; align-items: center; gap: 12px; }
    .mark { width: 54px; height: 54px; display: grid; place-items: center; background: #1C1C1C; color: white; border: 2px solid #B87E62; border-radius: 8px; font-size: 30px; font-weight: 900; }
    h1, h2, h3 { margin: 0; }
    h1 { font-size: 24px; }
    h2 { color: #B87E62; font-size: 22px; }
    .muted { color: #4F4F4F; font-size: 12px; }
    .title { text-align: left; }
    .grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin-bottom: 20px; }
    .box { border: 1px solid #E5D9C8; border-radius: 8px; padding: 12px; background: #F9F7F1; }
    .box b { display: block; font-size: 12px; color: #4F4F4F; margin-bottom: 5px; }
    .box span { font-size: 17px; font-weight: 900; }
    table { width: 100%; border-collapse: collapse; margin-top: 10px; }
    th { background: #1C1C1C; color: #fff; padding: 10px; font-size: 12px; text-align: right; }
    td { padding: 10px; border-bottom: 1px solid #E5D9C8; font-size: 12px; vertical-align: top; }
    .ok { color: #2F7D57; font-weight: 900; }
    .warn { color: #B87E62; font-weight: 900; }
    .footer { margin-top: 34px; display: grid; grid-template-columns: 1fr 1fr; gap: 24px; }
    .sign { height: 82px; border-top: 1px solid #4F4F4F; padding-top: 8px; color: #4F4F4F; margin-top: 46px; }
    @media print { body { background: white; } .page { border: 0; padding: 0; } }
  </style>
</head>
<body>
  <div class="page">
    <div class="head">
      <div class="brand">
        <div class="mark">ش</div>
        <div>
          <h1>الشعري</h1>
          <div class="muted">لصناعة وحلول الأثاث المخصص والديكور</div>
        </div>
      </div>
      <div class="title">
        <h2>${htmlEscape(title)}</h2>
        <div class="muted">تاريخ الطباعة: ${DateTime.now().toIso8601String().substring(0, 10)}</div>
      </div>
    </div>
''';
  }

  String printFooter() {
    return '''
    <div class="footer">
      <div class="sign">مسؤول النظام</div>
      <div class="sign">اعتماد الإدارة</div>
    </div>
  </div>
  <script>window.addEventListener('load', () => window.print());</script>
</body>
</html>
''';
  }

  Future<void> printAudit() async {
    final items = (audit['items'] as List?) ?? [];
    final summary = (audit['summary'] as List?) ?? [];
    final buffer = StringBuffer(printHeader('سجل المراجعة'));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>عدد العمليات المعروضة</b><span>${items.length}</span></div>
      <div class="box"><b>فلتر الكيان</b><span>${htmlEscape(labelEntity(selectedEntity))}</span></div>
      <div class="box"><b>فلتر العملية</b><span>${htmlEscape(labelAction(selectedAction))}</span></div>
    </div>
    <h3>ملخص العمليات</h3>
    <table><thead><tr><th>الكيان</th><th>العملية</th><th>العدد</th></tr></thead><tbody>
''');
    if (summary.isEmpty) {
      buffer.write('<tr><td colspan="3">لا توجد عمليات.</td></tr>');
    } else {
      for (final raw in summary) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write(
            '<tr><td>${htmlEscape(labelEntity(row['entity']))}</td><td>${htmlEscape(labelAction(row['action']))}</td><td>${htmlEscape(row['count'])}</td></tr>');
      }
    }
    buffer
        .write('</tbody></table><h3 style="margin-top:22px">آخر العمليات</h3>');
    buffer.write(
        '<table><thead><tr><th>الوقت</th><th>المستخدم</th><th>الكيان</th><th>العملية</th><th>التفاصيل</th></tr></thead><tbody>');
    if (items.isEmpty) {
      buffer.write('<tr><td colspan="5">لا توجد عمليات.</td></tr>');
    } else {
      for (final raw in items) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write(
            '<tr><td>${htmlEscape(row['created_at'])}</td><td>${htmlEscape(row['user_name'] ?? row['user_id'])}</td><td>${htmlEscape(labelEntity(row['entity']))}</td><td>${htmlEscape(labelAction(row['action']))}</td><td>${htmlEscape(row['details'])}</td></tr>');
      }
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());

    try {
      await openPrintDocument(
          title: 'سجل المراجعة', content: buffer.toString());
    } catch (_) {
      showMessage('الطباعة متاحة حاليًا من نسخة الويب');
    }
  }

  Future<void> printReadiness() async {
    final checks = (readiness['checks'] as List?) ?? [];
    final counts =
        Map<String, dynamic>.from((readiness['counts'] as Map?) ?? {});
    final ready = readiness['ready'] == true;
    final buffer = StringBuffer(printHeader('تقرير الجاهزية التشغيلية'));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>حالة التشغيل</b><span class="${ready ? 'ok' : 'warn'}">${ready ? 'جاهز' : 'يحتاج استكمال'}</span></div>
      <div class="box"><b>الحسابات</b><span>${htmlEscape(counts['accounts'])}</span></div>
      <div class="box"><b>المشاريع</b><span>${htmlEscape(counts['projects'])}</span></div>
    </div>
    <table><thead><tr><th>الفحص</th><th>الحالة</th><th>الملاحظة</th></tr></thead><tbody>
''');
    for (final raw in checks) {
      final row = Map<String, dynamic>.from(raw as Map);
      final ok = row['ok'] == true;
      buffer.write(
          '<tr><td>${htmlEscape(row['key'])}</td><td class="${ok ? 'ok' : 'warn'}">${ok ? 'ناجح' : 'تنبيه'}</td><td>${htmlEscape(row['message'])}</td></tr>');
    }
    buffer.write('</tbody></table>');
    buffer.write(printFooter());
    try {
      await openPrintDocument(
          title: 'تقرير الجاهزية التشغيلية', content: buffer.toString());
    } catch (_) {
      showMessage('الطباعة متاحة حاليًا من نسخة الويب');
    }
  }

  Widget statCard(String title, dynamic value, IconData icon, {Color? color}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: (color ?? AlshaariColors.deepGreen).withOpacity(.10),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color ?? AlshaariColors.deepGreen),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  Text('$value',
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.w900)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget cardsGrid(List<Widget> cards) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 720) {
          return Column(
              children: cards
                  .map((card) => Padding(
                      padding: const EdgeInsets.only(bottom: 8), child: card))
                  .toList());
        }
        return GridView.count(
          crossAxisCount: 3,
          childAspectRatio: 2.9,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: cards,
        );
      },
    );
  }

  Widget auditTab() {
    final items = (audit['items'] as List?) ?? [];
    final summary = (audit['summary'] as List?) ?? [];
    final entities = entityLabels.keys.toList();
    final actions = actionLabels.keys.toList();

    return RefreshIndicator(
      onRefresh: loadData,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String?>(
                  initialValue: selectedEntity,
                  decoration: const InputDecoration(labelText: 'الكيان'),
                  items: [
                    const DropdownMenuItem<String?>(
                        value: null, child: Text('الكل')),
                    ...entities.map((entity) => DropdownMenuItem<String?>(
                        value: entity, child: Text(labelEntity(entity)))),
                  ],
                  onChanged: (value) {
                    setState(() => selectedEntity = value);
                    loadData();
                  },
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: DropdownButtonFormField<String?>(
                  initialValue: selectedAction,
                  decoration: const InputDecoration(labelText: 'العملية'),
                  items: [
                    const DropdownMenuItem<String?>(
                        value: null, child: Text('الكل')),
                    ...actions.map((action) => DropdownMenuItem<String?>(
                        value: action, child: Text(labelAction(action)))),
                  ],
                  onChanged: (value) {
                    setState(() => selectedAction = value);
                    loadData();
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          cardsGrid([
            statCard('العمليات المعروضة', items.length, Icons.history),
            statCard('أنواع العمليات', summary.length, Icons.insights),
            statCard(
                'آخر تحديث',
                DateTime.now().toIso8601String().substring(11, 16),
                Icons.schedule),
          ]),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.icon(
              onPressed: printAudit,
              icon: const Icon(Icons.print_outlined),
              label: const Text('طباعة سجل المراجعة'),
            ),
          ),
          const SizedBox(height: 14),
          if (items.isEmpty)
            const Card(child: ListTile(title: Text('لا توجد عمليات مطابقة')))
          else
            ...items.map((raw) {
              final row = Map<String, dynamic>.from(raw as Map);
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.manage_history),
                  title: Text(
                      '${labelAction(row['action'])} - ${labelEntity(row['entity'])}'),
                  subtitle: Text(
                      '${row['user_name'] ?? 'مستخدم'} | ${row['created_at'] ?? '-'}\n${row['details'] ?? ''}'),
                  isThreeLine: true,
                  trailing: Text('#${row['entity_id'] ?? row['id']}'),
                ),
              );
            }),
        ],
      ),
    );
  }

  Widget readinessTab() {
    final checks = (readiness['checks'] as List?) ?? [];
    final counts =
        Map<String, dynamic>.from((readiness['counts'] as Map?) ?? {});
    final ready = readiness['ready'] == true;

    return RefreshIndicator(
      onRefresh: loadData,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          cardsGrid([
            statCard('حالة التشغيل', ready ? 'جاهز' : 'يحتاج استكمال',
                ready ? Icons.verified : Icons.warning_amber,
                color: ready ? const Color(0xFF2F7D57) : AlshaariColors.copper),
            statCard('دليل الحسابات', counts['accounts'] ?? 0,
                Icons.account_tree_outlined),
            statCard('قواعد الترحيل', counts['posting_rules'] ?? 0, Icons.rule),
          ]),
          const SizedBox(height: 10),
          Align(
            alignment: Alignment.centerLeft,
            child: FilledButton.icon(
              onPressed: printReadiness,
              icon: const Icon(Icons.print_outlined),
              label: const Text('طباعة تقرير الجاهزية'),
            ),
          ),
          const SizedBox(height: 14),
          ...checks.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            final ok = row['ok'] == true;
            return Card(
              child: ListTile(
                leading: Icon(ok ? Icons.check_circle : Icons.warning_amber,
                    color:
                        ok ? const Color(0xFF2F7D57) : AlshaariColors.copper),
                title: Text('${row['key'] ?? '-'}'),
                subtitle: Text('${row['message'] ?? '-'}'),
              ),
            );
          }),
          const SizedBox(height: 14),
          Text('إحصائيات التشغيل',
              style: Theme.of(context)
                  .textTheme
                  .titleMedium
                  ?.copyWith(fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          ...counts.entries.map((entry) => Card(
                child: ListTile(
                  title: Text(entry.key),
                  trailing: Text('${entry.value}',
                      style: const TextStyle(fontWeight: FontWeight.w900)),
                ),
              )),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('المراجعة والجاهزية'),
            ],
          ),
          actions: [
            IconButton(onPressed: loadData, icon: const Icon(Icons.refresh)),
          ],
          bottom: TabBar(
            controller: controller,
            tabs: const [
              Tab(icon: Icon(Icons.manage_history), text: 'سجل المراجعة'),
              Tab(icon: Icon(Icons.fact_check_outlined), text: 'الجاهزية'),
            ],
          ),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                controller: controller,
                children: [
                  auditTab(),
                  readinessTab(),
                ],
              ),
      ),
    );
  }
}
