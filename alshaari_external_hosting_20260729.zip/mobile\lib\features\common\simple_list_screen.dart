﻿import 'dart:ui' as ui;
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../app/theme.dart';
import '../../core/config.dart';

class SimpleListScreen extends StatefulWidget {
  final String title;
  final String endpoint;

  const SimpleListScreen({
    super.key,
    required this.title,
    required this.endpoint,
  });

  @override
  State<SimpleListScreen> createState() => _SimpleListScreenState();
}

class _SimpleListScreenState extends State<SimpleListScreen> {
  bool loading = true;
  List<dynamic> items = [];

  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ),
  );

  @override
  void initState() {
    super.initState();
    configureAndLoad();
  }

  Future<void> configureAndLoad() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ??
        prefs.getString('access_token') ??
        prefs.getString('auth_token');

    if (token != null && token.isNotEmpty) {
      dio.options.headers['Authorization'] = 'Bearer $token';
    }

    await loadData();
  }

  Future<void> loadData() async {
    setState(() => loading = true);

    try {
      final res = await dio.get(widget.endpoint);

      if (!mounted) return;

      setState(() {
        if (res.data is List) {
          items = res.data as List<dynamic>;
        } else if (res.data is Map && res.data['items'] is List) {
          items = res.data['items'] as List<dynamic>;
        } else if (res.data is Map) {
          items = [res.data];
        } else {
          items = [];
        }
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('فشل تحميل البيانات: $e')),
      );
    }
  }

  String titleOf(Map<String, dynamic> item) {
    return '${item['name'] ?? item['project_code'] ?? item['code'] ?? item['title'] ?? item['id'] ?? 'عنصر'}';
  }

  String subtitleOf(Map<String, dynamic> item) {
    final parts = <String>[];

    if (item['phone'] != null) parts.add('الهاتف: ${item['phone']}');
    if (item['amount'] != null) parts.add('المبلغ: ${item['amount']}');
    if (item['contract_value'] != null) parts.add('العقد: ${item['contract_value']}');
    if (item['balance'] != null) parts.add('الرصيد: ${item['balance']}');
    if (item['status'] != null) parts.add('الحالة: ${item['status']}');

    if (parts.isEmpty) {
      parts.add('ID: ${item['id'] ?? '-'}');
    }

    return parts.join(' | ');
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const BrandMark(size: 32),
              const SizedBox(width: 10),
              Text(widget.title),
            ],
          ),
          actions: [
            IconButton(
              onPressed: loadData,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: loadData,
                child: items.isEmpty
                    ? ListView(
                        padding: const EdgeInsets.all(18),
                        children: [
                          const SizedBox(height: 70),
                          Center(
                            child: Container(
                              width: 72,
                              height: 72,
                              decoration: BoxDecoration(
                                color: AlshaariColors.deepGreen.withOpacity(.10),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: const Icon(Icons.inbox_outlined, size: 36, color: AlshaariColors.deepGreen),
                            ),
                          ),
                          const SizedBox(height: 14),
                          const Center(
                            child: Text(
                              'لا توجد بيانات',
                              style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
                            ),
                          ),
                          const SizedBox(height: 6),
                          Center(
                            child: Text(
                              'ستظهر السجلات هنا بعد إدخالها أو اعتمادها',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(color: AlshaariColors.slate),
                            ),
                          ),
                        ],
                      )
                    : ListView.separated(
                        padding: const EdgeInsets.all(14),
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 8),
                        itemBuilder: (_, index) {
                          final item = Map<String, dynamic>.from(items[index] as Map);
                          return Card(
                            child: ListTile(
                              contentPadding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
                              title: Text(titleOf(item)),
                              subtitle: Text(subtitleOf(item)),
                              leading: Container(
                                width: 42,
                                height: 42,
                                decoration: BoxDecoration(
                                  color: AlshaariColors.deepGreen.withOpacity(.10),
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: Text(
                                    '${item['id'] ?? index + 1}',
                                    style: const TextStyle(
                                      color: AlshaariColors.deepGreen,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
              ),
      ),
    );
  }
}
