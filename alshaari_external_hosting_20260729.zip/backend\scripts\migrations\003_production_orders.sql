BEGIN;

CREATE TABLE IF NOT EXISTS production_orders (
    id SERIAL PRIMARY KEY,
    order_no VARCHAR(80) UNIQUE NOT NULL,
    project_id INTEGER NOT NULL REFERENCES projects(id),
    stage_id INTEGER REFERENCES project_stages(id),
    item_description VARCHAR(220) NOT NULL,
    qty NUMERIC(14,3) DEFAULT 1,
    unit VARCHAR(30) DEFAULT 'pcs',
    priority VARCHAR(20) DEFAULT 'normal',
    status VARCHAR(30) DEFAULT 'planned',
    planned_start_date DATE,
    planned_end_date DATE,
    actual_start_date DATE,
    actual_end_date DATE,
    notes TEXT,
    created_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS ix_production_orders_order_no ON production_orders(order_no);
CREATE INDEX IF NOT EXISTS ix_production_orders_project_id ON production_orders(project_id);
CREATE INDEX IF NOT EXISTS ix_production_orders_stage_id ON production_orders(stage_id);

INSERT INTO document_sequences (document_type, prefix, next_number, padding, is_active)
VALUES ('production_order', 'PO', 1, 6, TRUE)
ON CONFLICT (document_type) DO NOTHING;

COMMIT;
