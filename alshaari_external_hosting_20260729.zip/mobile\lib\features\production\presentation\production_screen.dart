import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';

class ProductionScreen extends StatefulWidget {
  const ProductionScreen({super.key});

  @override
  State<ProductionScreen> createState() => _ProductionScreenState();
}

class _ProductionScreenState extends State<ProductionScreen> {
  final money = NumberFormat('#,##0.##', 'en_US');

  bool loading = true;
  bool saving = false;
  Map<String, dynamic> summary = {};
  List<dynamic> projects = [];
  String search = '';
  String statusFilter = 'all';

  @override
  void initState() {
    super.initState();
    configureAndLoad();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadData();
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        apiClient.dio.get('/production/summary'),
        apiClient.dio.get('/production/projects'),
      ]);
      if (!mounted) return;
      setState(() {
        summary = Map<String, dynamic>.from(result[0].data as Map);
        projects = (result[1].data as List?) ?? [];
      });
    } catch (e) {
      showError(e);
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  double asDouble(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toDouble();
    return double.tryParse(value.toString()) ?? 0;
  }

  int asInt(dynamic value) {
    if (value == null) return 0;
    if (value is num) return value.toInt();
    return int.tryParse(value.toString()) ?? 0;
  }

  String amount(dynamic value) => money.format(asDouble(value));

  List<Map<String, dynamic>> filteredProjects() {
    final q = search.trim().toLowerCase();
    return projects
        .map((raw) => Map<String, dynamic>.from(raw as Map))
        .where((project) {
      final status = '${project['status'] ?? ''}';
      if (statusFilter != 'all' && status != statusFilter) return false;
      if (q.isEmpty) return true;
      final text =
          '${project['project_code']} ${project['name']} ${project['status_label']}'
              .toLowerCase();
      return text.contains(q);
    }).toList();
  }

  Color statusColor(String? status) {
    switch (status) {
      case 'done':
      case 'ready_for_delivery':
        return const Color(0xFF2F7D57);
      case 'in_progress':
      case 'in_production':
        return AlshaariColors.deepGreen;
      case 'blocked':
        return const Color(0xFFB3261E);
      case 'cancelled':
        return AlshaariColors.slate;
      default:
        return AlshaariColors.copper;
    }
  }

  String statusLabel(String? status) {
    const labels = {
      'not_started': 'لم تبدأ',
      'in_progress': 'قيد التنفيذ',
      'done': 'مكتملة',
      'blocked': 'متعطلة',
      'cancelled': 'ملغاة',
      'active': 'نشط',
      'in_production': 'قيد الإنتاج',
      'ready_for_delivery': 'جاهز للتسليم',
      'new': 'جديد',
    };
    return labels[status] ?? status ?? '-';
  }

  InputDecoration dec(String label, {IconData? icon}) {
    return InputDecoration(
      labelText: label,
      prefixIcon: icon == null ? null : Icon(icon),
      border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      filled: true,
      fillColor: Colors.white,
    );
  }

  Future<void> bootstrapStages(Map<String, dynamic> project) async {
    await runAction(
      () => apiClient.dio
          .post('/production/projects/${project['id']}/stages/bootstrap'),
      'تم إنشاء مراحل الإنتاج للمشروع',
    );
  }

  Future<void> updateStage(
    Map<String, dynamic> stage,
    String status, {
    int? progress,
  }) async {
    await runAction(
      () => apiClient.dio.patch('/production/stages/${stage['id']}', data: {
        'status': status,
        if (progress != null) 'progress_percent': progress,
      }),
      'تم تحديث مرحلة الإنتاج',
    );
  }

  Future<void> addStage(Map<String, dynamic> project) async {
    final formKey = GlobalKey<FormState>();
    final stages = (project['stages'] as List?) ?? [];
    final order = TextEditingController(text: '${stages.length + 1}');
    final name = TextEditingController();
    final code = TextEditingController(text: 'custom_${DateTime.now().millisecondsSinceEpoch}');
    final plannedStart = TextEditingController();
    final plannedEnd = TextEditingController();
    final notes = TextEditingController();
    final navigator = Navigator.of(context, rootNavigator: true);

    await showDialog<void>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: const Text('إضافة مرحلة إنتاج'),
          content: SizedBox(
            width: 520,
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      controller: name,
                      decoration: dec('اسم المرحلة', icon: Icons.view_timeline),
                      validator: (value) =>
                          (value ?? '').trim().isEmpty ? 'أدخل اسم المرحلة' : null,
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: order,
                            decoration: dec('الترتيب'),
                            keyboardType: TextInputType.number,
                            validator: (value) {
                              final parsed = int.tryParse(value ?? '');
                              if (parsed == null || parsed <= 0) {
                                return 'ترتيب غير صحيح';
                              }
                              return null;
                            },
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: code,
                            decoration: dec('كود المرحلة'),
                            validator: (value) =>
                                (value ?? '').trim().isEmpty ? 'أدخل الكود' : null,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: plannedStart,
                            decoration: dec('بداية مخططة YYYY-MM-DD'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: plannedEnd,
                            decoration: dec('نهاية مخططة YYYY-MM-DD'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: notes,
                      minLines: 2,
                      maxLines: 3,
                      decoration: dec('ملاحظات تشغيلية'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => navigator.pop(),
              child: const Text('إلغاء'),
            ),
            FilledButton.icon(
              icon: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.add),
              label: const Text('إضافة'),
              onPressed: saving
                  ? null
                  : () async {
                      if (!formKey.currentState!.validate()) return;
                      await runAction(
                        () => apiClient.dio.post('/production/stages', data: {
                          'project_id': project['id'],
                          'stage_order': int.parse(order.text),
                          'stage_code': code.text.trim(),
                          'name': name.text.trim(),
                          'status': 'not_started',
                          'progress_percent': 0,
                          if (plannedStart.text.trim().isNotEmpty)
                            'planned_start_date': plannedStart.text.trim(),
                          if (plannedEnd.text.trim().isNotEmpty)
                            'planned_end_date': plannedEnd.text.trim(),
                          if (notes.text.trim().isNotEmpty)
                            'notes': notes.text.trim(),
                        }),
                        'تمت إضافة مرحلة الإنتاج',
                      );
                      if (navigator.canPop()) navigator.pop();
                    },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> addOrder(Map<String, dynamic> project) async {
    final formKey = GlobalKey<FormState>();
    final stages = (project['stages'] as List?)
            ?.map((raw) => Map<String, dynamic>.from(raw as Map))
            .toList() ??
        [];
    int? stageId = stages.isEmpty ? null : stages.first['id'] as int?;
    String priority = 'normal';
    final item = TextEditingController(text: '${project['name'] ?? ''}');
    final qty = TextEditingController(text: '1');
    final unit = TextEditingController(text: 'pcs');
    final plannedStart = TextEditingController();
    final plannedEnd = TextEditingController(text: '${project['expected_end_date'] ?? ''}');
    final notes = TextEditingController();
    final navigator = Navigator.of(context, rootNavigator: true);

    await showDialog<void>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: StatefulBuilder(
          builder: (context, setDialogState) {
            return AlertDialog(
              title: const Text('إضافة أمر تشغيل'),
              content: SizedBox(
                width: 540,
                child: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextFormField(
                          controller: item,
                          decoration: dec('وصف المنتج / العمل', icon: Icons.chair_outlined),
                          validator: (value) => (value ?? '').trim().isEmpty
                              ? 'أدخل وصف أمر التشغيل'
                              : null,
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: qty,
                                decoration: dec('الكمية'),
                                keyboardType: TextInputType.number,
                                validator: (value) {
                                  final parsed = double.tryParse(value ?? '');
                                  if (parsed == null || parsed <= 0) {
                                    return 'كمية غير صحيحة';
                                  }
                                  return null;
                                },
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextFormField(
                                controller: unit,
                                decoration: dec('الوحدة'),
                                validator: (value) =>
                                    (value ?? '').trim().isEmpty ? 'أدخل الوحدة' : null,
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<int?>(
                          initialValue: stageId,
                          decoration: dec('مرحلة الإنتاج', icon: Icons.view_timeline),
                          items: [
                            const DropdownMenuItem<int?>(
                              value: null,
                              child: Text('بدون مرحلة محددة'),
                            ),
                            ...stages.map(
                              (stage) => DropdownMenuItem<int?>(
                                value: stage['id'] as int?,
                                child: Text('${stage['stage_order']}. ${stage['name']}'),
                              ),
                            ),
                          ],
                          onChanged: (value) => setDialogState(() => stageId = value),
                        ),
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: priority,
                          decoration: dec('الأولوية', icon: Icons.priority_high),
                          items: const [
                            DropdownMenuItem(value: 'low', child: Text('منخفضة')),
                            DropdownMenuItem(value: 'normal', child: Text('عادية')),
                            DropdownMenuItem(value: 'high', child: Text('عالية')),
                            DropdownMenuItem(value: 'urgent', child: Text('عاجلة')),
                          ],
                          onChanged: (value) =>
                              setDialogState(() => priority = value ?? priority),
                        ),
                        const SizedBox(height: 10),
                        Row(
                          children: [
                            Expanded(
                              child: TextFormField(
                                controller: plannedStart,
                                decoration: dec('بداية مخططة YYYY-MM-DD'),
                              ),
                            ),
                            const SizedBox(width: 10),
                            Expanded(
                              child: TextFormField(
                                controller: plannedEnd,
                                decoration: dec('تسليم مخطط YYYY-MM-DD'),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          controller: notes,
                          minLines: 2,
                          maxLines: 3,
                          decoration: dec('تعليمات الإنتاج'),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => navigator.pop(),
                  child: const Text('إلغاء'),
                ),
                FilledButton.icon(
                  icon: saving
                      ? const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.add_task),
                  label: const Text('إنشاء الأمر'),
                  onPressed: saving
                      ? null
                      : () async {
                          if (!formKey.currentState!.validate()) return;
                          await runAction(
                            () => apiClient.dio.post('/production/orders', data: {
                              'project_id': project['id'],
                              'stage_id': stageId,
                              'item_description': item.text.trim(),
                              'qty': qty.text.trim(),
                              'unit': unit.text.trim(),
                              'priority': priority,
                              'status': 'planned',
                              if (plannedStart.text.trim().isNotEmpty)
                                'planned_start_date': plannedStart.text.trim(),
                              if (plannedEnd.text.trim().isNotEmpty)
                                'planned_end_date': plannedEnd.text.trim(),
                              if (notes.text.trim().isNotEmpty)
                                'notes': notes.text.trim(),
                            }),
                            'تم إنشاء أمر التشغيل',
                          );
                          if (navigator.canPop()) navigator.pop();
                        },
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Future<void> updateOrderStatus(Map<String, dynamic> order, String status) async {
    await runAction(
      () => apiClient.dio.patch('/production/orders/${order['id']}', data: {
        'status': status,
      }),
      'تم تحديث أمر التشغيل',
    );
  }

  Future<void> editStage(Map<String, dynamic> stage) async {
    final formKey = GlobalKey<FormState>();
    final name = TextEditingController(text: '${stage['name'] ?? ''}');
    final progress =
        TextEditingController(text: '${stage['progress_percent'] ?? 0}');
    final plannedStart =
        TextEditingController(text: '${stage['planned_start_date'] ?? ''}');
    final plannedEnd =
        TextEditingController(text: '${stage['planned_end_date'] ?? ''}');
    final notes = TextEditingController(text: '${stage['notes'] ?? ''}');
    String status = '${stage['status'] ?? 'not_started'}';
    final navigator = Navigator.of(context, rootNavigator: true);

    await showDialog<void>(
      context: context,
      builder: (_) => Directionality(
        textDirection: ui.TextDirection.rtl,
        child: AlertDialog(
          title: Text('تحديث مرحلة: ${stage['name']}'),
          content: SizedBox(
            width: 520,
            child: Form(
              key: formKey,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextFormField(
                      controller: name,
                      decoration: dec('اسم المرحلة', icon: Icons.view_timeline),
                      validator: (value) =>
                          (value ?? '').trim().isEmpty ? 'أدخل اسم المرحلة' : null,
                    ),
                    const SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      initialValue: status,
                      decoration: dec('الحالة', icon: Icons.flag_outlined),
                      items: const [
                        DropdownMenuItem(value: 'not_started', child: Text('لم تبدأ')),
                        DropdownMenuItem(value: 'in_progress', child: Text('قيد التنفيذ')),
                        DropdownMenuItem(value: 'blocked', child: Text('متعطلة')),
                        DropdownMenuItem(value: 'done', child: Text('مكتملة')),
                        DropdownMenuItem(value: 'cancelled', child: Text('ملغاة')),
                      ],
                      onChanged: (value) => status = value ?? status,
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: progress,
                      decoration: dec('نسبة الإنجاز %', icon: Icons.percent),
                      keyboardType: TextInputType.number,
                      validator: (value) {
                        final number = int.tryParse(value ?? '');
                        if (number == null || number < 0 || number > 100) {
                          return 'النسبة من 0 إلى 100';
                        }
                        return null;
                      },
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            controller: plannedStart,
                            decoration: dec('بداية مخططة YYYY-MM-DD'),
                          ),
                        ),
                        const SizedBox(width: 10),
                        Expanded(
                          child: TextFormField(
                            controller: plannedEnd,
                            decoration: dec('نهاية مخططة YYYY-MM-DD'),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    TextFormField(
                      controller: notes,
                      minLines: 2,
                      maxLines: 3,
                      decoration: dec('ملاحظات تشغيلية'),
                    ),
                  ],
                ),
              ),
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => navigator.pop(),
              child: const Text('إلغاء'),
            ),
            FilledButton.icon(
              icon: saving
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: const Text('حفظ'),
              onPressed: saving
                  ? null
                  : () async {
                      if (!formKey.currentState!.validate()) return;
                      await runAction(
                        () => apiClient.dio.patch(
                          '/production/stages/${stage['id']}',
                          data: {
                            'name': name.text.trim(),
                            'status': status,
                            'progress_percent': int.parse(progress.text),
                            'planned_start_date':
                                plannedStart.text.trim().isEmpty
                                    ? null
                                    : plannedStart.text.trim(),
                            'planned_end_date': plannedEnd.text.trim().isEmpty
                                ? null
                                : plannedEnd.text.trim(),
                            'notes': notes.text.trim(),
                          },
                        ),
                        'تم حفظ المرحلة',
                      );
                      if (navigator.canPop()) navigator.pop();
                    },
            ),
          ],
        ),
      ),
    );
  }

  Future<void> runAction(
    Future<Response<dynamic>> Function() action,
    String message,
  ) async {
    setState(() => saving = true);
    try {
      await action();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
      await loadData();
    } catch (e) {
      showError(e);
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  void showError(Object error) {
    if (!mounted) return;
    var message = 'تعذر تنفيذ العملية';
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) {
        message = '${data['detail']}';
      } else if (error.type == DioExceptionType.connectionError) {
        message = 'تعذر الاتصال بالخادم';
      } else if (error.message != null) {
        message = error.message!;
      }
    }
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message), backgroundColor: const Color(0xFFB3261E)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final rows = filteredProjects();
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('إدارة الإنتاج'),
            ],
          ),
          actions: [
            IconButton(
              onPressed: loadData,
              icon: const Icon(Icons.refresh),
              tooltip: 'تحديث',
            ),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: loadData,
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    header(),
                    const SizedBox(height: 12),
                    summaryGrid(),
                    const SizedBox(height: 12),
                    filters(),
                    const SizedBox(height: 12),
                    if (rows.isEmpty)
                      emptyState('لا توجد مشاريع إنتاجية مطابقة.')
                    else
                      ...rows.map(projectCard),
                  ],
                ),
              ),
      ),
    );
  }

  Widget header() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AlshaariColors.deepGreen,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AlshaariColors.brass),
      ),
      child: const Row(
        children: [
          Icon(Icons.precision_manufacturing_outlined,
              color: Colors.white, size: 36),
          SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'متابعة تصنيع الأثاث حسب الطلب',
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                    fontSize: 18,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  'إدارة مراحل التصميم، النجارة، الدهان، التشطيب، التركيب، ومراقبة التكلفة الفعلية لكل مشروع.',
                  style: TextStyle(color: Color(0xFFE8DDC8)),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget summaryGrid() {
    final cards = [
      (
        'مشاريع بالإنتاج',
        summary['projects_in_production'] ?? 0,
        Icons.work_outline,
        AlshaariColors.deepGreen,
      ),
      (
        'مراحل قيد التنفيذ',
        summary['in_progress'] ?? 0,
        Icons.play_circle_outline,
        const Color(0xFF2F7D57),
      ),
      (
        'مراحل متعطلة',
        summary['blocked'] ?? 0,
        Icons.report_problem_outlined,
        const Color(0xFFB3261E),
      ),
      (
        'أوامر مفتوحة',
        summary['open_orders'] ?? 0,
        Icons.assignment_outlined,
        AlshaariColors.deepGreen,
      ),
      (
        'أوامر متأخرة',
        summary['late_orders'] ?? 0,
        Icons.schedule_outlined,
        AlshaariColors.copper,
      ),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth > 760;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: wide ? 4 : 2,
          childAspectRatio: wide ? 2.2 : 1.55,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: cards
              .map((card) => statCard(card.$1, card.$2, card.$3, card.$4))
              .toList(),
        );
      },
    );
  }

  Widget filters() {
    return Column(
      children: [
        TextField(
          decoration: dec('بحث برقم المشروع أو اسمه', icon: Icons.search),
          onChanged: (value) => setState(() => search = value),
        ),
        const SizedBox(height: 10),
        SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: Row(
            children: [
              filterChip('all', 'الكل'),
              filterChip('active', 'نشط'),
              filterChip('in_production', 'قيد الإنتاج'),
              filterChip('blocked', 'متعطل'),
              filterChip('ready_for_delivery', 'جاهز للتسليم'),
            ],
          ),
        ),
      ],
    );
  }

  Widget filterChip(String value, String label) {
    return Padding(
      padding: const EdgeInsetsDirectional.only(end: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: statusFilter == value,
        onSelected: (_) => setState(() => statusFilter = value),
      ),
    );
  }

  Widget statCard(String title, Object value, IconData icon, Color color) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            CircleAvatar(
              backgroundColor: color.withValues(alpha: .12),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(title, style: const TextStyle(color: AlshaariColors.slate)),
                  const SizedBox(height: 4),
                  Text(
                    '$value',
                    style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget projectCard(Map<String, dynamic> project) {
    final stages = (project['stages'] as List?)
            ?.map((raw) => Map<String, dynamic>.from(raw as Map))
            .toList() ??
        [];
    final orders = (project['orders'] as List?)
            ?.map((raw) => Map<String, dynamic>.from(raw as Map))
            .toList() ??
        [];
    final progress = asInt(project['progress_percent']).clamp(0, 100);
    final status = '${project['status'] ?? 'new'}';
    final color = statusColor(status);
    final cost = Map<String, dynamic>.from((project['cost_breakdown'] as Map?) ?? {});

    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CircleAvatar(
                  backgroundColor: color.withValues(alpha: .12),
                  child: Icon(Icons.foundation_outlined, color: color),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${project['project_code'] ?? ''} - ${project['name'] ?? ''}',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 3),
                      Text(
                        'العقد: ${amount(project['contract_value'])} | التكلفة: ${amount(project['actual_cost'])} | الربح المتوقع: ${amount(project['expected_profit'])}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                    ],
                  ),
                ),
                Chip(
                  label: Text('${project['status_label'] ?? statusLabel(status)}'),
                  side: BorderSide(color: color.withValues(alpha: .35)),
                ),
              ],
            ),
            const SizedBox(height: 12),
            LinearProgressIndicator(value: progress / 100, color: color),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(child: Text('إنجاز المشروع: $progress%')),
                Text('الهامش: ${project['profit_margin_percent'] ?? 0}%'),
              ],
            ),
            const SizedBox(height: 12),
            costStrip(cost),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.end,
              children: [
                OutlinedButton.icon(
                  onPressed: saving ? null : () => bootstrapStages(project),
                  icon: const Icon(Icons.auto_fix_high),
                  label: Text(stages.isEmpty ? 'إنشاء المراحل' : 'استكمال المراحل'),
                ),
                FilledButton.icon(
                  onPressed: saving ? null : () => addStage(project),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة مرحلة'),
                ),
                FilledButton.icon(
                  onPressed: saving ? null : () => addOrder(project),
                  icon: const Icon(Icons.add_task),
                  label: const Text('أمر تشغيل'),
                ),
              ],
            ),
            const SizedBox(height: 8),
            productionOrdersSection(orders),
            const SizedBox(height: 8),
            if (stages.isEmpty)
              emptyState('لم يتم إنشاء مراحل لهذا المشروع بعد.')
            else
              ...stages.map(stageTile),
          ],
        ),
      ),
    );
  }

  Widget productionOrdersSection(List<Map<String, dynamic>> orders) {
    return ExpansionTile(
      tilePadding: EdgeInsets.zero,
      initiallyExpanded: orders.isNotEmpty,
      title: Text(
        'أوامر التشغيل (${orders.length})',
        style: const TextStyle(fontWeight: FontWeight.w900),
      ),
      children: orders.isEmpty
          ? [
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: emptyState('لا توجد أوامر تشغيل لهذا المشروع.'),
              ),
            ]
          : orders.map(orderTile).toList(),
    );
  }

  Widget orderTile(Map<String, dynamic> order) {
    final status = '${order['status'] ?? 'planned'}';
    final late = order['is_late'] == true;
    final color = late ? const Color(0xFFB3261E) : statusColor(status);
    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: late ? const Color(0xFFFFF7F2) : Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withValues(alpha: .30)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(Icons.assignment_outlined, color: color),
              const SizedBox(width: 8),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${order['order_no'] ?? ''} - ${order['item_description'] ?? ''}',
                      style: const TextStyle(fontWeight: FontWeight.w900),
                    ),
                    const SizedBox(height: 3),
                    Text(
                      'الكمية: ${amount(order['qty'])} ${order['unit'] ?? ''} | المرحلة: ${order['stage_name'] ?? '-'} | الأولوية: ${order['priority_label'] ?? '-'}',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    if (order['planned_end_date'] != null)
                      Text(
                        'التسليم المخطط: ${order['planned_end_date']}',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                  ],
                ),
              ),
              Chip(
                label: Text('${order['status_label'] ?? statusLabel(status)}'),
                side: BorderSide(color: color.withValues(alpha: .35)),
              ),
            ],
          ),
          if ((order['notes'] ?? '').toString().trim().isNotEmpty) ...[
            const SizedBox(height: 6),
            Text('${order['notes']}', style: Theme.of(context).textTheme.bodySmall),
          ],
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.end,
            children: [
              OutlinedButton.icon(
                onPressed: saving ? null : () => updateOrderStatus(order, 'released'),
                icon: const Icon(Icons.verified_outlined),
                label: const Text('اعتماد'),
              ),
              OutlinedButton.icon(
                onPressed: saving ? null : () => updateOrderStatus(order, 'in_progress'),
                icon: const Icon(Icons.play_arrow),
                label: const Text('تشغيل'),
              ),
              OutlinedButton.icon(
                onPressed: saving ? null : () => updateOrderStatus(order, 'blocked'),
                icon: const Icon(Icons.report_problem_outlined),
                label: const Text('تعطيل'),
              ),
              FilledButton.icon(
                onPressed: saving ? null : () => updateOrderStatus(order, 'done'),
                icon: const Icon(Icons.check),
                label: const Text('إنهاء'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget costStrip(Map<String, dynamic> cost) {
    final items = [
      ('مواد', cost['materials'], Icons.category_outlined),
      ('عمالة', cost['labor'], Icons.engineering_outlined),
      ('تشغيل', cost['overhead'], Icons.bolt_outlined),
      ('تكاليف مباشرة', cost['manual_project_costs'], Icons.receipt_long),
    ];
    return LayoutBuilder(
      builder: (context, constraints) {
        final wide = constraints.maxWidth > 720;
        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: wide ? 4 : 2,
          childAspectRatio: wide ? 3.1 : 2.2,
          mainAxisSpacing: 8,
          crossAxisSpacing: 8,
          children: items
              .map(
                (item) => Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: AlshaariColors.pearl,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AlshaariColors.border),
                  ),
                  child: Row(
                    children: [
                      Icon(item.$3, color: AlshaariColors.deepGreen, size: 20),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text(item.$1, style: Theme.of(context).textTheme.bodySmall),
                            Text(
                              amount(item.$2),
                              style: const TextStyle(fontWeight: FontWeight.w900),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }

  Widget stageTile(Map<String, dynamic> stage) {
    final status = '${stage['status'] ?? 'not_started'}';
    final color = statusColor(status);
    final progress = asInt(stage['progress_percent']).clamp(0, 100);
    final late = stage['is_late'] == true;
    return Container(
      margin: const EdgeInsets.only(top: 8),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: late ? const Color(0xFFFFF7F2) : Colors.white,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: late ? const Color(0xFFB3261E) : color.withValues(alpha: .25),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(late ? Icons.schedule : Icons.drag_indicator, color: color),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  '${stage['stage_order']}. ${stage['name']}',
                  style: const TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
              Text('${stage['status_label'] ?? statusLabel(status)} | $progress%'),
            ],
          ),
          const SizedBox(height: 6),
          if (stage['planned_start_date'] != null || stage['planned_end_date'] != null)
            Text(
              'المخطط: ${stage['planned_start_date'] ?? '-'} إلى ${stage['planned_end_date'] ?? '-'}',
              style: Theme.of(context).textTheme.bodySmall,
            ),
          if ((stage['notes'] ?? '').toString().trim().isNotEmpty)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Text(
                '${stage['notes']}',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
          const SizedBox(height: 8),
          LinearProgressIndicator(value: progress / 100, color: color),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            alignment: WrapAlignment.end,
            children: [
              OutlinedButton.icon(
                onPressed: saving ? null : () => updateStage(stage, 'in_progress'),
                icon: const Icon(Icons.play_arrow),
                label: const Text('بدء'),
              ),
              OutlinedButton.icon(
                onPressed: saving
                    ? null
                    : () => updateStage(stage, 'blocked', progress: progress),
                icon: const Icon(Icons.report_problem_outlined),
                label: const Text('تعطيل'),
              ),
              FilledButton.icon(
                onPressed:
                    saving ? null : () => updateStage(stage, 'done', progress: 100),
                icon: const Icon(Icons.check),
                label: const Text('إكمال'),
              ),
              IconButton(
                tooltip: 'تعديل',
                onPressed: saving ? null : () => editStage(stage),
                icon: const Icon(Icons.edit_outlined),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget emptyState(String text) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          children: [
            const Icon(
              Icons.precision_manufacturing_outlined,
              size: 44,
              color: AlshaariColors.copper,
            ),
            const SizedBox(height: 10),
            Text(text, textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }
}
