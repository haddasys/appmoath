import 'dart:async';
import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../../app/theme.dart';
import '../../../core/config.dart';
import '../../../core/network/connectivity_service.dart';
import '../../../core/permissions.dart';
import '../../../core/sync/sync_models.dart';
import '../../../core/sync/sync_service.dart';
import '../../../core/widgets/alshaari_settlement_button.dart';
import '../../../core/widgets/alshaari_ui.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  final dio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 10),
      receiveTimeout: const Duration(seconds: 10),
    ),
  );

  final NumberFormat _numberFormat = NumberFormat.decimalPattern('ar');

  bool loading = true;
  bool autoSyncing = false;
  String? error;
  Map<String, dynamic> data = {};
  Set<String> permissions = {};
  SyncStatusSnapshot? localSyncStatus;
  ConnectivitySnapshot? connection;

  @override
  void initState() {
    super.initState();
    configureAndLoad();
  }

  Future<void> configureAndLoad() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ??
        prefs.getString('access_token') ??
        prefs.getString('auth_token');

    if (token == null || token.isEmpty) {
      if (!mounted) return;
      setState(() {
        loading = false;
        error = 'انتهت الجلسة. سجل الدخول مرة أخرى لعرض لوحة القيادة.';
      });
      context.go('/login');
      return;
    }

    dio.options.headers['Authorization'] = 'Bearer $token';
    permissions = await AlshaariPermissions.currentPermissions();
    unawaited(refreshOfflineStatus());
    await loadDashboard();
  }

  Future<void> refreshOfflineStatus() async {
    try {
      final status = await syncService.localStatus();
      final snapshot = await connectivityService.status();
      if (!mounted) return;
      setState(() {
        localSyncStatus = status;
        connection = snapshot;
      });
    } catch (_) {
      // Dashboard should keep working even if local sync status is unavailable.
    }
  }

  Future<void> loadDashboard({bool runAutoSync = false}) async {
    setState(() {
      if (data.isEmpty) loading = true;
      error = null;
    });

    try {
      Response response;
      try {
        response = await dio.get('/api/v1/dashboard');
      } catch (_) {
        response = await dio.get('/dashboard');
      }

      if (!mounted) return;
      setState(() {
        data = Map<String, dynamic>.from(response.data as Map);
        loading = false;
      });

      if (runAutoSync) {
        unawaited(_refreshAndSyncAfterFirstPaint());
      } else {
        unawaited(refreshOfflineStatus());
      }
    } catch (e) {
      if (!mounted) return;
      if (e is DioException &&
          (e.response?.statusCode == 401 || e.response?.statusCode == 403)) {
        setState(() {
          loading = false;
          error = 'لا توجد صلاحية أو انتهت الجلسة. سجل الدخول مرة أخرى.';
        });
        context.go('/login');
        return;
      }

      setState(() {
        loading = false;
        error = 'فشل تحميل لوحة القيادة. تأكد أن الخادم يعمل ثم أعد المحاولة.';
      });
      unawaited(refreshOfflineStatus());
    }
  }

  Future<void> _refreshAndSyncAfterFirstPaint() async {
    await Future<void>.delayed(const Duration(milliseconds: 700));
    await refreshOfflineStatus();
    await autoSyncPending();
  }

  Future<void> autoSyncPending() async {
    if (autoSyncing) return;

    final localStatus = await syncService.localStatus();
    if (localStatus.pending == 0 && localStatus.failed == 0) return;

    autoSyncing = true;
    try {
      final result = await syncService.pushPending();
      if (!mounted || !result.hasWork) return;

      final message = result.failed > 0 || result.conflict > 0
          ? 'توجد عمليات لم تكتمل مزامنتها. راجع شاشة المزامنة.'
          : 'تمت مزامنة ${result.synced} عملية محلية بنجاح.';
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(message),
          action: SnackBarAction(
            label: 'عرض',
            onPressed: () => context.push('/sync-status'),
          ),
        ),
      );

      if (result.synced > 0 && mounted) {
        await refreshOfflineStatus();
        await loadDashboard(runAutoSync: false);
      }
    } catch (_) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: const Text(
            'توجد عمليات محلية بانتظار المزامنة. سيتم إرسالها عند توفر الاتصال.',
          ),
          action: SnackBarAction(
            label: 'عرض',
            onPressed: () => context.push('/sync-status'),
          ),
        ),
      );
    } finally {
      autoSyncing = false;
      await refreshOfflineStatus();
    }
  }

  dynamic valueOf(String primary, String fallback) =>
      data[primary] ?? data[fallback] ?? 0;

  num numberOf(String primary, String fallback) {
    final value = valueOf(primary, fallback);
    if (value is num) return value;
    return num.tryParse(value.toString()) ?? 0;
  }

  String moneyOf(String primary, String fallback) {
    final value = numberOf(primary, fallback);
    return '${_numberFormat.format(value)} ريال';
  }

  bool canAny(Iterable<String> required) =>
      AlshaariPermissions.hasAny(permissions, required);

  Widget _statusBanner() {
    final status = localSyncStatus;
    final hasLocalWork = status != null &&
        (status.pending + status.syncing + status.failed + status.conflict) > 0;
    final online = connection?.canUseServer == true;
    final color = !online
        ? AlshaariColors.warning
        : hasLocalWork
            ? AlshaariColors.copper
            : AlshaariColors.success;
    final title = !online
        ? 'وضع العمل بدون اتصال'
        : hasLocalWork
            ? 'عمليات محلية بانتظار المزامنة'
            : 'متصل بالخادم';
    final message = !online
        ? 'يمكن إنشاء المسودات المدعومة محليًا، وستتم مزامنتها عند عودة الاتصال.'
        : hasLocalWork
            ? 'بانتظار: ${status.pending} | جارية: ${status.syncing} | فاشلة: ${status.failed} | تعارض: ${status.conflict}'
            : 'لا توجد عمليات معلقة على هذا الجهاز.';

    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .10),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withValues(alpha: .28)),
      ),
      child: Row(
        children: [
          Icon(!online ? Icons.cloud_off_outlined : Icons.cloud_done_outlined,
              color: color),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(color: color, fontWeight: FontWeight.w900),
                ),
                const SizedBox(height: 3),
                Text(message),
              ],
            ),
          ),
          TextButton.icon(
            onPressed: () => context
                .push('/sync-status')
                .then((_) => refreshOfflineStatus()),
            icon: const Icon(Icons.sync_outlined),
            label: const Text('المزامنة'),
          ),
          if (hasLocalWork && online) ...[
            const SizedBox(width: 4),
            FilledButton.icon(
              onPressed: autoSyncing ? null : autoSyncPending,
              icon: const Icon(Icons.cloud_sync_outlined),
              label: const Text('مزامنة الآن'),
            ),
          ],
        ],
      ),
    );
  }

  List<Widget> _executiveCards() {
    final netCash = numberOf('net_cash_today', 'netCashToday');
    return [
      AlshaariStatCard(
        title: 'النقد المتاح',
        value: moneyOf('cash_balance', 'cashBalance'),
        subtitle: 'إجمالي الصناديق والمحافظ النشطة',
        icon: Icons.account_balance_wallet_outlined,
        color: AlshaariColors.deepGreen,
      ),
      AlshaariStatCard(
        title: 'مقبوضات اليوم',
        value: moneyOf('today_receipts', 'todayReceipts'),
        subtitle: 'قبض العملاء والدفعات المقدمة',
        icon: Icons.south_west,
        color: AlshaariColors.success,
      ),
      AlshaariStatCard(
        title: 'مدفوعات اليوم',
        value: moneyOf('today_payments', 'todayPayments'),
        subtitle: 'مصروفات، موردون، رواتب وسلف',
        icon: Icons.north_east,
        color: AlshaariColors.danger,
      ),
      AlshaariStatCard(
        title: 'صافي حركة اليوم',
        value: '${_numberFormat.format(netCash)} ريال',
        subtitle: netCash >= 0 ? 'تدفق نقدي موجب' : 'تدفق نقدي سالب',
        icon: Icons.payments_outlined,
        color: netCash >= 0 ? AlshaariColors.success : AlshaariColors.danger,
      ),
    ];
  }

  List<Widget> _riskCards() {
    return [
      AlshaariStatCard(
        title: 'بانتظار الاعتماد',
        value: '${valueOf('draft_transactions', 'draftTransactions')}',
        subtitle: 'مسودات لا تؤثر محاسبيًا قبل الاعتماد',
        icon: Icons.pending_actions_outlined,
        color: AlshaariColors.warning,
      ),
      AlshaariStatCard(
        title: 'ذمم العملاء',
        value: moneyOf('receivables_due', 'receivablesDue'),
        subtitle: 'مبالغ مستحقة التحصيل',
        icon: Icons.person_search_outlined,
        color: AlshaariColors.info,
      ),
      AlshaariStatCard(
        title: 'ذمم الموردين',
        value: moneyOf('payables_due', 'payablesDue'),
        subtitle: 'التزامات واجبة المتابعة',
        icon: Icons.local_shipping_outlined,
        color: AlshaariColors.copper,
      ),
      AlshaariStatCard(
        title: 'السلف المفتوحة',
        value: moneyOf('open_worker_advances', 'openWorkerAdvances'),
        subtitle: 'ذمم على العمال لم تتم تسويتها',
        icon: Icons.assignment_ind_outlined,
        color: AlshaariColors.warning,
      ),
      AlshaariStatCard(
        title: 'المشاريع النشطة',
        value: '${valueOf('active_projects', 'activeProjects')}',
        subtitle: 'مشاريع لم تغلق تشغيليًا أو ماليًا',
        icon: Icons.work_outline,
        color: AlshaariColors.walnut,
      ),
      AlshaariStatCard(
        title: 'العملاء والموردون',
        value:
            '${valueOf('customers_count', 'customersCount')} / ${valueOf('suppliers_count', 'suppliersCount')}',
        subtitle: 'عملاء / موردون في قاعدة البيانات',
        icon: Icons.groups_2_outlined,
        color: AlshaariColors.slate,
      ),
    ];
  }

  Widget _responsiveCards(List<Widget> cards) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 720) {
          return Column(
            children: cards
                .map(
                  (card) => Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: card,
                  ),
                )
                .toList(),
          );
        }

        return GridView.count(
          crossAxisCount: constraints.maxWidth >= 1100 ? 4 : 3,
          childAspectRatio: constraints.maxWidth >= 1100 ? 2.45 : 2.3,
          crossAxisSpacing: 8,
          mainAxisSpacing: 8,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          children: cards,
        );
      },
    );
  }

  Widget _quickActions() {
    final actions = [
      ('مستند جديد', Icons.add_circle_outline, '/documents/new', true),
      ('سند قبض', Icons.receipt_long_outlined, '/receipt-voucher', true),
      ('سند صرف', Icons.payments_outlined, '/payment-voucher', true),
      ('صرف سلفة', Icons.assignment_ind_outlined, '/advance-payment', false),
      (
        'اعتماد المستندات',
        Icons.fact_check_outlined,
        '/documents-review',
        true
      ),
      ('المشتريات', Icons.shopping_cart_checkout, '/purchases', false),
      ('المخزون', Icons.inventory_2_outlined, '/inventory', false),
      ('المزامنة', Icons.sync_outlined, '/sync-status', false),
      ('الرواتب', Icons.request_quote_outlined, '/payroll', false),
      ('مراكز التكلفة', Icons.account_tree_outlined, '/cost-centers', false),
      ('التقارير', Icons.bar_chart_outlined, '/reports', false),
    ];

    return AlshaariSectionCard(
      title: 'الإجراءات السريعة',
      subtitle: 'اختصارات للعمليات اليومية الأكثر استخدامًا في النظام المالي.',
      icon: Icons.flash_on_outlined,
      child: LayoutBuilder(
        builder: (context, constraints) {
          final wide = constraints.maxWidth >= 780;
          return GridView.count(
            crossAxisCount: wide ? 5 : 2,
            childAspectRatio: wide ? 2.7 : 2.25,
            crossAxisSpacing: 8,
            mainAxisSpacing: 8,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              ...actions.map(
                (action) => AlshaariActionButton(
                  label: action.$1,
                  icon: action.$2,
                  primary: action.$4,
                  onPressed: () =>
                      context.push(action.$3).then((_) => loadDashboard()),
                ),
              ),
              if (canAny(const [
                'manage_settlements',
                'approve_adjustment_journal',
                'transactions.write',
                'inventory.write',
                'purchases.write',
                'project_costs.write',
              ]))
                const AlshaariSettlementButton(contextType: 'dashboard'),
            ],
          );
        },
      ),
    );
  }

  Widget _managementLinks() {
    final links = [
      ('العملاء', Icons.people_alt_outlined, '/customers'),
      ('الموردون', Icons.local_shipping_outlined, '/suppliers'),
      ('المشاريع', Icons.work_outline, '/projects'),
      ('العمال والحضور', Icons.groups_2_outlined, '/employees'),
      ('الفواتير والذمم', Icons.receipt_long_outlined, '/invoices'),
      ('كشوف الحساب', Icons.manage_search_outlined, '/statements'),
      ('دورة المشتريات', Icons.shopping_cart_checkout, '/purchases'),
      (
        'تقرير المشتريات والمخزون',
        Icons.inventory_2_outlined,
        '/reports?tab=purchases-inventory'
      ),
      (
        'الفترات المالية',
        Icons.event_available_outlined,
        '/accounting-periods'
      ),
      ('الصلاحيات', Icons.admin_panel_settings_outlined, '/access-control'),
      ('المراجعة والتدقيق', Icons.manage_history_outlined, '/audit'),
      ('إعدادات الشركة', Icons.business_outlined, '/settings'),
    ];

    return AlshaariSectionCard(
      title: 'التشغيل والإدارة',
      subtitle: 'تنقل منظم للوحدات المالية والتشغيلية والرقابية.',
      icon: Icons.apps_outlined,
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: links.map((link) {
          return ActionChip(
            avatar: Icon(link.$2, color: AlshaariColors.copper, size: 18),
            label: Text(link.$1),
            onPressed: () => context.push(link.$3).then((_) => loadDashboard()),
          );
        }).toList(),
      ),
    );
  }

  Widget _alertsPanel() {
    final draft = numberOf('draft_transactions', 'draftTransactions');
    final payables = numberOf('payables_due', 'payablesDue');
    final advances = numberOf('open_worker_advances', 'openWorkerAdvances');

    final alerts =
        <({String title, String message, IconData icon, Color color})>[
      if (draft > 0)
        (
          title: 'مستندات غير معتمدة',
          message:
              'يوجد $draft مستند بانتظار الاعتماد. راجعها قبل إقفال اليوم.',
          icon: Icons.pending_actions_outlined,
          color: AlshaariColors.warning,
        ),
      if (payables > 0)
        (
          title: 'التزامات موردين',
          message:
              'راجع جدول الدفع حتى لا تتأخر مستحقات الموردين أو تتكرر الدفعات.',
          icon: Icons.local_shipping_outlined,
          color: AlshaariColors.copper,
        ),
      if (advances > 0)
        (
          title: 'سلف مفتوحة',
          message: 'يجب تسوية السلف قبل تحميلها على المشاريع أو الرواتب.',
          icon: Icons.assignment_ind_outlined,
          color: AlshaariColors.warning,
        ),
    ];

    if (alerts.isEmpty) {
      return const AlshaariSectionCard(
        title: 'مركز الرقابة',
        subtitle: 'لا توجد تنبيهات مالية حرجة حاليًا.',
        icon: Icons.verified_user_outlined,
        child: AlshaariEmptyState(
          title: 'الوضع مستقر',
          subtitle: 'لا توجد مستندات معلقة أو تنبيهات تتطلب إجراءً فوريًا.',
          icon: Icons.check_circle_outline,
        ),
      );
    }

    return AlshaariSectionCard(
      title: 'مركز الرقابة',
      subtitle: 'تنبيهات تساعد الإدارة على إغلاق اليوم المالي بشكل منضبط.',
      icon: Icons.health_and_safety_outlined,
      child: Column(
        children: alerts.map((alert) {
          return Container(
            margin: const EdgeInsets.only(bottom: 8),
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: alert.color.withValues(alpha: .10),
              border: Border.all(color: alert.color.withValues(alpha: .22)),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                Icon(alert.icon, color: alert.color),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        alert.title,
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                      const SizedBox(height: 2),
                      Text(alert.message),
                    ],
                  ),
                ),
              ],
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _closingChecklist() {
    final items = [
      (
        'اعتماد المستندات',
        'لا تظهر المسودات في القيود حتى تعتمد.',
        Icons.fact_check_outlined,
        numberOf('draft_transactions', 'draftTransactions') == 0
      ),
      (
        'مراجعة النقدية',
        'قارن أرصدة الصناديق والمحافظ مع الواقع.',
        Icons.account_balance_wallet_outlined,
        true
      ),
      (
        'متابعة الذمم',
        'راجع المستحق على العملاء والموردين.',
        Icons.balance_outlined,
        true
      ),
      (
        'تسوية السلف',
        'السلفة ذمة على العامل وليست مصروفًا.',
        Icons.assignment_ind_outlined,
        numberOf('open_worker_advances', 'openWorkerAdvances') == 0
      ),
    ];

    return AlshaariSectionCard(
      title: 'قائمة إقفال اليوم',
      subtitle: 'خطوات رقابية مختصرة قبل اعتماد التقارير اليومية.',
      icon: Icons.checklist_rtl_outlined,
      child: Column(
        children: items.map((item) {
          final done = item.$4;
          return ListTile(
            contentPadding: EdgeInsets.zero,
            leading: CircleAvatar(
              backgroundColor: done
                  ? AlshaariColors.success.withValues(alpha: .12)
                  : AlshaariColors.warning.withValues(alpha: .14),
              child: Icon(
                done ? Icons.check : item.$3,
                color: done ? AlshaariColors.success : AlshaariColors.warning,
              ),
            ),
            title: Text(
              item.$1,
              style: const TextStyle(fontWeight: FontWeight.w800),
            ),
            subtitle: Text(item.$2),
          );
        }).toList(),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 34),
              SizedBox(width: 10),
              Text('الشعري المالي'),
            ],
          ),
          actions: [
            IconButton(
              tooltip: 'تحديث',
              onPressed: loadDashboard,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
        body: loading
            ? const AlshaariLoading(label: 'جاري تحميل لوحة القيادة...')
            : error != null
                ? AlshaariErrorState(message: error!, onRetry: loadDashboard)
                : RefreshIndicator(
                    onRefresh: loadDashboard,
                    child: ListView(
                      padding: const EdgeInsets.all(16),
                      children: [
                        const AlshaariPageHeader(
                          title: 'لوحة القيادة التنفيذية',
                          subtitle:
                              'نظرة مالية وتشغيلية على النقدية، الذمم، الاعتمادات، السلف والمشاريع.',
                          icon: Icons.dashboard_customize_outlined,
                        ),
                        const SizedBox(height: 12),
                        _statusBanner(),
                        const SizedBox(height: 12),
                        AlshaariSectionCard(
                          title: 'المركز المالي المختصر',
                          subtitle:
                              'أرقام اليوم التي يحتاجها المدير قبل اتخاذ القرار.',
                          icon: Icons.insights_outlined,
                          child: _responsiveCards(_executiveCards()),
                        ),
                        const SizedBox(height: 12),
                        AlshaariSectionCard(
                          title: 'الرقابة والمخاطر',
                          subtitle:
                              'بنود تحتاج متابعة محاسبية أو تشغيلية قبل الإقفال.',
                          icon: Icons.admin_panel_settings_outlined,
                          child: _responsiveCards(_riskCards()),
                        ),
                        const SizedBox(height: 12),
                        _quickActions(),
                        const SizedBox(height: 12),
                        LayoutBuilder(
                          builder: (context, constraints) {
                            if (constraints.maxWidth < 920) {
                              return Column(
                                children: [
                                  _alertsPanel(),
                                  const SizedBox(height: 12),
                                  _closingChecklist(),
                                ],
                              );
                            }
                            return Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Expanded(child: _alertsPanel()),
                                const SizedBox(width: 12),
                                Expanded(child: _closingChecklist()),
                              ],
                            );
                          },
                        ),
                        const SizedBox(height: 12),
                        _managementLinks(),
                      ],
                    ),
                  ),
      ),
    );
  }
}
