import 'package:flutter/material.dart';

import '../../app/theme.dart';

class AlshaariPageHeader extends StatelessWidget {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget? trailing;

  const AlshaariPageHeader({
    super.key,
    required this.title,
    required this.subtitle,
    required this.icon,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AlshaariColors.matteBlack,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AlshaariColors.gold.withOpacity(.55)),
      ),
      child: Row(
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: AlshaariColors.copper.withOpacity(.22),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: AlshaariColors.gold),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: textTheme.titleLarge?.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w900,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: textTheme.bodySmall?.copyWith(
                    color: const Color(0xFFE8DDC8),
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: 8),
            trailing!,
          ],
        ],
      ),
    );
  }
}

class AlshaariSectionCard extends StatelessWidget {
  final String? title;
  final String? subtitle;
  final IconData? icon;
  final Widget child;
  final EdgeInsetsGeometry padding;

  const AlshaariSectionCard({
    super.key,
    this.title,
    this.subtitle,
    this.icon,
    required this.child,
    this.padding = const EdgeInsets.all(14),
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: padding,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (title != null) ...[
              Row(
                children: [
                  if (icon != null) ...[
                    Icon(icon, color: AlshaariColors.copper, size: 20),
                    const SizedBox(width: 8),
                  ],
                  Expanded(
                    child: Text(
                      title!,
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                            fontWeight: FontWeight.w900,
                          ),
                    ),
                  ),
                ],
              ),
              if (subtitle != null) ...[
                const SizedBox(height: 4),
                Text(subtitle!, style: Theme.of(context).textTheme.bodySmall),
              ],
              const SizedBox(height: 12),
            ],
            child,
          ],
        ),
      ),
    );
  }
}

class AlshaariStatCard extends StatelessWidget {
  final String title;
  final String value;
  final IconData icon;
  final Color color;
  final String? subtitle;

  const AlshaariStatCard({
    super.key,
    required this.title,
    required this.value,
    required this.icon,
    this.color = AlshaariColors.copper,
    this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(
                color: color.withOpacity(.12),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 3),
                  AlshaariMoneyText(value),
                  if (subtitle != null) ...[
                    const SizedBox(height: 2),
                    Text(
                      subtitle!,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class AlshaariMoneyText extends StatelessWidget {
  final String value;
  final bool danger;
  final double fontSize;

  const AlshaariMoneyText(
    this.value, {
    super.key,
    this.danger = false,
    this.fontSize = 18,
  });

  @override
  Widget build(BuildContext context) {
    return Text(
      value,
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
      style: TextStyle(
        color: danger ? AlshaariColors.danger : AlshaariColors.ink,
        fontSize: fontSize,
        fontWeight: FontWeight.w900,
      ),
    );
  }
}

class AlshaariActionButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final VoidCallback onPressed;
  final bool primary;

  const AlshaariActionButton({
    super.key,
    required this.label,
    required this.icon,
    required this.onPressed,
    this.primary = false,
  });

  @override
  Widget build(BuildContext context) {
    final child = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 20),
        const SizedBox(width: 8),
        Flexible(
          child: Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );

    return SizedBox(
      height: 52,
      child: primary
          ? FilledButton(onPressed: onPressed, child: child)
          : OutlinedButton(onPressed: onPressed, child: child),
    );
  }
}

class AlshaariStatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final IconData? icon;

  const AlshaariStatusBadge({
    super.key,
    required this.label,
    required this.color,
    this.icon,
  });

  factory AlshaariStatusBadge.byStatus(String? status) {
    switch (status) {
      case 'approved':
        return const AlshaariStatusBadge(
          label: 'معتمدة',
          color: AlshaariColors.success,
          icon: Icons.verified_outlined,
        );
      case 'rejected':
        return const AlshaariStatusBadge(
          label: 'مرفوضة',
          color: AlshaariColors.danger,
          icon: Icons.cancel_outlined,
        );
      case 'reversed':
        return const AlshaariStatusBadge(
          label: 'معكوسة',
          color: AlshaariColors.slate,
          icon: Icons.undo_outlined,
        );
      default:
        return const AlshaariStatusBadge(
          label: 'مسودة',
          color: AlshaariColors.warning,
          icon: Icons.pending_actions,
        );
    }
  }

  factory AlshaariStatusBadge.bySyncStatus(String? status) {
    switch (status) {
      case 'synced':
        return const AlshaariStatusBadge(
          label: 'تمت المزامنة',
          color: AlshaariColors.success,
          icon: Icons.cloud_done_outlined,
        );
      case 'failed':
        return const AlshaariStatusBadge(
          label: 'فشل',
          color: AlshaariColors.danger,
          icon: Icons.error_outline,
        );
      case 'conflict':
        return const AlshaariStatusBadge(
          label: 'تعارض',
          color: AlshaariColors.warning,
          icon: Icons.report_problem_outlined,
        );
      case 'syncing':
        return const AlshaariStatusBadge(
          label: 'جارية',
          color: AlshaariColors.info,
          icon: Icons.sync_outlined,
        );
      case 'pending':
      case 'pending_sync':
        return const AlshaariStatusBadge(
          label: 'بانتظار المزامنة',
          color: AlshaariColors.copper,
          icon: Icons.schedule_outlined,
        );
      default:
        return const AlshaariStatusBadge(
          label: 'محلي',
          color: AlshaariColors.slate,
          icon: Icons.phone_iphone_outlined,
        );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Chip(
      avatar: icon == null ? null : Icon(icon, size: 16, color: color),
      label: Text(label),
      backgroundColor: color.withOpacity(.12),
      labelStyle: TextStyle(color: color, fontWeight: FontWeight.w800),
      side: BorderSide(color: color.withOpacity(.24)),
    );
  }
}

class AlshaariEmptyState extends StatelessWidget {
  final String title;
  final String? subtitle;
  final IconData icon;

  const AlshaariEmptyState({
    super.key,
    required this.title,
    this.subtitle,
    this.icon = Icons.inbox_outlined,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 56),
      child: Column(
        children: [
          Icon(icon, size: 46, color: AlshaariColors.slate),
          const SizedBox(height: 10),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          if (subtitle != null) ...[
            const SizedBox(height: 4),
            Text(subtitle!, textAlign: TextAlign.center),
          ],
        ],
      ),
    );
  }
}

class AlshaariErrorState extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;

  const AlshaariErrorState({
    super.key,
    required this.message,
    required this.onRetry,
  });

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(
              Icons.error_outline,
              size: 46,
              color: AlshaariColors.danger,
            ),
            const SizedBox(height: 10),
            Text(message, textAlign: TextAlign.center),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh),
              label: const Text('إعادة المحاولة'),
            ),
          ],
        ),
      ),
    );
  }
}

class AlshaariLoading extends StatelessWidget {
  final String? label;

  const AlshaariLoading({super.key, this.label});

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          const CircularProgressIndicator(),
          if (label != null) ...[
            const SizedBox(height: 12),
            Text(label!),
          ],
        ],
      ),
    );
  }
}

Future<bool> showAlshaariConfirmDialog({
  required BuildContext context,
  required String title,
  required String message,
  String confirmLabel = 'تأكيد',
}) async {
  final result = await showDialog<bool>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [
        TextButton(
          onPressed: () => Navigator.pop(context, false),
          child: const Text('إلغاء'),
        ),
        FilledButton(
          onPressed: () => Navigator.pop(context, true),
          child: Text(confirmLabel),
        ),
      ],
    ),
  );
  return result == true;
}
