class SyncQueueItem {
  final String id;
  final String localId;
  final String entityType;
  final String operation;
  final String payloadJson;
  final String status;
  final int retryCount;
  final String? errorMessage;
  final int createdAt;
  final int updatedAt;
  final int? syncedAt;

  const SyncQueueItem({
    required this.id,
    required this.localId,
    required this.entityType,
    required this.operation,
    required this.payloadJson,
    required this.status,
    required this.retryCount,
    required this.createdAt,
    required this.updatedAt,
    this.errorMessage,
    this.syncedAt,
  });

  factory SyncQueueItem.fromJson(Map<String, dynamic> json) {
    return SyncQueueItem(
      id: '${json['id']}',
      localId: '${json['local_id']}',
      entityType: '${json['entity_type']}',
      operation: '${json['operation']}',
      payloadJson: '${json['payload_json']}',
      status: '${json['status']}',
      retryCount: json['retry_count'] as int? ?? 0,
      errorMessage: json['error_message']?.toString(),
      createdAt: json['created_at'] as int? ?? 0,
      updatedAt: json['updated_at'] as int? ?? 0,
      syncedAt: json['synced_at'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'local_id': localId,
      'entity_type': entityType,
      'operation': operation,
      'payload_json': payloadJson,
      'status': status,
      'retry_count': retryCount,
      'error_message': errorMessage,
      'created_at': createdAt,
      'updated_at': updatedAt,
      'synced_at': syncedAt,
    };
  }

  SyncQueueItem copyWith({
    String? status,
    int? retryCount,
    String? errorMessage,
    int? updatedAt,
    int? syncedAt,
  }) {
    return SyncQueueItem(
      id: id,
      localId: localId,
      entityType: entityType,
      operation: operation,
      payloadJson: payloadJson,
      status: status ?? this.status,
      retryCount: retryCount ?? this.retryCount,
      errorMessage: errorMessage,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      syncedAt: syncedAt ?? this.syncedAt,
    );
  }
}
