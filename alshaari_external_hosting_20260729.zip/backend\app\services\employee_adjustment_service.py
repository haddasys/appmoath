from datetime import datetime

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session


ADJUSTMENT_TYPES = {
    "advance",
    "custody",
    "deduction",
    "bonus",
    "qat",
    "transport",
    "food",
    "overtime_amount",
    "other",
}


def create_adjustment(db: Session, data, user_id: int):
    if data.adjustment_type not in ADJUSTMENT_TYPES:
        raise HTTPException(status_code=400, detail="نوع تعديل العامل غير معتمد")
    if data.amount <= 0:
        raise HTTPException(status_code=400, detail="مبلغ التعديل يجب أن يكون أكبر من صفر")

    row = db.execute(
        text(
            """
            INSERT INTO employee_adjustments (
                employee_id, date, adjustment_type, amount, project_id,
                cost_center_id, description, status, created_by, created_at
            )
            VALUES (
                :employee_id, :date, :adjustment_type, :amount, :project_id,
                :cost_center_id, :description, 'draft', :created_by, CURRENT_TIMESTAMP
            )
            RETURNING *
            """
        ),
        {
            "employee_id": data.employee_id,
            "date": data.date,
            "adjustment_type": data.adjustment_type,
            "amount": data.amount,
            "project_id": data.project_id,
            "cost_center_id": data.cost_center_id,
            "description": data.description,
            "created_by": user_id,
        },
    ).mappings().first()
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'create_employee_adjustment', 'employee_adjustment', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {
            "user_id": user_id,
            "entity_id": row["id"],
            "details": data.description or data.adjustment_type,
        },
    )
    db.commit()
    return dict(row)


def approve_adjustment(db: Session, adjustment_id: int, user_id: int):
    row = db.execute(
        text(
            """
            UPDATE employee_adjustments
            SET status = 'approved',
                approved_by = :user_id,
                approved_at = :approved_at
            WHERE id = :id AND status = 'draft'
            RETURNING *
            """
        ),
        {"id": adjustment_id, "user_id": user_id, "approved_at": datetime.utcnow()},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد تعديل غير مسودة أو غير موجود")
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'approve_employee_adjustment', 'employee_adjustment', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": adjustment_id, "details": row["adjustment_type"]},
    )
    db.commit()
    return dict(row)


def reject_adjustment(db: Session, adjustment_id: int, user_id: int, reason: str | None):
    row = db.execute(
        text(
            """
            UPDATE employee_adjustments
            SET status = 'rejected'
            WHERE id = :id AND status = 'draft'
            RETURNING *
            """
        ),
        {"id": adjustment_id},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=400, detail="لا يمكن رفض تعديل غير مسودة أو غير موجود")
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'reject_employee_adjustment', 'employee_adjustment', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": adjustment_id, "details": reason or row["adjustment_type"]},
    )
    db.commit()
    return dict(row)
