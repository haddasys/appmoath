CREATE TABLE IF NOT EXISTS warehouses (
    id SERIAL PRIMARY KEY,
    code VARCHAR(40) UNIQUE NOT NULL,
    name VARCHAR(150) NOT NULL,
    type VARCHAR(30) DEFAULT 'general',
    project_id INTEGER NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO warehouses (code, name, type, project_id, is_active)
VALUES ('WH-GEN-001', 'المخزن العام', 'general', NULL, TRUE)
ON CONFLICT (code) DO UPDATE SET
    name = EXCLUDED.name,
    type = EXCLUDED.type,
    is_active = TRUE;

ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS warehouse_id INTEGER NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS cost_center_id INTEGER NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS supplier_invoice_id INTEGER NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS goods_receipt_id INTEGER NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS attachment_id INTEGER NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS movement_source VARCHAR(80) NULL;
ALTER TABLE inventory_movements ADD COLUMN IF NOT EXISTS movement_reference VARCHAR(120) NULL;

ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS warehouse_id INTEGER NULL;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS supplier_invoice_id INTEGER NULL;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS goods_receipt_id INTEGER NULL;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS attachment_id INTEGER NULL;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS movement_source VARCHAR(80) NULL;
ALTER TABLE stock_movements ADD COLUMN IF NOT EXISTS movement_reference VARCHAR(120) NULL;

ALTER TABLE attachments ADD COLUMN IF NOT EXISTS file_path VARCHAR(500) NULL;
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS file_type VARCHAR(80) NULL;
ALTER TABLE attachments ADD COLUMN IF NOT EXISTS entity_type VARCHAR(80) NULL;
