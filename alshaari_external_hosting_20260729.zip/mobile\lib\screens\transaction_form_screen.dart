import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';

class TransactionFormScreen extends StatefulWidget {
  const TransactionFormScreen({super.key});
  @override
  State<TransactionFormScreen> createState() => _TransactionFormScreenState();
}

class _TransactionFormScreenState extends State<TransactionFormScreen> {
  final formKey = GlobalKey<FormState>();
  bool loading = true;
  bool saving = false;
  List<dynamic> customers = [], suppliers = [], workers = [], projects = [], items = [];

  String? transactionType;
  String currency = 'YER';
  String paymentMethod = 'cash';
  String? costCategory;
  int? relatedId, projectId, itemId;
  String? relatedAccountType;

  final amount = TextEditingController();
  final qty = TextEditingController();
  final unitCost = TextEditingController();
  final description = TextEditingController();

  final types = const [
    {'value': 'receipt_from_customer', 'label': 'قبض من عميل'},
    {'value': 'general_payment', 'label': 'صرف عام'},
    {'value': 'material_purchase', 'label': 'شراء مواد'},
    {'value': 'material_issue_to_project', 'label': 'صرف مواد لمشروع'},
    {'value': 'customer_invoice', 'label': 'فاتورة عميل'},
    {'value': 'supplier_invoice', 'label': 'فاتورة مورد'},
    {'value': 'worker_wage', 'label': 'أجر عامل'},
    {'value': 'advance_payment', 'label': 'عهدة'},
    {'value': 'advance_settlement', 'label': 'تسوية عهدة'},
    {'value': 'cash_transfer', 'label': 'تحويل بين صناديق'},
  ];
  final currencies = const [
    {'value': 'YER', 'label': 'ريال يمني'},
    {'value': 'SAR', 'label': 'ريال سعودي'},
    {'value': 'USD', 'label': 'دولار'},
  ];
  final methods = const [
    {'value': 'cash', 'label': 'نقد'},
    {'value': 'kuraimi', 'label': 'كريمي'},
    {'value': 'bank', 'label': 'بنك'},
    {'value': 'transfer', 'label': 'حوالة'},
  ];
  final categories = const [
    {'value': 'wood', 'label': 'خشب'},
    {'value': 'paint', 'label': 'دهان'},
    {'value': 'accessories', 'label': 'إكسسوارات'},
    {'value': 'labor', 'label': 'أجور'},
    {'value': 'transport', 'label': 'نقل'},
    {'value': 'installation', 'label': 'تركيب'},
    {'value': 'general', 'label': 'مصروف عام'},
  ];

  @override
  void initState() { super.initState(); loadLookups(); }

  Future<List<dynamic>> getList(String path) async => (await apiClient.dio.get(path)).data as List<dynamic>;

  Future<void> loadLookups() async {
    try {
      final r = await Future.wait([getList('/customers'), getList('/suppliers'), getList('/workers'), getList('/projects'), getList('/items')]);
      if (!mounted) return;
      setState(() { customers = r[0]; suppliers = r[1]; workers = r[2]; projects = r[3]; items = r[4]; loading = false; });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل تحميل القوائم: $e')));
    }
  }

  bool requiresCustomer() => transactionType == 'receipt_from_customer' || transactionType == 'customer_invoice';
  bool requiresSupplier() => transactionType == 'material_purchase' || transactionType == 'supplier_invoice';
  bool requiresWorker() => transactionType == 'worker_wage' || transactionType == 'advance_payment' || transactionType == 'advance_settlement';
  bool requiresProject() => transactionType == 'material_issue_to_project' || transactionType == 'customer_invoice' || transactionType == 'worker_wage' || transactionType == 'receipt_from_customer';
  bool requiresItem() => transactionType == 'material_purchase' || transactionType == 'material_issue_to_project';
  bool requiresQty() => requiresItem();
  bool requiresCategory() => transactionType == 'general_payment' || transactionType == 'worker_wage' || transactionType == 'material_purchase' || transactionType == 'material_issue_to_project';

  List<dynamic> parties() { if (requiresCustomer()) return customers; if (requiresSupplier()) return suppliers; if (requiresWorker()) return workers; return []; }
  String partyTitle() { if (requiresCustomer()) return 'العميل'; if (requiresSupplier()) return 'المورد'; if (requiresWorker()) return 'العامل'; return 'الطرف'; }
  void updatePartyType() { if (requiresCustomer()) {
    relatedAccountType = 'customer';
  } else if (requiresSupplier()) relatedAccountType = 'supplier'; else if (requiresWorker()) relatedAccountType = 'worker'; else { relatedAccountType = null; relatedId = null; } }

  DropdownMenuItem<String> strItem(Map<String, String> e) => DropdownMenuItem(value: e['value'], child: Text(e['label'] ?? ''));
  Widget title(String t) => Padding(padding: const EdgeInsets.only(top: 14, bottom: 8), child: Text(t, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)));

  Widget lookup({required String label, required List<dynamic> data, required int? value, required ValueChanged<int?> onChanged, String Function(Map<String, dynamic>)? labelBuilder}) {
    return DropdownButtonFormField<int>(
      initialValue: value,
      decoration: InputDecoration(labelText: label, border: const OutlineInputBorder()),
      items: data.map((raw) {
        final e = Map<String, dynamic>.from(raw as Map);
        final txt = labelBuilder != null ? labelBuilder(e) : '${e['name'] ?? e['code'] ?? e['project_code'] ?? e['id']}';
        return DropdownMenuItem(value: e['id'] as int, child: Text(txt));
      }).toList(),
      onChanged: onChanged,
    );
  }

  Future<void> submit() async {
    updatePartyType();
    if (!formKey.currentState!.validate()) return;
    if (parties().isNotEmpty && relatedId == null) { msg('اختر ${partyTitle()}'); return; }
    if (requiresProject() && projectId == null) { msg('اختر المشروع'); return; }
    if (requiresItem() && itemId == null) { msg('اختر المادة'); return; }
    if (requiresCategory() && costCategory == null) { msg('اختر بند التكلفة'); return; }
    setState(() => saving = true);
    try {
      final payload = {
        'date': DateTime.now().toIso8601String().substring(0, 10),
        'type': transactionType,
        'amount': double.tryParse(amount.text.trim()) ?? 0,
        'currency': currency,
        'payment_method': paymentMethod,
        'related_account_type': relatedAccountType,
        'related_id': relatedId,
        'project_id': projectId,
        'cost_category': costCategory,
        'item_id': itemId,
        'qty': double.tryParse(qty.text.trim()) ?? 0,
        'unit_cost': double.tryParse(unitCost.text.trim()) ?? 0,
        'description': buildDescription(),
      };
      final res = await apiClient.dio.post('/transactions', data: payload);
      if (!mounted) return;
      msg('تم حفظ الحركة كمسودة رقم ${res.data['id']}');
      Navigator.pop(context);
    } catch (e) { if (mounted) msg('فشل الحفظ: $e'); }
    finally { if (mounted) setState(() => saving = false); }
  }

  String buildDescription() {
    final parts = <String>[];
    if (description.text.trim().isNotEmpty) parts.add(description.text.trim());
    if (qty.text.trim().isNotEmpty) parts.add('الكمية: ${qty.text.trim()}');
    if (unitCost.text.trim().isNotEmpty) parts.add('تكلفة الوحدة: ${unitCost.text.trim()}');
    return parts.join(' | ');
  }
  void msg(String s) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(s)));

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('إضافة حركة موحدة')),
        body: loading ? const Center(child: CircularProgressIndicator()) : SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Form(key: formKey, child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            title('نوع العملية'),
            DropdownButtonFormField<String>(initialValue: transactionType, decoration: const InputDecoration(labelText: 'اختر نوع العملية', border: OutlineInputBorder()), items: types.map(strItem).toList(), validator: (v) => v == null ? 'اختر نوع العملية' : null, onChanged: (v) => setState(() { transactionType = v; relatedId = null; projectId = null; itemId = null; costCategory = null; })),
            if (transactionType != null) ...[
              title('بيانات المبلغ'),
              TextFormField(controller: amount, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'المبلغ', border: OutlineInputBorder()), validator: (v) => (double.tryParse((v ?? '').trim()) ?? 0) <= 0 ? 'أدخل مبلغًا صحيحًا' : null),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(initialValue: currency, decoration: const InputDecoration(labelText: 'العملة', border: OutlineInputBorder()), items: currencies.map(strItem).toList(), onChanged: (v) => setState(() => currency = v ?? 'YER')),
              const SizedBox(height: 10),
              DropdownButtonFormField<String>(initialValue: paymentMethod, decoration: const InputDecoration(labelText: 'طريقة الدفع', border: OutlineInputBorder()), items: methods.map(strItem).toList(), onChanged: (v) => setState(() => paymentMethod = v ?? 'cash')),
              if (parties().isNotEmpty) ...[title(partyTitle()), lookup(label: 'اختر ${partyTitle()}', data: parties(), value: relatedId, onChanged: (v) => setState(() => relatedId = v))],
              if (requiresProject()) ...[title('المشروع'), lookup(label: 'اختر المشروع', data: projects, value: projectId, onChanged: (v) => setState(() => projectId = v), labelBuilder: (e) => '${e['project_code'] ?? ''} - ${e['name'] ?? ''}')],
              if (requiresItem()) ...[
                title('المادة'), lookup(label: 'اختر المادة', data: items, value: itemId, onChanged: (v) => setState(() => itemId = v), labelBuilder: (e) => '${e['code'] ?? ''} - ${e['name'] ?? ''} | رصيد: ${e['current_qty'] ?? 0}'),
                const SizedBox(height: 10),
                TextFormField(controller: qty, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'الكمية', border: OutlineInputBorder()), validator: (v) => requiresQty() && ((double.tryParse((v ?? '').trim()) ?? 0) <= 0) ? 'أدخل كمية صحيحة' : null),
                const SizedBox(height: 10),
                TextFormField(controller: unitCost, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'تكلفة الوحدة - اختياري', border: OutlineInputBorder())),
              ],
              if (requiresCategory()) ...[title('بند التكلفة'), DropdownButtonFormField<String>(initialValue: costCategory, decoration: const InputDecoration(labelText: 'اختر بند التكلفة', border: OutlineInputBorder()), items: categories.map(strItem).toList(), onChanged: (v) => setState(() => costCategory = v))],
              title('البيان'),
              TextFormField(controller: description, maxLines: 3, decoration: const InputDecoration(labelText: 'ملاحظات أو بيان الحركة', border: OutlineInputBorder())),
              const SizedBox(height: 20),
              FilledButton.icon(onPressed: saving ? null : submit, icon: const Icon(Icons.save), label: Text(saving ? 'جاري الحفظ...' : 'حفظ كمسودة')),
            ]
          ])),
        ),
      ),
    );
  }
}
