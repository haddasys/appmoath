import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';
import '../../../core/printing/official_print.dart';
import '../../../core/printing/print_document.dart';
import '../../../core/widgets/alshaari_settlement_button.dart';

class StatementsScreen extends StatefulWidget {
  final String initialPartyType;
  final int? initialPartyId;

  const StatementsScreen({
    super.key,
    this.initialPartyType = 'customer',
    this.initialPartyId,
  });

  @override
  State<StatementsScreen> createState() => _StatementsScreenState();
}

class _StatementAmount extends StatelessWidget {
  final String label;
  final dynamic value;

  const _StatementAmount(this.label, this.value);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodySmall),
        const SizedBox(height: 4),
        Text(
          '$value',
          style: const TextStyle(fontWeight: FontWeight.w900),
        ),
      ],
    );
  }
}

class _StatementsScreenState extends State<StatementsScreen> {
  bool loading = true;
  bool statementLoading = false;

  late String partyType;
  int? partyId;

  List<dynamic> customers = [];
  List<dynamic> suppliers = [];
  Map<String, dynamic>? statement;
  CompanyPrintProfile printProfile = CompanyPrintProfile.defaults();
  final statementFromDateController = TextEditingController();
  final statementToDateController = TextEditingController();

  String get partyLabel => partyType == 'customer' ? 'العميل' : 'المورد';

  List<dynamic> get parties => partyType == 'customer' ? customers : suppliers;

  @override
  void initState() {
    super.initState();
    partyType = widget.initialPartyType == 'supplier' ? 'supplier' : 'customer';
    partyId = widget.initialPartyId;
    configureAndLoad();
  }

  @override
  void dispose() {
    statementFromDateController.dispose();
    statementToDateController.dispose();
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadParties();
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
      if (error.response?.statusCode == 403) {
        return 'لا تملك صلاحية تنفيذ هذه العملية';
      }
    }
    return 'حدث خطأ غير متوقع';
  }

  Future<List<dynamic>> getList(String endpoint) async {
    final res = await apiClient.dio.get(endpoint);
    if (res.data is List) return res.data as List<dynamic>;
    if (res.data is Map && res.data['items'] is List) {
      return res.data['items'] as List<dynamic>;
    }
    return [];
  }

  Future<void> loadParties() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        getList('/customers'),
        getList('/suppliers'),
        loadCompanyPrintProfile(),
      ]);
      if (!mounted) return;
      setState(() {
        customers = result[0] as List<dynamic>;
        suppliers = result[1] as List<dynamic>;
        printProfile = result[2] as CompanyPrintProfile;
        loading = false;
      });
      if (partyId != null) {
        await loadStatement();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل الأطراف: ${friendlyError(e)}');
    }
  }

  Future<void> loadStatement() async {
    if (partyId == null) {
      showMessage('اختر $partyLabel');
      return;
    }

    setState(() => statementLoading = true);
    try {
      final endpoint = statementEndpoint();
      final res = await apiClient.dio.get(endpoint);
      if (!mounted) return;
      setState(() {
        statement = Map<String, dynamic>.from(res.data as Map);
        statementLoading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => statementLoading = false);
      showMessage('فشل تحميل الكشف: ${friendlyError(e)}');
    }
  }

  String statementEndpoint() {
    final params = <String, String>{};
    final fromDate = statementFromDateController.text.trim();
    final toDate = statementToDateController.text.trim();
    if (fromDate.isNotEmpty) params['from_date'] = fromDate;
    if (toDate.isNotEmpty) params['to_date'] = toDate;
    final base = partyType == 'customer'
        ? '/customers/$partyId/statement'
        : '/suppliers/$partyId/statement';
    final query = Uri(queryParameters: params).query;
    return query.isEmpty ? base : '$base?$query';
  }

  Future<void> pickStatementDate(TextEditingController target) async {
    final now = DateTime.now();
    final selected = await showDatePicker(
      context: context,
      initialDate: now,
      firstDate: DateTime(now.year - 5),
      lastDate: DateTime(now.year + 1),
    );
    if (selected == null) return;
    target.text = selected.toIso8601String().substring(0, 10);
  }

  void showMessage(String message) {
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  DropdownMenuItem<int> partyItem(Map<String, dynamic> item) {
    final label = item['name'] ?? item['phone'] ?? item['id'];
    return DropdownMenuItem<int>(
      value: item['id'] as int,
      child: Text('$label', overflow: TextOverflow.ellipsis),
    );
  }

  String money(dynamic value) => '${value ?? 0}';

  String htmlEscape(Object? value) {
    return '${value ?? ''}'
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#39;');
  }

  String currentPartyName() {
    for (final raw in parties) {
      final item = Map<String, dynamic>.from(raw as Map);
      if (item['id'] == partyId) return '${item['name'] ?? item['id']}';
    }
    return '${statement?[partyType == 'customer' ? 'customer' : 'supplier'] ?? partyLabel}';
  }

  String printStyles(String title) {
    return officialPrintHeader(printProfile, title);
  }

  String buildStatementHtml() {
    final data = statement ?? {};
    final ledger = (data['ledger'] as List?) ?? [];
    final invoices = (data['invoices'] as List?) ?? [];
    final transactions = (data['transactions'] as List?) ?? [];
    final fromDate = statementFromDateController.text.trim();
    final toDate = statementToDateController.text.trim();
    final title = 'كشف حساب $partyLabel';

    final buffer = StringBuffer(printStyles(title));
    buffer.write('''
    <div class="grid">
      <div class="box"><b>$partyLabel</b><span>${htmlEscape(currentPartyName())}</span></div>
      <div class="box"><b>إجمالي الفواتير المرحلة</b><span>${htmlEscape(data['posted_invoices_total'])}</span></div>
      <div class="box"><b>الرصيد المستحق</b><span>${htmlEscape(data['balance_due'])}</span></div>
    </div>
    <p><b>الفترة:</b> ${htmlEscape(fromDate.isEmpty ? 'البداية' : fromDate)} إلى ${htmlEscape(toDate.isEmpty ? 'اليوم' : toDate)}</p>
    <h3>الحركة الزمنية والرصيد التراكمي</h3>
    <table>
      <thead><tr><th>التاريخ</th><th>المرجع</th><th>البيان</th><th class="amount">مدين</th><th class="amount">دائن</th><th class="amount">الرصيد</th></tr></thead>
      <tbody>
''');
    if (ledger.isEmpty) {
      buffer.write('<tr><td colspan="6">لا توجد حركة حساب.</td></tr>');
    } else {
      for (final raw in ledger) {
        final row = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
          <tr>
            <td>${htmlEscape(row['date'])}</td>
            <td>${htmlEscape(row['reference'])}</td>
            <td>${htmlEscape(row['description'])}</td>
            <td class="amount">${htmlEscape(row['debit'])}</td>
            <td class="amount">${htmlEscape(row['credit'])}</td>
            <td class="amount">${htmlEscape(row['balance'])}</td>
          </tr>
''');
      }
    }
    buffer.write('''
      </tbody>
    </table>
    <h3>الفواتير</h3>
    <table>
      <thead><tr><th>رقم الفاتورة</th><th>التاريخ</th><th>الحالة</th><th class="amount">الإجمالي</th></tr></thead>
      <tbody>
''');
    if (invoices.isEmpty) {
      buffer.write('<tr><td colspan="4">لا توجد فواتير.</td></tr>');
    } else {
      for (final raw in invoices) {
        final invoice = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
          <tr>
            <td>${htmlEscape(invoice['invoice_no'] ?? invoice['id'])}</td>
            <td>${htmlEscape(invoice['date'])}</td>
            <td>${htmlEscape(invoice['status'])}</td>
            <td class="amount">${htmlEscape(invoice['total'])}</td>
          </tr>
''');
      }
    }
    buffer.write('''
      </tbody>
    </table>
    <h3 style="margin-top:22px">الحركات المالية</h3>
    <table>
      <thead><tr><th>التاريخ</th><th>النوع</th><th>البيان</th><th class="amount">المبلغ</th></tr></thead>
      <tbody>
''');
    if (transactions.isEmpty) {
      buffer.write('<tr><td colspan="4">لا توجد حركات مالية.</td></tr>');
    } else {
      for (final raw in transactions) {
        final tx = Map<String, dynamic>.from(raw as Map);
        buffer.write('''
          <tr>
            <td>${htmlEscape(tx['date'])}</td>
            <td>${htmlEscape(tx['type'])}</td>
            <td>${htmlEscape(tx['description'])}</td>
            <td class="amount">${htmlEscape(tx['amount'])}</td>
          </tr>
''');
      }
    }
    buffer.write('''
      </tbody>
    </table>
''');
    buffer.write(officialPrintFooter());
    return buffer.toString();
  }

  Future<void> printStatement() async {
    if (statement == null) {
      showMessage('حمّل الكشف أولًا');
      return;
    }
    try {
      await openPrintDocument(
        title: 'كشف حساب $partyLabel',
        content: buildStatementHtml(),
      );
    } catch (_) {
      showMessage('الطباعة متاحة حاليًا من نسخة الويب');
    }
  }

  Widget summaryCard(String title, dynamic value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: AlshaariColors.deepGreen.withOpacity(.10),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: AlshaariColors.deepGreen),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: Theme.of(context).textTheme.bodySmall),
                  const SizedBox(height: 4),
                  Text(
                    money(value),
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.w900),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget statementDateFilters() {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'فترة كشف الحساب',
              style: Theme.of(context)
                  .textTheme
                  .titleSmall
                  ?.copyWith(fontWeight: FontWeight.w900),
            ),
            const SizedBox(height: 10),
            LayoutBuilder(
              builder: (context, constraints) {
                final compact = constraints.maxWidth < 680;
                final fromField = TextFormField(
                  controller: statementFromDateController,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'من تاريخ',
                    suffixIcon: IconButton(
                      onPressed: () =>
                          pickStatementDate(statementFromDateController),
                      icon: const Icon(Icons.calendar_today_outlined),
                    ),
                  ),
                );
                final toField = TextFormField(
                  controller: statementToDateController,
                  readOnly: true,
                  decoration: InputDecoration(
                    labelText: 'إلى تاريخ',
                    suffixIcon: IconButton(
                      onPressed: () =>
                          pickStatementDate(statementToDateController),
                      icon: const Icon(Icons.event_outlined),
                    ),
                  ),
                );
                final actions = Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () async {
                        statementFromDateController.clear();
                        statementToDateController.clear();
                        if (partyId != null) await loadStatement();
                      },
                      icon: const Icon(Icons.clear),
                      label: const Text('مسح الفترة'),
                    ),
                    FilledButton.icon(
                      onPressed: partyId == null ? null : loadStatement,
                      icon: const Icon(Icons.filter_alt_outlined),
                      label: const Text('تطبيق الفترة'),
                    ),
                  ],
                );

                if (compact) {
                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      fromField,
                      const SizedBox(height: 8),
                      toField,
                      const SizedBox(height: 10),
                      actions,
                    ],
                  );
                }

                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Expanded(child: fromField),
                        const SizedBox(width: 8),
                        Expanded(child: toField),
                      ],
                    ),
                    const SizedBox(height: 10),
                    actions,
                  ],
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget buildStatementBody() {
    if (statementLoading) {
      return const Padding(
        padding: EdgeInsets.all(32),
        child: Center(child: CircularProgressIndicator()),
      );
    }
    if (statement == null) {
      return Padding(
        padding: const EdgeInsets.only(top: 60),
        child: Center(
          child: Column(
            children: [
              Icon(Icons.manage_search,
                  size: 56, color: AlshaariColors.deepGreen.withOpacity(.55)),
              const SizedBox(height: 12),
              const Text('اختر الطرف ثم اعرض الكشف',
                  style: TextStyle(fontWeight: FontWeight.w900)),
            ],
          ),
        ),
      );
    }

    final data = statement!;
    final ledger = (data['ledger'] as List?) ?? [];
    final invoices = (data['invoices'] as List?) ?? [];
    final transactions = (data['transactions'] as List?) ?? [];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        LayoutBuilder(
          builder: (context, constraints) {
            final cards = [
              summaryCard('إجمالي الفواتير المرحلة',
                  data['posted_invoices_total'], Icons.receipt_long),
              summaryCard(
                  partyType == 'customer' ? 'إجمالي المقبوض' : 'إجمالي المدفوع',
                  partyType == 'customer'
                      ? data['receipts_total']
                      : data['payments_total'],
                  Icons.payments_outlined),
              summaryCard('الرصيد المستحق', data['balance_due'],
                  Icons.account_balance_wallet_outlined),
            ];
            if (constraints.maxWidth < 720) {
              return Column(
                  children: cards
                      .map((card) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: card))
                      .toList());
            }
            return GridView.count(
              crossAxisCount: 3,
              childAspectRatio: 2.9,
              crossAxisSpacing: 8,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              children: cards,
            );
          },
        ),
        const SizedBox(height: 10),
        FilledButton.icon(
          onPressed: printStatement,
          icon: const Icon(Icons.print_outlined),
          label: const Text('طباعة الكشف الرسمي'),
        ),
        const SizedBox(height: 18),
        Text('الحركة الزمنية والرصيد التراكمي',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (ledger.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد حركة حساب')))
        else
          ...ledger.map((raw) {
            final row = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.timeline,
                            color: AlshaariColors.deepGreen),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            '${row['reference'] ?? '-'}',
                            style: const TextStyle(fontWeight: FontWeight.w900),
                          ),
                        ),
                        Text('${row['date'] ?? '-'}'),
                      ],
                    ),
                    if ('${row['description'] ?? ''}'.trim().isNotEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text('${row['description']}'),
                      ),
                    const Divider(height: 20),
                    Row(
                      children: [
                        Expanded(child: _StatementAmount('مدين', row['debit'])),
                        Expanded(
                            child: _StatementAmount('دائن', row['credit'])),
                        Expanded(
                            child: _StatementAmount(
                                'الرصيد', row['balance'] ?? 0)),
                      ],
                    ),
                  ],
                ),
              ),
            );
          }),
        const SizedBox(height: 18),
        Text('الفواتير',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (invoices.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد فواتير')))
        else
          ...invoices.map((raw) {
            final invoice = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.receipt_long_outlined),
                title: Text('${invoice['invoice_no'] ?? invoice['id']}'),
                subtitle: Text(
                    '${invoice['date'] ?? '-'} | ${invoice['status'] ?? '-'}'),
                trailing: Text('${invoice['total'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
        const SizedBox(height: 18),
        Text('الحركات',
            style: Theme.of(context)
                .textTheme
                .titleMedium
                ?.copyWith(fontWeight: FontWeight.w900)),
        const SizedBox(height: 8),
        if (transactions.isEmpty)
          const Card(child: ListTile(title: Text('لا توجد حركات')))
        else
          ...transactions.map((raw) {
            final tx = Map<String, dynamic>.from(raw as Map);
            return Card(
              child: ListTile(
                leading: const Icon(Icons.swap_horiz),
                title: Text('${tx['type'] ?? '-'}'),
                subtitle:
                    Text('${tx['date'] ?? '-'} | ${tx['description'] ?? ''}'),
                trailing: Text('${tx['amount'] ?? 0}',
                    style: const TextStyle(fontWeight: FontWeight.w900)),
              ),
            );
          }),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('كشوف الحسابات'),
            ],
          ),
          actions: [
            IconButton(onPressed: loadParties, icon: const Icon(Icons.refresh)),
          ],
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: () async {
                  await loadParties();
                  if (partyId != null) await loadStatement();
                },
                child: ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    SegmentedButton<String>(
                      segments: const [
                        ButtonSegment(
                            value: 'customer',
                            label: Text('عميل'),
                            icon: Icon(Icons.person_outline)),
                        ButtonSegment(
                            value: 'supplier',
                            label: Text('مورد'),
                            icon: Icon(Icons.local_shipping_outlined)),
                      ],
                      selected: {partyType},
                      onSelectionChanged: (value) {
                        setState(() {
                          partyType = value.first;
                          partyId = null;
                          statement = null;
                        });
                      },
                    ),
                    const SizedBox(height: 14),
                    DropdownButtonFormField<int>(
                      initialValue: partyId,
                      decoration: InputDecoration(labelText: partyLabel),
                      items: parties
                          .map((raw) =>
                              partyItem(Map<String, dynamic>.from(raw as Map)))
                          .toList(),
                      onChanged: (value) {
                        setState(() {
                          partyId = value;
                          statement = null;
                        });
                      },
                    ),
                    const SizedBox(height: 12),
                    statementDateFilters(),
                    const SizedBox(height: 12),
                    FilledButton.icon(
                      onPressed: statementLoading ? null : loadStatement,
                      icon: statementLoading
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child: CircularProgressIndicator(strokeWidth: 2))
                          : const Icon(Icons.manage_search),
                      label: const Text('عرض الكشف'),
                    ),
                    const SizedBox(height: 10),
                    AlshaariSettlementButton(
                      contextType: partyType,
                      contextId: partyId,
                      primary: false,
                    ),
                    const SizedBox(height: 18),
                    buildStatementBody(),
                  ],
                ),
              ),
      ),
    );
  }
}
