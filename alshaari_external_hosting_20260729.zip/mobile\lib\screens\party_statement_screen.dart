import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';

class PartyStatementScreen extends StatefulWidget {
  final String type; // customer/supplier/worker
  final int id;
  final String title;
  const PartyStatementScreen({super.key, required this.type, required this.id, required this.title});
  @override
  State<PartyStatementScreen> createState() => _PartyStatementScreenState();
}

class _PartyStatementScreenState extends State<PartyStatementScreen> {
  Map<String, dynamic>? data;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    final path = widget.type == 'customer' ? '/reports/customer/${widget.id}' : widget.type == 'supplier' ? '/reports/supplier/${widget.id}' : '/reports/worker/${widget.id}';
    try { final res = await apiClient.dio.get(path); if (!mounted) return; setState(() => data = Map<String,dynamic>.from(res.data as Map)); }
    catch(e) { if (mounted) setState(() => error = '$e'); }
  }

  Widget line(String k, dynamic v) => Card(child: ListTile(title: Text(k), trailing: Text('${v ?? 0}', style: const TextStyle(fontWeight: FontWeight.bold))));

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: ui.TextDirection.rtl, child: Scaffold(appBar: AppBar(title: Text(widget.title)), body: error != null ? Center(child: Text(error!)) : data == null ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(12), children: [
      if (widget.type == 'customer') ...[line('إجمالي الفواتير', data!['total_invoices']), line('إجمالي المقبوض', data!['total_receipts']), line('الرصيد', data!['balance'])],
      if (widget.type == 'supplier') ...[line('إجمالي الفواتير', data!['total_invoices']), line('المدفوع', data!['paid']), line('الرصيد', data!['balance'])],
      if (widget.type == 'worker') ...[line('الأجور', data!['wages']), line('العهد', data!['advances']), line('التسويات', data!['settlements']), line('رصيد العهد', data!['advance_balance'])],
      const SizedBox(height: 12),
      const Text('الحركات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ...(data!['transactions'] as List? ?? []).map((raw) { final e = Map<String,dynamic>.from(raw as Map); return ListTile(title: Text('${e['type']} - ${e['amount']}'), subtitle: Text('${e['date']} | ${e['description'] ?? ''}')); }),
    ]))));
  }
}
