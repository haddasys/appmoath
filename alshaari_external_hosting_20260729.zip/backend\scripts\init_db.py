from app.db.database import Base, engine
from app.models import models

if __name__ == "__main__":
    Base.metadata.create_all(bind=engine)
    print("تم إنشاء الجداول بنجاح")
