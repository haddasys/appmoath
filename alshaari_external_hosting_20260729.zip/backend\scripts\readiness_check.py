from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
import sys

from sqlalchemy import inspect, text
from sqlalchemy.exc import SQLAlchemyError

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.db.database import SessionLocal, engine  # noqa: E402


@dataclass
class CheckResult:
    level: str
    title: str
    details: str


class ReadinessChecker:
    def __init__(self) -> None:
        self.inspector = inspect(engine)
        self.tables = set(self.inspector.get_table_names())
        self.results: list[CheckResult] = []

    def run(self) -> int:
        with SessionLocal() as db:
            self._check_required_tables()
            self._check_document_sequences(db)
            self._check_cash_accounts(db)
            self._check_accounting_integrity(db)
            self._check_offline_sync_schema()
            self._check_attendance_schema()

        self._print_report()
        return 1 if any(item.level == "FAIL" for item in self.results) else 0

    def _check_required_tables(self) -> None:
        required = [
            "accounts",
            "cash_accounts",
            "document_sequences",
            "transactions",
            "journal_entries",
            "journal_entry_lines",
            "audit_logs",
        ]
        missing = [name for name in required if name not in self.tables]
        if missing:
            self._fail("الجداول الأساسية", f"جداول ناقصة: {', '.join(missing)}")
        else:
            self._pass("الجداول الأساسية", "كل الجداول المالية الأساسية موجودة.")

    def _check_document_sequences(self, db) -> None:
        if "document_sequences" not in self.tables:
            return
        expected = [
            "cash_receipt",
            "cash_payment",
            "cash_transfer",
            "advance_payment",
            "settlement_voucher",
            "supplier_invoice",
            "supplier_payment",
            "purchase_request",
            "purchase_order",
            "goods_receipt",
            "inventory_adjustment",
            "payroll",
            "journal_entry",
        ]
        rows = self._scalar_list(
            db,
            "select document_type from document_sequences where is_active = 1 or is_active = true",
        )
        existing = {str(item) for item in rows}
        missing = [item for item in expected if item not in existing]
        if missing:
            self._warn("ترقيم المستندات", f"أنواع تسلسل ناقصة: {', '.join(missing)}")
        else:
            self._pass("ترقيم المستندات", "تسلسلات المستندات الأساسية موجودة.")

    def _check_cash_accounts(self, db) -> None:
        if "cash_accounts" not in self.tables:
            return
        rows = db.execute(
            text("select code, account_code, name from cash_accounts where is_active = 1 or is_active = true")
        ).mappings().all()
        expected_accounts = {"10111", "10121", "10131", "10201", "10204", "10205", "10206"}
        found = {str(row.get("account_code") or row.get("code") or "") for row in rows}
        missing = sorted(expected_accounts - found)
        if not rows:
            self._fail("الصناديق والمحافظ", "لا توجد صناديق أو محافظ نشطة.")
        elif missing:
            self._warn("الصناديق والمحافظ", f"حسابات نقدية مقترحة غير موجودة: {', '.join(missing)}")
        else:
            self._pass("الصناديق والمحافظ", f"الصناديق والمحافظ الأساسية موجودة ({len(rows)} حساب).")

    def _check_accounting_integrity(self, db) -> None:
        if "journal_entries" not in self.tables or "journal_entry_lines" not in self.tables:
            return

        entry_columns = self._columns("journal_entries")
        line_columns = self._columns("journal_entry_lines")
        if {"journal_entry_id", "debit", "credit"}.issubset(line_columns):
            imbalanced = db.execute(
                text(
                    """
                    select journal_entry_id,
                           round(coalesce(sum(debit), 0), 2) as total_debit,
                           round(coalesce(sum(credit), 0), 2) as total_credit
                    from journal_entry_lines
                    group by journal_entry_id
                    having round(coalesce(sum(debit), 0), 2) != round(coalesce(sum(credit), 0), 2)
                    limit 10
                    """
                )
            ).mappings().all()
            if imbalanced:
                self._fail("توازن القيود", f"يوجد {len(imbalanced)} قيد غير متوازن ضمن أول 10 نتائج.")
            else:
                self._pass("توازن القيود", "لا توجد قيود غير متوازنة في دفتر اليومية.")
        else:
            self._warn("توازن القيود", "أعمدة سطور القيود غير مكتملة للفحص الآلي.")

        if {"source_type", "source_id"}.issubset(entry_columns):
            duplicates = db.execute(
                text(
                    """
                    select source_type, source_id, count(*) as count_rows
                    from journal_entries
                    where source_type is not null and source_id is not null
                    group by source_type, source_id
                    having count(*) > 1
                    limit 10
                    """
                )
            ).mappings().all()
            if duplicates:
                self._fail("منع القيود المكررة", f"يوجد مصادر لها أكثر من قيد ضمن أول 10 نتائج.")
            else:
                self._pass("منع القيود المكررة", "لا توجد قيود مكررة لنفس المصدر.")
        else:
            self._warn("مصدر القيود", "أعمدة source_type/source_id غير متاحة للفحص.")

    def _check_offline_sync_schema(self) -> None:
        expected_tables = ["devices", "sync_logs"]
        missing_tables = [name for name in expected_tables if name not in self.tables]
        watched_tables = [
            "transactions",
            "settlement_vouchers",
            "supplier_invoices",
            "purchase_requests",
            "purchase_orders",
            "goods_receipts",
            "supplier_payments",
            "inventory_movements",
            "attendance",
            "payrolls",
        ]
        required_columns = {"local_uuid", "device_id", "sync_status", "created_offline", "server_version", "updated_at"}
        missing_columns: list[str] = []
        for table_name in watched_tables:
            if table_name not in self.tables:
                continue
            columns = self._columns(table_name)
            missed = required_columns - columns
            if missed:
                missing_columns.append(f"{table_name}: {', '.join(sorted(missed))}")
        if missing_tables or missing_columns:
            details = []
            if missing_tables:
                details.append(f"جداول ناقصة: {', '.join(missing_tables)}")
            if missing_columns:
                details.append("أعمدة ناقصة: " + " | ".join(missing_columns[:5]))
            self._warn("جاهزية Offline/Sync", "؛ ".join(details))
        else:
            self._pass("جاهزية Offline/Sync", "جداول وأعمدة المزامنة الأساسية موجودة.")

    def _check_attendance_schema(self) -> None:
        if "attendance" not in self.tables:
            self._warn("الحضور", "جدول attendance غير موجود؛ لا تبدأ تشغيل الرواتب قبل إضافته.")
            return
        required = {"employee_id", "date", "status", "project_id", "cost_center_id", "created_at"}
        missing = required - self._columns("attendance")
        if missing:
            self._warn("الحضور", f"أعمدة ناقصة: {', '.join(sorted(missing))}")
        else:
            self._pass("الحضور", "جدول الحضور جاهز للتسجيل اليومي.")

    def _columns(self, table_name: str) -> set[str]:
        if table_name not in self.tables:
            return set()
        return {column["name"] for column in self.inspector.get_columns(table_name)}

    def _scalar_list(self, db, sql: str) -> list[object]:
        try:
            return [row[0] for row in db.execute(text(sql)).all()]
        except SQLAlchemyError as exc:
            self._warn("فحص SQL", str(exc))
            return []

    def _pass(self, title: str, details: str) -> None:
        self.results.append(CheckResult("PASS", title, details))

    def _warn(self, title: str, details: str) -> None:
        self.results.append(CheckResult("WARN", title, details))

    def _fail(self, title: str, details: str) -> None:
        self.results.append(CheckResult("FAIL", title, details))

    def _print_report(self) -> None:
        print("\nتقرير جاهزية نظام الشعري")
        print("=" * 40)
        for item in self.results:
            label = {"PASS": "نجح", "WARN": "تنبيه", "FAIL": "فشل"}[item.level]
            print(f"[{label}] {item.title}: {item.details}")
        print("=" * 40)
        print("الفشل يعني: لا تبدأ التشغيل الفعلي قبل الإصلاح.")
        print("التنبيه يعني: يمكن التشغيل بحذر إذا كان البند غير مستخدم حاليًا.")


if __name__ == "__main__":
    raise SystemExit(ReadinessChecker().run())
