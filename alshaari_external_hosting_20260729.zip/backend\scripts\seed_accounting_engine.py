﻿from sqlalchemy import text
from app.db.database import engine

ACCOUNTS = [
    ("10101", "صندوق يمني", "cash"),
    ("10102", "صندوق سعودي", "cash"),
    ("10103", "صندوق دولار", "cash"),
    ("10201", "حساب الكريمي", "bank"),
    ("10202", "حساب بنك محلي", "bank"),
    ("10301", "العملاء", "asset"),
    ("10302", "دفعات عملاء مقدمة", "liability"),
    ("10601", "دفعات مقدمة للموردين", "asset"),
    ("10401", "مخزون خشب MDF", "inventory"),
    ("10402", "مخزون أبلاكاش", "inventory"),
    ("10403", "مخزون دهانات", "inventory"),
    ("10404", "مخزون إكسسوارات", "inventory"),
    ("10405", "مخزون زجاج وألمنيوم", "inventory"),
    ("10406", "مخزون إسفنج وتنجيد", "inventory"),
    ("20101", "الموردون", "liability"),
    ("20201", "أجور مستحقة للعمال", "liability"),
    ("20202", "سلف العمال", "asset"),
    ("20203", "عهد العمال", "asset"),
    ("30101", "رأس المال", "equity"),
    ("30201", "مسحوبات شخصية", "equity"),
    ("40101", "إيرادات المشاريع", "revenue"),
    ("40105", "إيرادات CNC خارجي", "revenue"),
    ("50101", "تكلفة مواد المشاريع", "cost"),
    ("50201", "أجور مباشرة", "cost"),
    ("50303", "مصروفات مشروع أخرى", "cost"),
    ("60301", "مصروفات إدارية", "expense"),
    ("60201", "مصروفات تسويق", "expense"),
]

POSTING_RULES = [
    ("receipt_from_customer", "10101", "10301", "قبض من عميل"),
    ("customer_advance", "10101", "10302", "دفعة مقدمة من عميل"),
    ("general_payment", "60301", "10101", "صرف عام"),
    ("material_purchase", "10401", "10101", "شراء مواد نقدًا"),
    ("material_issue_to_project", "50101", "10401", "صرف مواد لمشروع"),
    ("customer_invoice", "10301", "40101", "فاتورة عميل"),
    ("supplier_invoice", "10401", "20101", "فاتورة مورد"),
    ("supplier_payment", "20101", "10101", "دفعة مورد"),
    ("supplier_advance", "10601", "10101", "دفعة مقدمة لمورد"),
    ("worker_wage", "50201", "10101", "أجر عامل"),
    ("advance_payment", "20203", "10101", "عهدة عامل"),
    ("advance_settlement", "60301", "20203", "تسوية عهدة"),
    ("cash_transfer", "10201", "10101", "تحويل صندوق"),
]

DOCUMENT_SEQUENCES = [
    ("transaction", "TX"),
    ("journal_entry", "JE"),
    ("receipt", "RV"),
    ("payment", "PV"),
    ("invoice", "INV"),
]

def main():
    with engine.begin() as conn:
        for code, name, acc_type in ACCOUNTS:
            conn.execute(
                text("""
                    INSERT INTO accounts (code, name, type, currency, balance)
                    VALUES (:code, :name, :type, 'YER', 0)
                    ON CONFLICT (code) DO NOTHING
                """),
                {"code": code, "name": name, "type": acc_type},
            )

        for operation_type, debit, credit, description in POSTING_RULES:
            conn.execute(
                text("""
                    INSERT INTO posting_rules (
                        operation_type,
                        debit_account_code,
                        credit_account_code,
                        description,
                        is_active
                    )
                    VALUES (
                        :operation_type,
                        :debit,
                        :credit,
                        :description,
                        TRUE
                    )
                    ON CONFLICT (operation_type) DO UPDATE SET
                        debit_account_code = EXCLUDED.debit_account_code,
                        credit_account_code = EXCLUDED.credit_account_code,
                        description = EXCLUDED.description,
                        is_active = TRUE
                """),
                {
                    "operation_type": operation_type,
                    "debit": debit,
                    "credit": credit,
                    "description": description,
                },
            )

        for document_type, prefix in DOCUMENT_SEQUENCES:
            conn.execute(
                text("""
                    INSERT INTO document_sequences (
                        document_type,
                        prefix,
                        next_number,
                        padding,
                        is_active
                    )
                    VALUES (
                        :document_type,
                        :prefix,
                        1,
                        6,
                        TRUE
                    )
                    ON CONFLICT (document_type) DO NOTHING
                """),
                {"document_type": document_type, "prefix": prefix},
            )

    print("Chart of accounts and posting rules seeded successfully.")

if __name__ == "__main__":
    main()
