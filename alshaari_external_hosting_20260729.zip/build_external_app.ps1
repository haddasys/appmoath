﻿param(
  [Parameter(Mandatory = $true)]
  [string]$ApiBaseUrl,

  [switch]$BuildApk
)

$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Mobile = Join-Path $Root "mobile"

Push-Location $Mobile
flutter pub get
flutter build web --release --dart-define=API_BASE_URL=$ApiBaseUrl
if ($BuildApk) {
  flutter build apk --release --dart-define=API_BASE_URL=$ApiBaseUrl
}
Pop-Location

Write-Host "External build completed for API: $ApiBaseUrl"
Write-Host "Web output: $Mobile\build\web"
if ($BuildApk) {
  Write-Host "APK output: $Mobile\build\app\outputs\flutter-apk\app-release.apk"
}
