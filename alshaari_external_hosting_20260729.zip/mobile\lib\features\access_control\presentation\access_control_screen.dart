import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/network/api_client.dart';

class AccessControlScreen extends StatefulWidget {
  const AccessControlScreen({super.key});

  @override
  State<AccessControlScreen> createState() => _AccessControlScreenState();
}

class _AccessControlScreenState extends State<AccessControlScreen>
    with SingleTickerProviderStateMixin {
  late final TabController controller;

  bool loading = true;
  bool saving = false;
  List<dynamic> users = [];
  List<dynamic> roles = [];
  Map<String, dynamic> permissionLabels = {};

  final roleNames = const {
    'manager': 'المدير العام',
    'accountant': 'المحاسب',
    'cashier': 'أمين الصندوق',
    'purchasing': 'مسؤول المشتريات',
    'inventory': 'مسؤول المخزون',
    'production': 'مسؤول الإنتاج',
    'data_entry': 'مدخل بيانات',
    'read_only': 'مشاهد فقط',
  };

  @override
  void initState() {
    super.initState();
    controller = TabController(length: 2, vsync: this);
    configureAndLoad();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  Future<void> configureAndLoad() async {
    await apiClient.loadToken();
    await loadData();
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.response?.statusCode == 403) {
        return 'هذه الشاشة مخصصة للمدير العام فقط';
      }
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
    }
    return 'حدث خطأ غير متوقع';
  }

  void showMessage(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
        .showSnackBar(SnackBar(content: Text(message)));
  }

  Future<void> loadData() async {
    setState(() => loading = true);
    try {
      final result = await Future.wait([
        apiClient.dio.get('/access-control/users'),
        apiClient.dio.get('/access-control/roles'),
      ]);
      final rolePayload = Map<String, dynamic>.from(result[1].data as Map);
      if (!mounted) return;
      setState(() {
        users = (result[0].data as List?) ?? [];
        roles = (rolePayload['roles'] as List?) ?? [];
        permissionLabels = Map<String, dynamic>.from(
          (rolePayload['permission_labels'] as Map?) ?? {},
        );
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      showMessage('فشل تحميل الصلاحيات: ${friendlyError(e)}');
    }
  }

  String roleLabel(String? role) {
    return roleNames[role] ?? role ?? '-';
  }

  DropdownMenuItem<String> roleItem(Map<String, dynamic> role) {
    final code = '${role['code']}';
    return DropdownMenuItem<String>(
      value: code,
      child: Text('${role['name'] ?? roleLabel(code)}'),
    );
  }

  Future<void> openUserDialog({Map<String, dynamic>? user}) async {
    final formKey = GlobalKey<FormState>();
    final name = TextEditingController(text: '${user?['name'] ?? ''}');
    final phone = TextEditingController(text: '${user?['phone'] ?? ''}');
    final password = TextEditingController();
    String selectedRole = '${user?['role'] ?? 'data_entry'}';
    bool isActive = user?['is_active'] != false;
    final rootNavigator = Navigator.of(context, rootNavigator: true);

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return Directionality(
          textDirection: ui.TextDirection.rtl,
          child: StatefulBuilder(
            builder: (context, setDialogState) {
              return AlertDialog(
                title: Text(
                  user == null ? 'إضافة مستخدم' : 'تعديل مستخدم',
                ),
                content: Form(
                  key: formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        TextFormField(
                          controller: name,
                          decoration:
                              const InputDecoration(labelText: 'الاسم'),
                          validator: (value) => (value ?? '').trim().isEmpty
                              ? 'أدخل الاسم'
                              : null,
                        ),
                        const SizedBox(height: 10),
                        TextFormField(
                          controller: phone,
                          decoration: const InputDecoration(
                            labelText: 'رقم الهاتف',
                          ),
                          keyboardType: TextInputType.phone,
                          validator: (value) => (value ?? '').trim().isEmpty
                              ? 'أدخل رقم الهاتف'
                              : null,
                        ),
                        if (user == null) ...[
                          const SizedBox(height: 10),
                          TextFormField(
                            controller: password,
                            decoration: const InputDecoration(
                              labelText: 'كلمة المرور',
                            ),
                            obscureText: true,
                            validator: (value) {
                              if ((value ?? '').length < 6) {
                                return '6 أحرف على الأقل';
                              }
                              return null;
                            },
                          ),
                        ],
                        const SizedBox(height: 10),
                        DropdownButtonFormField<String>(
                          initialValue: selectedRole,
                          decoration:
                              const InputDecoration(labelText: 'الدور'),
                          items: roles
                              .map((raw) => roleItem(
                                    Map<String, dynamic>.from(raw as Map),
                                  ))
                              .toList(),
                          onChanged: (value) => setDialogState(
                            () => selectedRole = value ?? selectedRole,
                          ),
                        ),
                        const SizedBox(height: 8),
                        SwitchListTile(
                          contentPadding: EdgeInsets.zero,
                          title: const Text('مستخدم نشط'),
                          value: isActive,
                          onChanged: (value) =>
                              setDialogState(() => isActive = value),
                        ),
                      ],
                    ),
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => rootNavigator.pop(),
                    child: const Text('إلغاء'),
                  ),
                  FilledButton(
                    onPressed: saving
                        ? null
                        : () async {
                            if (!formKey.currentState!.validate()) return;
                            await saveUser(
                              id: user?['id'] as int?,
                              name: name.text.trim(),
                              phone: phone.text.trim(),
                              password: password.text,
                              role: selectedRole,
                              isActive: isActive,
                            );
                            if (rootNavigator.canPop()) rootNavigator.pop();
                          },
                    child: Text(user == null ? 'إضافة' : 'حفظ'),
                  ),
                ],
              );
            },
          ),
        );
      },
    );

    name.dispose();
    phone.dispose();
    password.dispose();
  }

  Future<void> saveUser({
    int? id,
    required String name,
    required String phone,
    required String password,
    required String role,
    required bool isActive,
  }) async {
    setState(() => saving = true);
    try {
      if (id == null) {
        await apiClient.dio.post('/access-control/users', data: {
          'name': name,
          'phone': phone,
          'password': password,
          'role': role,
          'is_active': isActive,
        });
      } else {
        await apiClient.dio.patch('/access-control/users/$id', data: {
          'name': name,
          'phone': phone,
          'role': role,
          'is_active': isActive,
        });
      }
      await loadData();
      showMessage(id == null ? 'تمت إضافة المستخدم' : 'تم حفظ المستخدم');
    } catch (e) {
      showMessage('فشل حفظ المستخدم: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Future<void> openPasswordDialog(Map<String, dynamic> user) async {
    final formKey = GlobalKey<FormState>();
    final password = TextEditingController();
    final rootNavigator = Navigator.of(context, rootNavigator: true);

    await showDialog<void>(
      context: context,
      builder: (dialogContext) {
        return Directionality(
          textDirection: ui.TextDirection.rtl,
          child: AlertDialog(
            title: Text('تغيير كلمة مرور ${user['name']}'),
            content: Form(
              key: formKey,
              child: TextFormField(
                controller: password,
                decoration: const InputDecoration(
                  labelText: 'كلمة المرور الجديدة',
                ),
                obscureText: true,
                validator: (value) => (value ?? '').length < 6
                    ? '6 أحرف على الأقل'
                    : null,
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => rootNavigator.pop(),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: () async {
                  if (!formKey.currentState!.validate()) return;

                  await updatePassword(user['id'] as int, password.text);
                  if (rootNavigator.canPop()) rootNavigator.pop();
                },
                child: const Text('تغيير'),
              ),
            ],
          ),
        );
      },
    );

    password.dispose();
  }

  Future<void> updatePassword(int id, String password) async {
    try {
      await apiClient.dio.patch(
        '/access-control/users/$id/password',
        data: {'password': password},
      );
      showMessage('تم تغيير كلمة المرور');
    } catch (e) {
      showMessage('فشل تغيير كلمة المرور: ${friendlyError(e)}');
    }
  }

  Future<void> updateRolePermissions(
      String roleCode, List<String> permissions) async {
    setState(() => saving = true);
    try {
      await apiClient.dio.put(
        '/access-control/roles/$roleCode/permissions',
        data: {'permissions': permissions},
      );
      await loadData();
      showMessage('تم حفظ صلاحيات الدور');
    } catch (e) {
      showMessage('فشل حفظ الصلاحيات: ${friendlyError(e)}');
    } finally {
      if (mounted) setState(() => saving = false);
    }
  }

  Widget usersTab() {
    if (users.isEmpty) {
      return ListView(
        padding: const EdgeInsets.all(16),
        children: [
          FilledButton.icon(
            onPressed: () => openUserDialog(),
            icon: const Icon(Icons.person_add_alt),
            label: const Text('إضافة مستخدم'),
          ),
          const SizedBox(height: 80),
          const Center(child: Text('لا توجد حسابات مستخدمين')),
        ],
      );
    }

    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: users.length + 1,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, index) {
        if (index == 0) {
          return FilledButton.icon(
            onPressed: () => openUserDialog(),
            icon: const Icon(Icons.person_add_alt),
            label: const Text('إضافة مستخدم'),
          );
        }
        final user = Map<String, dynamic>.from(users[index - 1] as Map);
        final active = user['is_active'] != false;
        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  children: [
                    Container(
                      width: 42,
                      height: 42,
                      decoration: BoxDecoration(
                        color: active
                            ? AlshaariColors.deepGreen.withOpacity(.10)
                            : AlshaariColors.copper.withOpacity(.10),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        active ? Icons.verified_user_outlined : Icons.block,
                        color: active
                            ? AlshaariColors.deepGreen
                            : AlshaariColors.copper,
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '${user['name'] ?? '-'}',
                            style: const TextStyle(
                              fontWeight: FontWeight.w900,
                            ),
                          ),
                          const SizedBox(height: 3),
                          Text(
                            '${user['phone'] ?? '-'} | ${roleLabel('${user['role']}')}',
                          ),
                        ],
                      ),
                    ),
                    _StatusBadge(active: active),
                  ],
                ),
                const Divider(height: 22),
                Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  alignment: WrapAlignment.end,
                  children: [
                    OutlinedButton.icon(
                      onPressed: () => openPasswordDialog(user),
                      icon: const Icon(Icons.lock_reset),
                      label: const Text('كلمة المرور'),
                    ),
                    FilledButton.icon(
                      onPressed: () => openUserDialog(user: user),
                      icon: const Icon(Icons.edit_outlined),
                      label: const Text('تعديل'),
                    ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget rolesTab() {
    return ListView.separated(
      padding: const EdgeInsets.all(16),
      itemCount: roles.length,
      separatorBuilder: (_, __) => const SizedBox(height: 8),
      itemBuilder: (_, index) {
        final role = Map<String, dynamic>.from(roles[index] as Map);
        final code = '${role['code']}';
        final selected = Set<String>.from(
          (role['permissions'] as List?)?.map((e) => '$e') ?? [],
        );
        final allPermissions = permissionLabels.keys.map((e) => e).toList()
          ..sort();

        return Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: StatefulBuilder(
              builder: (context, setCardState) {
                return Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      children: [
                        Container(
                          width: 42,
                          height: 42,
                          decoration: BoxDecoration(
                            color: AlshaariColors.deepGreen.withOpacity(.10),
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: const Icon(
                            Icons.admin_panel_settings_outlined,
                            color: AlshaariColors.deepGreen,
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                '${role['name'] ?? roleLabel(code)}',
                                style: const TextStyle(
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                              const SizedBox(height: 3),
                              Text(
                                '${role['notes'] ?? code}',
                                style: Theme.of(context).textTheme.bodySmall,
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const Divider(height: 22),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: allPermissions.map((permission) {
                        final checked = selected.contains(permission);
                        return FilterChip(
                          label: Text(
                            '${permissionLabels[permission] ?? permission}',
                          ),
                          selected: checked,
                          onSelected: (value) {
                            setCardState(() {
                              if (value) {
                                selected.add(permission);
                              } else {
                                selected.remove(permission);
                              }
                            });
                          },
                        );
                      }).toList(),
                    ),
                    const SizedBox(height: 12),
                    Align(
                      alignment: Alignment.centerLeft,
                      child: FilledButton.icon(
                        onPressed: saving
                            ? null
                            : () => updateRolePermissions(
                                  code,
                                  selected.toList()..sort(),
                                ),
                        icon: saving
                            ? const SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                ),
                              )
                            : const Icon(Icons.save_outlined),
                        label: const Text('حفظ الصلاحيات'),
                      ),
                    ),
                  ],
                );
              },
            ),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              BrandMark(size: 32),
              SizedBox(width: 10),
              Text('الأدوار والصلاحيات'),
            ],
          ),
          actions: [
            IconButton(onPressed: loadData, icon: const Icon(Icons.refresh)),
          ],
          bottom: TabBar(
            controller: controller,
            tabs: const [
              Tab(
                icon: Icon(Icons.people_outline),
                text: 'المستخدمون',
              ),
              Tab(
                icon: Icon(Icons.admin_panel_settings_outlined),
                text: 'الأدوار',
              ),
            ],
          ),
        ),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : TabBarView(
                controller: controller,
                children: [
                  usersTab(),
                  rolesTab(),
                ],
              ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final bool active;

  const _StatusBadge({required this.active});

  @override
  Widget build(BuildContext context) {
    final color = active ? const Color(0xFF2F7D57) : AlshaariColors.copper;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withOpacity(.10),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(.35)),
      ),
      child: Text(
        active ? 'نشط' : 'موقوف',
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w900,
          fontSize: 12,
        ),
      ),
    );
  }
}
