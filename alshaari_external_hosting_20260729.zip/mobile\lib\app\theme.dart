﻿import 'package:flutter/material.dart';

class AlshaariColors {
  // Official brand palette
  static const Color copper = Color(0xFFB87E62);
  static const Color matteBlack = Color(0xFF1C1C1C);
  static const Color darkGrey = Color(0xFF4F4F4F);
  static const Color pearlWhite = Color(0xFFF9F7F1);
  static const Color gold = Color(0xFFC8A45D);

  // Compatibility aliases used by existing screens
  static const Color deepGreen = Color(0xFF1F3D35);
  static const Color brass = Color(0xFFC8A45D);
  static const Color slate = Color(0xFF4F4F4F);
  static const Color walnut = Color(0xFF6B4A35);
  static const Color ink = Color(0xFF1C1C1C);
  static const Color pearl = Color(0xFFF9F7F1);
  static const Color border = Color(0xFFE3D8CC);

  // Status colors
  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFF9A825);
  static const Color danger = Color(0xFFC62828);
  static const Color info = Color(0xFF1565C0);
}

class AlshaariTheme {
  static ThemeData light() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AlshaariColors.copper,
      brightness: Brightness.light,
      primary: AlshaariColors.copper,
      secondary: AlshaariColors.gold,
      surface: AlshaariColors.pearlWhite,
      error: AlshaariColors.danger,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      fontFamily: 'Cairo',
      scaffoldBackgroundColor: AlshaariColors.pearlWhite,
      colorScheme: scheme.copyWith(
        primary: AlshaariColors.copper,
        secondary: AlshaariColors.gold,
        surface: AlshaariColors.pearlWhite,
        onPrimary: Colors.white,
        onSecondary: AlshaariColors.matteBlack,
        onSurface: AlshaariColors.matteBlack,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: AlshaariColors.pearlWhite,
        foregroundColor: AlshaariColors.matteBlack,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontSize: 20,
          fontWeight: FontWeight.w800,
        ),
      ),

      cardTheme: CardThemeData(
        elevation: 0,
        color: Colors.white,
        surfaceTintColor: Colors.transparent,
        margin: const EdgeInsets.symmetric(vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: const BorderSide(color: AlshaariColors.border),
        ),
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AlshaariColors.copper,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          padding: const EdgeInsets.symmetric(horizontal: 18, vertical: 14),
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),

      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: AlshaariColors.copper,
          minimumSize: const Size(double.infinity, 52),
          side: const BorderSide(color: AlshaariColors.copper, width: 1.2),
          textStyle: const TextStyle(
            fontFamily: 'Cairo',
            fontSize: 15,
            fontWeight: FontWeight.w700,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: const TextStyle(
          color: AlshaariColors.slate,
          fontWeight: FontWeight.w600,
        ),
        hintStyle: TextStyle(
          color: AlshaariColors.slate.withOpacity(0.65),
        ),
        prefixIconColor: AlshaariColors.copper,
        suffixIconColor: AlshaariColors.copper,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AlshaariColors.border),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AlshaariColors.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(
            color: AlshaariColors.copper,
            width: 1.5,
          ),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AlshaariColors.danger),
        ),
      ),

      chipTheme: ChipThemeData(
        backgroundColor: Colors.white,
        selectedColor: AlshaariColors.copper.withOpacity(0.16),
        disabledColor: AlshaariColors.slate.withOpacity(0.08),
        labelStyle: const TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontWeight: FontWeight.w600,
        ),
        side: const BorderSide(color: AlshaariColors.border),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),

      snackBarTheme: SnackBarThemeData(
        backgroundColor: AlshaariColors.matteBlack,
        contentTextStyle: const TextStyle(
          fontFamily: 'Cairo',
          color: Colors.white,
          fontWeight: FontWeight.w600,
        ),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
      ),

      dividerTheme: const DividerThemeData(
        color: AlshaariColors.border,
        thickness: 1,
      ),

      floatingActionButtonTheme: const FloatingActionButtonThemeData(
        backgroundColor: AlshaariColors.copper,
        foregroundColor: Colors.white,
      ),

      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: AlshaariColors.copper,
      ),

      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontWeight: FontWeight.w900,
        ),
        headlineMedium: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontWeight: FontWeight.w800,
        ),
        titleLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontWeight: FontWeight.w800,
        ),
        titleMedium: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          fontWeight: FontWeight.w700,
        ),
        bodyLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.matteBlack,
          height: 1.45,
        ),
        bodyMedium: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.slate,
          height: 1.45,
        ),
        bodySmall: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.slate,
          height: 1.4,
        ),
      ),
    );
  }

  static ThemeData dark() {
    final scheme = ColorScheme.fromSeed(
      seedColor: AlshaariColors.copper,
      brightness: Brightness.dark,
      primary: AlshaariColors.copper,
      secondary: AlshaariColors.gold,
      surface: AlshaariColors.matteBlack,
      error: AlshaariColors.danger,
    );

    return ThemeData(
      useMaterial3: true,
      brightness: Brightness.dark,
      fontFamily: 'Cairo',
      scaffoldBackgroundColor: AlshaariColors.matteBlack,
      colorScheme: scheme.copyWith(
        primary: AlshaariColors.copper,
        secondary: AlshaariColors.gold,
        surface: AlshaariColors.matteBlack,
        onPrimary: Colors.white,
        onSecondary: AlshaariColors.matteBlack,
        onSurface: AlshaariColors.pearlWhite,
      ),

      appBarTheme: const AppBarTheme(
        backgroundColor: AlshaariColors.matteBlack,
        foregroundColor: AlshaariColors.pearlWhite,
        elevation: 0,
        centerTitle: false,
      ),

      cardTheme: CardThemeData(
        elevation: 0,
        color: const Color(0xFF252525),
        surfaceTintColor: Colors.transparent,
        margin: const EdgeInsets.symmetric(vertical: 8),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
          side: BorderSide(color: AlshaariColors.copper.withOpacity(0.22)),
        ),
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AlshaariColors.copper,
          foregroundColor: Colors.white,
          minimumSize: const Size(double.infinity, 52),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: const Color(0xFF252525),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        labelStyle: const TextStyle(color: AlshaariColors.pearlWhite),
        hintStyle: TextStyle(color: AlshaariColors.pearlWhite.withOpacity(0.55)),
        prefixIconColor: AlshaariColors.gold,
        suffixIconColor: AlshaariColors.gold,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: AlshaariColors.copper.withOpacity(0.22)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: AlshaariColors.copper.withOpacity(0.22)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: AlshaariColors.gold, width: 1.5),
        ),
      ),

      textTheme: const TextTheme(
        headlineLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.pearlWhite,
          fontWeight: FontWeight.w900,
        ),
        titleLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.pearlWhite,
          fontWeight: FontWeight.w800,
        ),
        bodyLarge: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.pearlWhite,
          height: 1.45,
        ),
        bodyMedium: TextStyle(
          fontFamily: 'Cairo',
          color: Color(0xFFD8D2C8),
          height: 1.45,
        ),
      ),
    );
  }
}

class BrandMark extends StatelessWidget {
  final double size;

  const BrandMark({
    super.key,
    this.size = 42,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        color: AlshaariColors.matteBlack,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(
          color: AlshaariColors.brass,
          width: 1.4,
        ),
        boxShadow: [
          BoxShadow(
            color: AlshaariColors.copper.withOpacity(0.18),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      alignment: Alignment.center,
      child: Text(
        'ش',
        style: TextStyle(
          fontFamily: 'Cairo',
          color: AlshaariColors.brass,
          fontSize: size * 0.52,
          fontWeight: FontWeight.w900,
          height: 1,
        ),
      ),
    );
  }
}
