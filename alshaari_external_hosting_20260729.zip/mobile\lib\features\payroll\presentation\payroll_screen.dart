import 'dart:ui' as ui;

import 'package:flutter/material.dart';

import '../../../app/theme.dart';
import '../../../core/permissions.dart';
import '../../../core/widgets/alshaari_ui.dart';
import 'payroll_api.dart';

class PayrollScreen extends StatefulWidget {
  const PayrollScreen({super.key});

  @override
  State<PayrollScreen> createState() => _PayrollScreenState();
}

class _PayrollScreenState extends State<PayrollScreen> {
  bool loading = true;
  int year = DateTime.now().year;
  int month = DateTime.now().month;
  List<Map<String, dynamic>> periods = [];
  List<Map<String, dynamic>> payrolls = [];
  List<Map<String, dynamic>> cashAccounts = [];
  Set<String> permissions = {};
  int? selectedPeriodId;

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() => loading = true);
    try {
      final dio = await payrollDio();
      final loadedPermissions = await AlshaariPermissions.currentPermissions();
      final periodsRes = await dio.get('/api/v1/payroll-periods');
      final cashRes = await dio.get('/api/v1/cash-accounts');
      final loadedPeriods = asList(periodsRes.data);
      Map<String, dynamic>? period;
      for (final item in loadedPeriods) {
        if (item['year'] == year && item['month'] == month) {
          period = item;
          break;
        }
      }
      final periodId = selectedPeriodId ?? period?['id'] as int?;
      List<Map<String, dynamic>> loadedPayrolls = [];
      if (periodId != null) {
        final payrollRes =
            await dio.get('/api/v1/payroll-periods/$periodId/payrolls');
        loadedPayrolls = asList(payrollRes.data);
      }
      if (!mounted) return;
      setState(() {
        periods = loadedPeriods;
        cashAccounts = asList(cashRes.data);
        permissions = loadedPermissions;
        selectedPeriodId = periodId;
        payrolls = loadedPayrolls;
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  bool can(String permission) {
    return AlshaariPermissions.hasPermission(permissions, permission);
  }

  Future<void> createPeriod() async {
    try {
      final start = DateTime(year, month, 1);
      final end = DateTime(year, month + 1, 0);
      final dio = await payrollDio();
      final res = await dio.post('/api/v1/payroll-periods', data: {
        'year': year,
        'month': month,
        'start_date': start.toIso8601String().substring(0, 10),
        'end_date': end.toIso8601String().substring(0, 10),
      });
      if (!mounted) return;
      selectedPeriodId =
          Map<String, dynamic>.from(res.data as Map)['id'] as int?;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم إنشاء فترة الرواتب.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> calculate() async {
    if (selectedPeriodId == null) {
      await createPeriod();
    }
    if (selectedPeriodId == null) return;
    try {
      final dio = await payrollDio();
      await dio.post('/api/v1/payroll-periods/$selectedPeriodId/calculate');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حساب رواتب الشهر بنجاح.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> approvePayroll(int id) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('اعتماد كشف الراتب'),
        content: const Text(
            'بعد اعتماد كشف الراتب سيتم إثبات الأجور المستحقة محاسبيًا ولا يمكن تعديله إلا بسند تسوية.'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('اعتماد')),
        ],
      ),
    );
    if (confirmed != true) return;
    try {
      final dio = await payrollDio();
      await dio.post('/api/v1/payrolls/$id/approve');
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('تم اعتماد كشف الراتب وإنشاء القيد المحاسبي.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> editPayroll(Map<String, dynamic> payroll) async {
    final gross = TextEditingController(text: '${payroll['gross_wage'] ?? 0}');
    final qat =
        TextEditingController(text: '${payroll['qat_allowance_total'] ?? 0}');
    final transport = TextEditingController(
        text: '${payroll['transport_allowance_total'] ?? 0}');
    final food =
        TextEditingController(text: '${payroll['food_allowance_total'] ?? 0}');
    final bonuses =
        TextEditingController(text: '${payroll['bonuses_total'] ?? 0}');
    final deductions =
        TextEditingController(text: '${payroll['deductions_total'] ?? 0}');
    final advances =
        TextEditingController(text: '${payroll['advances_total'] ?? 0}');

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تعديل كشف مرتب'),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text(
                  'التعديل متاح للمسودة فقط. بعد الاعتماد يتم التصحيح بسند تسوية.'),
              const SizedBox(height: 12),
              TextField(
                  controller: gross,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'إجمالي الأجر')),
              const SizedBox(height: 8),
              TextField(
                  controller: qat,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'بدل القات')),
              const SizedBox(height: 8),
              TextField(
                  controller: transport,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'بدل المواصلات')),
              const SizedBox(height: 8),
              TextField(
                  controller: food,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'بدل الغداء')),
              const SizedBox(height: 8),
              TextField(
                  controller: bonuses,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'الإضافات')),
              const SizedBox(height: 8),
              TextField(
                  controller: deductions,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(labelText: 'الخصومات')),
              const SizedBox(height: 8),
              TextField(
                  controller: advances,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'السلف المخصومة')),
            ],
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context, false),
              child: const Text('إلغاء')),
          FilledButton(
              onPressed: () => Navigator.pop(context, true),
              child: const Text('حفظ')),
        ],
      ),
    );
    if (saved != true) return;

    try {
      final dio = await payrollDio();
      await dio.put('/api/v1/payrolls/${payroll['id']}', data: {
        'gross_wage': num.tryParse(gross.text) ?? 0,
        'qat_allowance_total': num.tryParse(qat.text) ?? 0,
        'transport_allowance_total': num.tryParse(transport.text) ?? 0,
        'food_allowance_total': num.tryParse(food.text) ?? 0,
        'bonuses_total': num.tryParse(bonuses.text) ?? 0,
        'deductions_total': num.tryParse(deductions.text) ?? 0,
        'advances_total': num.tryParse(advances.text) ?? 0,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم تعديل كشف المرتب.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Future<void> payPayroll(Map<String, dynamic> payroll) async {
    int? accountId =
        cashAccounts.isNotEmpty ? cashAccounts.first['id'] as int? : null;
    final amount = TextEditingController(
        text: '${payroll['remaining_due'] ?? payroll['net_due'] ?? 0}');
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocal) => AlertDialog(
            title: const Text('دفع راتب'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text('سيتم تخفيض رصيد الصندوق المحدد بقيمة الدفعة.'),
                const SizedBox(height: 12),
                DropdownButtonFormField<int>(
                  initialValue: accountId,
                  decoration: const InputDecoration(
                      labelText: 'الصندوق / الحساب النقدي'),
                  items: cashAccounts
                      .map((item) => DropdownMenuItem<int>(
                            value: item['id'] as int?,
                            child: Text('${item['name'] ?? item['code']}'),
                          ))
                      .toList(),
                  onChanged: (value) => setLocal(() => accountId = value),
                ),
                const SizedBox(height: 10),
                TextField(
                  controller: amount,
                  keyboardType: TextInputType.number,
                  decoration:
                      const InputDecoration(labelText: 'المبلغ المدفوع'),
                ),
              ],
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('إلغاء')),
              FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('دفع')),
            ],
          ),
        );
      },
    );
    if (confirmed != true || accountId == null) return;
    try {
      final dio = await payrollDio();
      await dio.post('/api/v1/payrolls/${payroll['id']}/pay', data: {
        'amount': num.tryParse(amount.text) ?? 0,
        'cash_account_id': accountId,
      });
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم دفع الراتب وتحديث رصيد الصندوق.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Widget payrollCard(Map<String, dynamic> item) {
    final status = '${item['status'] ?? 'draft'}';
    final approved = status == 'approved';
    final paid = status == 'paid';
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${item['employee_name'] ?? 'عامل #${item['employee_id']}'}',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
                AlshaariStatusBadge(
                  label: paid
                      ? 'مدفوع'
                      : approved
                          ? 'معتمد'
                          : 'مسودة',
                  color: paid
                      ? AlshaariColors.success
                      : approved
                          ? AlshaariColors.deepGreen
                          : AlshaariColors.warning,
                ),
              ],
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(label: Text('عمل: ${item['worked_days'] ?? 0}')),
                Chip(label: Text('نصف يوم: ${item['half_days'] ?? 0}')),
                Chip(label: Text('جمع: ${item['paid_fridays'] ?? 0}')),
                Chip(label: Text('غياب: ${item['absent_days'] ?? 0}')),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                    child: AlshaariMoneyText(
                        'الصافي ${formatMoney(item['net_due'])}',
                        fontSize: 16)),
                Expanded(
                    child: AlshaariMoneyText(
                        'المتبقي ${formatMoney(item['remaining_due'])}',
                        danger: (item['remaining_due'] ?? 0) > 0,
                        fontSize: 16)),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                if (!approved && !paid && can('payroll.write'))
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => editPayroll(item),
                      icon: const Icon(Icons.edit_outlined),
                      label: const Text('تعديل'),
                    ),
                  ),
                if (!approved && !paid && can('payroll.write'))
                  const SizedBox(width: 8),
                if (!approved && !paid && can('payroll.approve'))
                  Expanded(
                    child: FilledButton.icon(
                      onPressed: () => approvePayroll(item['id'] as int),
                      icon: const Icon(Icons.verified),
                      label: const Text('اعتماد'),
                    ),
                  ),
                if (!approved && !paid && can('payroll.approve'))
                  const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: (approved || paid) && can('payroll.pay')
                        ? () => payPayroll(item)
                        : null,
                    icon: const Icon(Icons.payments_outlined),
                    label: const Text('دفع'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('الرواتب الشهرية'),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh))
          ],
        ),
        body: RefreshIndicator(
          onRefresh: load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const AlshaariPageHeader(
                title: 'كشف الرواتب',
                subtitle:
                    'الحساب يثبت الأجور المستحقة، والدفع وحده يخفض الصندوق.',
                icon: Icons.request_quote_outlined,
              ),
              const SizedBox(height: 12),
              AlshaariSectionCard(
                title: 'الفترة',
                icon: Icons.calendar_month,
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    SizedBox(
                      width: 120,
                      child: TextFormField(
                        initialValue: '$year',
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'السنة'),
                        onChanged: (value) =>
                            year = int.tryParse(value) ?? year,
                      ),
                    ),
                    SizedBox(
                      width: 120,
                      child: TextFormField(
                        initialValue: '$month',
                        keyboardType: TextInputType.number,
                        decoration: const InputDecoration(labelText: 'الشهر'),
                        onChanged: (value) =>
                            month = int.tryParse(value) ?? month,
                      ),
                    ),
                    FilledButton.icon(
                      onPressed: createPeriod,
                      icon: const Icon(Icons.add),
                      label: const Text('إنشاء فترة'),
                    ),
                    OutlinedButton.icon(
                      onPressed: calculate,
                      icon: const Icon(Icons.calculate_outlined),
                      label: const Text('حساب الرواتب'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (loading)
                const Center(
                    child: Padding(
                        padding: EdgeInsets.all(24),
                        child: CircularProgressIndicator())),
              if (!loading && payrolls.isEmpty)
                const AlshaariSectionCard(
                  child: Text(
                      'لا توجد كشوف محسوبة لهذه الفترة. أنشئ الفترة ثم اضغط حساب الرواتب.'),
                ),
              ...payrolls.map(payrollCard),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }
}
