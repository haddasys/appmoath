from datetime import date

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.database import get_db
from app.models.models import (
    Account,
    CashAccount,
    Customer,
    Invoice,
    Project,
    Supplier,
    SupplierInvoice,
    SupplierPayment,
    Transaction,
)

router = APIRouter(prefix="/api/v1", tags=["Dashboard"])


def f(v):
    return float(v or 0)


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user=Depends(get_current_user)):
    today = date.today()
    cash_accounts_total = (
        db.query(func.coalesce(func.sum(CashAccount.balance), 0))
        .filter(CashAccount.is_active == True)
        .scalar()
    )
    cash = cash_accounts_total or (
        db.query(func.coalesce(func.sum(Account.balance), 0))
        .filter(Account.type.in_(["cash", "bank"]))
        .scalar()
    )
    receipts = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.status == "approved",
            Transaction.type == "receipt_from_customer",
            Transaction.date == today,
        )
        .scalar()
    )
    transaction_payments = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.status == "approved",
            Transaction.type.in_(
                ["general_payment", "worker_wage", "advance_payment", "material_purchase"]
            ),
            Transaction.date == today,
        )
        .scalar()
    )
    supplier_payments_today = (
        db.query(func.coalesce(func.sum(SupplierPayment.amount), 0))
        .filter(SupplierPayment.status == "approved", SupplierPayment.payment_date == today)
        .scalar()
    )
    payments = f(transaction_payments) + f(supplier_payments_today)
    draft = db.query(Transaction).filter(Transaction.status == "draft").count()
    active_projects = (
        db.query(Project)
        .filter(Project.status.notin_(["delivered", "financially_closed", "closed"]))
        .count()
    )
    customers_count = db.query(Customer).count()
    suppliers_count = db.query(Supplier).count()
    customer_invoices = (
        db.query(func.coalesce(func.sum(Invoice.total), 0))
        .filter(Invoice.party_type == "customer", Invoice.status.in_(["posted", "open"]))
        .scalar()
    )
    customer_receipts = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.status == "approved",
            Transaction.type.in_(["receipt_from_customer", "customer_advance"]),
        )
        .scalar()
    )
    supplier_invoices = (
        db.query(func.coalesce(func.sum(Invoice.total), 0))
        .filter(Invoice.party_type == "supplier", Invoice.status.in_(["posted", "open"]))
        .scalar()
    )
    supplier_payments = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(
            Transaction.status == "approved",
            Transaction.type.in_(["supplier_payment", "supplier_advance"]),
        )
        .scalar()
    )
    purchase_payables_due = (
        db.query(func.coalesce(func.sum(SupplierInvoice.net_amount - SupplierInvoice.paid_amount), 0))
        .filter(SupplierInvoice.status.in_(["approved", "partially_paid"]))
        .scalar()
    )
    worker_advances = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(Transaction.status == "approved", Transaction.type == "advance_payment")
        .scalar()
    )
    worker_settlements = (
        db.query(func.coalesce(func.sum(Transaction.amount), 0))
        .filter(Transaction.status == "approved", Transaction.type == "advance_settlement")
        .scalar()
    )
    receivables_due = max(f(customer_invoices) - f(customer_receipts), 0)
    payables_due = max(f(supplier_invoices) - f(supplier_payments), 0) + max(
        f(purchase_payables_due), 0
    )
    open_worker_advances = max(f(worker_advances) - f(worker_settlements), 0)

    alerts = []
    if draft:
        alerts.append({"type": "draft_transactions", "message": f"حركات غير معتمدة: {draft}"})

    return {
        "cash_balance": f(cash),
        "today_receipts": f(receipts),
        "today_payments": f(payments),
        "today_revenues": f(receipts),
        "today_expenses": f(payments),
        "net_cash_today": f(receipts) - f(payments),
        "draft_transactions": draft,
        "active_projects": active_projects,
        "receivables_due": receivables_due,
        "payables_due": payables_due,
        "open_worker_advances": open_worker_advances,
        "customers_count": customers_count,
        "suppliers_count": suppliers_count,
        "alerts": alerts,
    }

