import 'dart:convert';

import 'package:image_picker/image_picker.dart';

import '../local_db/local_database.dart';
import '../local_db/local_entities.dart';
import 'sync_queue_item.dart';

class OfflineAttachmentResult {
  final String localUuid;
  final String temporaryNo;

  const OfflineAttachmentResult({
    required this.localUuid,
    required this.temporaryNo,
  });
}

class OfflineAttachmentService {
  final LocalDatabase database;

  const OfflineAttachmentService({required this.database});

  Future<OfflineAttachmentResult> enqueueUpload({
    required XFile file,
    required String entityType,
    required String entityLocalUuid,
    int? entityId,
  }) async {
    final now = DateTime.now().millisecondsSinceEpoch;
    final localUuid = database.newLocalUuid('attachment');
    final temporaryNo = await database.nextTemporaryNo(
      'attachment',
      'LOCAL-ATTACH',
    );
    final bytes = await file.readAsBytes();
    final payload = <String, dynamic>{
      'local_uuid': localUuid,
      'temporary_document_no': temporaryNo,
      'entity_type': entityType,
      'entity_local_uuid': entityLocalUuid,
      'entity_id': entityId ?? 0,
      'file_name': file.name,
      'file_path': file.path,
      'mime_type': file.mimeType,
      'file_data_base64': base64Encode(bytes),
      'sync_status': 'pending',
      'created_offline': true,
    };

    await database.upsertLocalAttachment(
      LocalAttachmentDraft(
        localUuid: localUuid,
        entityLocalUuid: entityLocalUuid,
        entityType: entityType,
        filePath: file.path,
        fileName: file.name,
        mimeType: file.mimeType,
        syncStatus: 'pending',
        fileDataBase64: payload['file_data_base64']?.toString(),
        createdAt: now,
      ),
    );

    await database.upsertQueueItem(
      SyncQueueItem(
        id: database.newLocalUuid('sync_queue'),
        localId: localUuid,
        entityType: 'attachment',
        operation: 'create',
        payloadJson: jsonEncode(payload),
        status: 'pending',
        retryCount: 0,
        createdAt: now,
        updatedAt: now,
      ),
    );

    return OfflineAttachmentResult(
      localUuid: localUuid,
      temporaryNo: temporaryNo,
    );
  }
}

final offlineAttachmentService =
    OfflineAttachmentService(database: localDatabase);
