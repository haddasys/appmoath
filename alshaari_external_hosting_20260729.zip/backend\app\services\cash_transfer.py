from decimal import Decimal
from sqlalchemy.orm import Session
from sqlalchemy.sql import func
from app.models.cash_transfer import CashTransfer
from app.services.cash_account import transfer_between_accounts
from app.services.journal import post_journal_entry
from app.services.guards import ensure_not_approved

def create_cash_transfer(db: Session, payload, current_user):
    transfer = CashTransfer(
        transfer_no=payload.transfer_no,
        from_cash_account_id=payload.from_cash_account_id,
        to_cash_account_id=payload.to_cash_account_id,
        amount=Decimal(str(payload.amount)),
        currency=payload.currency,
        payment_method=payload.payment_method,
        reason=payload.reason,
        status="draft",
        created_by=current_user.id,
    )
    db.add(transfer)
    db.commit()
    db.refresh(transfer)
    return transfer

def approve_cash_transfer(db: Session, transfer: CashTransfer, current_user):
    ensure_not_approved(transfer, "تحويل نقدي")

    amount = Decimal(str(transfer.amount))

    transfer_between_accounts(
        db=db,
        from_cash_account_id=transfer.from_cash_account_id,
        to_cash_account_id=transfer.to_cash_account_id,
        amount=amount,
    )

    journal_lines = [
        {
            "account_code": transfer.from_account.account_code,
            "description": f"سحب تحويل {transfer.transfer_no}",
            "debit": Decimal("0"),
            "credit": amount,
            "cash_account_id": transfer.from_cash_account_id,
        },
        {
            "account_code": transfer.to_account.account_code,
            "description": f"إيداع تحويل {transfer.transfer_no}",
            "debit": amount,
            "credit": Decimal("0"),
            "cash_account_id": transfer.to_cash_account_id,
        },
    ]

    journal = post_journal_entry(
        db=db,
        description=f"قيد اعتماد تحويل نقدي {transfer.transfer_no}",
        source_type="cash_transfer",
        source_id=transfer.id,
        created_by_id=current_user.id,
        lines=journal_lines,
        commit=False,
    )

    transfer.status = "approved"
    if hasattr(transfer, "approved_by_id"):
        transfer.approved_by_id = current_user.id
    else:
        transfer.approved_by = current_user.id
    transfer.approved_at = func.now()
    transfer.journal_entry_id = journal.id
    db.add(transfer)
    db.commit()
    db.refresh(transfer)
    return transfer

def reverse_cash_transfer(db: Session, transfer: CashTransfer, current_user):
    if transfer.status != "approved":
        raise ValueError("يمكن فقط عكس التحويلات المعتمدة.")
    amount = Decimal(str(transfer.amount))

    journal_lines = [
        {
            "account_code": transfer.from_account.account_code,
            "description": f"عكس تحويل {transfer.transfer_no}",
            "debit": amount,
            "credit": Decimal("0"),
            "cash_account_id": transfer.from_cash_account_id,
        },
        {
            "account_code": transfer.to_account.account_code,
            "description": f"عكس تحويل {transfer.transfer_no}",
            "debit": Decimal("0"),
            "credit": amount,
            "cash_account_id": transfer.to_cash_account_id,
        },
    ]

    journal = post_journal_entry(
        db=db,
        description=f"قيد عكس تحويل نقدي {transfer.transfer_no}",
        source_type="cash_transfer",
        source_id=transfer.id,
        created_by_id=current_user.id,
        lines=journal_lines,
        commit=False,
    )

    transfer.status = "reversed"
    transfer.journal_entry_id = journal.id
    db.add(transfer)
    db.commit()
    db.refresh(transfer)
    return transfer