BEGIN;

CREATE TABLE IF NOT EXISTS document_sequences (
    id SERIAL PRIMARY KEY,
    document_type VARCHAR(60) UNIQUE NOT NULL,
    prefix VARCHAR(20) NOT NULL,
    next_number INTEGER DEFAULT 1,
    padding INTEGER DEFAULT 6,
    is_active BOOLEAN DEFAULT TRUE
);

INSERT INTO document_sequences (document_type, prefix, next_number, padding, is_active)
VALUES
    ('transaction', 'TX', 1, 6, TRUE),
    ('journal_entry', 'JE', 1, 6, TRUE),
    ('receipt', 'RV', 1, 6, TRUE),
    ('payment', 'PV', 1, 6, TRUE),
    ('invoice', 'INV', 1, 6, TRUE)
ON CONFLICT (document_type) DO NOTHING;

ALTER TABLE transactions ADD COLUMN IF NOT EXISTS document_no VARCHAR(80);
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS reversal_of_id INTEGER;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS reversed_by_id INTEGER;
ALTER TABLE transactions ADD COLUMN IF NOT EXISTS void_reason TEXT;

ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS reversal_of_id INTEGER;
ALTER TABLE journal_entries ADD COLUMN IF NOT EXISTS is_reversal BOOLEAN DEFAULT FALSE;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'uq_transactions_document_no'
    ) THEN
        ALTER TABLE transactions
        ADD CONSTRAINT uq_transactions_document_no UNIQUE (document_no);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_transactions_reversal_of'
    ) THEN
        ALTER TABLE transactions
        ADD CONSTRAINT fk_transactions_reversal_of
        FOREIGN KEY (reversal_of_id) REFERENCES transactions(id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_transactions_reversed_by'
    ) THEN
        ALTER TABLE transactions
        ADD CONSTRAINT fk_transactions_reversed_by
        FOREIGN KEY (reversed_by_id) REFERENCES transactions(id);
    END IF;
END $$;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'fk_journal_entries_reversal_of'
    ) THEN
        ALTER TABLE journal_entries
        ADD CONSTRAINT fk_journal_entries_reversal_of
        FOREIGN KEY (reversal_of_id) REFERENCES journal_entries(id);
    END IF;
END $$;

COMMIT;
