import 'package:flutter/foundation.dart';

class AppConfig {
  static const _configuredApiBaseUrl = String.fromEnvironment('API_BASE_URL');

  static String get apiBaseUrl {
    if (_configuredApiBaseUrl.isNotEmpty) {
      return _configuredApiBaseUrl.replaceAll(RegExp(r'/+$'), '');
    }
    if (kIsWeb) {
      final pageHost = Uri.base.host.isEmpty ? 'localhost' : Uri.base.host;
      final host = pageHost == 'localhost' ? '127.0.0.1' : pageHost;
      final scheme = Uri.base.scheme == 'https' ? 'https' : 'http';
      return '$scheme://$host:8000';
    }
    return 'http://10.0.2.2:8000';
  }
}
