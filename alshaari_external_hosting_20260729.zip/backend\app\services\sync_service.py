from datetime import datetime
from typing import Any

from fastapi import HTTPException
from sqlalchemy import func, text
from sqlalchemy.orm import Session

from app.models.models import Device, SyncLog, Transaction
from app.schemas.schemas import (
    AttendanceBulkCreate,
    AttendanceCreate,
    SyncOperation,
    TransactionCreate,
)
from app.services.attendance_service import bulk_save_attendance, create_attendance
from app.services.offline_sync_schema import ensure_offline_sync_schema
from app.services.transaction_service import create_transaction


TRANSACTION_CREATE_ENTITIES = {"transaction", "transactions"}
ATTENDANCE_CREATE_ENTITIES = {"attendance", "attendances"}
ATTENDANCE_BULK_CREATE_ENTITIES = {"attendance_bulk", "bulk_attendance"}
SUPPORTED_CREATE_ENTITIES = (
    TRANSACTION_CREATE_ENTITIES
    | ATTENDANCE_CREATE_ENTITIES
    | ATTENDANCE_BULK_CREATE_ENTITIES
)


def _log_sync(
    db: Session,
    *,
    device_id: str,
    user_id: int | None,
    entity_type: str,
    local_uuid: str,
    operation: str,
    status: str,
    server_id: int | None = None,
    error_message: str | None = None,
) -> SyncLog:
    log = SyncLog(
        device_id=device_id,
        user_id=user_id,
        entity_type=entity_type,
        local_uuid=local_uuid,
        server_id=server_id,
        operation=operation,
        status=status,
        error_message=error_message,
    )
    db.add(log)
    return log


def _document_no_for(entity_type: str, server_id: int | None, db: Session) -> str | None:
    if not server_id:
        return None
    if entity_type in TRANSACTION_CREATE_ENTITIES:
        tx = db.query(Transaction).filter(Transaction.id == server_id).first()
        if tx:
            return tx.voucher_no or tx.document_no
    return None


def _synced_result(
    *,
    local_uuid: str,
    entity_type: str,
    server_id: int | None,
    official_no: str | None,
    message: str | None = None,
    summary: dict[str, Any] | None = None,
) -> dict[str, Any]:
    result = {
        "local_uuid": local_uuid,
        "entity_type": entity_type,
        "status": "synced",
        "server_id": server_id,
        "official_no": official_no,
        "official_document_no": official_no,
    }
    if message:
        result["message"] = message
    if summary is not None:
        result["summary"] = summary
    return result


def _attendance_by_local_uuid(db: Session, local_uuid: str):
    return db.execute(
        text(
            """
            SELECT id
            FROM attendance
            WHERE local_uuid = :local_uuid
            LIMIT 1
            """
        ),
        {"local_uuid": local_uuid},
    ).mappings().first()


def _iso_value(value):
    if value is None:
        return None
    if hasattr(value, "isoformat"):
        return value.isoformat()
    return value


def register_device(db: Session, device_id: str, device_name: str | None, user_id: int | None):
    ensure_offline_sync_schema(db)
    device = db.query(Device).filter(Device.device_id == device_id).first()
    now = datetime.utcnow()
    if device:
        device.device_name = device_name or device.device_name
        device.user_id = user_id or device.user_id
        device.last_sync_at = now
        device.is_active = True
    else:
        device = Device(
            device_id=device_id,
            device_name=device_name,
            user_id=user_id,
            last_sync_at=now,
            is_active=True,
        )
        db.add(device)
    db.commit()
    db.refresh(device)
    return {
        "device_id": device.device_id,
        "device_name": device.device_name,
        "last_sync_at": device.last_sync_at,
        "is_active": device.is_active,
    }


def _existing_synced_result(db: Session, device_id: str, operation: SyncOperation) -> dict[str, Any] | None:
    existing_log = (
        db.query(SyncLog)
        .filter(
            SyncLog.device_id == device_id,
            SyncLog.local_uuid == operation.local_uuid,
            SyncLog.entity_type == operation.entity_type,
            SyncLog.status == "synced",
        )
        .order_by(SyncLog.id.desc())
        .first()
    )
    if existing_log:
        return _synced_result(
            local_uuid=operation.local_uuid,
            entity_type=operation.entity_type,
            server_id=existing_log.server_id,
            official_no=_document_no_for(
                operation.entity_type,
                existing_log.server_id,
                db,
            ),
            message="تمت مزامنة هذا المستند سابقًا، ولم يتم إنشاء تكرار.",
        )

    if operation.entity_type in TRANSACTION_CREATE_ENTITIES:
        tx = db.query(Transaction).filter(Transaction.local_uuid == operation.local_uuid).first()
        if tx:
            _log_sync(
                db,
                device_id=device_id,
                user_id=tx.created_by,
                entity_type=operation.entity_type,
                local_uuid=operation.local_uuid,
                operation=operation.operation,
                status="synced",
                server_id=tx.id,
            )
            db.commit()
            return _synced_result(
                local_uuid=operation.local_uuid,
                entity_type=operation.entity_type,
                server_id=tx.id,
                official_no=tx.voucher_no or tx.document_no,
                message="تم العثور على المستند المحلي محفوظًا سابقًا.",
            )

    if operation.entity_type in ATTENDANCE_CREATE_ENTITIES:
        attendance = _attendance_by_local_uuid(db, operation.local_uuid)
        if attendance:
            _log_sync(
                db,
                device_id=device_id,
                user_id=None,
                entity_type=operation.entity_type,
                local_uuid=operation.local_uuid,
                operation=operation.operation,
                status="synced",
                server_id=attendance["id"],
            )
            db.commit()
            return _synced_result(
                local_uuid=operation.local_uuid,
                entity_type=operation.entity_type,
                server_id=attendance["id"],
                official_no=None,
                message="تم العثور على سجل الحضور المحلي محفوظًا سابقًا.",
            )

    return None


def _sync_transaction_create(
    db: Session,
    *,
    device_id: str,
    operation: SyncOperation,
    user_id: int,
) -> dict[str, Any]:
    payload = dict(operation.payload or {})
    payload["local_uuid"] = operation.local_uuid
    payload["device_id"] = device_id
    payload["sync_status"] = "synced"
    payload["created_offline"] = True

    data = TransactionCreate(**payload)
    tx = create_transaction(db, data, user_id)
    tx.sync_status = "synced"
    tx.device_id = device_id
    tx.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(tx)

    _log_sync(
        db,
        device_id=device_id,
        user_id=user_id,
        entity_type=operation.entity_type,
        local_uuid=operation.local_uuid,
        operation=operation.operation,
        status="synced",
        server_id=tx.id,
    )
    db.commit()

    return _synced_result(
        local_uuid=operation.local_uuid,
        entity_type=operation.entity_type,
        server_id=tx.id,
        official_no=tx.voucher_no or tx.document_no,
    )


def _mark_attendance_synced(
    db: Session,
    *,
    attendance_id: int,
    local_uuid: str | None,
    device_id: str,
) -> None:
    db.execute(
        text(
            """
            UPDATE attendance
            SET local_uuid = COALESCE(local_uuid, :local_uuid),
                device_id = :device_id,
                sync_status = 'synced',
                created_offline = TRUE,
                server_version = COALESCE(server_version, 1),
                updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
            """
        ),
        {
            "id": attendance_id,
            "local_uuid": local_uuid,
            "device_id": device_id,
        },
    )


def _sync_attendance_create(
    db: Session,
    *,
    device_id: str,
    operation: SyncOperation,
    user_id: int,
) -> dict[str, Any]:
    data = AttendanceCreate(**dict(operation.payload or {}))
    row = create_attendance(db, data, user_id)
    attendance_id = row["id"]
    _mark_attendance_synced(
        db,
        attendance_id=attendance_id,
        local_uuid=operation.local_uuid,
        device_id=device_id,
    )
    _log_sync(
        db,
        device_id=device_id,
        user_id=user_id,
        entity_type=operation.entity_type,
        local_uuid=operation.local_uuid,
        operation=operation.operation,
        status="synced",
        server_id=attendance_id,
    )
    db.commit()
    return _synced_result(
        local_uuid=operation.local_uuid,
        entity_type=operation.entity_type,
        server_id=attendance_id,
        official_no=None,
    )


def _sync_attendance_bulk_create(
    db: Session,
    *,
    device_id: str,
    operation: SyncOperation,
    user_id: int,
) -> dict[str, Any]:
    data = AttendanceBulkCreate(**dict(operation.payload or {}))
    summary = bulk_save_attendance(
        db,
        data.date,
        data.records,
        data.project_id,
        data.cost_center_id,
        user_id,
    )
    for row in summary.get("records", []):
        _mark_attendance_synced(
            db,
            attendance_id=row["id"],
            local_uuid=None,
            device_id=device_id,
        )

    _log_sync(
        db,
        device_id=device_id,
        user_id=user_id,
        entity_type=operation.entity_type,
        local_uuid=operation.local_uuid,
        operation=operation.operation,
        status="synced",
        server_id=None,
    )
    db.commit()
    return _synced_result(
        local_uuid=operation.local_uuid,
        entity_type=operation.entity_type,
        server_id=None,
        official_no=None,
        summary={
            "total_records": summary.get("total_records", 0),
            "created_count": summary.get("created_count", 0),
            "updated_count": summary.get("updated_count", 0),
            "present_count": summary.get("present_count", 0),
            "absent_count": summary.get("absent_count", 0),
            "half_day_count": summary.get("half_day_count", 0),
        },
    )


def push_operations(db: Session, *, device_id: str, operations: list[SyncOperation], user_id: int):
    ensure_offline_sync_schema(db)
    register_device(db, device_id=device_id, device_name=None, user_id=user_id)

    results = []
    for operation in operations:
        if not operation.local_uuid:
            results.append(
                {
                    "local_uuid": None,
                    "entity_type": operation.entity_type,
                    "status": "failed",
                    "error_message": "local_uuid إلزامي لمنع تكرار المستندات.",
                }
            )
            continue

        existing = _existing_synced_result(db, device_id, operation)
        if existing:
            results.append(existing)
            continue

        try:
            if operation.operation != "create":
                raise HTTPException(
                    status_code=400,
                    detail="في هذه المرحلة المزامنة تدعم إنشاء المسودات فقط.",
                )

            if operation.entity_type in TRANSACTION_CREATE_ENTITIES:
                results.append(
                    _sync_transaction_create(
                        db,
                        device_id=device_id,
                        operation=operation,
                        user_id=user_id,
                    )
                )
            elif operation.entity_type in ATTENDANCE_CREATE_ENTITIES:
                results.append(
                    _sync_attendance_create(
                        db,
                        device_id=device_id,
                        operation=operation,
                        user_id=user_id,
                    )
                )
            elif operation.entity_type in ATTENDANCE_BULK_CREATE_ENTITIES:
                results.append(
                    _sync_attendance_bulk_create(
                        db,
                        device_id=device_id,
                        operation=operation,
                        user_id=user_id,
                    )
                )
            else:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "هذا النوع سيضاف في Sprint لاحق. المدعوم الآن: "
                        "transaction و attendance create كمسودات."
                    ),
                )
        except Exception as exc:
            db.rollback()
            message = getattr(exc, "detail", None) or str(exc)
            status = "failed"
            if (
                isinstance(exc, HTTPException)
                and 400 <= exc.status_code < 500
                and operation.operation == "create"
                and operation.entity_type in SUPPORTED_CREATE_ENTITIES
            ):
                status = "conflict"
            _log_sync(
                db,
                device_id=device_id,
                user_id=user_id,
                entity_type=operation.entity_type,
                local_uuid=operation.local_uuid,
                operation=operation.operation,
                status=status,
                error_message=message,
            )
            db.commit()
            results.append(
                {
                    "local_uuid": operation.local_uuid,
                    "entity_type": operation.entity_type,
                    "status": status,
                    "error_message": message,
                }
            )

    device = db.query(Device).filter(Device.device_id == device_id).first()
    if device:
        device.last_sync_at = datetime.utcnow()
        db.commit()

    return {"results": results, "server_time": datetime.utcnow()}


def pull_updates(db: Session, *, since: datetime | None, user_id: int):
    ensure_offline_sync_schema(db)
    query = db.query(Transaction)
    if since:
        query = query.filter(
            (Transaction.updated_at != None) & (Transaction.updated_at >= since)
            | ((Transaction.updated_at == None) & (Transaction.created_at >= since))
        )

    updates = []
    for tx in query.order_by(Transaction.id.desc()).limit(500).all():
        updates.append(
            {
                "entity_type": "transaction",
                "server_id": tx.id,
                "local_uuid": tx.local_uuid,
                "server_version": tx.server_version,
                "sync_status": tx.sync_status,
                "official_no": tx.voucher_no or tx.document_no,
                "official_document_no": tx.voucher_no or tx.document_no,
                "payload": {
                    "id": tx.id,
                    "date": _iso_value(tx.date),
                    "type": tx.type,
                    "amount": str(tx.amount),
                    "status": tx.status,
                    "description": tx.description,
                },
                "updated_at": (tx.updated_at or tx.created_at),
            }
        )

    attendance_where = ""
    params: dict[str, Any] = {}
    if since:
        attendance_where = """
            WHERE (updated_at IS NOT NULL AND updated_at >= :since)
               OR (updated_at IS NULL AND created_at >= :since)
        """
        params["since"] = since
    attendance_rows = db.execute(
        text(
            f"""
            SELECT id, local_uuid, server_version, sync_status, date,
                   employee_id, status, project_id, cost_center_id, notes,
                   updated_at, created_at
            FROM attendance
            {attendance_where}
            ORDER BY id DESC
            LIMIT 500
            """
        ),
        params,
    ).mappings().all()
    for row in attendance_rows:
        updates.append(
            {
                "entity_type": "attendance",
                "server_id": row["id"],
                "local_uuid": row["local_uuid"],
                "server_version": row["server_version"],
                "sync_status": row["sync_status"],
                "official_no": None,
                "official_document_no": None,
                "payload": {
                    "id": row["id"],
                    "date": _iso_value(row["date"]),
                    "employee_id": row["employee_id"],
                    "status": row["status"],
                    "project_id": row["project_id"],
                    "cost_center_id": row["cost_center_id"],
                    "notes": row["notes"],
                },
                "updated_at": (row["updated_at"] or row["created_at"]),
            }
        )

    return {"server_time": datetime.utcnow(), "updates": updates}


def sync_status(db: Session, *, device_id: str | None, user_id: int):
    ensure_offline_sync_schema(db)
    query = db.query(SyncLog.status, func.count(SyncLog.id))
    if device_id:
        query = query.filter(SyncLog.device_id == device_id)
    rows = query.group_by(SyncLog.status).all()
    counts = {status: count for status, count in rows}
    return {
        "device_id": device_id,
        "pending": 0,
        "syncing": 0,
        "synced": counts.get("synced", 0),
        "failed": counts.get("failed", 0),
        "conflict": counts.get("conflict", 0),
        "server_time": datetime.utcnow(),
    }
