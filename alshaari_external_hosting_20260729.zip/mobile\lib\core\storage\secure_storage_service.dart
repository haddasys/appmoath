import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class CachedSession {
  final String? accessToken;
  final String? refreshToken;
  final String? userId;
  final String? userRole;
  final String? deviceId;
  final List<String> permissions;

  const CachedSession({
    this.accessToken,
    this.refreshToken,
    this.userId,
    this.userRole,
    this.deviceId,
    this.permissions = const [],
  });

  bool get canUseOffline =>
      accessToken != null && accessToken!.isNotEmpty && userRole != null;
}

class SecureStorageService {
  static const _accessTokenKey = 'token';
  static const _refreshTokenKey = 'refresh_token';
  static const _userIdKey = 'user_id';
  static const _userRoleKey = 'role';
  static const _deviceIdKey = 'alshaari_device_id';
  static const _permissionsKey = 'permissions';

  Future<CachedSession> cachedSession() async {
    final prefs = await SharedPreferences.getInstance();
    final rawPermissions = prefs.getString(_permissionsKey);
    return CachedSession(
      accessToken: prefs.getString(_accessTokenKey),
      refreshToken: prefs.getString(_refreshTokenKey),
      userId: prefs.getString(_userIdKey),
      userRole: prefs.getString(_userRoleKey) ??
          prefs.getString('user_role') ??
          prefs.getString('current_user_role'),
      deviceId: prefs.getString(_deviceIdKey),
      permissions: _decodePermissions(rawPermissions),
    );
  }

  Future<void> cacheSession({
    String? accessToken,
    String? refreshToken,
    String? userId,
    String? userRole,
    String? deviceId,
    List<String>? permissions,
  }) async {
    final prefs = await SharedPreferences.getInstance();
    if (accessToken != null) {
      await prefs.setString(_accessTokenKey, accessToken);
    }
    if (refreshToken != null) {
      await prefs.setString(_refreshTokenKey, refreshToken);
    }
    if (userId != null) {
      await prefs.setString(_userIdKey, userId);
    }
    if (userRole != null) {
      await prefs.setString(_userRoleKey, userRole);
    }
    if (deviceId != null) {
      await prefs.setString(_deviceIdKey, deviceId);
    }
    if (permissions != null) {
      await prefs.setString(_permissionsKey, jsonEncode(permissions));
    }
  }

  Future<void> clearSession() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(_accessTokenKey);
    await prefs.remove(_refreshTokenKey);
    await prefs.remove(_userIdKey);
    await prefs.remove(_userRoleKey);
    await prefs.remove('user_role');
    await prefs.remove('current_user_role');
    await prefs.remove(_permissionsKey);
  }

  List<String> _decodePermissions(String? raw) {
    if (raw == null || raw.isEmpty) return const [];
    try {
      final rows = jsonDecode(raw) as List;
      return rows.map((item) => '$item').toList();
    } catch (_) {
      return const [];
    }
  }
}

final secureStorageService = SecureStorageService();
