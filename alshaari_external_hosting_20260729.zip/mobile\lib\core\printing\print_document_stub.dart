Future<void> openPrintDocument({
  required String title,
  required String content,
}) async {
  throw UnsupportedError('Printing is available in the web build only.');
}
