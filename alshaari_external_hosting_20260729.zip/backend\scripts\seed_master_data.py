from app.db.database import SessionLocal, Base, engine
from app.models.models import Account, Item

Base.metadata.create_all(bind=engine)

def upsert_account(db, code, name, type_, currency="YER"):
    obj = db.query(Account).filter(Account.code == code).first()
    if not obj:
        db.add(Account(code=code, name=name, type=type_, currency=currency, balance=0))
    else:
        obj.name = name
        obj.type = type_
        obj.currency = currency


def upsert_item(db, code, name, unit, reorder=0, avg_cost=0, qty=0):
    obj = db.query(Item).filter(Item.code == code).first()
    if not obj:
        db.add(Item(code=code, name=name, unit=unit, current_qty=qty, avg_cost=avg_cost, reorder_level=reorder))
    else:
        obj.name = name
        obj.unit = unit
        obj.reorder_level = reorder

ACCOUNTS = [
    ("10101", "صندوق يمني", "cash", "YER"),
    ("10102", "صندوق سعودي", "cash", "SAR"),
    ("10103", "صندوق دولار", "cash", "USD"),
    ("10104", "عهدة نقدية مؤقتة", "asset", "YER"),
    ("10201", "حساب الكريمي", "bank", "YER"),
    ("10202", "حساب بنك محلي", "bank", "YER"),
    ("10203", "حوالات قيد التحصيل", "asset", "YER"),
    ("10301", "العملاء", "asset", "YER"),
    ("10302", "دفعات عملاء مقدمة", "liability", "YER"),
    ("10303", "شيكات/حوالات عملاء قيد التحصيل", "asset", "YER"),
    ("10401", "مخزون خشب MDF", "asset", "YER"),
    ("10402", "مخزون أبلاكاش", "asset", "YER"),
    ("10403", "مخزون دهانات", "asset", "YER"),
    ("10404", "مخزون إكسسوارات", "asset", "YER"),
    ("10405", "مخزون زجاج وألمنيوم", "asset", "YER"),
    ("10406", "مخزون إسفنج وتنجيد", "asset", "YER"),
    ("10409", "مواد تحت الجرد", "control", "YER"),
    ("10501", "آلات ومعدات CNC", "asset", "YER"),
    ("10502", "أدوات وعدد إنتاج", "asset", "YER"),
    ("10503", "أثاث وتجهيزات المعرض", "asset", "YER"),
    ("10504", "أجهزة كمبيوتر وبرامج", "asset", "YER"),
    ("10509", "مجمع إهلاك الأصول", "asset_contra", "YER"),
    ("20101", "الموردون", "liability", "YER"),
    ("20102", "موردو الأخشاب", "liability", "YER"),
    ("20103", "موردو الدهانات", "liability", "YER"),
    ("20104", "موردو الإكسسوارات", "liability", "YER"),
    ("20105", "موردو الزجاج والألمنيوم", "liability", "YER"),
    ("20106", "موردو الإسفنج والتنجيد", "liability", "YER"),
    ("20201", "أجور مستحقة للعمال", "liability", "YER"),
    ("20202", "سلف العمال", "asset", "YER"),
    ("20203", "عهد العمال", "asset", "YER"),
    ("20301", "إيجارات مستحقة", "liability", "YER"),
    ("20302", "كهرباء ومياه مستحقة", "liability", "YER"),
    ("20303", "التزامات نقل وتركيب", "liability", "YER"),
    ("20304", "مصروفات مستحقة أخرى", "liability", "YER"),
    ("30101", "رأس مال معاذ الشعري", "equity", "YER"),
    ("30201", "مسحوبات شخصية", "equity_contra", "YER"),
    ("30301", "أرباح أو خسائر مرحلة", "equity", "YER"),
    ("30401", "صافي ربح الفترة", "equity", "YER"),
    ("40101", "إيرادات غرف النوم", "revenue", "YER"),
    ("40102", "إيرادات الدواليب", "revenue", "YER"),
    ("40103", "إيرادات المجالس والكنب", "revenue", "YER"),
    ("40104", "إيرادات الديكورات والبارتيشن", "revenue", "YER"),
    ("40105", "إيرادات CNC لعملاء خارجيين", "revenue", "YER"),
    ("40106", "إيرادات كوش الأعراس", "revenue", "YER"),
    ("40107", "إيرادات صيانة وتعديلات", "revenue", "YER"),
    ("40901", "خصومات ومردودات مبيعات", "revenue_contra", "YER"),
    ("50101", "تكلفة خشب MDF", "direct_cost", "YER"),
    ("50102", "تكلفة أبلاكاش", "direct_cost", "YER"),
    ("50103", "تكلفة دهانات", "direct_cost", "YER"),
    ("50104", "تكلفة إكسسوارات", "direct_cost", "YER"),
    ("50105", "تكلفة زجاج وألمنيوم", "direct_cost", "YER"),
    ("50106", "تكلفة إسفنج وتنجيد", "direct_cost", "YER"),
    ("50201", "أجور نجارة مباشرة", "direct_cost", "YER"),
    ("50202", "أجور CNC مباشرة", "direct_cost", "YER"),
    ("50203", "أجور صنفرة", "direct_cost", "YER"),
    ("50204", "أجور دهان", "direct_cost", "YER"),
    ("50205", "أجور تشطيب وتركيب", "direct_cost", "YER"),
    ("50301", "نقل المشروع", "direct_cost", "YER"),
    ("50302", "تركيب خارجي", "direct_cost", "YER"),
    ("50303", "مصاريف مشروع أخرى", "direct_cost", "YER"),
    ("60101", "إيجار المعرض/الورشة", "expense", "YER"),
    ("60102", "كهرباء ومياه", "expense", "YER"),
    ("60103", "إنترنت واتصالات", "expense", "YER"),
    ("60104", "صيانة معدات", "expense", "YER"),
    ("60105", "أدوات واستهلاكات عامة", "expense", "YER"),
    ("60106", "نظافة وضيافة", "expense", "YER"),
    ("60201", "مصاريف تسويق وإعلانات", "expense", "YER"),
    ("60202", "تصوير ومونتاج", "expense", "YER"),
    ("60203", "تصاميم وبراندنج", "expense", "YER"),
    ("60301", "مصاريف إدارية", "expense", "YER"),
    ("60302", "رواتب إدارية", "expense", "YER"),
    ("60303", "مواصلات إدارية", "expense", "YER"),
    ("60401", "مصروفات بنكية وتحويلات", "expense", "YER"),
    ("60402", "فروقات عملة", "expense", "YER"),
    ("70101", "حركات غير معتمدة", "control", "YER"),
    ("70102", "فواتير غير مرفقة", "control", "YER"),
    ("70103", "فروقات جرد", "control", "YER"),
    ("70104", "مشاريع تحت المراجعة", "control", "YER"),
    ("70105", "التزامات عاجلة", "control", "YER"),
]

ITEMS = [
    ("MDF-18", "MDF 18 ملم", "لوح", 3, 0, 0),
    ("MDF-15", "MDF 15 ملم", "لوح", 3, 0, 0),
    ("MDF-09", "MDF 9 ملم", "لوح", 3, 0, 0),
    ("PLY-12", "أبلاكاش 12 ملم", "لوح", 3, 0, 0),
    ("PLY-18", "أبلاكاش 18 ملم", "لوح", 3, 0, 0),
    ("MEL-WHITE", "ميلامين أبيض لؤلؤي", "لوح", 3, 0, 0),
    ("EDGE-WHITE", "شريط PVC أبيض", "رول", 1, 0, 0),
    ("EDGE-GOLD", "شريط PVC ذهبي/نحاسي", "رول", 1, 0, 0),
    ("PAINT-BASE", "أساس دهان", "علبة", 2, 0, 0),
    ("PAINT-THINNER", "تينار", "جالون", 2, 0, 0),
    ("PAINT-CLEAR", "ورنيش/كلير", "علبة", 2, 0, 0),
    ("PAINT-COLOR", "دهان ملون", "علبة", 2, 0, 0),
    ("HINGE-STD", "مفصلة عادية", "حبة", 20, 0, 0),
    ("HINGE-SOFT", "مفصلة سوفت كلوز", "حبة", 20, 0, 0),
    ("SLIDE-35", "سحاب درج 35 سم", "زوج", 10, 0, 0),
    ("SLIDE-45", "سحاب درج 45 سم", "زوج", 10, 0, 0),
    ("HANDLE-GOLD", "مسكة ذهبية", "حبة", 20, 0, 0),
    ("HANDLE-BLACK", "مسكة سوداء", "حبة", 20, 0, 0),
    ("GLASS-CLEAR", "زجاج شفاف", "متر", 2, 0, 0),
    ("GLASS-BRONZE", "زجاج برونزي", "متر", 2, 0, 0),
    ("ALU-PROFILE", "بروفيل ألمنيوم", "متر", 10, 0, 0),
    ("FOAM-30", "إسفنج 30", "متر", 3, 0, 0),
    ("FABRIC", "قماش تنجيد", "متر", 5, 0, 0),
    ("LED-3000K", "شريط إضاءة LED 3000K", "متر", 5, 0, 0),
    ("SCREW", "براغي متنوعة", "علبة", 5, 0, 0),
    ("GLUE", "غراء خشب", "علبة", 3, 0, 0),
]

if __name__ == "__main__":
    db = SessionLocal()
    try:
        for row in ACCOUNTS:
            upsert_account(db, *row)
        for row in ITEMS:
            upsert_item(db, *row)
        db.commit()
        print(f"تم تحديث دليل الحسابات: {len(ACCOUNTS)} حساب")
        print(f"تم تحديث المخزون القياسي: {len(ITEMS)} مادة")
    finally:
        db.close()
