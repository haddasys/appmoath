from app.db.database import SessionLocal
from app.models.models import Account, CashAccount, Item, Role, Permission, Employee

ACCOUNTS = [
    ("10101", "صندوق يمني", "cash", "YER", None),
    ("10102", "صندوق سعودي", "cash", "SAR", None),
    ("10103", "صندوق دولار", "cash", "USD", None),
    ("10104", "عهدة نقدية مؤقتة", "asset", "YER", None),
    ("10201", "حساب الكريمي", "bank", "YER", None),
    ("10202", "حساب بنك محلي", "bank", "YER", None),
    ("10203", "حوالات قيد التحصيل", "asset", "YER", None),
    ("10301", "العملاء", "asset", "YER", None),
    ("10302", "دفعات عملاء مقدمة", "liability", "YER", None),
    ("10303", "شيكات/حوالات عملاء قيد التحصيل", "asset", "YER", None),
    ("10401", "مخزون خشب MDF", "asset", "YER", None),
    ("10402", "مخزون أبلاكاش", "asset", "YER", None),
    ("10403", "مخزون دهانات", "asset", "YER", None),
    ("10404", "مخزون إكسسوارات", "asset", "YER", None),
    ("10405", "مخزون زجاج وألمنيوم", "asset", "YER", None),
    ("10406", "مخزون إسفنج وتنجيد", "asset", "YER", None),
    ("10409", "مواد تحت الجرد", "control", "YER", None),
    ("10501", "آلات ومعدات CNC", "asset", "YER", None),
    ("10502", "أدوات وعدد إنتاج", "asset", "YER", None),
    ("10503", "أثاث وتجهيزات المعرض", "asset", "YER", None),
    ("10504", "أجهزة كمبيوتر وبرامج", "asset", "YER", None),
    ("10509", "مجمع إهلاك الأصول", "asset_contra", "YER", None),
    ("20101", "الموردون", "liability", "YER", None),
    ("20102", "موردو الأخشاب", "liability", "YER", None),
    ("20103", "موردو الدهانات", "liability", "YER", None),
    ("20104", "موردو الإكسسوارات", "liability", "YER", None),
    ("20105", "موردو الزجاج والألمنيوم", "liability", "YER", None),
    ("20106", "موردو الإسفنج والتنجيد", "liability", "YER", None),
    ("20201", "أجور مستحقة للعمال", "liability", "YER", None),
    ("20202", "سلف العمال", "asset", "YER", None),
    ("20203", "عهد العمال", "asset", "YER", None),
    ("20301", "إيجارات مستحقة", "liability", "YER", None),
    ("20302", "كهرباء ومياه مستحقة", "liability", "YER", None),
    ("20303", "التزامات نقل وتركيب", "liability", "YER", None),
    ("20304", "مصروفات مستحقة أخرى", "liability", "YER", None),
    ("30101", "رأس مال معاذ الشعري", "equity", "YER", None),
    ("30201", "مسحوبات شخصية", "equity_contra", "YER", None),
    ("30301", "أرباح أو خسائر مرحلة", "equity", "YER", None),
    ("30401", "صافي ربح الفترة", "equity", "YER", None),
    ("40101", "إيرادات غرف النوم", "revenue", "YER", None),
    ("40102", "إيرادات الدواليب", "revenue", "YER", None),
    ("40103", "إيرادات المجالس والكنب", "revenue", "YER", None),
    ("40104", "إيرادات الديكورات والبارتيشن", "revenue", "YER", None),
    ("40105", "إيرادات CNC لعملاء خارجيين", "revenue", "YER", None),
    ("40106", "إيرادات كوش الأعراس", "revenue", "YER", None),
    ("40107", "إيرادات صيانة وتعديلات", "revenue", "YER", None),
    ("40901", "خصومات ومردودات مبيعات", "revenue_contra", "YER", None),
    ("50101", "تكلفة خشب MDF", "cost", "YER", None),
    ("50102", "تكلفة أبلاكاش", "cost", "YER", None),
    ("50103", "تكلفة دهانات", "cost", "YER", None),
    ("50104", "تكلفة إكسسوارات", "cost", "YER", None),
    ("50105", "تكلفة زجاج وألمنيوم", "cost", "YER", None),
    ("50106", "تكلفة إسفنج وتنجيد", "cost", "YER", None),
    ("50201", "أجور نجارة مباشرة", "cost", "YER", None),
    ("50202", "أجور CNC مباشرة", "cost", "YER", None),
    ("50203", "أجور صنفرة", "cost", "YER", None),
    ("50204", "أجور دهان", "cost", "YER", None),
    ("50205", "أجور تشطيب وتركيب", "cost", "YER", None),
    ("50301", "نقل المشروع", "cost", "YER", None),
    ("50302", "تركيب خارجي", "cost", "YER", None),
    ("50303", "مصاريف مشروع أخرى", "cost", "YER", None),
    ("60101", "إيجار المعرض/الورشة", "expense", "YER", None),
    ("60102", "كهرباء ومياه", "expense", "YER", None),
    ("60103", "إنترنت واتصالات", "expense", "YER", None),
    ("60104", "صيانة معدات", "expense", "YER", None),
    ("60105", "أدوات واستهلاكات عامة", "expense", "YER", None),
    ("60106", "نظافة وضيافة", "expense", "YER", None),
    ("60201", "مصاريف تسويق وإعلانات", "expense", "YER", None),
    ("60202", "تصوير ومونتاج", "expense", "YER", None),
    ("60203", "تصاميم وبراندنج", "expense", "YER", None),
    ("60301", "مصاريف إدارية", "expense", "YER", None),
    ("60302", "رواتب إدارية", "expense", "YER", None),
    ("60303", "مواصلات إدارية", "expense", "YER", None),
    ("60401", "مصروفات بنكية وتحويلات", "expense", "YER", None),
    ("60402", "فروقات عملة", "expense", "YER", None),
    ("70101", "حركات غير معتمدة", "control", "YER", None),
    ("70102", "فواتير غير مرفقة", "control", "YER", None),
    ("70103", "فروقات جرد", "control", "YER", None),
    ("70104", "مشاريع تحت المراجعة", "control", "YER", None),
    ("70105", "التزامات عاجلة", "control", "YER", None),
]

ITEMS = [
    ("MDF-18", "MDF 18 ملم", "خشب", "لوح", 0, 0, 3),
    ("MDF-15", "MDF 15 ملم", "خشب", "لوح", 0, 0, 3),
    ("PLY-12", "أبلاكاش 12 ملم", "خشب", "لوح", 0, 0, 3),
    ("PLY-18", "أبلاكاش 18 ملم", "خشب", "لوح", 0, 0, 3),
    ("PAINT-BASE", "أساس دهان", "دهان", "علبة", 0, 0, 2),
    ("PAINT-THINNER", "تينار", "دهان", "علبة", 0, 0, 2),
    ("HINGE-STD", "مفصلة عادية", "إكسسوارات", "حبة", 0, 0, 20),
    ("SLIDE-45", "سحاب 45 سم", "إكسسوارات", "زوج", 0, 0, 10),
    ("GLASS-BRONZE", "زجاج برونزي", "زجاج", "متر", 0, 0, 2),
    ("FOAM-30", "إسفنج 30", "تنجيد", "متر", 0, 0, 2),
]

ROLES = [
    ("manager", "المدير العام"),
    ("accountant", "المحاسب"),
    ("purchasing", "مسؤول المشتريات"),
    ("production", "مسؤول الإنتاج"),
    ("data_entry", "مدخل بيانات"),
]

def upsert(db, model, key_field, key_value, values):
    obj = db.query(model).filter(getattr(model, key_field) == key_value).first()
    if not obj:
        obj = model(**values)
        db.add(obj)
    else:
        for k, v in values.items():
            if hasattr(obj, k):
                setattr(obj, k, v)
    return obj

def main():
    db = SessionLocal()
    try:
        for code, name, typ, currency, parent in ACCOUNTS:
            upsert(db, Account, "code", code, {"code": code, "name": name, "type": typ, "currency": currency, "parent_code": parent, "balance": 0})
        for code, name, category, unit, qty, avg, reorder in ITEMS:
            upsert(db, Item, "code", code, {"code": code, "name": name, "unit": unit, "current_qty": qty, "avg_cost": avg, "reorder_level": reorder})
        for code, name in ROLES:
            upsert(db, Role, "code", code, {"code": code, "name": name})
        # Cash accounts mirror the main cash accounts.
        for code, name, currency in [("10101", "صندوق يمني", "YER"), ("10102", "صندوق سعودي", "SAR"), ("10103", "صندوق دولار", "USD")]:
            upsert(db, CashAccount, "code", code, {"code": code, "name": name, "currency": currency, "opening_balance": 0, "balance": 0})
        db.commit()
        print("V3 seed completed")
    finally:
        db.close()

if __name__ == "__main__":
    main()
