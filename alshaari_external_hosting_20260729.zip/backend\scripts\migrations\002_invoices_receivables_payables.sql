BEGIN;

ALTER TABLE invoices ADD COLUMN IF NOT EXISTS invoice_no VARCHAR(80);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS party_type VARCHAR(30);
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS posted_by INTEGER;
ALTER TABLE invoices ADD COLUMN IF NOT EXISTS posted_at TIMESTAMP;

DO $$
BEGIN
    IF NOT EXISTS (
        SELECT 1
        FROM pg_constraint
        WHERE conname = 'uq_invoices_invoice_no'
    ) THEN
        ALTER TABLE invoices
        ADD CONSTRAINT uq_invoices_invoice_no UNIQUE (invoice_no);
    END IF;
END $$;

CREATE TABLE IF NOT EXISTS invoice_lines (
    id SERIAL PRIMARY KEY,
    invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    item_description VARCHAR(255) NOT NULL,
    qty NUMERIC(14,3) DEFAULT 1,
    unit_price NUMERIC(14,2) DEFAULT 0,
    total NUMERIC(14,2) DEFAULT 0,
    project_id INTEGER REFERENCES projects(id),
    notes TEXT
);

INSERT INTO accounts (code, name, type, currency, balance)
VALUES ('10501', 'دفعات مقدمة للموردين', 'asset', 'YER', 0)
ON CONFLICT (code) DO NOTHING;

INSERT INTO posting_rules (
    operation_type,
    debit_account_code,
    credit_account_code,
    description,
    is_active
)
VALUES
    ('customer_advance', '10101', '10302', 'دفعة مقدمة من عميل', TRUE),
    ('supplier_payment', '20101', '10101', 'دفعة مورد', TRUE),
    ('supplier_advance', '10501', '10101', 'دفعة مقدمة لمورد', TRUE)
ON CONFLICT (operation_type) DO UPDATE SET
    debit_account_code = EXCLUDED.debit_account_code,
    credit_account_code = EXCLUDED.credit_account_code,
    description = EXCLUDED.description,
    is_active = TRUE;

COMMIT;
