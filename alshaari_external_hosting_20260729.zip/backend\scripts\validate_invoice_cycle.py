from datetime import date
from decimal import Decimal

from sqlalchemy import func

from app.db.database import SessionLocal
from app.models.models import (
    AuditLog,
    Customer,
    Invoice,
    InvoiceLine,
    JournalEntry,
    JournalEntryLine,
    Supplier,
)
from app.schemas.schemas import InvoiceCreate, InvoiceLineCreate
from app.services.invoice_service import create_invoice, post_invoice


MARKER = "invoice-cycle-validation"
USER_ID = 1


def cleanup(db):
    invoices = db.query(Invoice).filter(Invoice.notes == MARKER).all()
    invoice_ids = [invoice.id for invoice in invoices]

    if invoice_ids:
        entry_ids = [
            row[0]
            for row in db.query(JournalEntry.id)
            .filter(JournalEntry.source_type == "invoice", JournalEntry.source_id.in_(invoice_ids))
            .all()
        ]
        if entry_ids:
            db.query(JournalEntryLine).filter(JournalEntryLine.journal_entry_id.in_(entry_ids)).delete(synchronize_session=False)
            db.query(JournalEntry).filter(JournalEntry.id.in_(entry_ids)).delete(synchronize_session=False)

        db.query(AuditLog).filter(AuditLog.entity == "invoice", AuditLog.entity_id.in_(invoice_ids)).delete(synchronize_session=False)
        db.query(InvoiceLine).filter(InvoiceLine.invoice_id.in_(invoice_ids)).delete(synchronize_session=False)
        db.query(Invoice).filter(Invoice.id.in_(invoice_ids)).delete(synchronize_session=False)

    db.query(Customer).filter(Customer.name == MARKER).delete(synchronize_session=False)
    db.query(Supplier).filter(Supplier.name == MARKER).delete(synchronize_session=False)
    db.commit()


def entry_totals(db, invoice_id):
    return (
        db.query(
            func.coalesce(func.sum(JournalEntryLine.debit), 0),
            func.coalesce(func.sum(JournalEntryLine.credit), 0),
        )
        .join(JournalEntry, JournalEntry.id == JournalEntryLine.journal_entry_id)
        .filter(JournalEntry.source_type == "invoice", JournalEntry.source_id == invoice_id)
        .one()
    )


def main():
    db = SessionLocal()
    try:
        cleanup(db)

        customer = Customer(name=MARKER, phone="770000001", customer_type="validation")
        supplier = Supplier(name=MARKER, phone="770000002", category="validation")
        db.add_all([customer, supplier])
        db.commit()
        db.refresh(customer)
        db.refresh(supplier)

        customer_invoice = create_invoice(
            db,
            InvoiceCreate(
                invoice_type="customer",
                party_id=customer.id,
                date=date.today(),
                total=Decimal("1200.00"),
                notes=MARKER,
                lines=[
                    InvoiceLineCreate(
                        item_description="Custom cabinet validation line",
                        qty=Decimal("2"),
                        unit_price=Decimal("600.00"),
                    )
                ],
            ),
            USER_ID,
        )
        customer_invoice = post_invoice(db, customer_invoice.id, USER_ID)

        supplier_invoice = create_invoice(
            db,
            InvoiceCreate(
                invoice_type="supplier",
                party_id=supplier.id,
                date=date.today(),
                total=Decimal("900.00"),
                notes=MARKER,
                lines=[
                    InvoiceLineCreate(
                        item_description="MDF validation purchase",
                        qty=Decimal("3"),
                        unit_price=Decimal("300.00"),
                    )
                ],
            ),
            USER_ID,
        )
        supplier_invoice = post_invoice(db, supplier_invoice.id, USER_ID)

        customer_debit, customer_credit = entry_totals(db, customer_invoice.id)
        supplier_debit, supplier_credit = entry_totals(db, supplier_invoice.id)

        assert customer_invoice.status == "posted"
        assert supplier_invoice.status == "posted"
        assert Decimal(customer_debit) == Decimal(customer_credit) == Decimal("1200.00")
        assert Decimal(supplier_debit) == Decimal(supplier_credit) == Decimal("900.00")

        print(
            {
                "customer_invoice": customer_invoice.invoice_no,
                "customer_status": customer_invoice.status,
                "customer_balanced": str(customer_debit) == str(customer_credit),
                "supplier_invoice": supplier_invoice.invoice_no,
                "supplier_status": supplier_invoice.status,
                "supplier_balanced": str(supplier_debit) == str(supplier_credit),
            }
        )
    finally:
        cleanup(db)
        db.close()


if __name__ == "__main__":
    main()
