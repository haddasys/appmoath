from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.core.deps import get_current_user, require_approval_role
from app.models.models import Transaction
from app.schemas.schemas import TransactionCreate, TransactionReverseRequest
from app.services.transaction_service import (
    create_transaction,
    delete_transaction_draft,
    approve_transaction,
    reject_transaction,
    reverse_transaction,
    update_transaction_draft,
)

router = APIRouter(prefix="/api/v1/transactions", tags=["Transactions"])

def as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}

@router.get("")
def list_transactions(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [as_dict(x) for x in db.query(Transaction).order_by(Transaction.id.desc()).limit(500).all()]

@router.post("")
def add_transaction(data: TransactionCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return as_dict(create_transaction(db, data, user.id))

@router.put("/{tx_id}")
def update_transaction(tx_id: int, data: TransactionCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return as_dict(update_transaction_draft(db, tx_id, data, user.id))

@router.delete("/{tx_id}")
def delete_transaction(tx_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return delete_transaction_draft(db, tx_id, user.id)

@router.patch("/{tx_id}/approve")
def approve(tx_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return as_dict(approve_transaction(db, tx_id, user.id))

@router.patch("/{tx_id}/reject")
def reject(tx_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return as_dict(reject_transaction(db, tx_id, user.id))

@router.post("/{tx_id}/reverse")
def reverse(tx_id: int, data: TransactionReverseRequest, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return as_dict(reverse_transaction(db, tx_id, user.id, data.reason))
