from datetime import date, datetime

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_permission
from app.db.database import get_db
from app.services.accounting_periods import ensure_accounting_period_schema


router = APIRouter(prefix="/api/v1/accounting-periods", tags=["Accounting Periods"])


class AccountingPeriodCreate(BaseModel):
    year: int = Field(..., ge=2000, le=2100)
    month: int = Field(..., ge=1, le=12)
    start_date: date
    end_date: date
    status: str = "open"


def _as_dict(row):
    return dict(row._mapping) if hasattr(row, "_mapping") else dict(row)


@router.get("")
def list_accounting_periods(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_accounting_period_schema(db)
    rows = (
        db.execute(
            text(
                """
                SELECT id, year, month, start_date, end_date, status, closed_by, closed_at, created_at
                FROM accounting_periods
                ORDER BY year DESC, month DESC
                """
            )
        )
        .mappings()
        .all()
    )
    return [_as_dict(row) for row in rows]


@router.post("")
def create_accounting_period(data: AccountingPeriodCreate, db: Session = Depends(get_db), user=Depends(require_permission("close_period"))):
    ensure_accounting_period_schema(db)
    if data.end_date < data.start_date:
        raise HTTPException(status_code=400, detail="تاريخ نهاية الفترة لا يمكن أن يكون قبل تاريخ البداية")
    if data.status not in {"open", "closed"}:
        raise HTTPException(status_code=400, detail="حالة الفترة يجب أن تكون open أو closed")
    db.execute(
        text(
            """
            INSERT INTO accounting_periods (year, month, start_date, end_date, status)
            VALUES (:year, :month, :start_date, :end_date, :status)
            ON CONFLICT (year, month) DO UPDATE SET
                start_date = EXCLUDED.start_date,
                end_date = EXCLUDED.end_date,
                status = EXCLUDED.status
            """
        ),
        data.model_dump(),
    )
    db.commit()
    return {"message": "تم حفظ الفترة المالية"}


@router.post("/{period_id}/close")
def close_accounting_period(period_id: int, db: Session = Depends(get_db), user=Depends(require_permission("close_period"))):
    ensure_accounting_period_schema(db)
    result = db.execute(
        text(
            """
            UPDATE accounting_periods
            SET status = 'closed', closed_by = :user_id, closed_at = :closed_at
            WHERE id = :period_id
            """
        ),
        {"period_id": period_id, "user_id": user.id, "closed_at": datetime.utcnow()},
    )
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="الفترة المالية غير موجودة")
    db.commit()
    return {"message": "تم إقفال الفترة المالية"}


@router.post("/{period_id}/open")
def open_accounting_period(period_id: int, db: Session = Depends(get_db), user=Depends(require_permission("open_closed_period"))):
    ensure_accounting_period_schema(db)
    result = db.execute(
        text(
            """
            UPDATE accounting_periods
            SET status = 'open', closed_by = NULL, closed_at = NULL
            WHERE id = :period_id
            """
        ),
        {"period_id": period_id},
    )
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="الفترة المالية غير موجودة")
    db.commit()
    return {"message": "تم فتح الفترة المالية"}
