import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';
import 'transaction_form_screen.dart';
import 'lists_screen.dart';
import 'master_data_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});
  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  bool loading = true;
  Map<String, dynamic> data = {};

  @override
  void initState() {
    super.initState();
    loadDashboard();
  }

  Future<void> loadDashboard() async {
    setState(() => loading = true);
    try {
      final res = await apiClient.dio.get('/dashboard');
      if (!mounted) return;
      setState(() {
        data = Map<String, dynamic>.from(res.data as Map);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() => loading = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('فشل تحميل لوحة القيادة: $e')));
    }
  }

  Widget card(String title, dynamic value, IconData icon) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          CircleAvatar(child: Icon(icon)),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontSize: 13, color: Colors.black54)),
            const SizedBox(height: 4),
            Text('${value ?? 0}', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          ])),
        ]),
      ),
    );
  }

  Widget action(String text, IconData icon, VoidCallback onTap, {bool primary = false}) {
    return SizedBox(
      width: double.infinity,
      child: primary
          ? FilledButton.icon(onPressed: onTap, icon: Icon(icon), label: Text(text))
          : FilledButton.tonalIcon(onPressed: onTap, icon: Icon(icon), label: Text(text)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(title: const Text('نظام الشعري المالي'), actions: [IconButton(onPressed: loadDashboard, icon: const Icon(Icons.refresh))]),
        body: loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: loadDashboard,
                child: ListView(padding: const EdgeInsets.all(16), children: [
                  const Text('لوحة القيادة', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  GridView.count(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    crossAxisCount: MediaQuery.of(context).size.width > 700 ? 4 : 2,
                    childAspectRatio: 1.25,
                    children: [
                      card('رصيد الصندوق', data['cash_balance'], Icons.account_balance_wallet),
                      card('المقبوضات', data['total_receipts'], Icons.south_west),
                      card('المصروفات', data['total_payments'], Icons.north_east),
                      card('حركات مسودة', data['draft_transactions'], Icons.pending_actions),
                      card('مستحقات العملاء', data['customer_receivables'], Icons.people),
                      card('مستحقات الموردين', data['supplier_payables'], Icons.local_shipping),
                      card('مشاريع نشطة', data['active_projects'], Icons.work),
                      card('مواد ناقصة', data['low_stock_items'], Icons.inventory),
                    ],
                  ),
                  const SizedBox(height: 16),
                  action('إضافة حركة موحدة', Icons.add_circle, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const TransactionFormScreen())).then((_) => loadDashboard()), primary: true),
                  const SizedBox(height: 10),
                  action('البيانات والتقارير', Icons.list_alt, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ListsScreen())).then((_) => loadDashboard())),
                  const SizedBox(height: 10),
                  action('إدارة البيانات الأساسية', Icons.settings_applications, () => Navigator.push(context, MaterialPageRoute(builder: (_) => const MasterDataScreen())).then((_) => loadDashboard())),
                ]),
              ),
      ),
    );
  }
}
