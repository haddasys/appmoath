import 'dart:ui' as ui;

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../app/theme.dart';
import '../network/api_client.dart';
import '../permissions.dart';

class AlshaariSettlementButton extends StatefulWidget {
  final String contextType;
  final int? contextId;
  final bool primary;
  final bool expand;

  const AlshaariSettlementButton({
    super.key,
    this.contextType = 'dashboard',
    this.contextId,
    this.primary = true,
    this.expand = true,
  });

  @override
  State<AlshaariSettlementButton> createState() =>
      _AlshaariSettlementButtonState();
}

class _AlshaariSettlementButtonState extends State<AlshaariSettlementButton> {
  bool loading = false;
  bool checkingPermission = true;
  bool visible = false;

  @override
  void initState() {
    super.initState();
    checkVisibility();
  }

  Future<void> checkVisibility() async {
    final allowed = await AlshaariPermissions.canAny(const [
      'manage_settlements',
      'approve_adjustment_journal',
      'transactions.write',
      'inventory.write',
      'purchases.write',
      'project_costs.write',
    ]);
    if (!mounted) return;
    setState(() {
      visible = allowed;
      checkingPermission = false;
    });
  }

  Future<void> openOptions() async {
    setState(() => loading = true);
    try {
      await apiClient.loadToken();
      final res = await apiClient.dio.get(
        '/settlement-options',
        queryParameters: {
          'context_type': widget.contextType,
          if (widget.contextId != null) 'context_id': widget.contextId,
        },
      );
      if (!mounted) return;
      final options = (res.data as List)
          .map((raw) => Map<String, dynamic>.from(raw as Map))
          .where((option) => option['enabled'] == true)
          .toList();
      showSettlementSheet(options);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(friendlyError(e))),
      );
    } finally {
      if (mounted) setState(() => loading = false);
    }
  }

  String friendlyError(Object error) {
    if (error is DioException) {
      final data = error.response?.data;
      if (data is Map && data['detail'] != null) return '${data['detail']}';
      if (error.type == DioExceptionType.connectionError) {
        return 'تعذر الاتصال بالخادم';
      }
    }
    return 'تعذر تحميل خيارات التسوية';
  }

  void showSettlementSheet(List<Map<String, dynamic>> options) {
    showModalBottomSheet(
      context: context,
      showDragHandle: true,
      isScrollControlled: true,
      builder: (sheetContext) {
        return Directionality(
          textDirection: ui.TextDirection.rtl,
          child: SafeArea(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 18),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Text(
                    'اختر نوع التسوية',
                    style: Theme.of(sheetContext)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'كل نوع تسوية له شاشة واعتماد وقيد محاسبي مستقل عند الحاجة.',
                    style: Theme.of(sheetContext).textTheme.bodySmall,
                  ),
                  const SizedBox(height: 14),
                  if (options.isEmpty)
                    const _EmptyOptions()
                  else
                    ConstrainedBox(
                      constraints: BoxConstraints(
                        maxHeight:
                            MediaQuery.of(sheetContext).size.height * .62,
                      ),
                      child: ListView.separated(
                        shrinkWrap: true,
                        itemCount: options.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, index) {
                          final option = options[index];
                          return _SettlementOptionCard(
                            option: option,
                            onTap: () {
                              Navigator.pop(sheetContext);
                              routeTo(option['type']?.toString() ?? '');
                            },
                          );
                        },
                      ),
                    ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  void routeTo(String type) {
    switch (type) {
      case 'advance_settlement':
        context.push('/advance-settlement-voucher');
        break;
      case 'inventory_adjustment':
        context.push('/inventory-adjustment');
        break;
      case 'supplier_adjustment':
        context.push('/supplier-adjustment');
        break;
      case 'customer_adjustment':
        context.push('/customer-adjustment');
        break;
      case 'adjustment_journal':
      default:
        context.push('/adjustment-voucher');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    if (checkingPermission || !visible) return const SizedBox.shrink();

    final child = Row(
      mainAxisAlignment: MainAxisAlignment.center,
      mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
      children: [
        if (loading)
          const SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2),
          )
        else
          const Icon(Icons.tune_outlined, size: 20),
        const SizedBox(width: 8),
        const Flexible(
          child: Text(
            'تسوية',
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );

    final button = widget.primary
        ? FilledButton(onPressed: loading ? null : openOptions, child: child)
        : OutlinedButton(onPressed: loading ? null : openOptions, child: child);

    return widget.expand ? SizedBox(height: 52, child: button) : button;
  }
}

class _SettlementOptionCard extends StatelessWidget {
  final Map<String, dynamic> option;
  final VoidCallback onTap;

  const _SettlementOptionCard({required this.option, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final enabled = option['enabled'] == true;
    final color = enabled ? AlshaariColors.copper : AlshaariColors.slate;
    return InkWell(
      onTap: enabled ? onTap : null,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: enabled ? Colors.white : AlshaariColors.slate.withOpacity(.06),
          borderRadius: BorderRadius.circular(8),
          border: Border.all(
            color: enabled
                ? AlshaariColors.border
                : AlshaariColors.slate.withOpacity(.18),
          ),
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CircleAvatar(
              backgroundColor: color.withOpacity(.12),
              child: Icon(iconFor(option['type']?.toString()), color: color),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '${option['label'] ?? ''}',
                    style: TextStyle(
                      color: enabled
                          ? AlshaariColors.matteBlack
                          : AlshaariColors.slate,
                      fontWeight: FontWeight.w900,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    '${option['description'] ?? ''}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                  if (option['reason'] != null) ...[
                    const SizedBox(height: 6),
                    Text(
                      '${option['reason']}',
                      style: TextStyle(
                        color: enabled
                            ? AlshaariColors.warning
                            : AlshaariColors.danger,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ],
              ),
            ),
            Icon(
              Icons.chevron_left,
              color: enabled ? AlshaariColors.copper : AlshaariColors.slate,
            ),
          ],
        ),
      ),
    );
  }

  IconData iconFor(String? type) {
    switch (type) {
      case 'advance_settlement':
        return Icons.assignment_ind_outlined;
      case 'inventory_adjustment':
        return Icons.inventory_2_outlined;
      case 'supplier_adjustment':
        return Icons.local_shipping_outlined;
      case 'customer_adjustment':
        return Icons.people_alt_outlined;
      case 'adjustment_journal':
      default:
        return Icons.balance_outlined;
    }
  }
}

class _EmptyOptions extends StatelessWidget {
  const _EmptyOptions();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AlshaariColors.pearlWhite,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AlshaariColors.border),
      ),
      child: const Text(
        'لا توجد خيارات تسوية متاحة لهذا السياق.',
        textAlign: TextAlign.center,
        style: TextStyle(fontWeight: FontWeight.w700),
      ),
    );
  }
}
