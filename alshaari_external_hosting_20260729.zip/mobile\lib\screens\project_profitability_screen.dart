import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import '../core/api_client.dart';

class ProjectProfitabilityScreen extends StatefulWidget {
  final int projectId;
  const ProjectProfitabilityScreen({super.key, required this.projectId});
  @override
  State<ProjectProfitabilityScreen> createState() => _ProjectProfitabilityScreenState();
}

class _ProjectProfitabilityScreenState extends State<ProjectProfitabilityScreen> {
  Map<String, dynamic>? data;
  String? error;

  @override
  void initState() { super.initState(); load(); }

  Future<void> load() async {
    try { final res = await apiClient.dio.get('/projects/${widget.projectId}/profitability'); if (!mounted) return; setState(() => data = Map<String,dynamic>.from(res.data as Map)); }
    catch(e) { if (mounted) setState(() => error = '$e'); }
  }

  Widget row(String label, dynamic value, {bool strong=false}) => Card(child: ListTile(title: Text(label), trailing: Text('${value ?? 0}', style: TextStyle(fontWeight: strong ? FontWeight.bold : FontWeight.normal, fontSize: strong ? 18 : 15))));

  @override
  Widget build(BuildContext context) {
    return Directionality(textDirection: ui.TextDirection.rtl, child: Scaffold(appBar: AppBar(title: const Text('ربحية المشروع')), body: error != null ? Center(child: Text(error!)) : data == null ? const Center(child: CircularProgressIndicator()) : RefreshIndicator(onRefresh: load, child: ListView(padding: const EdgeInsets.all(12), children: [
      Text('${data!['project_code'] ?? ''} - ${data!['project_name'] ?? ''}', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
      const SizedBox(height: 12),
      row('قيمة العقد', data!['contract_value']),
      row('المفوترة', data!['invoiced']),
      row('المقبوض', data!['received']),
      row('المتبقي', data!['remaining']),
      row('تكلفة المواد', data!['material_cost']),
      row('أجور العمال', data!['labor_cost']),
      row('مصروفات أخرى', data!['other_expenses']),
      row('إجمالي التكلفة', data!['total_cost'], strong: true),
      row('الربح / الخسارة', data!['profit'], strong: true),
      row('هامش الربح %', data!['margin_percent'], strong: true),
      row('نسبة الإنجاز', '${data!['progress_percent'] ?? 0}%'),
    ]))));
  }
}
