from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func, text
from app.db.database import get_db
from app.core.deps import get_current_user
from app.models.models import (
    Customer,
    Invoice,
    Item,
    Project,
    ProjectCost,
    StockMovement,
    Supplier,
    SupplierInvoice,
    SupplierPayment,
    Transaction,
)
from app.services.project_costing import project_profitability as project_profitability_payload

router = APIRouter(prefix="/api/v1", tags=["Reports"])

def f(v): return float(v or 0)

def d(v):
    return float(v or 0)


def _bucket_aging(days: int, amount: float, buckets: dict[str, float]):
    if amount <= 0:
        return
    if days <= 0:
        buckets["current"] += amount
    elif days <= 30:
        buckets["days_1_30"] += amount
    elif days <= 60:
        buckets["days_31_60"] += amount
    elif days <= 90:
        buckets["days_61_90"] += amount
    else:
        buckets["days_over_90"] += amount

@router.get("/projects/{project_id}/cost-summary")
def project_cost_summary(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    try:
        result = project_profitability_payload(db, project_id)
    except ValueError:
        raise HTTPException(404, "المشروع غير موجود")
    result["collected"] = result["total_collected"]
    result["remaining_from_customer"] = result["remaining_customer_balance"]
    result["total_cost"] = result["actual_total_cost"]
    result["net_profit"] = result["actual_profit"]
    result["profit_margin_percent"] = result["actual_profit_percent"]
    return result

@router.get("/reports/inventory-balance")
def inventory_balance_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(Item).order_by(Item.code.asc()).all()
    result = []
    for item in items:
        reserved = db.query(func.coalesce(func.sum(StockMovement.qty), 0)).filter(
            StockMovement.item_id == item.id,
            StockMovement.movement_type == "reserve_stock_for_project",
        ).scalar()
        issued = db.query(func.coalesce(func.sum(StockMovement.qty), 0)).filter(
            StockMovement.item_id == item.id,
            StockMovement.movement_type == "issue_stock_to_project",
        ).scalar()
        current_qty = f(item.current_qty)
        reserved_qty = max(f(reserved) - f(issued), 0)
        available_qty = current_qty - reserved_qty
        result.append({
            "item_id": item.id,
            "code": item.code,
            "name": item.name,
            "unit": item.unit,
            "current_qty": current_qty,
            "reserved_qty": reserved_qty,
            "available_qty": available_qty,
            "avg_cost": f(item.avg_cost),
            "stock_value": current_qty * f(item.avg_cost),
        })
    return result

@router.get("/reports/project-material-costs")
def project_material_costs_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = (
        db.query(StockMovement, Item, Project)
        .join(Item, StockMovement.item_id == Item.id)
        .join(Project, StockMovement.project_id == Project.id)
        .filter(StockMovement.movement_type.in_(["issue_stock_to_project", "direct_purchase_to_project"]))
        .order_by(StockMovement.date.desc(), StockMovement.id.desc())
        .limit(500)
        .all()
    )
    return [
        {
            "movement_id": movement.id,
            "date": movement.date,
            "project_id": project.id,
            "project_name": project.name,
            "item_id": item.id,
            "item_name": item.name,
            "qty": f(movement.qty),
            "unit_cost": f(movement.unit_cost),
            "total_cost": f(movement.qty) * f(movement.unit_cost),
            "cost_center_id": movement.cost_center_id,
            "attachment_id": movement.attachment_id,
            "movement_type": movement.movement_type,
            "description": movement.notes,
        }
        for movement, item, project in rows
    ]

@router.get("/reports/project-reserved-stock")
def project_reserved_stock_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    reserved_rows = db.execute(
        text(
            """
            SELECT
                p.id AS project_id,
                p.name AS project_name,
                i.id AS item_id,
                i.name AS item_name,
                COALESCE(SUM(CASE WHEN sm.movement_type = 'reserve_stock_for_project' THEN sm.qty ELSE 0 END), 0) AS reserved_qty,
                COALESCE(SUM(CASE WHEN sm.movement_type = 'issue_stock_to_project' THEN sm.qty ELSE 0 END), 0) AS issued_qty
            FROM stock_movements sm
            JOIN projects p ON p.id = sm.project_id
            JOIN items i ON i.id = sm.item_id
            WHERE sm.movement_type IN ('reserve_stock_for_project', 'issue_stock_to_project')
            GROUP BY p.id, p.name, i.id, i.name
            ORDER BY p.name, i.name
            """
        )
    ).mappings().all()
    return [
        {
            **dict(row),
            "reserved_qty": f(row["reserved_qty"]),
            "issued_qty": f(row["issued_qty"]),
            "remaining_qty": max(f(row["reserved_qty"]) - f(row["issued_qty"]), 0),
        }
        for row in reserved_rows
    ]

@router.get("/reports/direct-project-purchases")
def direct_project_purchases_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = (
        db.query(StockMovement, Item, Project)
        .join(Item, StockMovement.item_id == Item.id)
        .join(Project, StockMovement.project_id == Project.id)
        .filter(StockMovement.movement_type == "direct_purchase_to_project")
        .order_by(StockMovement.date.desc(), StockMovement.id.desc())
        .limit(500)
        .all()
    )
    return [
        {
            "movement_id": movement.id,
            "date": movement.date,
            "project_id": project.id,
            "project_name": project.name,
            "item_name": item.name,
            "description": movement.notes,
            "qty": f(movement.qty),
            "unit_cost": f(movement.unit_cost),
            "amount": f(movement.qty) * f(movement.unit_cost),
            "attachment_id": movement.attachment_id,
            "journal_source_type": "direct_project_purchase",
        }
        for movement, item, project in rows
    ]

@router.get("/reports/project-profitability")
def project_profitability(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [
        project_profitability_payload(db, p.id)
        for p in db.query(Project).order_by(Project.id.desc()).limit(100).all()
    ]

@router.get("/reports/over-budget-projects")
def over_budget_projects(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = []
    for project in db.query(Project).order_by(Project.id.desc()).limit(200).all():
        payload = project_profitability_payload(db, project.id)
        if payload.get("is_over_budget"):
            rows.append(payload)
    rows.sort(key=lambda row: f(row.get("cost_variance")), reverse=True)
    return rows[:100]

@router.get("/reports/profit-loss")
def profit_loss(db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoice_revenues = db.query(func.coalesce(func.sum(Invoice.total), 0)).filter(Invoice.status == "posted", Invoice.invoice_type == "customer").scalar()
    general_expenses = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type == "general_payment").scalar()
    unassigned_wages = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type == "worker_wage", Transaction.project_id == None).scalar()
    project_costs = db.query(func.coalesce(func.sum(ProjectCost.amount), 0)).scalar()
    expenses = f(general_expenses) + f(unassigned_wages) + f(project_costs)
    revenues = f(invoice_revenues)
    return {"revenues": revenues, "expenses": f(expenses), "net_profit": revenues - f(expenses)}

@router.get("/reports/cash-flow")
def cash_flow(db: Session = Depends(get_db), user=Depends(get_current_user)):
    inflow = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type.in_(["receipt_from_customer", "customer_advance"])).scalar()
    transaction_outflow = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type.in_(["general_payment", "project_expense", "worker_wage", "advance_payment", "material_purchase", "supplier_payment", "supplier_advance"])).scalar()
    supplier_payment_outflow = db.query(func.coalesce(func.sum(SupplierPayment.amount), 0)).filter(SupplierPayment.status == "approved").scalar()
    outflow = f(transaction_outflow) + f(supplier_payment_outflow)
    return {"cash_inflow": f(inflow), "cash_outflow": outflow, "net_cash_flow": f(inflow) - outflow}

@router.get("/reports/cost-centers")
def cost_center_report(
    from_date: date | None = None,
    to_date: date | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    params: dict[str, object] = {"from_date": from_date, "to_date": to_date}
    rows = db.execute(
        text(
            """
            SELECT
                cc.id,
                cc.code,
                cc.name,
                cc.parent_id,
                cc.type,
                cc.allocation_method,
                cc.allocation_base,
                cc.budget_amount,
                cc.is_postable,
                cc.is_active,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.debit ELSE 0 END), 0) AS total_debit,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.credit ELSE 0 END), 0) AS total_credit,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.debit - jel.credit ELSE 0 END), 0) AS net_amount
            FROM cost_centers cc
            LEFT JOIN journal_entry_lines jel ON jel.cost_center_id = cc.id
            LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id
              AND (:from_date IS NULL OR je.entry_date >= :from_date)
              AND (:to_date IS NULL OR je.entry_date <= :to_date)
            GROUP BY cc.id, cc.code, cc.name, cc.parent_id, cc.type,
                     cc.allocation_method, cc.allocation_base, cc.budget_amount,
                     cc.is_postable, cc.is_active
            ORDER BY cc.code
            """
        ),
        params,
    ).mappings().all()

    project_rows = db.execute(
        text(
            """
            SELECT
                pc.cost_center_id AS id,
                COALESCE(SUM(pc.amount), 0) AS project_costs
            FROM project_costs pc
            WHERE (:from_date IS NULL OR pc.date >= :from_date)
              AND (:to_date IS NULL OR pc.date <= :to_date)
              AND pc.cost_center_id IS NOT NULL
            GROUP BY pc.cost_center_id
            """
        ),
        params,
    ).mappings().all()
    project_by_center = {row["id"]: f(row["project_costs"]) for row in project_rows}

    items = {}
    children: dict[int | None, list[int]] = {}

    for row in rows:
        item = dict(row)
        item["total_debit"] = f(row["total_debit"])
        item["total_credit"] = f(row["total_credit"])
        item["net_amount"] = f(row["net_amount"])
        item["project_costs"] = project_by_center.get(row["id"], 0)
        item["budget_amount"] = f(row["budget_amount"])
        item["total_with_children"] = item["net_amount"]
        item["project_costs_with_children"] = item["project_costs"]
        items[item["id"]] = item
        children.setdefault(item["parent_id"], []).append(item["id"])

    def rollup(center_id: int, depth: int = 0, seen: set[int] | None = None):
        seen = seen or set()
        if center_id in seen:
            return 0, 0, depth
        seen.add(center_id)

        item = items[center_id]
        total = item["net_amount"]
        project_total = item["project_costs"]
        max_depth = depth

        for child_id in children.get(center_id, []):
            child_total, child_project_total, child_depth = rollup(child_id, depth + 1, seen)
            total += child_total
            project_total += child_project_total
            max_depth = max(max_depth, child_depth)

        item["level"] = depth
        item["total_with_children"] = total
        item["project_costs_with_children"] = project_total
        item["budget_variance"] = item["budget_amount"] - total
        return total, project_total, max_depth

    for root_id in children.get(None, []):
        rollup(root_id)

    return [items[row["id"]] for row in rows]


@router.get("/reports/worker-advances")
def worker_advances_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.execute(
        text(
            """
            SELECT
                w.id AS worker_id,
                w.name AS worker_name,
                COALESCE(SUM(CASE WHEN t.type = 'advance_payment' THEN t.amount ELSE 0 END), 0) AS total_advances,
                COALESCE(SUM(CASE WHEN t.type = 'advance_settlement' THEN t.amount ELSE 0 END), 0) AS total_settlements,
                COALESCE(SUM(CASE WHEN t.type = 'advance_payment' THEN t.amount ELSE 0 END), 0)
                  - COALESCE(SUM(CASE WHEN t.type = 'advance_settlement' THEN t.amount ELSE 0 END), 0) AS open_balance
            FROM workers w
            LEFT JOIN transactions t
              ON t.related_account_type = 'worker'
             AND t.related_id = w.id
             AND t.status = 'approved'
             AND t.type IN ('advance_payment', 'advance_settlement')
            GROUP BY w.id, w.name
            ORDER BY open_balance DESC, w.name
            """
        )
    ).mappings().all()

    return [
        {
            **dict(row),
            "total_advances": f(row["total_advances"]),
            "total_settlements": f(row["total_settlements"]),
            "open_balance": f(row["open_balance"]),
            "risk_level": "high" if f(row["open_balance"]) > 100000 else "normal",
        }
        for row in rows
    ]


@router.get("/reports/cost-center-expenses")
def cost_center_expenses_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.execute(
        text(
            """
            SELECT
                cc.id,
                cc.code,
                cc.name,
                cc.type,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.debit ELSE 0 END), 0) AS total_debit,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.credit ELSE 0 END), 0) AS total_credit,
                COALESCE(SUM(CASE WHEN je.id IS NOT NULL THEN jel.debit - jel.credit ELSE 0 END), 0) AS net_cost,
                COUNT(DISTINCT CASE WHEN je.id IS NOT NULL THEN jel.project_id ELSE NULL END) AS linked_projects
            FROM cost_centers cc
            LEFT JOIN journal_entry_lines jel ON jel.cost_center_id = cc.id
            LEFT JOIN journal_entries je ON je.id = jel.journal_entry_id AND je.status = 'posted'
            GROUP BY cc.id, cc.code, cc.name, cc.type
            ORDER BY net_cost DESC, cc.code
            """
        )
    ).mappings().all()

    total = sum(f(row["net_cost"]) for row in rows) or 1
    return [
        {
            **dict(row),
            "total_debit": f(row["total_debit"]),
            "total_credit": f(row["total_credit"]),
            "net_cost": f(row["net_cost"]),
            "cost_share_percent": round((f(row["net_cost"]) / total) * 100, 2),
        }
        for row in rows
    ]


@router.get("/reports/customer-aging")
def customer_aging_report(
    as_of: date | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    as_of = as_of or date.today()
    customers = db.query(Customer).order_by(Customer.name.asc()).all()
    payload = []

    for customer in customers:
        invoices = (
            db.query(Invoice)
            .filter(
                Invoice.party_type == "customer",
                Invoice.party_id == customer.id,
                Invoice.status.in_(["posted", "open", "partially_paid"]),
            )
            .order_by(Invoice.due_date.asc().nulls_last(), Invoice.date.asc(), Invoice.id.asc())
            .all()
        )
        receipts = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(
            Transaction.status == "approved",
            Transaction.related_account_type == "customer",
            Transaction.related_id == customer.id,
            Transaction.type.in_(["receipt_from_customer", "customer_advance"]),
            Transaction.date <= as_of,
        ).scalar()

        paid_on_invoices = sum(f(invoice.paid_amount) for invoice in invoices)
        remaining_credit = max(f(receipts), paid_on_invoices)
        buckets = {
            "current": 0.0,
            "days_1_30": 0.0,
            "days_31_60": 0.0,
            "days_61_90": 0.0,
            "days_over_90": 0.0,
        }

        for invoice in invoices:
            if invoice.date and invoice.date > as_of:
                continue
            invoice_balance = max(f(invoice.total), 0)
            applied = min(remaining_credit, invoice_balance)
            remaining_credit -= applied
            open_balance = invoice_balance - applied
            due_date = invoice.due_date or invoice.date or as_of
            days = (as_of - due_date).days
            _bucket_aging(days, open_balance, buckets)

        total = sum(buckets.values())
        if total > 0:
            payload.append(
                {
                    "customer_id": customer.id,
                    "customer": customer.name,
                    **{key: round(value, 2) for key, value in buckets.items()},
                    "total": round(total, 2),
                    "risk_level": "high" if buckets["days_over_90"] > 0 else ("medium" if buckets["days_61_90"] > 0 else "normal"),
                }
            )

    return payload

@router.get("/customers/{customer_id}/statement")
def customer_statement(
    customer_id: int,
    from_date: date | None = None,
    to_date: date | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    if not customer: raise HTTPException(404, "العميل غير موجود")
    rows = db.query(Transaction).filter(Transaction.status == "approved", Transaction.related_account_type == "customer", Transaction.related_id == customer_id).order_by(Transaction.date.desc()).all()
    invoices = db.query(Invoice).filter(Invoice.status == "posted", Invoice.party_type == "customer", Invoice.party_id == customer_id).order_by(Invoice.date.desc()).all()
    if from_date:
        rows = [row for row in rows if row.date and row.date >= from_date]
        invoices = [invoice for invoice in invoices if invoice.date and invoice.date >= from_date]
    if to_date:
        rows = [row for row in rows if row.date and row.date <= to_date]
        invoices = [invoice for invoice in invoices if invoice.date and invoice.date <= to_date]
    posted_invoices = sum(f(i.total) for i in invoices)
    receipts = sum(f(row.amount) for row in rows if row.type == "receipt_from_customer")
    ledger = []
    for invoice in invoices:
        ledger.append({
            "date": invoice.date,
            "source_type": "invoice",
            "source_id": invoice.id,
            "reference": invoice.invoice_no or f"INV-{invoice.id}",
            "description": invoice.notes or "فاتورة عميل",
            "debit": f(invoice.total),
            "credit": 0,
        })
    for tx in rows:
        is_credit = tx.type in {"receipt_from_customer", "customer_advance"}
        ledger.append({
            "date": tx.date,
            "source_type": "transaction",
            "source_id": tx.id,
            "reference": getattr(tx, "voucher_no", None) or getattr(tx, "document_no", None) or f"TX-{tx.id}",
            "description": tx.description or tx.type,
            "debit": 0 if is_credit else f(tx.amount),
            "credit": f(tx.amount) if is_credit else 0,
        })
    ledger.sort(key=lambda item: (item["date"] or date.min, item["source_type"], item["source_id"] or 0))
    running_balance = 0.0
    for item in ledger:
        running_balance += f(item["debit"]) - f(item["credit"])
        item["balance"] = round(running_balance, 2)
    return {
        "customer": customer.name,
        "balance_due": posted_invoices - f(receipts),
        "posted_invoices_total": posted_invoices,
        "receipts_total": f(receipts),
        "filters": {
            "from_date": from_date.isoformat() if from_date else None,
            "to_date": to_date.isoformat() if to_date else None,
        },
        "ledger": ledger,
        "invoices": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in invoices],
        "transactions": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in rows],
    }

@router.get("/suppliers/{supplier_id}/statement")
def supplier_statement(
    supplier_id: int,
    from_date: date | None = None,
    to_date: date | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    if not supplier: raise HTTPException(404, "المورد غير موجود")
    rows = db.query(Transaction).filter(Transaction.status == "approved", Transaction.related_account_type == "supplier", Transaction.related_id == supplier_id).order_by(Transaction.date.desc()).all()
    invoices = db.query(Invoice).filter(Invoice.status == "posted", Invoice.party_type == "supplier", Invoice.party_id == supplier_id).order_by(Invoice.date.desc()).all()
    purchase_invoices = db.query(SupplierInvoice).filter(SupplierInvoice.supplier_id == supplier_id, SupplierInvoice.status.in_(["approved", "partially_paid", "paid"])).order_by(SupplierInvoice.invoice_date.desc()).all()
    supplier_payments = db.query(SupplierPayment).filter(SupplierPayment.supplier_id == supplier_id, SupplierPayment.status == "approved").order_by(SupplierPayment.payment_date.desc()).all()
    if from_date:
        rows = [row for row in rows if row.date and row.date >= from_date]
        invoices = [invoice for invoice in invoices if invoice.date and invoice.date >= from_date]
        purchase_invoices = [invoice for invoice in purchase_invoices if invoice.invoice_date and invoice.invoice_date >= from_date]
        supplier_payments = [payment for payment in supplier_payments if payment.payment_date and payment.payment_date >= from_date]
    if to_date:
        rows = [row for row in rows if row.date and row.date <= to_date]
        invoices = [invoice for invoice in invoices if invoice.date and invoice.date <= to_date]
        purchase_invoices = [invoice for invoice in purchase_invoices if invoice.invoice_date and invoice.invoice_date <= to_date]
        supplier_payments = [payment for payment in supplier_payments if payment.payment_date and payment.payment_date <= to_date]
    posted_invoices = sum(f(i.total) for i in invoices) + sum(f(i.net_amount) for i in purchase_invoices)
    payments = sum(f(row.amount) for row in rows if row.type == "supplier_payment")
    total_payments = f(payments) + sum(f(payment.amount) for payment in supplier_payments)
    ledger = []
    for invoice in invoices:
        ledger.append({
            "date": invoice.date,
            "source_type": "invoice",
            "source_id": invoice.id,
            "reference": invoice.invoice_no or f"INV-{invoice.id}",
            "description": invoice.notes or "فاتورة مورد",
            "debit": 0,
            "credit": f(invoice.total),
        })
    for invoice in purchase_invoices:
        ledger.append({
            "date": invoice.invoice_date,
            "source_type": "supplier_invoice",
            "source_id": invoice.id,
            "reference": invoice.internal_invoice_no or invoice.supplier_invoice_no or f"SINV-{invoice.id}",
            "description": invoice.description or "فاتورة مورد",
            "debit": 0,
            "credit": f(invoice.net_amount),
        })
    for tx in rows:
        is_debit = tx.type in {"supplier_payment", "supplier_advance"}
        ledger.append({
            "date": tx.date,
            "source_type": "transaction",
            "source_id": tx.id,
            "reference": getattr(tx, "voucher_no", None) or getattr(tx, "document_no", None) or f"TX-{tx.id}",
            "description": tx.description or tx.type,
            "debit": f(tx.amount) if is_debit else 0,
            "credit": 0 if is_debit else f(tx.amount),
        })
    for payment in supplier_payments:
        ledger.append({
            "date": payment.payment_date,
            "source_type": "supplier_payment",
            "source_id": payment.id,
            "reference": payment.payment_no or f"SPV-{payment.id}",
            "description": payment.description or "سند دفع مورد",
            "debit": f(payment.amount),
            "credit": 0,
        })
    ledger.sort(key=lambda item: (item["date"] or date.min, item["source_type"], item["source_id"] or 0))
    running_balance = 0.0
    for item in ledger:
        running_balance += f(item["credit"]) - f(item["debit"])
        item["balance"] = round(running_balance, 2)
    return {
        "supplier": supplier.name,
        "balance_due": posted_invoices - total_payments,
        "posted_invoices_total": posted_invoices,
        "payments_total": total_payments,
        "filters": {
            "from_date": from_date.isoformat() if from_date else None,
            "to_date": to_date.isoformat() if to_date else None,
        },
        "ledger": ledger,
        "invoices": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in invoices],
        "supplier_invoices": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in purchase_invoices],
        "transactions": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in rows],
        "supplier_payments": [{c.name: getattr(r, c.name) for c in r.__table__.columns} for r in supplier_payments],
    }
