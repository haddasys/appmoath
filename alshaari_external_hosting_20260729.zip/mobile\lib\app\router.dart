import 'package:go_router/go_router.dart';

import '../features/auth/presentation/login_screen.dart';
import '../features/access_control/presentation/access_control_screen.dart';
import '../features/accounting/presentation/accounting_periods_screen.dart';
import '../features/adjustments/presentation/advance_settlement_voucher_screen.dart';
import '../features/adjustments/presentation/adjustment_voucher_screen.dart';
import '../features/adjustments/presentation/customer_adjustment_screen.dart';
import '../features/adjustments/presentation/inventory_adjustment_screen.dart';
import '../features/adjustments/presentation/supplier_adjustment_screen.dart';
import '../features/audit/presentation/audit_readiness_screen.dart';
import '../features/cost_centers/presentation/cost_centers_screen.dart';
import '../features/dashboard/presentation/dashboard_screen.dart';
import '../features/employees/presentation/employees_screen.dart';
import '../features/invoices/presentation/invoices_screen.dart';
import '../features/inventory/presentation/inventory_screen.dart';
import '../features/master_data/presentation/master_data_screen.dart';
import '../features/payroll/presentation/attendance_screen.dart';
import '../features/payroll/presentation/employee_adjustments_screen.dart';
import '../features/payroll/presentation/employee_statement_screen.dart';
import '../features/payroll/presentation/payroll_screen.dart';
import '../features/production/presentation/production_screen.dart';
import '../features/purchases/presentation/purchase_cycle_screen.dart';
import '../features/reports/presentation/reports_screen.dart';
import '../features/settings/presentation/company_settings_screen.dart';
import '../features/statements/presentation/statements_screen.dart';
import '../features/sync/presentation/sync_status_screen.dart';
import '../features/transactions/presentation/transaction_form_screen.dart';
import '../features/transactions/presentation/transactions_review_screen.dart';
import '../features/common/simple_list_screen.dart';

final router = GoRouter(
  initialLocation: '/login',
  routes: [
    GoRoute(
      path: '/login',
      builder: (_, __) => const LoginScreen(),
    ),
    GoRoute(
      path: '/dashboard',
      builder: (_, __) => const DashboardScreen(),
    ),
    GoRoute(
      path: '/sync-status',
      builder: (_, __) => const SyncStatusScreen(),
    ),
    GoRoute(
      path: '/transactions/new',
      builder: (_, __) => const TransactionFormScreen(),
    ),
    GoRoute(
      path: '/documents/new',
      builder: (_, __) => const TransactionFormScreen(),
    ),
    GoRoute(
      path: '/cashbox',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'cash_transfer',
      ),
    ),
    GoRoute(
      path: '/receipt-voucher',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'receipt_from_customer',
      ),
    ),
    GoRoute(
      path: '/payment-voucher',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'general_payment',
      ),
    ),
    GoRoute(
      path: '/advance-payment',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'advance_payment',
      ),
    ),
    GoRoute(
      path: '/advance-settlement',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'advance_settlement',
      ),
    ),
    GoRoute(
      path: '/settlement-voucher',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'advance_settlement',
      ),
    ),
    GoRoute(
      path: '/advance-settlement-voucher',
      builder: (_, __) => const AdvanceSettlementVoucherScreen(),
    ),
    GoRoute(
      path: '/adjustment-voucher',
      builder: (_, __) => const AdjustmentVoucherScreen(),
    ),
    GoRoute(
      path: '/inventory-adjustment',
      builder: (_, __) => const InventoryAdjustmentScreen(),
    ),
    GoRoute(
      path: '/supplier-adjustment',
      builder: (_, __) => const SupplierAdjustmentScreen(),
    ),
    GoRoute(
      path: '/customer-adjustment',
      builder: (_, __) => const CustomerAdjustmentScreen(),
    ),
    GoRoute(
      path: '/worker-wage',
      builder: (_, __) => const TransactionFormScreen(
        initialType: 'worker_wage',
      ),
    ),
    GoRoute(
      path: '/transactions-review',
      builder: (_, __) => const TransactionsReviewScreen(),
    ),
    GoRoute(
      path: '/documents-review',
      builder: (_, __) => const TransactionsReviewScreen(),
    ),
    GoRoute(
      path: '/invoices',
      builder: (_, __) => const InvoicesScreen(),
    ),
    GoRoute(
      path: '/statements',
      builder: (_, state) => StatementsScreen(
        initialPartyType: state.uri.queryParameters['type'] ?? 'customer',
        initialPartyId: int.tryParse(state.uri.queryParameters['id'] ?? ''),
      ),
    ),
    GoRoute(
      path: '/access-control',
      builder: (_, __) => const AccessControlScreen(),
    ),
    GoRoute(
      path: '/audit',
      builder: (_, __) => const AuditReadinessScreen(),
    ),
    GoRoute(
      path: '/settings',
      builder: (_, __) => const CompanySettingsScreen(),
    ),
    GoRoute(
      path: '/master-data',
      builder: (_, __) => const MasterDataScreen(),
    ),
    GoRoute(
      path: '/master-data/customers',
      builder: (_, __) => const MasterDataScreen(initialTab: 0),
    ),
    GoRoute(
      path: '/master-data/suppliers',
      builder: (_, __) => const MasterDataScreen(initialTab: 1),
    ),
    GoRoute(
      path: '/master-data/projects',
      builder: (_, __) => const MasterDataScreen(initialTab: 4),
    ),
    GoRoute(
      path: '/master-data/inventory',
      builder: (_, __) => const MasterDataScreen(initialTab: 5),
    ),
    GoRoute(
      path: '/master-data/cost-centers',
      builder: (_, __) => const MasterDataScreen(initialTab: 8),
    ),
    GoRoute(
      path: '/cost-centers',
      builder: (_, __) => const CostCentersScreen(),
    ),
    GoRoute(
      path: '/accounting-periods',
      builder: (_, __) => const AccountingPeriodsScreen(),
    ),
    GoRoute(
      path: '/customers',
      builder: (_, __) => const MasterDataScreen(initialTab: 0),
    ),
    GoRoute(
      path: '/suppliers',
      builder: (_, __) => const MasterDataScreen(initialTab: 1),
    ),
    GoRoute(
      path: '/projects',
      builder: (_, __) => const MasterDataScreen(initialTab: 4),
    ),
    GoRoute(
      path: '/employees',
      builder: (_, __) => const EmployeesScreen(),
    ),
    GoRoute(
      path: '/payroll/attendance',
      builder: (_, state) => AttendanceScreen(
        initialEmployeeId:
            int.tryParse(state.uri.queryParameters['employee_id'] ?? ''),
      ),
    ),
    GoRoute(
      path: '/payroll/adjustments',
      builder: (_, __) => const EmployeeAdjustmentsScreen(),
    ),
    GoRoute(
      path: '/payroll',
      builder: (_, __) => const PayrollScreen(),
    ),
    GoRoute(
      path: '/payroll/statement/:employeeId',
      builder: (_, state) => EmployeeStatementScreen(
        employeeId: int.tryParse(state.pathParameters['employeeId'] ?? '') ?? 0,
      ),
    ),
    GoRoute(
      path: '/inventory',
      builder: (_, __) => const InventoryScreen(),
    ),
    GoRoute(
      path: '/purchases',
      builder: (_, __) => const PurchaseCycleScreen(),
    ),
    GoRoute(
      path: '/production',
      builder: (_, __) => const ProductionScreen(),
    ),
    GoRoute(
      path: '/items',
      builder: (_, __) => const InventoryScreen(),
    ),
    GoRoute(
      path: '/accounts',
      builder: (_, __) => const SimpleListScreen(
        title: 'دليل الحسابات',
        endpoint: '/api/v1/accounts',
      ),
    ),
    GoRoute(
      path: '/reports',
      builder: (_, state) {
        final tab = state.uri.queryParameters['tab'];
        final initialTab = switch (tab) {
          'journal' => 1,
          'profit-loss' => 2,
          'cash-flow' => 3,
          'projects' => 4,
          'cost-centers' => 5,
          'advances' => 6,
          'cost-center-expenses' => 7,
          'aging' => 8,
          'purchases-inventory' => 9,
          _ => 0,
        };
        return ReportsScreen(initialTab: initialTab);
      },
    ),
    GoRoute(
      path: '/reports/profit-loss',
      builder: (_, __) => const ReportsScreen(initialTab: 2),
    ),
    GoRoute(
      path: '/reports/cash-flow',
      builder: (_, __) => const ReportsScreen(initialTab: 3),
    ),
    GoRoute(
      path: '/reports/purchases-inventory',
      builder: (_, __) => const ReportsScreen(initialTab: 9),
    ),
    GoRoute(
      path: '/purchases-inventory-report',
      builder: (_, __) => const ReportsScreen(initialTab: 9),
    ),
  ],
);
