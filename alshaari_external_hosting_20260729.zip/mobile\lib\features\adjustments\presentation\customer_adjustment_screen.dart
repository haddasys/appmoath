import 'package:flutter/material.dart';

import 'adjustment_voucher_screen.dart';

class CustomerAdjustmentScreen extends StatelessWidget {
  const CustomerAdjustmentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const AdjustmentVoucherScreen();
  }
}
