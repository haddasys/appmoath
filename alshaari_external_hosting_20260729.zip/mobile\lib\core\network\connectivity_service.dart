import 'package:dio/dio.dart';

import '../config.dart';
import '../storage/device_identity.dart';
import 'api_client.dart';

enum ConnectionStatus {
  online,
  offline,
  serverUnreachable,
  syncing,
}

class ConnectivitySnapshot {
  final ConnectionStatus status;
  final bool serverReachable;
  final String message;

  const ConnectivitySnapshot({
    required this.status,
    required this.serverReachable,
    required this.message,
  });

  bool get canUseServer => status == ConnectionStatus.online;
}

class ConnectivityService {
  final Dio _healthDio = Dio(
    BaseOptions(
      baseUrl: AppConfig.apiBaseUrl,
      connectTimeout: const Duration(seconds: 2),
      receiveTimeout: const Duration(seconds: 2),
    ),
  );

  Future<bool> isOnline() async {
    final snapshot = await status();
    return snapshot.canUseServer;
  }

  Future<ConnectivitySnapshot> status() async {
    try {
      await _healthDio.get('/health');
    } on DioException catch (error) {
      return ConnectivitySnapshot(
        status: _isNetworkError(error)
            ? ConnectionStatus.offline
            : ConnectionStatus.serverUnreachable,
        serverReachable: false,
        message: _isNetworkError(error)
            ? 'أنت تعمل بدون اتصال. سيتم حفظ البيانات محليًا ومزامنتها لاحقًا.'
            : 'الخادم غير متاح حاليًا. سيتم حفظ البيانات محليًا.',
      );
    } catch (_) {
      return const ConnectivitySnapshot(
        status: ConnectionStatus.serverUnreachable,
        serverReachable: false,
        message: 'الخادم غير متاح حاليًا. سيتم حفظ البيانات محليًا.',
      );
    }

    try {
      await apiClient.loadToken();
      final deviceId = await deviceIdentity.getOrCreateDeviceId();
      await apiClient.dio.get(
        '/sync/status',
        queryParameters: {'device_id': deviceId},
      );
      return const ConnectivitySnapshot(
        status: ConnectionStatus.online,
        serverReachable: true,
        message: 'متصل بالخادم.',
      );
    } on DioException catch (error) {
      if (error.response?.statusCode == 401 ||
          error.response?.statusCode == 403 ||
          error.response?.statusCode == 404) {
        return const ConnectivitySnapshot(
          status: ConnectionStatus.online,
          serverReachable: true,
          message: 'الخادم متاح، وقد تحتاج الجلسة أو نقطة المزامنة إلى مراجعة.',
        );
      }
      return ConnectivitySnapshot(
        status: ConnectionStatus.serverUnreachable,
        serverReachable: false,
        message: _connectionMessage(error),
      );
    }
  }

  bool _isNetworkError(DioException error) {
    return error.type == DioExceptionType.connectionError ||
        error.type == DioExceptionType.connectionTimeout ||
        error.type == DioExceptionType.receiveTimeout ||
        error.type == DioExceptionType.sendTimeout;
  }

  String _connectionMessage(DioException error) {
    if (_isNetworkError(error)) {
      return 'تعذر الاتصال بالخادم. سيتم حفظ البيانات محليًا.';
    }
    return 'الخادم غير متاح حاليًا. سيتم حفظ البيانات محليًا.';
  }
}

final connectivityService = ConnectivityService();
