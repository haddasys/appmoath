import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.db.database import SessionLocal
from app.services.offline_sync_schema import ensure_offline_sync_schema


def main() -> None:
    db = SessionLocal()
    try:
        ensure_offline_sync_schema(db)
        print("Offline sync schema is ready.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
