import 'dart:ui' as ui;

import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../app/theme.dart';
import '../../../core/widgets/alshaari_ui.dart';
import '../../payroll/presentation/payroll_api.dart';

class EmployeesScreen extends StatefulWidget {
  const EmployeesScreen({super.key});

  @override
  State<EmployeesScreen> createState() => _EmployeesScreenState();
}

class _EmployeesScreenState extends State<EmployeesScreen> {
  bool loading = true;
  String? error;
  List<Map<String, dynamic>> employees = [];

  @override
  void initState() {
    super.initState();
    load();
  }

  Future<void> load() async {
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final dio = await payrollDio();
      final res = await dio.get('/api/v1/employees');
      if (!mounted) return;
      setState(() {
        employees = asList(res.data);
        loading = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        error = errorMessage(e);
        loading = false;
      });
    }
  }

  Future<void> showEmployeeForm() async {
    final name = TextEditingController();
    final phone = TextEditingController();
    final jobTitle = TextEditingController();
    final dailyWage = TextEditingController();
    final qat = TextEditingController(text: '0');
    final transport = TextEditingController(text: '0');
    final food = TextEditingController(text: '0');
    var fridayIncluded = false;

    final saved = await showDialog<bool>(
      context: context,
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setLocal) => AlertDialog(
            title: const Text('إضافة عامل'),
            content: SingleChildScrollView(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  TextField(
                      controller: name,
                      decoration:
                          const InputDecoration(labelText: 'اسم العامل')),
                  const SizedBox(height: 8),
                  TextField(
                      controller: phone,
                      decoration: const InputDecoration(labelText: 'الهاتف')),
                  const SizedBox(height: 8),
                  TextField(
                      controller: jobTitle,
                      decoration: const InputDecoration(labelText: 'المهنة')),
                  const SizedBox(height: 8),
                  TextField(
                    controller: dailyWage,
                    keyboardType: TextInputType.number,
                    decoration:
                        const InputDecoration(labelText: 'الأجر اليومي'),
                  ),
                  const SizedBox(height: 8),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    value: fridayIncluded,
                    title: const Text('الجمعة مشمولة في الأجر'),
                    subtitle: const Text(
                        'تحسب الجمعة ضمن المستحق الشهري حتى إذا لم يعمل.'),
                    onChanged: (value) =>
                        setLocal(() => fridayIncluded = value),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: qat,
                    keyboardType: TextInputType.number,
                    decoration:
                        const InputDecoration(labelText: 'بدل القات اليومي'),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: transport,
                    keyboardType: TextInputType.number,
                    decoration: const InputDecoration(
                        labelText: 'بدل المواصلات اليومي'),
                  ),
                  const SizedBox(height: 8),
                  TextField(
                    controller: food,
                    keyboardType: TextInputType.number,
                    decoration:
                        const InputDecoration(labelText: 'بدل الغداء اليومي'),
                  ),
                ],
              ),
            ),
            actions: [
              TextButton(
                  onPressed: () => Navigator.pop(context, false),
                  child: const Text('إلغاء')),
              FilledButton(
                  onPressed: () => Navigator.pop(context, true),
                  child: const Text('حفظ')),
            ],
          ),
        );
      },
    );

    if (saved != true) return;
    if (name.text.trim().isEmpty || num.tryParse(dailyWage.text) == null) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            content: Text('أدخل اسم العامل والأجر اليومي بشكل صحيح.')),
      );
      return;
    }

    try {
      final dio = await payrollDio();
      await dio.post(
        '/api/v1/employees',
        data: {
          'name': name.text.trim(),
          'phone': phone.text.trim().isEmpty ? null : phone.text.trim(),
          'job_title':
              jobTitle.text.trim().isEmpty ? null : jobTitle.text.trim(),
          'wage_type': 'daily',
          'daily_wage': num.parse(dailyWage.text),
          'friday_included': fridayIncluded,
          'qat_allowance_daily': num.tryParse(qat.text) ?? 0,
          'transport_allowance_daily': num.tryParse(transport.text) ?? 0,
          'food_allowance_daily': num.tryParse(food.text) ?? 0,
          'is_active': true,
        },
      );
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('تم حفظ بيانات العامل.')),
      );
      await load();
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text(errorMessage(e))));
    }
  }

  Widget employeeCard(Map<String, dynamic> employee) {
    final active =
        employee['is_active'] != false && employee['status'] != 'inactive';
    final fridayIncluded = employee['friday_included'] == true;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    '${employee['name'] ?? 'عامل'}',
                    style: Theme.of(context)
                        .textTheme
                        .titleMedium
                        ?.copyWith(fontWeight: FontWeight.w900),
                  ),
                ),
                AlshaariStatusBadge(
                  label: active ? 'نشط' : 'متوقف',
                  color: active ? AlshaariColors.success : AlshaariColors.slate,
                  icon:
                      active ? Icons.check_circle : Icons.pause_circle_outline,
                ),
              ],
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                Chip(
                    label: Text(
                        employee['job_title']?.toString().isNotEmpty == true
                            ? employee['job_title']
                            : 'بدون وظيفة')),
                Chip(
                    label: Text(
                        'الأجر: ${formatMoney(employee['daily_wage'] ?? 0)}')),
                Chip(
                  label: Text(fridayIncluded
                      ? 'الجمعة مشمولة'
                      : 'الجمعة عند الحضور فقط'),
                  avatar: Icon(
                      fridayIncluded ? Icons.event_available : Icons.event_busy,
                      size: 18),
                ),
              ],
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () => context.push(
                        '/payroll/attendance?employee_id=${employee['id']}'),
                    icon: const Icon(Icons.event_note),
                    label: const Text('الحضور'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: () =>
                        context.push('/payroll/statement/${employee['id']}'),
                    icon: const Icon(Icons.manage_search),
                    label: const Text('كشف العامل'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: ui.TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('العمال والرواتب'),
          actions: [
            IconButton(onPressed: load, icon: const Icon(Icons.refresh)),
          ],
        ),
        floatingActionButton: FloatingActionButton.extended(
          onPressed: showEmployeeForm,
          icon: const Icon(Icons.person_add_alt_1),
          label: const Text('عامل جديد'),
        ),
        body: RefreshIndicator(
          onRefresh: load,
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              const AlshaariPageHeader(
                title: 'إدارة العمال',
                subtitle:
                    'الأجر اليومي، سياسة الجمعة، والحالة التشغيلية لكل عامل.',
                icon: Icons.groups_2_outlined,
              ),
              const SizedBox(height: 12),
              AlshaariSectionCard(
                title: 'اختصارات الرواتب',
                icon: Icons.payments_outlined,
                child: Wrap(
                  spacing: 8,
                  runSpacing: 8,
                  children: [
                    FilledButton.icon(
                      onPressed: () => context.push('/payroll/attendance'),
                      icon: const Icon(Icons.event_available),
                      label: const Text('تسجيل الحضور'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => context.push('/payroll/adjustments'),
                      icon: const Icon(Icons.tune),
                      label: const Text('السلف والبدلات'),
                    ),
                    OutlinedButton.icon(
                      onPressed: () => context.push('/payroll'),
                      icon: const Icon(Icons.request_quote_outlined),
                      label: const Text('كشف الرواتب'),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 12),
              if (loading)
                const Center(
                    child: Padding(
                        padding: EdgeInsets.all(24),
                        child: CircularProgressIndicator())),
              if (error != null)
                AlshaariSectionCard(
                  child: Text(error!,
                      style: const TextStyle(color: AlshaariColors.danger)),
                ),
              if (!loading && error == null && employees.isEmpty)
                const AlshaariSectionCard(
                  child: Text(
                      'لا توجد بيانات عمال حتى الآن. ابدأ بإضافة العامل وأجره اليومي.'),
                ),
              ...employees.map(employeeCard),
              const SizedBox(height: 80),
            ],
          ),
        ),
      ),
    );
  }
}
