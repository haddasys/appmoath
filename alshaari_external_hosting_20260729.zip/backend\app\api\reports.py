from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db.database import get_db
from app.core.deps import get_current_user
from app.models.models import Transaction, Project, Invoice, StockMovement, Account, Item, Customer, Supplier, Worker
from decimal import Decimal

router = APIRouter(tags=["Reports"])


def dec(v):
    return Decimal(v or 0)


@router.get("/dashboard")
def dashboard(db: Session = Depends(get_db), user=Depends(get_current_user)):
    cash = db.query(Account).filter(Account.type.in_(["cash", "bank"])).all()
    cash_balance = sum(dec(a.balance) for a in cash)
    receipts = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type == "receipt_from_customer").scalar()
    payments = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.type.in_(["general_payment", "worker_wage", "advance_payment", "material_purchase"])).scalar()
    draft_count = db.query(Transaction).filter(Transaction.status == "draft").count()
    active_projects = db.query(Project).filter(Project.status == "active").count()
    low_stock = db.query(Item).filter(Item.current_qty <= Item.reorder_level).count()
    customer_invoices = db.query(func.coalesce(func.sum(Invoice.total - Invoice.paid_amount), 0)).filter(Invoice.invoice_type == "customer").scalar()
    supplier_invoices = db.query(func.coalesce(func.sum(Invoice.total - Invoice.paid_amount), 0)).filter(Invoice.invoice_type == "supplier").scalar()
    return {
        "cash_balance": cash_balance,
        "total_receipts": receipts,
        "total_payments": payments,
        "customer_receivables": customer_invoices,
        "supplier_payables": supplier_invoices,
        "draft_transactions": draft_count,
        "active_projects": active_projects,
        "low_stock_items": low_stock,
    }


@router.get("/projects/{project_id}/profitability")
def project_profitability(project_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        return {"error": "المشروع غير موجود"}

    customer_invoices = db.query(func.coalesce(func.sum(Invoice.total), 0)).filter(Invoice.invoice_type == "customer", Invoice.project_id == project_id).scalar()
    received = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.project_id == project_id, Transaction.type == "receipt_from_customer").scalar()
    material_cost = db.query(func.coalesce(func.sum(StockMovement.qty * StockMovement.unit_cost), 0)).filter(StockMovement.project_id == project_id, StockMovement.movement_type == "out").scalar()
    labor_cost = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.project_id == project_id, Transaction.type == "worker_wage").scalar()
    other_expenses = db.query(func.coalesce(func.sum(Transaction.amount), 0)).filter(Transaction.status == "approved", Transaction.project_id == project_id, Transaction.type == "general_payment").scalar()

    contract_value = dec(project.contract_value)
    revenue = dec(customer_invoices) if dec(customer_invoices) > 0 else contract_value
    total_cost = dec(material_cost) + dec(labor_cost) + dec(other_expenses)
    profit = revenue - total_cost
    margin = (profit / revenue * Decimal("100")) if revenue > 0 else Decimal("0")

    return {
        "project_id": project.id,
        "project_code": project.project_code,
        "project_name": project.name,
        "contract_value": contract_value,
        "invoiced": dec(customer_invoices),
        "received": dec(received),
        "remaining": revenue - dec(received),
        "material_cost": dec(material_cost),
        "labor_cost": dec(labor_cost),
        "other_expenses": dec(other_expenses),
        "total_cost": total_cost,
        "profit": profit,
        "margin_percent": margin,
        "status": project.status,
        "progress_percent": project.progress_percent,
    }


@router.get("/reports/customer/{customer_id}")
def customer_report(customer_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    customer = db.query(Customer).filter(Customer.id == customer_id).first()
    invoices = db.query(Invoice).filter(Invoice.invoice_type == "customer", Invoice.party_id == customer_id).all()
    receipts = db.query(Transaction).filter(Transaction.status == "approved", Transaction.related_account_type == "customer", Transaction.related_id == customer_id).order_by(Transaction.date.desc()).all()
    total_invoices = sum(dec(i.total) for i in invoices)
    paid_invoices = sum(dec(i.paid_amount) for i in invoices)
    total_receipts = sum(dec(t.amount) for t in receipts if t.type == "receipt_from_customer")
    return {
        "party": customer,
        "total_invoices": total_invoices,
        "paid_invoices": paid_invoices,
        "total_receipts": total_receipts,
        "balance": total_invoices - total_receipts,
        "invoices": invoices,
        "transactions": receipts,
    }


@router.get("/reports/supplier/{supplier_id}")
def supplier_report(supplier_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    invoices = db.query(Invoice).filter(Invoice.invoice_type == "supplier", Invoice.party_id == supplier_id).all()
    txs = db.query(Transaction).filter(Transaction.status == "approved", Transaction.related_account_type == "supplier", Transaction.related_id == supplier_id).order_by(Transaction.date.desc()).all()
    total_invoices = sum(dec(i.total) for i in invoices)
    paid = sum(dec(t.amount) for t in txs if t.type == "material_purchase")
    return {"party": supplier, "total_invoices": total_invoices, "paid": paid, "balance": total_invoices - paid, "invoices": invoices, "transactions": txs}


@router.get("/reports/worker/{worker_id}")
def worker_report(worker_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    worker = db.query(Worker).filter(Worker.id == worker_id).first()
    txs = db.query(Transaction).filter(Transaction.status == "approved", Transaction.related_account_type == "worker", Transaction.related_id == worker_id).order_by(Transaction.date.desc()).all()
    wages = sum(dec(t.amount) for t in txs if t.type == "worker_wage")
    advances = sum(dec(t.amount) for t in txs if t.type == "advance_payment")
    settlements = sum(dec(t.amount) for t in txs if t.type == "advance_settlement")
    return {"party": worker, "wages": wages, "advances": advances, "settlements": settlements, "advance_balance": advances - settlements, "transactions": txs}
