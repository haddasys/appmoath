from datetime import date
from decimal import Decimal
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db.database import get_db
from app.core.deps import get_current_user, require_approval_role, require_permission
from app.models.models import *
from app.schemas.schemas import *

router = APIRouter(prefix="/api/v1", tags=["MVP"])

def as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}

def list_model(db, model):
    return [as_dict(x) for x in db.query(model).order_by(model.id.desc()).limit(500).all()]

def _money(value) -> str:
    return str((Decimal(str(value or 0))).quantize(Decimal("0.01")))

def _account_parent_for_display(code: str, known_codes: set[str], parent_code: str | None) -> str | None:
    if code in {"10111", "10121", "10131"} and "10101" in known_codes:
        return "10101"
    if code.endswith("02") and code[:-2] in {"10111", "10121", "10131"} and "10102" in known_codes:
        return "10102"
    if code.endswith("03") and code[:-2] in {"10111", "10121", "10131"} and "10103" in known_codes:
        return "10103"
    if parent_code:
        return parent_code
    for index in range(len(code) - 1, 0, -1):
        candidate = code[:index]
        if candidate in known_codes:
            return candidate
    return None

def _account_level(code: str) -> int:
    length = len(code or "")
    if length <= 1:
        return 1
    if length <= 3:
        return 2
    if length <= 5:
        return 3
    return 4

def create_obj(db, model, data):
    obj = model(**data.model_dump(exclude_unset=True))
    db.add(obj)
    db.commit()
    db.refresh(obj)
    return as_dict(obj)

def update_obj(db: Session, model, obj_id: int, data, not_found_message: str, user=None, audit_action: str | None = None, entity: str | None = None):
    obj = db.query(model).filter(model.id == obj_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail=not_found_message)
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(obj, k, v)
    if user is not None and audit_action and entity:
        db.add(AuditLog(user_id=user.id, action=audit_action, entity=entity, entity_id=obj_id, details=getattr(obj, "name", None)))
    db.commit()
    db.refresh(obj)
    return as_dict(obj)

def ensure_not_referenced(db: Session, model_name: str, obj_id: int):
    if model_name == "customer":
        if db.query(Project).filter(Project.customer_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف عميل مرتبط بمشروع")
        if db.query(Transaction).filter(Transaction.related_account_type == "customer", Transaction.related_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف عميل مرتبط بحركات مالية")
    elif model_name == "supplier":
        if db.query(Transaction).filter(Transaction.related_account_type == "supplier", Transaction.related_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مورد مرتبط بحركات مالية")
        if db.query(SupplierInvoice).filter(SupplierInvoice.supplier_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مورد لديه فواتير مورد")
        if db.query(SupplierPayment).filter(SupplierPayment.supplier_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مورد لديه سندات دفع")
        if db.query(PurchaseOrder).filter(PurchaseOrder.supplier_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مورد مرتبط بأوامر شراء")
        if db.query(GoodsReceipt).filter(GoodsReceipt.supplier_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مورد مرتبط بسندات استلام")
    elif model_name == "worker":
        if db.query(Transaction).filter(Transaction.related_account_type == "worker", Transaction.related_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف عامل مرتبط بسلف أو أجور أو تسويات")
        if db.query(JournalEntryLine).filter(JournalEntryLine.party_type == "worker", JournalEntryLine.party_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف عامل مرتبط بقيود محاسبية")
    elif model_name == "project":
        if db.query(Transaction).filter(Transaction.project_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مشروع مرتبط بحركات مالية")
        if db.query(ProjectCost).filter(ProjectCost.project_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مشروع لديه تكاليف")
        if db.query(CostCenter).filter(CostCenter.project_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مشروع مرتبط بمركز تكلفة")
        if db.query(PurchaseRequest).filter(PurchaseRequest.project_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مشروع مرتبط بطلبات شراء")
        if db.query(PurchaseOrder).filter(PurchaseOrder.project_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مشروع مرتبط بأوامر شراء")
    elif model_name == "item":
        if db.query(StockMovement).filter(StockMovement.item_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مادة لها حركات مخزون")
        if db.query(Transaction).filter(Transaction.item_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مادة مرتبطة بحركات مالية")
        if db.query(PurchaseOrderLine).filter(PurchaseOrderLine.item_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مادة مرتبطة بأوامر شراء")
        if db.query(GoodsReceiptLine).filter(GoodsReceiptLine.item_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مادة مرتبطة بسندات استلام")
        if db.query(SupplierInvoiceLine).filter(SupplierInvoiceLine.item_id == obj_id).first():
            raise HTTPException(status_code=400, detail="لا يمكن حذف مادة مرتبطة بفواتير مورد")


def account_has_posted_activity(db: Session, account_code: str) -> bool:
    return db.query(JournalEntryLine).filter(JournalEntryLine.account_code == account_code).first() is not None


def account_has_system_references(db: Session, account_code: str) -> bool:
    return any(
        [
            account_has_posted_activity(db, account_code),
            db.query(PostingRule).filter(
                (PostingRule.debit_account_code == account_code)
                | (PostingRule.credit_account_code == account_code)
            ).first()
            is not None,
            db.query(SupplierInvoiceLine).filter(SupplierInvoiceLine.account_code == account_code).first() is not None,
            db.query(SupplierPayment).filter(SupplierPayment.cash_account_code == account_code).first() is not None,
            db.query(CashAccount).filter(CashAccount.code == account_code).first() is not None,
        ]
    )


def item_has_inventory_activity(db: Session, item_id: int) -> bool:
    return any(
        [
            db.query(StockMovement).filter(StockMovement.item_id == item_id).first() is not None,
            db.query(Transaction).filter(Transaction.item_id == item_id).first() is not None,
            db.query(PurchaseOrderLine).filter(PurchaseOrderLine.item_id == item_id).first() is not None,
            db.query(GoodsReceiptLine).filter(GoodsReceiptLine.item_id == item_id).first() is not None,
            db.query(SupplierInvoiceLine).filter(SupplierInvoiceLine.item_id == item_id).first() is not None,
        ]
    )


def project_has_financial_activity(db: Session, project_id: int) -> bool:
    return any(
        [
            db.query(Transaction).filter(Transaction.project_id == project_id).first() is not None,
            db.query(ProjectCost).filter(ProjectCost.project_id == project_id).first() is not None,
            db.query(JournalEntryLine).filter(JournalEntryLine.project_id == project_id).first() is not None,
            db.query(PurchaseRequest).filter(PurchaseRequest.project_id == project_id).first() is not None,
            db.query(PurchaseOrder).filter(PurchaseOrder.project_id == project_id).first() is not None,
            db.query(SupplierInvoiceLine).filter(SupplierInvoiceLine.project_id == project_id).first() is not None,
        ]
    )

@router.get("/accounts")
def accounts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    accounts = db.query(Account).order_by(Account.code.asc()).all()
    known_codes = {account.code for account in accounts}
    nodes = {}
    for account in accounts:
        own_balance = Decimal(str(account.balance or 0))
        parent_code = _account_parent_for_display(
            account.code,
            known_codes,
            account.parent_code,
        )
        row = as_dict(account)
        row["parent_code"] = parent_code
        row["account_level"] = _account_level(account.code)
        row["own_balance"] = _money(own_balance)
        row["children_balance"] = "0.00"
        row["total_balance"] = _money(own_balance)
        nodes[account.code] = {
            "row": row,
            "own_balance": own_balance,
            "children_balance": Decimal("0"),
            "total_balance": own_balance,
        }

    for code in sorted(nodes.keys(), key=len, reverse=True):
        parent_code = nodes[code]["row"].get("parent_code")
        if parent_code in nodes:
            nodes[parent_code]["children_balance"] += nodes[code]["total_balance"]
            nodes[parent_code]["total_balance"] += nodes[code]["total_balance"]

    rows = []
    for code in sorted(nodes.keys()):
        node = nodes[code]
        row = node["row"]
        row["own_balance"] = _money(node["own_balance"])
        row["children_balance"] = _money(node["children_balance"])
        row["total_balance"] = _money(node["total_balance"])
        row["balance"] = row["total_balance"]
        rows.append(row)
    return rows

@router.post("/accounts")
def create_account(data: AccountCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return create_obj(db, Account, data)

@router.put("/accounts/{id}")
def update_account(id: int, data: AccountCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Account).filter(Account.id == id).first()
    if not obj: raise HTTPException(404, "الحساب غير موجود")
    payload = data.model_dump(exclude_unset=True)
    if "code" in payload and payload["code"] != obj.code and account_has_system_references(db, obj.code):
        raise HTTPException(400, "لا يمكن تغيير كود حساب مستخدم في قيود أو قواعد ترحيل. أنشئ حسابًا جديدًا واستخدم قيد تسوية عند الحاجة")
    if "balance" in payload and payload["balance"] != obj.balance and account_has_posted_activity(db, obj.code):
        raise HTTPException(400, "لا يمكن تعديل رصيد حساب له قيود محاسبية يدويًا. استخدم سند تسوية أو قيد افتتاحي")
    for k, v in payload.items(): setattr(obj, k, v)
    db.add(AuditLog(user_id=user.id, action="update_account", entity="account", entity_id=id, details=data.name))
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.patch("/accounts/{id}/balance")
def update_account_balance(id: int, data: AccountBalanceUpdate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Account).filter(Account.id == id).first()
    if not obj: raise HTTPException(404, "الحساب غير موجود")
    if account_has_posted_activity(db, obj.code):
        raise HTTPException(400, "لا يمكن تعديل رصيد حساب له قيود محاسبية يدويًا. استخدم سند تسوية أو قيد عكسي")
    old_balance = obj.balance
    obj.balance = data.balance
    db.add(AuditLog(user_id=user.id, action="set_opening_balance", entity="account", entity_id=id, details=f"{old_balance} -> {data.balance}; {data.notes or ''}"))
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.get("/cost-centers")
def cost_centers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [as_dict(x) for x in db.query(CostCenter).order_by(CostCenter.code.asc()).limit(500).all()]

@router.get("/warehouses")
def warehouses(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [as_dict(x) for x in db.query(Warehouse).order_by(Warehouse.code.asc()).limit(500).all()]

@router.post("/warehouses")
def create_warehouse(data: WarehouseCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    if data.type not in {"general", "project", "temporary"}:
        raise HTTPException(status_code=400, detail="نوع المخزن يجب أن يكون عام أو مشروع أو مؤقت")
    if data.type == "project" and not data.project_id:
        raise HTTPException(status_code=400, detail="مخزن المشروع يتطلب تحديد المشروع")
    exists = db.query(Warehouse).filter(Warehouse.code == data.code).first()
    if exists:
        raise HTTPException(status_code=400, detail="كود المخزن موجود مسبقا")
    obj = Warehouse(**data.model_dump(exclude_unset=True))
    db.add(obj)
    db.flush()
    db.add(AuditLog(user_id=user.id, action="create_warehouse", entity="warehouse", entity_id=obj.id, details=obj.name))
    db.commit()
    db.refresh(obj)
    return as_dict(obj)

@router.post("/cost-centers")
def create_cost_center(data: CostCenterCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    exists = db.query(CostCenter).filter(CostCenter.code == data.code).first()
    if exists:
        raise HTTPException(status_code=400, detail="كود مركز التكلفة موجود مسبقا")
    obj = CostCenter(**data.model_dump(exclude_unset=True))
    db.add(obj)
    db.flush()
    db.add(AuditLog(user_id=user.id, action="create_cost_center", entity="cost_center", entity_id=obj.id, details=obj.name))
    db.commit()
    db.refresh(obj)
    return as_dict(obj)

@router.put("/cost-centers/{id}")
def update_cost_center(id: int, data: CostCenterCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(CostCenter).filter(CostCenter.id == id).first()
    if not obj:
        raise HTTPException(404, "مركز التكلفة غير موجود")
    for k, v in data.model_dump(exclude_unset=True).items():
        setattr(obj, k, v)
    db.add(AuditLog(user_id=user.id, action="update_cost_center", entity="cost_center", entity_id=id, details=obj.name))
    db.commit()
    db.refresh(obj)
    return as_dict(obj)

@router.get("/customers")
def customers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Customer)

@router.post("/customers")
def create_customer(data: CustomerCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return create_obj(db, Customer, data)

@router.put("/customers/{id}")
def update_customer(id: int, data: CustomerCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    obj = db.query(Customer).filter(Customer.id == id).first()
    if not obj: raise HTTPException(404, "العميل غير موجود")
    for k, v in data.model_dump(exclude_unset=True).items(): setattr(obj, k, v)
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.delete("/customers/{id}")
def delete_customer(id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Customer).filter(Customer.id == id).first()
    if not obj: raise HTTPException(404, "العميل غير موجود")
    ensure_not_referenced(db, "customer", id)
    db.delete(obj); db.commit(); return {"ok": True}

@router.get("/suppliers")
def suppliers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Supplier)

@router.post("/suppliers")
def create_supplier(data: SupplierCreate, db: Session = Depends(get_db), user=Depends(require_permission("suppliers.write"))):
    return create_obj(db, Supplier, data)

@router.put("/suppliers/{id}")
def update_supplier(id: int, data: SupplierCreate, db: Session = Depends(get_db), user=Depends(require_permission("suppliers.write"))):
    obj = db.query(Supplier).filter(Supplier.id == id).first()
    if not obj: raise HTTPException(404, "المورد غير موجود")
    for k, v in data.model_dump(exclude_unset=True).items(): setattr(obj, k, v)
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.delete("/suppliers/{id}")
def delete_supplier(id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Supplier).filter(Supplier.id == id).first()
    if not obj: raise HTTPException(404, "المورد غير موجود")
    ensure_not_referenced(db, "supplier", id)
    db.add(AuditLog(user_id=user.id, action="delete_supplier", entity="supplier", entity_id=id, details=obj.name))
    db.delete(obj)
    db.commit()
    return {"ok": True}

@router.get("/employees")
def employees(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Employee)

@router.post("/employees")
def create_employee(data: EmployeeCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return create_obj(db, Employee, data)

@router.put("/employees/{id}")
def update_employee(id: int, data: EmployeeCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return update_obj(db, Employee, id, data, "الموظف غير موجود", user, "update_employee", "employee")

@router.get("/workers")
def workers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Worker)

@router.post("/workers")
def create_worker(data: WorkerCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return create_obj(db, Worker, data)

@router.put("/workers/{id}")
def update_worker(id: int, data: WorkerCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return update_obj(db, Worker, id, data, "العامل غير موجود", user, "update_worker", "worker")

@router.delete("/workers/{id}")
def delete_worker(id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Worker).filter(Worker.id == id).first()
    if not obj: raise HTTPException(404, "العامل غير موجود")
    ensure_not_referenced(db, "worker", id)
    db.add(AuditLog(user_id=user.id, action="delete_worker", entity="worker", entity_id=id, details=obj.name))
    db.delete(obj)
    db.commit()
    return {"ok": True}

@router.get("/projects")
def projects(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Project)

@router.post("/projects")
def create_project(data: ProjectCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    payload = data.model_dump(exclude_unset=True)
    if not payload.get("project_code"):
        year = date.today().year
        count = db.query(Project).count() + 1
        payload["project_code"] = f"ASH-PRJ-{year}-{count:04d}"
    obj = Project(**payload)
    db.add(obj)
    db.flush()

    year = date.today().year
    cost_center_code = f"CC-PRJ-{year}-{obj.id:04d}"
    if not db.query(CostCenter).filter(CostCenter.code == cost_center_code).first():
        db.add(
            CostCenter(
                code=cost_center_code,
                name=f"مركز تكلفة مشروع: {obj.name}",
                type="project",
                project_id=obj.id,
                is_active=True,
                is_postable=True,
            )
        )

    db.commit(); db.refresh(obj); return as_dict(obj)

@router.put("/projects/{id}")
def update_project(id: int, data: ProjectCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    obj = db.query(Project).filter(Project.id == id).first()
    if not obj: raise HTTPException(404, "المشروع غير موجود")
    payload = data.model_dump(exclude_unset=True)
    if project_has_financial_activity(db, id):
        if "project_code" in payload and payload["project_code"] and payload["project_code"] != obj.project_code:
            raise HTTPException(400, "لا يمكن تغيير كود مشروع لديه حركات أو تكاليف")
        if "customer_id" in payload and payload["customer_id"] != obj.customer_id:
            raise HTTPException(400, "لا يمكن تغيير عميل مشروع لديه حركات أو تكاليف")
    for k, v in payload.items(): setattr(obj, k, v)
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.delete("/projects/{id}")
def delete_project(id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Project).filter(Project.id == id).first()
    if not obj: raise HTTPException(404, "المشروع غير موجود")
    ensure_not_referenced(db, "project", id)
    db.add(AuditLog(user_id=user.id, action="delete_project", entity="project", entity_id=id, details=obj.name))
    db.delete(obj)
    db.commit()
    return {"ok": True}

@router.get("/cash-accounts")
def cash_accounts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, CashAccount)

@router.post("/cash-accounts")
def create_cash_account(data: CashAccountCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    return create_obj(db, CashAccount, data)

@router.get("/cash-transactions")
def cash_transactions(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, CashTransaction)

@router.post("/cash-transactions")
def create_cash_transaction(data: CashTransactionCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    raise HTTPException(
        status_code=410,
        detail="تم إيقاف سندات الصندوق القديمة لأنها لا تنشئ قيدًا محاسبيًا. استخدم شاشة الحركات المالية أو سندات الموردين/العملاء المعتمدة",
    )

@router.get("/expenses")
def expenses(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Expense)

@router.post("/expenses")
def create_expense(data: ExpenseCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Expense, data)

@router.put("/expenses/{id}")
def update_expense(id: int, data: ExpenseCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(Expense).filter(Expense.id == id).first()
    if not obj: raise HTTPException(404, "المصروف غير موجود")
    if obj.status == "approved": raise HTTPException(400, "لا يمكن تعديل مصروف معتمد إلا بإجراء عكسي")
    for k, v in data.model_dump(exclude_unset=True).items(): setattr(obj, k, v)
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.get("/revenues")
def revenues(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Revenue)

@router.post("/revenues")
def create_revenue(data: RevenueCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Revenue, data)

@router.get("/items")
def items(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Item)

@router.post("/items")
def create_item(data: ItemCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return create_obj(db, Item, data)

@router.put("/items/{id}")
def update_item(id: int, data: ItemCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    obj = db.query(Item).filter(Item.id == id).first()
    if not obj: raise HTTPException(404, "المادة غير موجودة")
    payload = data.model_dump(exclude_unset=True)
    if item_has_inventory_activity(db, id):
        if "code" in payload and payload["code"] != obj.code:
            raise HTTPException(400, "لا يمكن تغيير كود مادة لها حركات مخزون")
        if "current_qty" in payload and payload["current_qty"] != obj.current_qty:
            raise HTTPException(400, "لا يمكن تعديل رصيد مادة لها حركات مخزون يدويًا. استخدم تسوية مخزون")
        if "avg_cost" in payload and payload["avg_cost"] != obj.avg_cost:
            raise HTTPException(400, "لا يمكن تعديل متوسط تكلفة مادة لها حركات مخزون يدويًا. استخدم تسوية مخزون")
    for k, v in payload.items(): setattr(obj, k, v)
    db.add(AuditLog(user_id=user.id, action="update_item", entity="item", entity_id=id, details=data.name))
    db.commit(); db.refresh(obj); return as_dict(obj)

@router.delete("/items/{id}")
def delete_item(id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(Item).filter(Item.id == id).first()
    if not obj: raise HTTPException(404, "المادة غير موجودة")
    ensure_not_referenced(db, "item", id)
    db.add(AuditLog(user_id=user.id, action="delete_item", entity="item", entity_id=id, details=obj.name))
    db.delete(obj)
    db.commit()
    return {"ok": True}

@router.get("/inventory-items")
def inventory_items(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, InventoryItem)

@router.post("/inventory-items")
def create_inventory_item(data: InventoryItemCreate, db: Session = Depends(get_db), user=Depends(require_permission("master_data.write"))):
    return create_obj(db, InventoryItem, data)

@router.get("/payrolls")
def payrolls(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return list_model(db, Payroll)

@router.post("/payrolls")
def create_payroll(data: PayrollCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_obj(db, Payroll, data)
