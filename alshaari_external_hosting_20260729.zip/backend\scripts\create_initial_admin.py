import os

from app.core.security import hash_password
from app.db.database import SessionLocal
from app.models.models import User


def required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise SystemExit(f"Missing required environment variable: {name}")
    return value


def main():
    name = required_env("INITIAL_ADMIN_NAME")
    phone = required_env("INITIAL_ADMIN_PHONE")
    password = required_env("INITIAL_ADMIN_PASSWORD")
    if len(password) < 8:
        raise SystemExit("INITIAL_ADMIN_PASSWORD must be at least 8 characters")

    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.phone == phone).first()
        if existing:
            existing.name = name
            existing.role = "manager"
            existing.is_active = True
            print("Initial admin already exists. Role and status were verified.")
        else:
            db.add(
                User(
                    name=name,
                    phone=phone,
                    password_hash=hash_password(password),
                    role="manager",
                    is_active=True,
                )
            )
            print("Initial admin user was created.")
        db.commit()
    finally:
        db.close()


if __name__ == "__main__":
    main()
