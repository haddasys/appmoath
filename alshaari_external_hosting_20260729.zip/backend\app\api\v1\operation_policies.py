from fastapi import APIRouter
from app.services.operation_policy import OPERATION_POLICIES, allowed_ui_fields

router = APIRouter(prefix="/api/v1/operation-policies", tags=["Operation Policies"])


@router.get("")
def list_operation_policies():
    return [
        {
            "type": operation_type,
            "label": policy["label"],
            "required": policy["required"],
            "optional": policy["optional"],
            "forbidden": policy["forbidden"],
            "cash_effect": policy["cash_effect"],
            "inventory_effect": policy["inventory_effect"],
            "project_cost_effect": policy["project_cost_effect"],
        }
        for operation_type, policy in OPERATION_POLICIES.items()
    ]


@router.get("/{operation_type}")
def get_operation_policy(operation_type: str):
    return allowed_ui_fields(operation_type)
