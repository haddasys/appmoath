from sqlalchemy import Column, Integer, String, Numeric, Date, DateTime, ForeignKey, Text, Boolean
from sqlalchemy.sql import func
from app.db.database import Base

class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(120), nullable=False)
    phone = Column(String(30), unique=True, index=True, nullable=False)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(30), default="data_entry")
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Role(Base):
    __tablename__ = "roles"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(50), unique=True, nullable=False)
    name = Column(String(120), nullable=False)
    notes = Column(Text, nullable=True)

class Permission(Base):
    __tablename__ = "permissions"
    id = Column(Integer, primary_key=True, index=True)
    role_code = Column(String(50), nullable=False)
    permission = Column(String(120), nullable=False)

class PostingRule(Base):
    __tablename__ = "posting_rules"
    id = Column(Integer, primary_key=True, index=True)
    operation_type = Column(String(80), unique=True, nullable=False)
    debit_account_code = Column(String(30), nullable=False)
    credit_account_code = Column(String(30), nullable=False)
    description = Column(Text, nullable=True)
    is_active = Column(Boolean, default=True)

class DocumentSequence(Base):
    __tablename__ = "document_sequences"
    id = Column(Integer, primary_key=True, index=True)
    document_type = Column(String(60), unique=True, nullable=False)
    prefix = Column(String(20), nullable=False)
    year = Column(Integer, nullable=True)
    next_number = Column(Integer, default=1)
    padding = Column(Integer, default=4)
    padding_length = Column(Integer, default=4)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), nullable=True)

class CostCenter(Base):
    __tablename__ = "cost_centers"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    parent_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    type = Column(String(40), default="production")
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    responsible_user_id = Column(Integer, nullable=True)
    allocation_method = Column(String(40), default="direct")
    allocation_base = Column(String(40), nullable=True)
    budget_amount = Column(Numeric(14, 2), default=0)
    is_postable = Column(Boolean, default=True)
    is_active = Column(Boolean, default=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Account(Base):
    __tablename__ = "accounts"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(30), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    type = Column(String(40), nullable=False)  # asset/liability/equity/revenue/cost/expense/control/cash/bank
    currency = Column(String(10), default="YER")
    balance = Column(Numeric(14, 2), default=0)
    parent_code = Column(String(30), nullable=True)
    is_active = Column(Boolean, default=True)

class Customer(Base):
    __tablename__ = "customers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    address = Column(String(255), nullable=True)
    customer_type = Column(String(50), nullable=True)
    notes = Column(Text, nullable=True)

class Supplier(Base):
    __tablename__ = "suppliers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    category = Column(String(80), nullable=True)
    notes = Column(Text, nullable=True)

class Employee(Base):
    __tablename__ = "employees"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    job_title = Column(String(80), nullable=True)
    wage_type = Column(String(30), default="daily")
    daily_wage = Column(Numeric(14, 2), default=0)
    monthly_salary = Column(Numeric(14, 2), default=0)
    department = Column(String(80), nullable=True)
    status = Column(String(30), default="active")
    notes = Column(Text, nullable=True)

# Backward-compatible alias table used by the current app screens.
class Worker(Base):
    __tablename__ = "workers"
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(150), nullable=False)
    phone = Column(String(30), nullable=True)
    daily_wage = Column(Numeric(14,2), default=0)
    notes = Column(Text, nullable=True)

class Project(Base):
    __tablename__ = "projects"
    id = Column(Integer, primary_key=True, index=True)
    project_code = Column(String(40), unique=True, index=True, nullable=False)
    name = Column(String(180), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    project_type = Column(String(80), nullable=True)
    contract_value = Column(Numeric(14,2), default=0)
    status = Column(String(40), default="new")
    progress_percent = Column(Integer, default=0)
    responsible_id = Column(Integer, nullable=True)
    start_date = Column(Date, nullable=True)
    expected_end_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)

class ProjectStage(Base):
    __tablename__ = "project_stages"
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    stage_order = Column(Integer, default=1)
    stage_code = Column(String(50), nullable=False)
    name = Column(String(120), nullable=False)
    status = Column(String(30), default="not_started")
    progress_percent = Column(Integer, default=0)
    planned_start_date = Column(Date, nullable=True)
    planned_end_date = Column(Date, nullable=True)
    actual_start_date = Column(Date, nullable=True)
    actual_end_date = Column(Date, nullable=True)
    responsible_id = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class ProductionOrder(Base):
    __tablename__ = "production_orders"
    id = Column(Integer, primary_key=True, index=True)
    order_no = Column(String(80), unique=True, nullable=False, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False, index=True)
    stage_id = Column(Integer, ForeignKey("project_stages.id"), nullable=True, index=True)
    item_description = Column(String(220), nullable=False)
    qty = Column(Numeric(14, 3), default=1)
    unit = Column(String(30), default="pcs")
    priority = Column(String(20), default="normal")
    status = Column(String(30), default="planned")
    planned_start_date = Column(Date, nullable=True)
    planned_end_date = Column(Date, nullable=True)
    actual_start_date = Column(Date, nullable=True)
    actual_end_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())

class CashAccount(Base):
    __tablename__ = "cash_accounts"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(30), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    account_code = Column(String(30), nullable=True)
    type = Column(String(40), default="cash")
    holder_name = Column(String(150), nullable=True)
    currency = Column(String(10), default="YER")
    opening_balance = Column(Numeric(14, 2), default=0)
    balance = Column(Numeric(14, 2), default=0)
    current_balance = Column(Numeric(14, 2), default=0)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class CashTransaction(Base):
    __tablename__ = "cash_transactions"
    id = Column(Integer, primary_key=True, index=True)
    voucher_no = Column(String(60), unique=True, nullable=True)
    date = Column(Date, nullable=False)
    transaction_type = Column(String(30), nullable=False)  # receipt/payment/transfer
    amount = Column(Numeric(14,2), default=0)
    currency = Column(String(10), default="YER")
    cash_account_id = Column(Integer, ForeignKey("cash_accounts.id"), nullable=True)
    related_account_type = Column(String(40), nullable=True)
    related_id = Column(Integer, nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    payment_method = Column(String(40), nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, nullable=True)
    approved_by = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Expense(Base):
    __tablename__ = "expenses"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    category = Column(String(80), nullable=False)
    amount = Column(Numeric(14,2), default=0)
    currency = Column(String(10), default="YER")
    payment_method = Column(String(40), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    employee_id = Column(Integer, nullable=True)
    supplier_id = Column(Integer, nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Revenue(Base):
    __tablename__ = "revenues"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    revenue_type = Column(String(80), nullable=False)
    customer_id = Column(Integer, ForeignKey("customers.id"), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    amount = Column(Numeric(14,2), default=0)
    currency = Column(String(10), default="YER")
    payment_method = Column(String(40), nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Purchase(Base):
    __tablename__ = "purchases"
    id = Column(Integer, primary_key=True, index=True)
    invoice_no = Column(String(80), nullable=True)
    date = Column(Date, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=True)
    total = Column(Numeric(14,2), default=0)
    paid_amount = Column(Numeric(14,2), default=0)
    status = Column(String(30), default="draft")
    notes = Column(Text, nullable=True)

class PurchaseItem(Base):
    __tablename__ = "purchase_items"
    id = Column(Integer, primary_key=True, index=True)
    purchase_id = Column(Integer, ForeignKey("purchases.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("inventory_items.id"), nullable=False)
    qty = Column(Numeric(14,3), default=0)
    unit_cost = Column(Numeric(14,2), default=0)
    total = Column(Numeric(14,2), default=0)

class PurchaseRequest(Base):
    __tablename__ = "purchase_requests"
    id = Column(Integer, primary_key=True, index=True)
    request_no = Column(String(80), unique=True, nullable=False)
    date = Column(Date, nullable=False)
    requested_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    department = Column(String(120), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    request_type = Column(String(40), default="materials")
    priority = Column(String(30), default="normal")
    status = Column(String(30), default="draft")
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class PurchaseRequestLine(Base):
    __tablename__ = "purchase_request_lines"
    id = Column(Integer, primary_key=True, index=True)
    request_id = Column(Integer, ForeignKey("purchase_requests.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=True)
    item_name = Column(String(180), nullable=False)
    qty = Column(Numeric(14,3), default=0)
    unit = Column(String(30), default="pcs")
    estimated_unit_cost = Column(Numeric(14,2), default=0)
    estimated_total = Column(Numeric(14,2), default=0)
    needed_date = Column(Date, nullable=True)
    notes = Column(Text, nullable=True)

class PurchaseOrder(Base):
    __tablename__ = "purchase_orders"
    id = Column(Integer, primary_key=True, index=True)
    po_no = Column(String(80), unique=True, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    purchase_request_id = Column(Integer, ForeignKey("purchase_requests.id"), nullable=True)
    date = Column(Date, nullable=False)
    expected_delivery_date = Column(Date, nullable=True)
    payment_terms = Column(String(120), nullable=True)
    currency = Column(String(10), default="YER")
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    status = Column(String(30), default="draft")
    description = Column(Text, nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class PurchaseOrderLine(Base):
    __tablename__ = "purchase_order_lines"
    id = Column(Integer, primary_key=True, index=True)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=True)
    item_name = Column(String(180), nullable=False)
    qty_ordered = Column(Numeric(14,3), default=0)
    qty_received = Column(Numeric(14,3), default=0)
    unit = Column(String(30), default="pcs")
    unit_price = Column(Numeric(14,2), default=0)
    discount = Column(Numeric(14,2), default=0)
    tax = Column(Numeric(14,2), default=0)
    total = Column(Numeric(14,2), default=0)

class GoodsReceipt(Base):
    __tablename__ = "goods_receipts"
    id = Column(Integer, primary_key=True, index=True)
    grn_no = Column(String(80), unique=True, nullable=False)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    date = Column(Date, nullable=False)
    received_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    warehouse_id = Column(Integer, nullable=True)
    status = Column(String(30), default="draft")
    notes = Column(Text, nullable=True)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class GoodsReceiptLine(Base):
    __tablename__ = "goods_receipt_lines"
    id = Column(Integer, primary_key=True, index=True)
    grn_id = Column(Integer, ForeignKey("goods_receipts.id"), nullable=False)
    po_line_id = Column(Integer, ForeignKey("purchase_order_lines.id"), nullable=True)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    qty_ordered = Column(Numeric(14,3), default=0)
    qty_received = Column(Numeric(14,3), default=0)
    qty_rejected = Column(Numeric(14,3), default=0)
    unit = Column(String(30), default="pcs")
    condition_status = Column(String(30), default="accepted")
    notes = Column(Text, nullable=True)

class SupplierInvoice(Base):
    __tablename__ = "supplier_invoices"
    id = Column(Integer, primary_key=True, index=True)
    internal_invoice_no = Column(String(80), unique=True, nullable=False)
    supplier_invoice_no = Column(String(120), nullable=True)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    po_id = Column(Integer, ForeignKey("purchase_orders.id"), nullable=True)
    grn_id = Column(Integer, ForeignKey("goods_receipts.id"), nullable=True)
    invoice_date = Column(Date, nullable=False)
    due_date = Column(Date, nullable=True)
    invoice_type = Column(String(40), default="inventory")
    currency = Column(String(10), default="YER")
    subtotal = Column(Numeric(14,2), default=0)
    discount = Column(Numeric(14,2), default=0)
    tax = Column(Numeric(14,2), default=0)
    net_amount = Column(Numeric(14,2), default=0)
    paid_amount = Column(Numeric(14,2), default=0)
    status = Column(String(30), default="draft")
    description = Column(Text, nullable=True)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class SupplierInvoiceLine(Base):
    __tablename__ = "supplier_invoice_lines"
    id = Column(Integer, primary_key=True, index=True)
    invoice_id = Column(Integer, ForeignKey("supplier_invoices.id"), nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=True)
    description = Column(Text, nullable=False)
    qty = Column(Numeric(14,3), default=0)
    unit_price = Column(Numeric(14,2), default=0)
    account_code = Column(String(30), nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    total = Column(Numeric(14,2), default=0)

class SupplierPayment(Base):
    __tablename__ = "supplier_payments"
    id = Column(Integer, primary_key=True, index=True)
    payment_no = Column(String(80), unique=True, nullable=False)
    supplier_id = Column(Integer, ForeignKey("suppliers.id"), nullable=False)
    invoice_id = Column(Integer, ForeignKey("supplier_invoices.id"), nullable=True)
    payment_date = Column(Date, nullable=False)
    amount = Column(Numeric(14,2), default=0)
    payment_method = Column(String(40), nullable=False)
    cash_account_code = Column(String(30), default="10101")
    currency = Column(String(10), default="YER")
    description = Column(Text, nullable=True)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class InventoryItem(Base):
    __tablename__ = "inventory_items"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    category = Column(String(80), nullable=True)
    unit = Column(String(30), default="pcs")
    current_qty = Column(Numeric(14,3), default=0)
    avg_cost = Column(Numeric(14,2), default=0)
    reorder_level = Column(Numeric(14,3), default=0)

# Backward-compatible table used by previous app version.
class Item(Base):
    __tablename__ = "items"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    category = Column(String(80), nullable=True)
    unit = Column(String(30), default="pcs")
    current_qty = Column(Numeric(14,3), default=0)
    avg_cost = Column(Numeric(14,2), default=0)
    reorder_level = Column(Numeric(14,3), default=0)

class InventoryMovement(Base):
    __tablename__ = "inventory_movements"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    item_id = Column(Integer, nullable=False)
    movement_type = Column(String(30), nullable=False)
    qty = Column(Numeric(14,3), default=0)
    unit_cost = Column(Numeric(14,2), default=0)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    supplier_invoice_id = Column(Integer, ForeignKey("supplier_invoices.id"), nullable=True)
    goods_receipt_id = Column(Integer, ForeignKey("goods_receipts.id"), nullable=True)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    movement_source = Column(String(80), nullable=True)
    movement_reference = Column(String(120), nullable=True)
    source_type = Column(String(50), nullable=True)
    source_id = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)

class Warehouse(Base):
    __tablename__ = "warehouses"
    id = Column(Integer, primary_key=True, index=True)
    code = Column(String(40), unique=True, nullable=False)
    name = Column(String(150), nullable=False)
    type = Column(String(30), default="general")
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class StockMovement(Base):
    __tablename__ = "stock_movements"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    item_id = Column(Integer, ForeignKey("items.id"), nullable=False)
    movement_type = Column(String(30), nullable=False)
    qty = Column(Numeric(14,3), default=0)
    unit_cost = Column(Numeric(14,2), default=0)
    warehouse_id = Column(Integer, ForeignKey("warehouses.id"), nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    supplier_invoice_id = Column(Integer, ForeignKey("supplier_invoices.id"), nullable=True)
    goods_receipt_id = Column(Integer, ForeignKey("goods_receipts.id"), nullable=True)
    attachment_id = Column(Integer, ForeignKey("attachments.id"), nullable=True)
    movement_source = Column(String(80), nullable=True)
    movement_reference = Column(String(120), nullable=True)
    transaction_id = Column(Integer, ForeignKey("transactions.id"), nullable=True)
    notes = Column(Text, nullable=True)

class Transaction(Base):
    __tablename__ = "transactions"
    id = Column(Integer, primary_key=True, index=True)
    local_uuid = Column(String(120), unique=True, nullable=True)
    device_id = Column(String(120), nullable=True)
    sync_status = Column(String(30), nullable=True)
    created_offline = Column(Boolean, default=False)
    server_version = Column(Integer, default=1)
    date = Column(Date, nullable=False)
    type = Column(String(60), nullable=False)
    amount = Column(Numeric(14,2), default=0)
    currency = Column(String(10), default="YER")
    payment_method = Column(String(40), nullable=True)
    cash_account_id = Column(Integer, ForeignKey("cash_accounts.id"), nullable=True)
    from_cash_account_id = Column(Integer, ForeignKey("cash_accounts.id"), nullable=True)
    to_cash_account_id = Column(Integer, ForeignKey("cash_accounts.id"), nullable=True)
    related_account_type = Column(String(40), nullable=True)
    related_id = Column(Integer, nullable=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    settlement_type = Column(String(40), nullable=True)
    cost_category = Column(String(80), nullable=True)
    item_id = Column(Integer, nullable=True)
    qty = Column(Numeric(14,3), default=0)
    unit_cost = Column(Numeric(14,2), default=0)
    description = Column(Text, nullable=True)
    document_no = Column(String(80), unique=True, nullable=True)
    voucher_no = Column(String(80), unique=True, nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    reversal_of_id = Column(Integer, ForeignKey("transactions.id"), nullable=True)
    reversed_by_id = Column(Integer, ForeignKey("transactions.id"), nullable=True)
    void_reason = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime, nullable=True)

class AdjustmentVoucher(Base):
    __tablename__ = "adjustment_vouchers"
    id = Column(Integer, primary_key=True, index=True)
    voucher_no = Column(String(80), unique=True, nullable=False)
    date = Column(Date, nullable=False)
    reason = Column(String(60), nullable=False)
    description = Column(Text, nullable=False)
    attachment_url = Column(String(500), nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    rejected_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    rejected_at = Column(DateTime, nullable=True)
    reversed_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    reversed_at = Column(DateTime, nullable=True)
    reversal_of_id = Column(Integer, ForeignKey("adjustment_vouchers.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class AdjustmentVoucherLine(Base):
    __tablename__ = "adjustment_voucher_lines"
    id = Column(Integer, primary_key=True, index=True)
    voucher_id = Column(Integer, ForeignKey("adjustment_vouchers.id"), nullable=False)
    account_code = Column(String(30), nullable=False)
    account_name = Column(String(255), nullable=False)
    debit = Column(Numeric(14, 2), default=0)
    credit = Column(Numeric(14, 2), default=0)
    project_id = Column(Integer, nullable=True)
    cost_center_id = Column(Integer, nullable=True)
    party_type = Column(String(50), nullable=True)
    party_id = Column(Integer, nullable=True)
    description = Column(Text, nullable=True)

class Payroll(Base):
    __tablename__ = "payrolls"
    id = Column(Integer, primary_key=True, index=True)
    payroll_no = Column(String(80), unique=True, nullable=True)
    employee_id = Column(Integer, nullable=True)
    worker_id = Column(Integer, nullable=True)
    period = Column(String(30), nullable=False)
    work_days = Column(Numeric(8,2), default=0)
    gross_amount = Column(Numeric(14,2), default=0)
    advances = Column(Numeric(14,2), default=0)
    deductions = Column(Numeric(14,2), default=0)
    additions = Column(Numeric(14,2), default=0)
    net_amount = Column(Numeric(14,2), default=0)
    status = Column(String(30), default="open")

class Attendance(Base):
    __tablename__ = "attendance"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    employee_id = Column(Integer, nullable=True)
    worker_id = Column(Integer, nullable=True)
    status = Column(String(30), nullable=False)  # present/absent/half_day
    project_id = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)

class Advance(Base):
    __tablename__ = "advances"
    id = Column(Integer, primary_key=True, index=True)
    date = Column(Date, nullable=False)
    employee_id = Column(Integer, nullable=True)
    worker_id = Column(Integer, nullable=True)
    amount = Column(Numeric(14,2), default=0)
    status = Column(String(30), default="open")
    notes = Column(Text, nullable=True)

class EmployeeAdjustment(Base):
    __tablename__ = "employee_adjustments"
    id = Column(Integer, primary_key=True, index=True)
    employee_id = Column(Integer, ForeignKey("employees.id"), nullable=False, index=True)
    date = Column(Date, nullable=False)
    adjustment_type = Column(String(40), nullable=False)
    amount = Column(Numeric(14, 2), default=0)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    description = Column(Text, nullable=True)
    status = Column(String(30), default="draft")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class PayrollPeriod(Base):
    __tablename__ = "payroll_periods"
    id = Column(Integer, primary_key=True, index=True)
    year = Column(Integer, nullable=False, index=True)
    month = Column(Integer, nullable=False, index=True)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(String(30), default="open")
    created_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class ProjectCost(Base):
    __tablename__ = "project_costs"
    id = Column(Integer, primary_key=True, index=True)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=False)
    cost_center_id = Column(Integer, ForeignKey("cost_centers.id"), nullable=True)
    date = Column(Date, nullable=False)
    category = Column(String(80), nullable=False)
    amount = Column(Numeric(14,2), default=0)
    source_type = Column(String(50), nullable=True)
    source_id = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)

class JournalEntry(Base):
    __tablename__ = "journal_entries"
    id = Column(Integer, primary_key=True, index=True)
    entry_no = Column(String(80), unique=True, nullable=True)
    entry_date = Column(Date, nullable=False)
    description = Column(Text, nullable=True)
    source_type = Column(String(50), nullable=True)
    source_id = Column(Integer, nullable=True)
    status = Column(String(30), default="posted")
    total_debit = Column(Numeric(14,2), default=0)
    total_credit = Column(Numeric(14,2), default=0)
    created_by = Column(Integer, nullable=True)
    reversal_of_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=True)
    is_reversal = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class JournalEntryLine(Base):
    __tablename__ = "journal_entry_lines"
    id = Column(Integer, primary_key=True, index=True)
    journal_entry_id = Column(Integer, ForeignKey("journal_entries.id"), nullable=False)
    account_code = Column(String(30), nullable=False)
    account_name = Column(String(255), nullable=False)
    debit = Column(Numeric(14,2), default=0)
    credit = Column(Numeric(14,2), default=0)
    project_id = Column(Integer, nullable=True)
    cost_center_id = Column(Integer, nullable=True)
    party_type = Column(String(50), nullable=True)
    party_id = Column(Integer, nullable=True)
    description = Column(Text, nullable=True)

class FiscalYear(Base):
    __tablename__ = "fiscal_years"
    id = Column(Integer, primary_key=True, index=True)
    year = Column(Integer, unique=True, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(String(30), default="open")
    closed_by = Column(Integer, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class AccountingPeriod(Base):
    __tablename__ = "accounting_periods"
    id = Column(Integer, primary_key=True, index=True)
    year = Column(Integer, nullable=False)
    month = Column(Integer, nullable=False)
    start_date = Column(Date, nullable=False)
    end_date = Column(Date, nullable=False)
    status = Column(String(30), default="open")
    closed_by = Column(Integer, nullable=True)
    closed_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Invoice(Base):
    __tablename__ = "invoices"
    id = Column(Integer, primary_key=True, index=True)
    invoice_no = Column(String(80), unique=True, nullable=True)
    invoice_type = Column(String(30), nullable=False)
    party_type = Column(String(30), nullable=True)
    party_id = Column(Integer, nullable=False)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    date = Column(Date, nullable=False)
    total = Column(Numeric(14,2), default=0)
    paid_amount = Column(Numeric(14,2), default=0)
    due_date = Column(Date, nullable=True)
    status = Column(String(30), default="open")
    posted_by = Column(Integer, nullable=True)
    posted_at = Column(DateTime, nullable=True)
    notes = Column(Text, nullable=True)

class InvoiceLine(Base):
    __tablename__ = "invoice_lines"
    id = Column(Integer, primary_key=True, index=True)
    invoice_id = Column(Integer, ForeignKey("invoices.id"), nullable=False)
    item_description = Column(String(255), nullable=False)
    qty = Column(Numeric(14,3), default=1)
    unit_price = Column(Numeric(14,2), default=0)
    total = Column(Numeric(14,2), default=0)
    project_id = Column(Integer, ForeignKey("projects.id"), nullable=True)
    notes = Column(Text, nullable=True)

class Attachment(Base):
    __tablename__ = "attachments"
    id = Column(Integer, primary_key=True, index=True)
    entity = Column(String(50), nullable=False)
    entity_id = Column(Integer, nullable=False)
    file_name = Column(String(255), nullable=False)
    file_url = Column(String(500), nullable=False)
    file_path = Column(String(500), nullable=True)
    file_type = Column(String(80), nullable=True)
    entity_type = Column(String(80), nullable=True)
    uploaded_by = Column(Integer, ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class Approval(Base):
    __tablename__ = "approvals"
    id = Column(Integer, primary_key=True, index=True)
    entity = Column(String(80), nullable=False)
    entity_id = Column(Integer, nullable=False)
    status = Column(String(30), default="pending")
    requested_by = Column(Integer, nullable=True)
    approved_by = Column(Integer, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

class AuditLog(Base):
    __tablename__ = "audit_logs"
    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, nullable=True)
    action = Column(String(100), nullable=False)
    entity = Column(String(80), nullable=False)
    entity_id = Column(Integer, nullable=True)
    details = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Device(Base):
    __tablename__ = "devices"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(120), unique=True, nullable=False)
    device_name = Column(String(180), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    last_sync_at = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class SyncLog(Base):
    __tablename__ = "sync_logs"
    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(String(120), nullable=False)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    entity_type = Column(String(80), nullable=False)
    local_uuid = Column(String(120), nullable=False)
    server_id = Column(Integer, nullable=True)
    operation = Column(String(30), nullable=False)
    status = Column(String(30), nullable=False)
    error_message = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())


class Setting(Base):
    __tablename__ = "settings"
    id = Column(Integer, primary_key=True, index=True)
    key = Column(String(120), unique=True, nullable=False)
    value = Column(Text, nullable=True)
