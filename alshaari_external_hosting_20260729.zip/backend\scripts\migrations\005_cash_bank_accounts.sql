ALTER TABLE transactions ADD COLUMN IF NOT EXISTS cash_account_id INTEGER;
