from fastapi import APIRouter, Depends, Query
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.core.deps import ROLE_ACCOUNTANT, ROLE_MANAGER, require_roles
from app.db.database import get_db


router = APIRouter(prefix="/api/v1/audit", tags=["Audit"])


@router.get("/logs")
def audit_logs(
    entity: str | None = None,
    action: str | None = None,
    user_id: int | None = None,
    limit: int = Query(200, ge=1, le=1000),
    db: Session = Depends(get_db),
    user=Depends(require_roles(ROLE_MANAGER, ROLE_ACCOUNTANT)),
):
    conditions = []
    params: dict[str, object] = {"limit": limit}

    if entity:
        conditions.append("al.entity = :entity")
        params["entity"] = entity
    if action:
        conditions.append("al.action = :action")
        params["action"] = action
    if user_id is not None:
        conditions.append("al.user_id = :user_id")
        params["user_id"] = user_id

    where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

    rows = db.execute(
        text(
            f"""
            SELECT
                al.id,
                al.user_id,
                u.name AS user_name,
                u.phone AS user_phone,
                al.action,
                al.entity,
                al.entity_id,
                al.details,
                al.created_at
            FROM audit_logs al
            LEFT JOIN users u ON u.id = al.user_id
            {where_clause}
            ORDER BY al.id DESC
            LIMIT :limit
            """
        ),
        params,
    ).mappings().all()

    summary = db.execute(
        text(
            f"""
            SELECT
                al.entity,
                al.action,
                COUNT(*) AS count
            FROM audit_logs al
            LEFT JOIN users u ON u.id = al.user_id
            {where_clause}
            GROUP BY al.entity, al.action
            ORDER BY count DESC, al.entity, al.action
            """
        ),
        params,
    ).mappings().all()

    return {
        "items": [dict(row) for row in rows],
        "summary": [dict(row) for row in summary],
        "filters": {
            "entity": entity,
            "action": action,
            "user_id": user_id,
            "limit": limit,
        },
    }
