from decimal import Decimal
from sqlalchemy import text
from sqlalchemy.orm import Session
from fastapi import HTTPException

from app.services.document_sequence import next_document_no
from app.services.accounting_periods import assert_period_open
from app.services.operation_policy import should_apply_cash


def _decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _sql_decimal(value) -> str:
    return str(_decimal(value))


def _get_account(db: Session, account_code: str):
    row = db.execute(
        text("SELECT code, name FROM accounts WHERE code = :code"),
        {"code": account_code},
    ).mappings().first()

    if not row:
        raise HTTPException(
            status_code=400,
            detail=f"الحساب غير موجود في دليل الحسابات: {account_code}",
        )

    return row


def _optional_cost_account_code(db: Session, value: str | None):
    if not value:
        return None
    row = db.execute(
        text(
            """
            SELECT code, type
            FROM accounts
            WHERE code = :code
              AND is_active = TRUE
            """
        ),
        {"code": str(value).strip()},
    ).mappings().first()
    if not row:
        return None
    if row["type"] not in {"expense", "cost"}:
        raise HTTPException(
            status_code=400,
            detail="بند التكلفة المختار يجب أن يكون حساب مصروف أو تكلفة",
        )
    return row["code"]


def _get_cash_account_code(db: Session, cash_account_id: int | None):
    if not cash_account_id:
        return None
    row = db.execute(
        text(
            """
            SELECT COALESCE(account_code, code) AS account_code
            FROM cash_accounts
            WHERE id = :id
              AND is_active = TRUE
            """
        ),
        {"id": cash_account_id},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=400, detail="حساب النقدية/البنك غير موجود أو غير نشط")
    return row["account_code"]


def _get_transfer_cash_account_code(db: Session, cash_account_id: int | None, label: str):
    code = _get_cash_account_code(db, cash_account_id)
    if not code:
        raise HTTPException(status_code=400, detail=f"{label} مطلوب لإنشاء قيد التحويل")
    return code


def _default_cash_account_code(currency: str | None) -> str:
    if currency == "SAR":
        return "10102"
    if currency == "USD":
        return "10103"
    return "10101"


def _required_cash_account_code(db: Session, tx):
    code = _get_cash_account_code(db, getattr(tx, "cash_account_id", None))
    if not code:
        raise HTTPException(
            status_code=400,
            detail="العملية النقدية تتطلب اختيار الصندوق أو المحفظة أو الحساب البنكي",
        )
    return code


def _get_posting_rule(db: Session, operation_type: str):
    row = db.execute(
        text("""
            SELECT operation_type, debit_account_code, credit_account_code
            FROM posting_rules
            WHERE operation_type = :operation_type
              AND is_active = TRUE
        """),
        {"operation_type": operation_type},
    ).mappings().first()

    if not row:
        raise HTTPException(
            status_code=400,
            detail=f"لا توجد قاعدة ترحيل محاسبي لنوع العملية: {operation_type}",
        )

    return row


def _resolve_transaction_posting_accounts(db: Session, tx):
    rule = _get_posting_rule(db, tx.type)

    debit_account_code = rule["debit_account_code"]
    credit_account_code = rule["credit_account_code"]

    if tx.type == "cash_transfer":
        debit_account_code = _get_transfer_cash_account_code(
            db,
            getattr(tx, "to_cash_account_id", None),
            "حساب النقدية المحول إليه",
        )
        credit_account_code = _get_transfer_cash_account_code(
            db,
            getattr(tx, "from_cash_account_id", None),
            "حساب النقدية المحول منه",
        )
        if debit_account_code == credit_account_code:
            raise HTTPException(status_code=400, detail="لا يمكن إنشاء قيد تحويل بين نفس حساب النقدية")
        return debit_account_code, credit_account_code

    cash_effect = should_apply_cash(tx)
    cash_account_code = None
    if cash_effect in {"increase", "decrease"}:
        cash_account_code = _required_cash_account_code(db, tx)
    default_cash_code = cash_account_code or _default_cash_account_code(getattr(tx, "currency", None))

    if tx.type == "advance_payment":
        debit_account_code = "20203"
        credit_account_code = default_cash_code

    elif tx.type == "advance_settlement":
        settlement_type = getattr(tx, "settlement_type", None)
        credit_account_code = "20203"
        if settlement_type == "wage_project":
            debit_account_code = "50201"
        elif settlement_type == "wage_general":
            debit_account_code = "60301"
        elif settlement_type == "expense_project":
            debit_account_code = "50303"
        elif settlement_type == "cash_return":
            debit_account_code = default_cash_code
        elif settlement_type == "salary_deduction":
            debit_account_code = "20201"
        else:
            raise HTTPException(status_code=400, detail="نوع تسوية السلفة غير معتمد")

    elif tx.type == "worker_wage":
        debit_account_code = "50201" if getattr(tx, "project_id", None) else "60301"
        credit_account_code = default_cash_code

    elif tx.type in {"general_payment", "project_expense"}:
        selected_cost_account = _optional_cost_account_code(db, getattr(tx, "cost_category", None))
        if selected_cost_account:
            debit_account_code = selected_cost_account

    if cash_account_code and cash_effect == "increase":
        debit_account_code = cash_account_code
    elif cash_account_code and cash_effect == "decrease":
        credit_account_code = cash_account_code

    return debit_account_code, credit_account_code


def _entry_exists(db: Session, source_type: str, source_id: int) -> bool:
    _assert_source(source_type, source_id)
    row = db.execute(
        text("""
            SELECT id
            FROM journal_entries
            WHERE source_type = :source_type
              AND source_id = :source_id
            LIMIT 1
        """),
        {"source_type": source_type, "source_id": source_id},
    ).first()

    return row is not None


def _assert_source(source_type: str | None, source_id: int | None) -> None:
    if not source_type or not str(source_type).strip():
        raise HTTPException(status_code=400, detail="فشل في تحديد نوع المستند المصدر لإنشاء القيد")
    if source_id is None:
        raise HTTPException(status_code=400, detail="فشل في تحديد رقم المرجع للمستند لإنشاء القيد")


def _audit_journal_entry(db: Session, user_id: int, journal_entry_id: int, details: str) -> None:
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'create_journal_entry', 'journal_entry', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {
            "user_id": user_id,
            "entity_id": journal_entry_id,
            "details": details,
        },
    )


def _assert_journal_entry_balanced(db: Session, journal_entry_id: int):
    row = db.execute(
        text("""
            SELECT
                je.total_debit AS header_debit,
                je.total_credit AS header_credit,
                COALESCE(SUM(jel.debit), 0) AS lines_debit,
                COALESCE(SUM(jel.credit), 0) AS lines_credit,
                COUNT(jel.id) AS line_count
            FROM journal_entries je
            LEFT JOIN journal_entry_lines jel ON jel.journal_entry_id = je.id
            WHERE je.id = :journal_entry_id
            GROUP BY je.id, je.total_debit, je.total_credit
        """),
        {"journal_entry_id": journal_entry_id},
    ).mappings().first()

    if not row:
        raise HTTPException(status_code=400, detail="خطأ فني: تعذر الوصول لبيانات القيد للتحقق من توازنه")

    if int(row["line_count"] or 0) < 2:
        raise HTTPException(status_code=400, detail="القيد المحاسبي يجب أن يحتوي على سطرين على الأقل")

    header_debit = _decimal(row["header_debit"])
    header_credit = _decimal(row["header_credit"])
    lines_debit = _decimal(row["lines_debit"])
    lines_credit = _decimal(row["lines_credit"])

    if header_debit != header_credit:
        raise HTTPException(status_code=400, detail="القيد غير متوازن: إجمالي رأس القيد غير متساو")

    if lines_debit != lines_credit:
        raise HTTPException(status_code=400, detail="القيد غير متوازن: مجموع سطور المدين لا يساوي مجموع سطور الدائن")

    if header_debit != lines_debit or header_credit != lines_credit:
        raise HTTPException(status_code=400, detail="إجمالي القيد لا يطابق مجموع سطوره")


def _next_entry_no(db: Session, entry_date=None) -> str:
    return next_document_no(db, "journal_entry", document_date=entry_date)


def _journal_entry_for_source(db: Session, source_type: str, source_id: int):
    _assert_source(source_type, source_id)
    return db.execute(
        text("""
            SELECT id, entry_no, entry_date, source_type, source_id, description,
                   status, total_debit, total_credit, created_by
            FROM journal_entries
            WHERE source_type = :source_type
              AND source_id = :source_id
            LIMIT 1
        """),
        {"source_type": source_type, "source_id": source_id},
    ).mappings().first()


def validate_transaction_posting_ready(db: Session, tx, user_id: int) -> None:
    if getattr(tx, "id", None) is None:
        raise HTTPException(status_code=400, detail="لا يمكن ترحيل مستند غير محفوظ")
    if _entry_exists(db, "transaction", tx.id):
        raise HTTPException(status_code=400, detail="يوجد قيد محاسبي سابق لهذا المستند، لا يمكن اعتماده مرة أخرى")

    assert_period_open(db, tx.date, user_id=user_id)

    amount = _decimal(tx.amount)
    if amount <= 0:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد مستند بمبلغ صفر أو أقل")

    debit_account_code, credit_account_code = _resolve_transaction_posting_accounts(db, tx)

    if debit_account_code == credit_account_code:
        raise HTTPException(status_code=400, detail="لا يمكن إنشاء قيد بنفس الحساب في المدين والدائن")

    _get_account(db, debit_account_code)
    _get_account(db, credit_account_code)


def create_journal_entry_for_transaction(db: Session, tx, user_id: int):
    if getattr(tx, "id", None) is None:
        raise HTTPException(status_code=400, detail="لا يمكن إنشاء قيد لمستند غير محفوظ")
    if _entry_exists(db, "transaction", tx.id):
        raise HTTPException(status_code=400, detail="يوجد قيد محاسبي سابق لهذا المستند، لا يمكن إنشاء قيد مكرر")
    assert_period_open(db, tx.date, user_id=user_id)

    amount = _decimal(tx.amount)

    if amount <= 0:
        raise HTTPException(
            status_code=400,
            detail="لا يمكن إنشاء قيد محاسبي لمبلغ صفر أو أقل",
        )

    debit_account_code, credit_account_code = _resolve_transaction_posting_accounts(db, tx)

    debit_account = _get_account(db, debit_account_code)
    credit_account = _get_account(db, credit_account_code)

    total_debit = amount
    total_credit = amount

    if total_debit != total_credit:
        raise HTTPException(
            status_code=400,
            detail="القيد غير متوازن: مجموع المدين لا يساوي مجموع الدائن",
        )

    entry_no = _next_entry_no(db, tx.date)

    entry_result = db.execute(
        text("""
            INSERT INTO journal_entries (
                entry_no,
                entry_date,
                source_type,
                source_id,
                description,
                status,
                total_debit,
                total_credit,
                created_by
            )
            VALUES (
                :entry_no,
                :entry_date,
                'transaction',
                :source_id,
                :description,
                'posted',
                :total_debit,
                :total_credit,
                :created_by
            )
            RETURNING id
        """),
        {
            "entry_no": entry_no,
            "entry_date": tx.date,
            "source_id": tx.id,
            "description": tx.description or f"قيد آلي للمستند رقم {tx.id}",
            "total_debit": _sql_decimal(total_debit),
            "total_credit": _sql_decimal(total_credit),
            "created_by": user_id,
        },
    ).mappings().first()

    journal_entry_id = entry_result["id"]

    party_type = getattr(tx, "related_account_type", None)
    party_id = getattr(tx, "related_id", None)
    project_id = getattr(tx, "project_id", None)
    cost_center_id = getattr(tx, "cost_center_id", None)
    debit_cost_center_id = cost_center_id
    credit_cost_center_id = None

    db.execute(
        text("""
            INSERT INTO journal_entry_lines (
                journal_entry_id,
                account_code,
                account_name,
                debit,
                credit,
                project_id,
                cost_center_id,
                party_type,
                party_id,
                description
            )
            VALUES (
                :journal_entry_id,
                :account_code,
                :account_name,
                :debit,
                0,
                :project_id,
                :cost_center_id,
                :party_type,
                :party_id,
                :description
            )
        """),
        {
            "journal_entry_id": journal_entry_id,
            "account_code": debit_account["code"],
            "account_name": debit_account["name"],
            "debit": _sql_decimal(total_debit),
            "project_id": project_id,
            "cost_center_id": debit_cost_center_id,
            "party_type": party_type,
            "party_id": party_id,
            "description": tx.description,
        },
    )

    db.execute(
        text("""
            INSERT INTO journal_entry_lines (
                journal_entry_id,
                account_code,
                account_name,
                debit,
                credit,
                project_id,
                cost_center_id,
                party_type,
                party_id,
                description
            )
            VALUES (
                :journal_entry_id,
                :account_code,
                :account_name,
                0,
                :credit,
                :project_id,
                :cost_center_id,
                :party_type,
                :party_id,
                :description
            )
        """),
        {
            "journal_entry_id": journal_entry_id,
            "account_code": credit_account["code"],
            "account_name": credit_account["name"],
            "credit": _sql_decimal(total_credit),
            "project_id": project_id,
            "cost_center_id": credit_cost_center_id,
            "party_type": party_type,
            "party_id": party_id,
            "description": tx.description,
        },
    )

    _assert_journal_entry_balanced(db, journal_entry_id)
    _audit_journal_entry(
        db,
        user_id,
        journal_entry_id,
        f"قيد آلي للمستند transaction:{tx.id}",
    )

    return journal_entry_id


def create_reversal_journal_entry_for_transaction(db: Session, tx, reversal_tx, user_id: int):
    if getattr(tx, "id", None) is None:
        raise HTTPException(status_code=400, detail="لا يمكن عكس قيد لمستند غير محفوظ")
    original = _journal_entry_for_source(db, "transaction", tx.id)
    assert_period_open(db, reversal_tx.date, user_id=user_id)

    if not original:
        raise HTTPException(status_code=400, detail="لا يوجد قيد أصلي لعكس هذا المستند")

    if _entry_exists(db, "transaction_reversal", tx.id):
        raise HTTPException(status_code=400, detail="تم عكس قيد هذا المستند مسبقًا")

    lines = db.execute(
        text("""
            SELECT account_code, account_name, debit, credit, project_id, cost_center_id,
                   party_type, party_id, description
            FROM journal_entry_lines
            WHERE journal_entry_id = :journal_entry_id
            ORDER BY id
        """),
        {"journal_entry_id": original["id"]},
    ).mappings().all()

    if not lines:
        raise HTTPException(status_code=400, detail="القيد الأصلي لا يحتوي على بنود")

    total_debit = sum(_decimal(line["credit"]) for line in lines)
    total_credit = sum(_decimal(line["debit"]) for line in lines)

    if total_debit != total_credit:
        raise HTTPException(status_code=400, detail="القيد العكسي غير متوازن")

    entry_result = db.execute(
        text("""
            INSERT INTO journal_entries (
                entry_no,
                entry_date,
                source_type,
                source_id,
                description,
                status,
                total_debit,
                total_credit,
                created_by,
                reversal_of_id,
                is_reversal
            )
            VALUES (
                :entry_no,
                :entry_date,
                'transaction_reversal',
                :source_id,
                :description,
                'posted',
                :total_debit,
                :total_credit,
                :created_by,
                :reversal_of_id,
                TRUE
            )
            RETURNING id
        """),
        {
            "entry_no": _next_entry_no(db, reversal_tx.date),
            "entry_date": reversal_tx.date,
            "source_id": tx.id,
            "description": reversal_tx.description or f"قيد عكسي للمستند رقم {tx.id}",
            "total_debit": _sql_decimal(total_debit),
            "total_credit": _sql_decimal(total_credit),
            "created_by": user_id,
            "reversal_of_id": original["id"],
        },
    ).mappings().first()

    reversal_entry_id = entry_result["id"]

    for line in lines:
        db.execute(
            text("""
                INSERT INTO journal_entry_lines (
                    journal_entry_id,
                    account_code,
                    account_name,
                    debit,
                    credit,
                    project_id,
                    cost_center_id,
                    party_type,
                    party_id,
                    description
                )
                VALUES (
                    :journal_entry_id,
                    :account_code,
                    :account_name,
                    :debit,
                    :credit,
                    :project_id,
                    :cost_center_id,
                    :party_type,
                    :party_id,
                    :description
                )
            """),
            {
                "journal_entry_id": reversal_entry_id,
                "account_code": line["account_code"],
                "account_name": line["account_name"],
                "debit": _sql_decimal(line["credit"]),
                "credit": _sql_decimal(line["debit"]),
                "project_id": line["project_id"],
                "cost_center_id": line["cost_center_id"],
                "party_type": line["party_type"],
                "party_id": line["party_id"],
                "description": reversal_tx.description,
            },
        )

    _assert_journal_entry_balanced(db, reversal_entry_id)
    _audit_journal_entry(
        db,
        user_id,
        reversal_entry_id,
        f"قيد عكسي للمستند transaction:{tx.id}",
    )

    return reversal_entry_id
