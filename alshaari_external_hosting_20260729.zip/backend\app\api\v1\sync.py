from datetime import datetime

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.database import get_db
from app.schemas.schemas import SyncPushRequest
from app.services.sync_service import pull_updates, push_operations, sync_status


router = APIRouter(prefix="/api/v1/sync", tags=["Offline Sync"])


@router.post("/push")
def push(data: SyncPushRequest, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return push_operations(
        db,
        device_id=data.device_id,
        operations=data.operations,
        user_id=user.id,
    )


@router.get("/pull")
def pull(
    since: datetime | None = Query(default=None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return pull_updates(db, since=since, user_id=user.id)


@router.get("/status")
def status(
    device_id: str | None = Query(default=None),
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    return sync_status(db, device_id=device_id, user_id=user.id)
