from datetime import date, datetime

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session

from app.core.deps import normalize_role
from app.models.models import User


CLOSED_PERIOD_OVERRIDE_ROLES = {"manager", "accountant_admin"}


def ensure_accounting_period_schema(db: Session) -> None:
    db.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS fiscal_years (
                id SERIAL PRIMARY KEY,
                year INTEGER UNIQUE NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                status VARCHAR(30) DEFAULT 'open',
                closed_by INTEGER NULL,
                closed_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
    )
    db.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS accounting_periods (
                id SERIAL PRIMARY KEY,
                year INTEGER NOT NULL,
                month INTEGER NOT NULL,
                start_date DATE NOT NULL,
                end_date DATE NOT NULL,
                status VARCHAR(30) DEFAULT 'open',
                closed_by INTEGER NULL,
                closed_at TIMESTAMP NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                UNIQUE (year, month)
            )
            """
        )
    )
    db.commit()


def _role_for(db: Session, user_id: int | None = None, user=None) -> str:
    if user is not None:
        return normalize_role(getattr(user, "role", None))
    if user_id is None:
        return "data_entry"
    row = db.query(User).filter(User.id == user_id).first()
    return normalize_role(getattr(row, "role", None))


def can_post_to_closed_period(db: Session, user_id: int | None = None, user=None) -> bool:
    return _role_for(db, user_id=user_id, user=user) in CLOSED_PERIOD_OVERRIDE_ROLES


def assert_period_open(db: Session, document_date: date, user_id: int | None = None, user=None) -> None:
    try:
        row = (
            db.execute(
                text(
                    """
                    SELECT id, year, month, status
                    FROM accounting_periods
                    WHERE :document_date BETWEEN start_date AND end_date
                    ORDER BY id DESC
                    LIMIT 1
                    """
                ),
                {"document_date": document_date},
            )
            .mappings()
            .first()
        )
    except SQLAlchemyError:
        return
    if not row or row["status"] != "closed":
        return
    if can_post_to_closed_period(db, user_id=user_id, user=user):
        return
    raise HTTPException(
        status_code=400,
        detail=f"الفترة المالية {row['year']}-{int(row['month']):02d} مغلقة، ولا يمكن اعتماد أو ترحيل مستند داخلها إلا بصلاحية خاصة",
    )


def close_period(db: Session, period_id: int, user_id: int) -> None:
    db.execute(
        text(
            """
            UPDATE accounting_periods
            SET status = 'closed', closed_by = :user_id, closed_at = :closed_at
            WHERE id = :period_id
            """
        ),
        {"period_id": period_id, "user_id": user_id, "closed_at": datetime.utcnow()},
    )
