from __future__ import annotations

from datetime import date
from decimal import Decimal
from typing import Any

from sqlalchemy import text
from sqlalchemy.orm import Session

from app.models.models import Customer, Project, ProjectCost, Transaction

VALID_COST_TYPES = {
    "material",
    "labor",
    "service",
    "direct_expense",
    "adjustment",
}

VALID_ESTIMATE_TYPES = {
    "material",
    "labor",
    "service",
    "direct_expense",
    "other",
}


def money(value: Any) -> float:
    return float(value or 0)


def normalized_cost_type(raw: str | None) -> str:
    value = (raw or "").strip().lower()
    aliases = {
        "materials": "material",
        "material_cost": "material",
        "stock_movement": "material",
        "inventory_issue": "material",
        "direct_project_purchase": "material",
        "worker_wage": "labor",
        "wage": "labor",
        "wages": "labor",
        "payroll": "labor",
        "overhead": "direct_expense",
        "expense": "direct_expense",
        "project_expense": "direct_expense",
        "direct_expenses": "direct_expense",
        "supplier_invoice": "service",
        "project_cost_settlement": "adjustment",
        "adjustments": "adjustment",
    }
    return aliases.get(value, value if value in VALID_COST_TYPES else "direct_expense")


def ensure_project_costing_schema(db: Session) -> None:
    db.execute(
        text(
            """
            CREATE TABLE IF NOT EXISTS project_estimates (
                id INTEGER PRIMARY KEY,
                project_id INTEGER NOT NULL,
                estimate_type VARCHAR(40) NOT NULL,
                description TEXT NOT NULL,
                estimated_amount NUMERIC(14, 2) NOT NULL DEFAULT 0,
                notes TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP
            )
            """
        )
    )
    for ddl in [
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS transaction_date DATE",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS supplier_id INTEGER",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS employee_id INTEGER",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS item_id INTEGER",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS created_by INTEGER",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS created_at TIMESTAMP",
        "ALTER TABLE project_costs ADD COLUMN IF NOT EXISTS reversed_at TIMESTAMP",
    ]:
        try:
            db.execute(text(ddl))
        except Exception:
            # SQLite in older local installs does not support ADD COLUMN IF NOT EXISTS.
            db.rollback()
    db.commit()


def record_project_cost(
    db: Session,
    *,
    project_id: int,
    cost_type: str,
    source_type: str,
    source_id: int,
    description: str,
    amount: float | Decimal,
    transaction_date: date | None = None,
    cost_center_id: int | None = None,
    supplier_id: int | None = None,
    employee_id: int | None = None,
    item_id: int | None = None,
    created_by: int | None = None,
) -> ProjectCost:
    amount_value = Decimal(str(amount or 0))
    if amount_value <= 0:
        raise ValueError("لا يمكن تسجيل تكلفة مشروع بمبلغ صفر أو سالب.")

    existing = (
        db.query(ProjectCost)
        .filter(
            ProjectCost.source_type == source_type,
            ProjectCost.source_id == source_id,
            ProjectCost.project_id == project_id,
        )
        .first()
    )
    if existing:
        return existing

    cost = ProjectCost(
        project_id=project_id,
        cost_center_id=cost_center_id,
        date=transaction_date or date.today(),
        category=normalized_cost_type(cost_type),
        amount=amount_value,
        source_type=source_type,
        source_id=source_id,
        notes=description,
    )
    if hasattr(cost, "transaction_date"):
        cost.transaction_date = transaction_date or date.today()
    if hasattr(cost, "supplier_id"):
        cost.supplier_id = supplier_id
    if hasattr(cost, "employee_id"):
        cost.employee_id = employee_id
    if hasattr(cost, "item_id"):
        cost.item_id = item_id
    if hasattr(cost, "created_by"):
        cost.created_by = created_by

    db.add(cost)
    return cost


def project_estimates_totals(db: Session, project_id: int) -> dict[str, float]:
    rows = db.execute(
        text(
            """
            SELECT estimate_type, COALESCE(SUM(estimated_amount), 0) AS total
            FROM project_estimates
            WHERE project_id = :project_id
            GROUP BY estimate_type
            """
        ),
        {"project_id": project_id},
    ).mappings()
    totals = {key: 0.0 for key in VALID_ESTIMATE_TYPES}
    for row in rows:
        key = row["estimate_type"] if row["estimate_type"] in totals else "other"
        totals[key] += money(row["total"])
    return totals


def project_cost_totals(db: Session, project_id: int) -> dict[str, float]:
    rows = (
        db.query(ProjectCost.category, ProjectCost.amount)
        .filter(ProjectCost.project_id == project_id)
        .all()
    )
    totals = {key: 0.0 for key in VALID_COST_TYPES}
    for category, amount in rows:
        totals[normalized_cost_type(category)] += money(amount)
    return totals


def project_cost_lines(db: Session, project_id: int, limit: int = 500) -> list[dict[str, Any]]:
    rows = (
        db.query(ProjectCost)
        .filter(ProjectCost.project_id == project_id)
        .order_by(ProjectCost.date.desc(), ProjectCost.id.desc())
        .limit(limit)
        .all()
    )
    return [
        {
            "id": row.id,
            "date": row.date.isoformat() if row.date else None,
            "cost_type": normalized_cost_type(row.category),
            "description": row.notes,
            "amount": money(row.amount),
            "source_type": row.source_type,
            "source_id": row.source_id,
            "cost_center_id": row.cost_center_id,
        }
        for row in rows
    ]


def project_profitability(db: Session, project_id: int) -> dict[str, Any]:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise ValueError("المشروع غير موجود")

    customer = (
        db.query(Customer).filter(Customer.id == project.customer_id).first()
        if project.customer_id
        else None
    )
    collected = (
        db.query(Transaction.amount)
        .filter(
            Transaction.status == "approved",
            Transaction.project_id == project_id,
            Transaction.type.in_(["receipt_from_customer", "customer_advance"]),
        )
        .all()
    )
    total_collected = sum(money(row[0]) for row in collected)
    contract_value = money(project.contract_value)
    estimated = project_estimates_totals(db, project_id)
    actual = project_cost_totals(db, project_id)

    estimated_total = sum(estimated.values())
    actual_total = sum(actual.values())
    expected_profit = contract_value - estimated_total
    actual_profit = contract_value - actual_total
    remaining = contract_value - total_collected
    variance = actual_total - estimated_total

    comparison = []
    labels = {
        "material": "مواد",
        "labor": "أجور",
        "service": "خدمات",
        "direct_expense": "مصروف مباشر",
        "adjustment": "تسويات",
        "other": "أخرى",
    }
    for key in ["material", "labor", "service", "direct_expense", "adjustment"]:
        estimated_value = estimated.get(key, 0.0)
        actual_value = actual.get(key, 0.0)
        comparison.append(
            {
                "cost_type": key,
                "label": labels[key],
                "estimated": estimated_value,
                "actual": actual_value,
                "variance": actual_value - estimated_value,
            }
        )

    return {
        "project_id": project.id,
        "project_code": project.project_code,
        "project_name": project.name,
        "customer_id": project.customer_id,
        "customer_name": customer.name if customer else None,
        "status": project.status,
        "progress_percent": project.progress_percent or 0,
        "contract_value": contract_value,
        "total_collected": total_collected,
        "remaining_customer_balance": remaining,
        "estimated_total_cost": estimated_total,
        "actual_material_cost": actual.get("material", 0.0),
        "actual_labor_cost": actual.get("labor", 0.0),
        "actual_service_cost": actual.get("service", 0.0),
        "actual_direct_expense": actual.get("direct_expense", 0.0),
        "actual_adjustments": actual.get("adjustment", 0.0),
        "actual_total_cost": actual_total,
        "expected_profit": expected_profit,
        "actual_profit": actual_profit,
        "actual_profit_percent": (actual_profit / contract_value * 100) if contract_value else 0,
        "cost_variance": variance,
        "is_over_budget": estimated_total > 0 and actual_total > estimated_total,
        "over_budget_message": "تكلفة المشروع الفعلية تجاوزت التكلفة المقدرة"
        if estimated_total > 0 and actual_total > estimated_total
        else None,
        "estimated_by_type": estimated,
        "actual_by_type": actual,
        "comparison": comparison,
        # Backward-compatible keys used by current Flutter screens.
        "materials": actual.get("material", 0.0),
        "labor": actual.get("labor", 0.0),
        "overhead": actual.get("direct_expense", 0.0) + actual.get("service", 0.0),
        "direct_transactions_total": actual_total,
        "manual_project_costs": actual_total,
        "total": actual_total,
        "by_category": [
            {"category": item["label"], "amount": item["actual"]}
            for item in comparison
            if item["actual"]
        ],
    }
