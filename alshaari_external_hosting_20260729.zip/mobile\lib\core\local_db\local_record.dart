class LocalRecord {
  final String localUuid;
  final String entityType;
  final String temporaryNo;
  final String payloadJson;
  final String syncStatus;
  final int? serverId;
  final String? officialDocumentNo;
  final int createdAt;
  final int updatedAt;

  const LocalRecord({
    required this.localUuid,
    required this.entityType,
    required this.temporaryNo,
    required this.payloadJson,
    required this.syncStatus,
    required this.createdAt,
    required this.updatedAt,
    this.serverId,
    this.officialDocumentNo,
  });

  factory LocalRecord.fromJson(Map<String, dynamic> json) {
    return LocalRecord(
      localUuid: '${json['local_uuid']}',
      entityType: '${json['entity_type']}',
      temporaryNo: '${json['temporary_no']}',
      payloadJson: '${json['payload_json']}',
      syncStatus: '${json['sync_status']}',
      serverId: json['server_id'] is int ? json['server_id'] as int : null,
      officialDocumentNo: json['official_document_no']?.toString(),
      createdAt: json['created_at'] as int? ?? 0,
      updatedAt: json['updated_at'] as int? ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'local_uuid': localUuid,
      'entity_type': entityType,
      'temporary_no': temporaryNo,
      'payload_json': payloadJson,
      'sync_status': syncStatus,
      'server_id': serverId,
      'official_document_no': officialDocumentNo,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }

  LocalRecord copyWith({
    String? payloadJson,
    String? syncStatus,
    int? serverId,
    String? officialDocumentNo,
    int? updatedAt,
  }) {
    return LocalRecord(
      localUuid: localUuid,
      entityType: entityType,
      temporaryNo: temporaryNo,
      payloadJson: payloadJson ?? this.payloadJson,
      syncStatus: syncStatus ?? this.syncStatus,
      serverId: serverId ?? this.serverId,
      officialDocumentNo: officialDocumentNo ?? this.officialDocumentNo,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
