from datetime import date, datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, normalize_role, require_approval_role, require_permission
from app.db.database import get_db
from app.models.models import (
    Account,
    AuditLog,
    CashAccount,
    CostCenter,
    GoodsReceipt,
    GoodsReceiptLine,
    Item,
    JournalEntry,
    JournalEntryLine,
    ProjectCost,
    PurchaseOrder,
    PurchaseOrderLine,
    PurchaseRequest,
    PurchaseRequestLine,
    StockMovement,
    Supplier,
    SupplierInvoice,
    SupplierInvoiceLine,
    SupplierPayment,
    Warehouse,
)
from app.schemas.schemas import (
    GoodsReceiptCreate,
    PurchaseOrderCreate,
    PurchaseRejectRequest,
    PurchaseRequestCreate,
    SupplierInvoiceCreate,
    SupplierPaymentCreate,
)
from app.services.posting_engine import _assert_journal_entry_balanced
from app.services.accounting_periods import assert_period_open
from app.services.document_sequence import next_document_no
from app.services.purchase_schema import ensure_purchase_schema

router = APIRouter(prefix="/api/v1", tags=["Purchases"])

INVENTORY_ACCOUNT = "10401"
SUPPLIER_PAYABLE_ACCOUNT = "20101"
GRNI_ACCOUNT = "20102"
SUPPLIER_ADVANCE_ACCOUNT = "10601"
PROJECT_COST_ACCOUNT = "50303"
ADMIN_EXPENSE_ACCOUNT = "60301"

PURCHASE_MANAGER_ROLES = {"manager", "accountant_admin"}


def dec(value) -> Decimal:
    return Decimal(str(value or 0))


def money(value) -> Decimal:
    return dec(value).quantize(Decimal("0.01"))


def qty(value) -> Decimal:
    return dec(value).quantize(Decimal("0.001"))


def as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


def role_of(user) -> str:
    return normalize_role(getattr(user, "role", None))


def can_override(user) -> bool:
    return role_of(user) in PURCHASE_MANAGER_ROLES


def next_year_no(db: Session, document_type: str, base_prefix: str, doc_date) -> str:
    return next_document_no(
        db,
        document_type,
        document_date=doc_date,
        prefix=base_prefix,
    )


def account(db: Session, code: str) -> Account:
    item = db.query(Account).filter(Account.code == code, Account.is_active == True).first()
    if not item:
        raise HTTPException(status_code=400, detail=f"الحساب غير موجود أو غير نشط: {code}")
    return item


def decrease_cash_balance(db: Session, account_code: str, amount) -> None:
    value = money(amount)
    acc = account(db, account_code)
    if acc.type not in {"cash", "bank"} and not str(acc.code).startswith(("101", "102")):
        raise HTTPException(status_code=400, detail="حساب الدفع يجب أن يكون صندوقًا أو بنكًا")

    acc.balance = money(dec(acc.balance) - value)

    cash_account = db.query(CashAccount).filter(CashAccount.code == account_code).first()
    if cash_account:
        cash_account.balance = money(dec(cash_account.balance) - value)
        cash_account.current_balance = money(dec(getattr(cash_account, "current_balance", 0)) - value)


def require_supplier(db: Session, supplier_id: int) -> Supplier:
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="المورد غير موجود")
    return supplier


def lines_for(db: Session, model, field_name: str, value: int):
    return db.query(model).filter(getattr(model, field_name) == value).order_by(model.id.asc()).all()


def request_payload(db: Session, obj: PurchaseRequest) -> dict:
    payload = as_dict(obj)
    payload["lines"] = [as_dict(line) for line in lines_for(db, PurchaseRequestLine, "request_id", obj.id)]
    payload["estimated_total"] = float(sum(dec(line.estimated_total) for line in lines_for(db, PurchaseRequestLine, "request_id", obj.id)))
    return payload


def order_payload(db: Session, obj: PurchaseOrder) -> dict:
    payload = as_dict(obj)
    payload["lines"] = [as_dict(line) for line in lines_for(db, PurchaseOrderLine, "po_id", obj.id)]
    payload["total"] = float(sum(dec(line.total) for line in lines_for(db, PurchaseOrderLine, "po_id", obj.id)))
    return payload


def grn_payload(db: Session, obj: GoodsReceipt) -> dict:
    payload = as_dict(obj)
    payload["lines"] = [as_dict(line) for line in lines_for(db, GoodsReceiptLine, "grn_id", obj.id)]
    return payload


def supplier_invoice_payload(db: Session, obj: SupplierInvoice) -> dict:
    payload = as_dict(obj)
    payload["lines"] = [as_dict(line) for line in lines_for(db, SupplierInvoiceLine, "invoice_id", obj.id)]
    payload["open_balance"] = float(max(money(dec(obj.net_amount) - dec(obj.paid_amount)), Decimal("0")))
    payload["three_way_match"] = three_way_match(db, obj)
    return payload


def supplier_payment_payload(obj: SupplierPayment) -> dict:
    return as_dict(obj)


def add_audit(db: Session, user_id: int, action: str, entity: str, entity_id: int, details: str | None = None) -> None:
    db.add(AuditLog(user_id=user_id, action=action, entity=entity, entity_id=entity_id, details=details))


def line_total(quantity, unit_price, discount=0, tax=0, explicit_total=None) -> Decimal:
    if explicit_total is not None:
        return money(explicit_total)
    return money(dec(quantity) * dec(unit_price) - dec(discount) + dec(tax))


def general_warehouse(db: Session) -> Warehouse:
    warehouse = db.query(Warehouse).filter(Warehouse.code == "WH-GEN-001").first()
    if not warehouse:
        warehouse = Warehouse(code="WH-GEN-001", name="المخزن العام", type="general", is_active=True)
        db.add(warehouse)
        db.flush()
    return warehouse


def require_inventory_line_item(db: Session, line: SupplierInvoiceLine, index: int) -> Item:
    if not line.item_id:
        raise HTTPException(status_code=400, detail=f"البند {index}: فاتورة المواد تتطلب اختيار صنف مخزني")
    item = db.query(Item).filter(Item.id == line.item_id).first()
    if not item:
        raise HTTPException(status_code=400, detail=f"البند {index}: الصنف غير موجود")
    return item


def receive_supplier_invoice_to_stock(db: Session, invoice: SupplierInvoice, lines: list[SupplierInvoiceLine]) -> None:
    warehouse = general_warehouse(db)
    for index, line in enumerate(lines, start=1):
        item = require_inventory_line_item(db, line, index)
        received_qty = qty(line.qty)
        if received_qty <= 0:
            raise HTTPException(status_code=400, detail=f"البند {index}: كمية الاستلام يجب أن تكون أكبر من صفر")

        old_qty = qty(item.current_qty)
        old_cost = money(item.avg_cost)
        unit_cost = money(line.unit_price)
        if old_qty <= 0:
            item.avg_cost = unit_cost
        else:
            item.avg_cost = money(((old_qty * old_cost) + (received_qty * unit_cost)) / (old_qty + received_qty))
        item.current_qty = qty(old_qty + received_qty)

        db.add(
            StockMovement(
                date=invoice.invoice_date,
                item_id=item.id,
                movement_type="purchase_receipt",
                qty=received_qty,
                unit_cost=unit_cost,
                warehouse_id=warehouse.id,
                supplier_invoice_id=invoice.id,
                movement_source="supplier_invoice",
                movement_reference=invoice.internal_invoice_no,
                notes=line.description,
            )
        )


def create_journal(
    db: Session,
    entry_date,
    description: str,
    source_type: str,
    source_id: int,
    user_id: int,
    rows: list[dict],
) -> JournalEntry:
    if db.query(JournalEntry).filter(JournalEntry.source_type == source_type, JournalEntry.source_id == source_id).first():
        raise HTTPException(status_code=400, detail="تم إنشاء قيد محاسبي لهذا المستند مسبقًا")

    assert_period_open(db, entry_date, user_id=user_id)
    if len(rows) < 2:
        raise HTTPException(status_code=400, detail="القيد المحاسبي يجب أن يحتوي على سطرين على الأقل")

    total_debit = money(sum(dec(row.get("debit")) for row in rows))
    total_credit = money(sum(dec(row.get("credit")) for row in rows))
    if total_debit <= 0 or total_debit != total_credit:
        raise HTTPException(status_code=400, detail="القيد المحاسبي غير متوازن")

    entry = JournalEntry(
        entry_no=next_document_no(db, "journal_entry", document_date=entry_date),
        entry_date=entry_date,
        description=description,
        source_type=source_type,
        source_id=source_id,
        status="posted",
        total_debit=total_debit,
        total_credit=total_credit,
        created_by=user_id,
    )
    db.add(entry)
    db.flush()

    for row in rows:
        acc = account(db, row["account_code"])
        debit = money(row.get("debit"))
        credit = money(row.get("credit"))
        if debit > 0 and credit > 0:
            raise HTTPException(status_code=400, detail="سطر القيد لا يمكن أن يكون مدينًا ودائنًا في نفس الوقت")
        if debit <= 0 and credit <= 0:
            raise HTTPException(status_code=400, detail="كل سطر قيد يجب أن يحتوي مبلغًا مدينًا أو دائنًا")
        db.add(
            JournalEntryLine(
                journal_entry_id=entry.id,
                account_code=acc.code,
                account_name=acc.name,
                debit=debit,
                credit=credit,
                project_id=row.get("project_id"),
                cost_center_id=row.get("cost_center_id"),
                party_type=row.get("party_type"),
                party_id=row.get("party_id"),
                description=row.get("description") or description,
            )
        )
    db.flush()
    _assert_journal_entry_balanced(db, entry.id)
    return entry


@router.get("/purchase-requests")
def list_purchase_requests(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_purchase_schema(db)
    rows = db.query(PurchaseRequest).order_by(PurchaseRequest.id.desc()).limit(300).all()
    return [request_payload(db, row) for row in rows]


@router.post("/purchase-requests")
def create_purchase_request(data: PurchaseRequestCreate, db: Session = Depends(get_db), user=Depends(require_permission("purchases.write"))):
    ensure_purchase_schema(db)
    if not data.lines:
        raise HTTPException(status_code=400, detail="يجب إضافة بند واحد على الأقل لطلب الشراء")
    if data.priority not in {"normal", "urgent", "critical"}:
        raise HTTPException(status_code=400, detail="أولوية طلب الشراء غير معتمدة")
    if data.request_type not in {"materials", "service", "tools", "maintenance", "admin"}:
        raise HTTPException(status_code=400, detail="نوع طلب الشراء غير معتمد")

    obj = PurchaseRequest(
        request_no=next_year_no(db, "purchase_request", "ASH-PR", data.date),
        date=data.date,
        requested_by=user.id,
        department=data.department,
        cost_center_id=data.cost_center_id,
        project_id=data.project_id,
        request_type=data.request_type,
        priority=data.priority,
        status="submitted",
        description=data.description,
    )
    db.add(obj)
    db.flush()

    for index, line in enumerate(data.lines, start=1):
        item_name = line.item_name
        if line.item_id:
            item = db.query(Item).filter(Item.id == line.item_id).first()
            if not item:
                raise HTTPException(status_code=400, detail=f"البند {index}: المادة غير موجودة")
            item_name = item_name or item.name
        if not item_name:
            raise HTTPException(status_code=400, detail=f"البند {index}: اسم المادة أو الخدمة إلزامي")
        if qty(line.qty) <= 0:
            raise HTTPException(status_code=400, detail=f"البند {index}: الكمية يجب أن تكون أكبر من صفر")
        estimated_total = line_total(line.qty, line.estimated_unit_cost, explicit_total=line.estimated_total)
        db.add(
            PurchaseRequestLine(
                request_id=obj.id,
                item_id=line.item_id,
                item_name=item_name,
                qty=line.qty,
                unit=line.unit,
                estimated_unit_cost=line.estimated_unit_cost,
                estimated_total=estimated_total,
                needed_date=line.needed_date,
                notes=line.notes,
            )
        )

    add_audit(db, user.id, "create_purchase_request", "purchase_request", obj.id, obj.request_no)
    db.commit()
    db.refresh(obj)
    return request_payload(db, obj)


@router.get("/purchase-requests/{request_id}")
def get_purchase_request(request_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(PurchaseRequest).filter(PurchaseRequest.id == request_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="طلب الشراء غير موجود")
    return request_payload(db, obj)


@router.post("/purchase-requests/{request_id}/approve")
def approve_purchase_request(request_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(PurchaseRequest).filter(PurchaseRequest.id == request_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="طلب الشراء غير موجود")
    if obj.status not in {"draft", "submitted"}:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد طلب الشراء بحالته الحالية")
    obj.status = "approved"
    add_audit(db, user.id, "approve_purchase_request", "purchase_request", obj.id, obj.request_no)
    db.commit()
    db.refresh(obj)
    return request_payload(db, obj)


@router.post("/purchase-requests/{request_id}/reject")
def reject_purchase_request(request_id: int, data: PurchaseRejectRequest | None = None, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(PurchaseRequest).filter(PurchaseRequest.id == request_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="طلب الشراء غير موجود")
    if obj.status in {"converted_to_po", "approved"}:
        raise HTTPException(status_code=400, detail="لا يمكن رفض طلب شراء معتمد أو محول لأمر شراء")
    obj.status = "rejected"
    add_audit(db, user.id, "reject_purchase_request", "purchase_request", obj.id, (data.reason if data else None) or obj.request_no)
    db.commit()
    db.refresh(obj)
    return request_payload(db, obj)


@router.post("/purchase-requests/{request_id}/convert-to-po")
def convert_purchase_request_to_po(request_id: int, data: PurchaseOrderCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    request = db.query(PurchaseRequest).filter(PurchaseRequest.id == request_id).first()
    if not request:
        raise HTTPException(status_code=404, detail="طلب الشراء غير موجود")
    if request.status != "approved":
        raise HTTPException(status_code=400, detail="لا يمكن إنشاء أمر شراء من طلب غير معتمد")
    data.purchase_request_id = request.id
    if data.project_id is None:
        data.project_id = request.project_id
    if data.cost_center_id is None:
        data.cost_center_id = request.cost_center_id
    po = _create_purchase_order(db, data, user.id)
    request.status = "converted_to_po"
    add_audit(db, user.id, "convert_purchase_request_to_po", "purchase_request", request.id, po.po_no)
    db.commit()
    db.refresh(po)
    return order_payload(db, po)


def _create_purchase_order(db: Session, data: PurchaseOrderCreate, user_id: int) -> PurchaseOrder:
    require_supplier(db, data.supplier_id)
    if data.purchase_request_id:
        request = db.query(PurchaseRequest).filter(PurchaseRequest.id == data.purchase_request_id).first()
        if not request:
            raise HTTPException(status_code=404, detail="طلب الشراء المرتبط غير موجود")
        if request.status not in {"approved", "converted_to_po"}:
            raise HTTPException(status_code=400, detail="لا يمكن إنشاء أمر شراء من طلب غير معتمد")
    if not data.lines:
        raise HTTPException(status_code=400, detail="يجب إضافة بند واحد على الأقل لأمر الشراء")

    obj = PurchaseOrder(
        po_no=next_year_no(db, "purchase_order", "ASH-PO", data.date),
        supplier_id=data.supplier_id,
        purchase_request_id=data.purchase_request_id,
        date=data.date,
        expected_delivery_date=data.expected_delivery_date,
        payment_terms=data.payment_terms,
        currency=data.currency,
        project_id=data.project_id,
        cost_center_id=data.cost_center_id,
        status="draft",
        description=data.description,
        created_by=user_id,
    )
    db.add(obj)
    db.flush()

    for index, line in enumerate(data.lines, start=1):
        item_name = line.item_name
        if line.item_id:
            item = db.query(Item).filter(Item.id == line.item_id).first()
            if not item:
                raise HTTPException(status_code=400, detail=f"البند {index}: المادة غير موجودة")
            item_name = item_name or item.name
        if not item_name:
            raise HTTPException(status_code=400, detail=f"البند {index}: اسم المادة أو الخدمة إلزامي")
        if qty(line.qty_ordered) <= 0 or money(line.unit_price) <= 0:
            raise HTTPException(status_code=400, detail=f"البند {index}: الكمية والسعر يجب أن يكونا أكبر من صفر")
        total = line_total(line.qty_ordered, line.unit_price, line.discount, line.tax, line.total)
        db.add(
            PurchaseOrderLine(
                po_id=obj.id,
                item_id=line.item_id,
                item_name=item_name,
                qty_ordered=line.qty_ordered,
                qty_received=0,
                unit=line.unit,
                unit_price=line.unit_price,
                discount=line.discount,
                tax=line.tax,
                total=total,
            )
        )
    add_audit(db, user_id, "create_purchase_order", "purchase_order", obj.id, obj.po_no)
    return obj


@router.get("/purchase-orders")
def list_purchase_orders(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_purchase_schema(db)
    rows = db.query(PurchaseOrder).order_by(PurchaseOrder.id.desc()).limit(300).all()
    return [order_payload(db, row) for row in rows]


@router.post("/purchase-orders")
def create_purchase_order(data: PurchaseOrderCreate, db: Session = Depends(get_db), user=Depends(require_permission("purchases.write"))):
    ensure_purchase_schema(db)
    obj = _create_purchase_order(db, data, user.id)
    db.commit()
    db.refresh(obj)
    return order_payload(db, obj)


@router.get("/purchase-orders/{po_id}")
def get_purchase_order(po_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
    return order_payload(db, obj)


@router.post("/purchase-orders/{po_id}/approve")
def approve_purchase_order(po_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد أمر شراء غير مسودة")
    obj.status = "issued"
    obj.approved_by = user.id
    obj.approved_at = datetime.utcnow()
    add_audit(db, user.id, "approve_purchase_order", "purchase_order", obj.id, obj.po_no)
    db.commit()
    db.refresh(obj)
    return order_payload(db, obj)


@router.post("/purchase-orders/{po_id}/close")
def close_purchase_order(po_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
    if obj.status not in {"issued", "partially_received", "received"}:
        raise HTTPException(status_code=400, detail="لا يمكن إغلاق أمر الشراء بحالته الحالية")
    obj.status = "closed"
    add_audit(db, user.id, "close_purchase_order", "purchase_order", obj.id, obj.po_no)
    db.commit()
    return order_payload(db, obj)


@router.post("/purchase-orders/{po_id}/cancel")
def cancel_purchase_order(po_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(PurchaseOrder).filter(PurchaseOrder.id == po_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
    if obj.status in {"received", "closed"}:
        raise HTTPException(status_code=400, detail="لا يمكن إلغاء أمر شراء مستلم أو مغلق")
    obj.status = "cancelled"
    add_audit(db, user.id, "cancel_purchase_order", "purchase_order", obj.id, obj.po_no)
    db.commit()
    return order_payload(db, obj)


@router.get("/goods-receipts")
def list_goods_receipts(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_purchase_schema(db)
    rows = db.query(GoodsReceipt).order_by(GoodsReceipt.id.desc()).limit(300).all()
    return [grn_payload(db, row) for row in rows]


@router.post("/goods-receipts")
def create_goods_receipt(data: GoodsReceiptCreate, db: Session = Depends(get_db), user=Depends(require_permission("inventory.write"))):
    ensure_purchase_schema(db)
    require_supplier(db, data.supplier_id)
    po = None
    if data.po_id:
        po = db.query(PurchaseOrder).filter(PurchaseOrder.id == data.po_id).first()
        if not po:
            raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
        if po.status not in {"issued", "partially_received"}:
            raise HTTPException(status_code=400, detail="لا يمكن الاستلام إلا مقابل أمر شراء معتمد")
        if po.supplier_id != data.supplier_id:
            raise HTTPException(status_code=400, detail="المورد في سند الاستلام لا يطابق أمر الشراء")
    if not data.lines:
        raise HTTPException(status_code=400, detail="يجب إضافة بند واحد على الأقل لسند الاستلام")

    obj = GoodsReceipt(
        grn_no=next_year_no(db, "goods_receipt", "ASH-GRN", data.date),
        po_id=data.po_id,
        supplier_id=data.supplier_id,
        date=data.date,
        received_by=user.id,
        warehouse_id=data.warehouse_id,
        status="draft",
        notes=data.notes,
        attachment_id=data.attachment_id,
    )
    db.add(obj)
    db.flush()

    for index, line in enumerate(data.lines, start=1):
        item = db.query(Item).filter(Item.id == line.item_id).first()
        if not item:
            raise HTTPException(status_code=400, detail=f"البند {index}: المادة غير موجودة")
        ordered_qty = line.qty_ordered
        if line.po_line_id:
            po_line = db.query(PurchaseOrderLine).filter(PurchaseOrderLine.id == line.po_line_id).first()
            if not po_line:
                raise HTTPException(status_code=400, detail=f"البند {index}: بند أمر الشراء غير موجود")
            if po_line.po_id != data.po_id:
                raise HTTPException(status_code=400, detail=f"البند {index}: بند الاستلام لا يتبع أمر الشراء المحدد")
            ordered_qty = po_line.qty_ordered
            if qty(line.qty_received) + qty(po_line.qty_received) > qty(po_line.qty_ordered) and not can_override(user):
                raise HTTPException(status_code=400, detail=f"البند {index}: لا يمكن استلام كمية أكبر من أمر الشراء إلا بصلاحية مدير")
        if qty(line.qty_received) <= 0:
            raise HTTPException(status_code=400, detail=f"البند {index}: الكمية المستلمة يجب أن تكون أكبر من صفر")
        db.add(
            GoodsReceiptLine(
                grn_id=obj.id,
                po_line_id=line.po_line_id,
                item_id=line.item_id,
                qty_ordered=ordered_qty,
                qty_received=line.qty_received,
                qty_rejected=line.qty_rejected,
                unit=line.unit,
                condition_status=line.condition_status,
                notes=line.notes,
            )
        )
    add_audit(db, user.id, "create_goods_receipt", "goods_receipt", obj.id, obj.grn_no)
    db.commit()
    db.refresh(obj)
    return grn_payload(db, obj)


@router.get("/goods-receipts/{grn_id}")
def get_goods_receipt(grn_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(GoodsReceipt).filter(GoodsReceipt.id == grn_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="سند الاستلام غير موجود")
    return grn_payload(db, obj)


@router.post("/goods-receipts/{grn_id}/approve")
def approve_goods_receipt(grn_id: int, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    obj = db.query(GoodsReceipt).filter(GoodsReceipt.id == grn_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="سند الاستلام غير موجود")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند استلام غير مسودة")
    lines = lines_for(db, GoodsReceiptLine, "grn_id", obj.id)
    if not lines:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند استلام بدون بنود")

    journal_rows = []
    for line in lines:
        item = db.query(Item).filter(Item.id == line.item_id).first()
        if not item:
            raise HTTPException(status_code=400, detail="مادة سند الاستلام غير موجودة")
        received_qty = qty(line.qty_received)
        rejected_qty = qty(line.qty_rejected)
        if received_qty <= 0 and rejected_qty <= 0:
            raise HTTPException(status_code=400, detail="كل بند استلام يجب أن يحتوي كمية مستلمة أو مرفوضة")
        if received_qty < 0 or rejected_qty < 0:
            raise HTTPException(status_code=400, detail="كمية الاستلام أو الرفض لا يمكن أن تكون سالبة")
        old_qty = dec(item.current_qty)
        old_cost = dec(item.avg_cost)
        unit_cost = Decimal("0")
        if line.po_line_id:
            po_line = db.query(PurchaseOrderLine).filter(PurchaseOrderLine.id == line.po_line_id).first()
            unit_cost = dec(po_line.unit_price) if po_line else Decimal("0")
            if po_line:
                remaining_qty = qty(dec(po_line.qty_ordered) - dec(po_line.qty_received))
                if received_qty > remaining_qty and not can_override(user):
                    raise HTTPException(
                        status_code=400,
                        detail=f"الكمية المستلمة أكبر من المتبقي في أمر الشراء. المتبقي: {remaining_qty}",
                    )
                po_line.qty_received = qty(dec(po_line.qty_received) + received_qty)
        if received_qty > 0:
            new_qty = old_qty + received_qty
            if unit_cost > 0 and new_qty > 0:
                item.avg_cost = money(((old_qty * old_cost) + (received_qty * unit_cost)) / new_qty)
            item.current_qty = qty(new_qty)
            db.add(
                StockMovement(
                    date=obj.date,
                    item_id=line.item_id,
                    movement_type="purchase_receipt",
                    qty=received_qty,
                    unit_cost=unit_cost,
                    warehouse_id=obj.warehouse_id,
                    goods_receipt_id=obj.id,
                    movement_source="goods_receipt",
                    movement_reference=obj.grn_no,
                    transaction_id=None,
                    notes=obj.grn_no,
                )
            )
        if received_qty > 0 and unit_cost > 0:
            amount = money(received_qty * unit_cost)
            journal_rows.append({"account_code": INVENTORY_ACCOUNT, "debit": amount, "credit": 0, "description": obj.grn_no})
            journal_rows.append({"account_code": GRNI_ACCOUNT, "debit": 0, "credit": amount, "description": obj.grn_no})

    if journal_rows:
        create_journal(db, obj.date, f"إثبات استلام مواد {obj.grn_no}", "goods_receipt", obj.id, user.id, journal_rows)

    if obj.po_id:
        po = db.query(PurchaseOrder).filter(PurchaseOrder.id == obj.po_id).first()
        if po:
            po_lines = lines_for(db, PurchaseOrderLine, "po_id", po.id)
            if all(qty(line.qty_received) >= qty(line.qty_ordered) for line in po_lines):
                po.status = "received"
            else:
                po.status = "partially_received"

    obj.status = "received"
    add_audit(db, user.id, "approve_goods_receipt", "goods_receipt", obj.id, obj.grn_no)
    db.commit()
    db.refresh(obj)
    return grn_payload(db, obj)


def three_way_match(db: Session, invoice: SupplierInvoice) -> dict:
    result = {"status": "not_required", "warnings": []}
    if not invoice.po_id and not invoice.grn_id:
        result["status"] = "direct_purchase"
        result["warnings"].append("فاتورة مباشرة بدون أمر شراء أو سند استلام")
        return result

    po = db.query(PurchaseOrder).filter(PurchaseOrder.id == invoice.po_id).first() if invoice.po_id else None
    grn = db.query(GoodsReceipt).filter(GoodsReceipt.id == invoice.grn_id).first() if invoice.grn_id else None
    if po and po.supplier_id != invoice.supplier_id:
        result["warnings"].append("المورد لا يطابق أمر الشراء")
    if grn and grn.supplier_id != invoice.supplier_id:
        result["warnings"].append("المورد لا يطابق سند الاستلام")
    if invoice.invoice_type == "inventory" and not grn:
        result["warnings"].append("فاتورة مواد بدون سند استلام")

    invoice_lines = lines_for(db, SupplierInvoiceLine, "invoice_id", invoice.id)
    if grn:
        received = sum(dec(line.qty_received) for line in lines_for(db, GoodsReceiptLine, "grn_id", grn.id))
        invoiced = sum(dec(line.qty) for line in invoice_lines)
        if invoiced > received:
            result["warnings"].append("الكمية المفوترة أكبر من الكمية المستلمة")
    if po:
        po_total = sum(dec(line.total) for line in lines_for(db, PurchaseOrderLine, "po_id", po.id))
        if dec(invoice.net_amount) > po_total:
            result["warnings"].append("قيمة الفاتورة أكبر من أمر الشراء")

    result["status"] = "matched" if not result["warnings"] else "exception"
    return result


@router.get("/supplier-invoices")
def list_supplier_invoices(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_purchase_schema(db)
    rows = db.query(SupplierInvoice).order_by(SupplierInvoice.id.desc()).limit(300).all()
    return [supplier_invoice_payload(db, row) for row in rows]


@router.post("/supplier-invoices")
def create_supplier_invoice(data: SupplierInvoiceCreate, db: Session = Depends(get_db), user=Depends(require_permission("purchases.write"))):
    ensure_purchase_schema(db)
    require_supplier(db, data.supplier_id)
    if data.supplier_invoice_no:
        duplicate = (
            db.query(SupplierInvoice)
            .filter(
                SupplierInvoice.supplier_id == data.supplier_id,
                SupplierInvoice.supplier_invoice_no == data.supplier_invoice_no,
                SupplierInvoice.status != "reversed",
            )
            .first()
        )
        if duplicate:
            raise HTTPException(status_code=400, detail="رقم فاتورة المورد مستخدم مسبقًا لنفس المورد")
    if data.po_id:
        po = db.query(PurchaseOrder).filter(PurchaseOrder.id == data.po_id).first()
        if not po:
            raise HTTPException(status_code=404, detail="أمر الشراء غير موجود")
        if po.supplier_id != data.supplier_id:
            raise HTTPException(status_code=400, detail="المورد لا يطابق أمر الشراء")
    if data.grn_id:
        grn = db.query(GoodsReceipt).filter(GoodsReceipt.id == data.grn_id).first()
        if not grn:
            raise HTTPException(status_code=404, detail="سند الاستلام غير موجود")
        if grn.status != "received":
            raise HTTPException(status_code=400, detail="لا يمكن ربط فاتورة بسند استلام غير معتمد")
        if grn.supplier_id != data.supplier_id:
            raise HTTPException(status_code=400, detail="المورد لا يطابق سند الاستلام")
    if not data.lines:
        raise HTTPException(status_code=400, detail="لا يمكن إنشاء فاتورة مورد بدون بنود")
    if data.invoice_type not in {"inventory", "project_service", "admin_expense", "asset", "mixed"}:
        raise HTTPException(status_code=400, detail="نوع فاتورة المورد غير معتمد")

    subtotal = Decimal("0")
    obj = SupplierInvoice(
        internal_invoice_no=next_year_no(db, "supplier_invoice", "ASH-PINV", data.invoice_date),
        supplier_invoice_no=data.supplier_invoice_no,
        supplier_id=data.supplier_id,
        po_id=data.po_id,
        grn_id=data.grn_id,
        invoice_date=data.invoice_date,
        due_date=data.due_date,
        invoice_type=data.invoice_type,
        currency=data.currency,
        discount=data.discount,
        tax=data.tax,
        status="draft",
        description=data.description,
        attachment_id=data.attachment_id,
        created_by=user.id,
    )
    db.add(obj)
    db.flush()

    for index, line in enumerate(data.lines, start=1):
        if qty(line.qty) <= 0 or money(line.unit_price) <= 0:
            raise HTTPException(status_code=400, detail=f"البند {index}: الكمية والسعر يجب أن يكونا أكبر من صفر")
        if data.invoice_type == "inventory":
            if not line.item_id:
                raise HTTPException(status_code=400, detail=f"البند {index}: فاتورة المواد تتطلب اختيار صنف مخزني")
            if not db.query(Item).filter(Item.id == line.item_id).first():
                raise HTTPException(status_code=400, detail=f"البند {index}: الصنف غير موجود")
        if line.project_id and not line.cost_center_id:
            raise HTTPException(status_code=400, detail=f"البند {index}: تحميل تكلفة على مشروع يتطلب مركز تكلفة")
        if line.cost_center_id and not db.query(CostCenter).filter(CostCenter.id == line.cost_center_id).first():
            raise HTTPException(status_code=400, detail=f"البند {index}: مركز التكلفة غير موجود")
        account(db, line.account_code)
        total = line_total(line.qty, line.unit_price, explicit_total=line.total)
        subtotal += total
        db.add(
            SupplierInvoiceLine(
                invoice_id=obj.id,
                item_id=line.item_id,
                description=line.description,
                qty=line.qty,
                unit_price=line.unit_price,
                account_code=line.account_code,
                project_id=line.project_id,
                cost_center_id=line.cost_center_id,
                total=total,
            )
        )
    obj.subtotal = money(subtotal)
    obj.net_amount = money(data.net_amount or (subtotal - dec(data.discount) + dec(data.tax)))
    if obj.net_amount <= 0:
        raise HTTPException(status_code=400, detail="صافي فاتورة المورد يجب أن يكون أكبر من صفر")

    add_audit(db, user.id, "create_supplier_invoice", "supplier_invoice", obj.id, obj.internal_invoice_no)
    db.commit()
    db.refresh(obj)
    return supplier_invoice_payload(db, obj)


@router.get("/supplier-invoices/{invoice_id}")
def get_supplier_invoice(invoice_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(SupplierInvoice).filter(SupplierInvoice.id == invoice_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
    return supplier_invoice_payload(db, obj)


@router.post("/supplier-invoices/{invoice_id}/approve")
def approve_supplier_invoice(invoice_id: int, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_invoice"))):
    obj = db.query(SupplierInvoice).filter(SupplierInvoice.id == invoice_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد فاتورة مورد غير مسودة")
    invoice_lines = lines_for(db, SupplierInvoiceLine, "invoice_id", obj.id)
    if not invoice_lines:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد فاتورة مورد بدون بنود")
    match = three_way_match(db, obj)
    if match["status"] == "exception" and not can_override(user):
        raise HTTPException(status_code=400, detail="توجد فروقات مطابقة ثلاثية تتطلب موافقة مدير: " + "، ".join(match["warnings"]))

    journal_rows = []
    for line in invoice_lines:
        debit_account = line.account_code
        if obj.invoice_type == "inventory":
            debit_account = GRNI_ACCOUNT if obj.grn_id else INVENTORY_ACCOUNT
        elif obj.invoice_type == "project_service":
            debit_account = line.account_code or PROJECT_COST_ACCOUNT
            if not (line.project_id or obj.po_id):
                raise HTTPException(status_code=400, detail="فاتورة خدمة مشروع تتطلب مشروعًا أو أمر شراء مرتبطًا بمشروع")
        elif obj.invoice_type == "admin_expense":
            debit_account = line.account_code or ADMIN_EXPENSE_ACCOUNT

        line_project_id = line.project_id or getattr(obj, "project_id", None)
        line_cost_center_id = line.cost_center_id or getattr(obj, "cost_center_id", None)
        if line_project_id and not line_cost_center_id:
            raise HTTPException(
                status_code=400,
                detail="أي بند فاتورة محمل على مشروع يجب أن يحتوي مركز تكلفة",
            )

        journal_rows.append(
            {
                "account_code": debit_account,
                "debit": line.total,
                "credit": 0,
                "project_id": line_project_id,
                "cost_center_id": line_cost_center_id,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": line.description,
            }
        )
        if line_project_id:
            db.add(
                ProjectCost(
                    project_id=line_project_id,
                    cost_center_id=line_cost_center_id,
                    date=obj.invoice_date,
                    category="supplier_invoice",
                    amount=line.total,
                    source_type="supplier_invoice",
                    source_id=obj.id,
                    notes=line.description,
                )
            )

    debit_total = money(sum(dec(row.get("debit")) for row in journal_rows))
    net_amount = money(obj.net_amount)
    if net_amount > debit_total:
        journal_rows.append(
            {
                "account_code": ADMIN_EXPENSE_ACCOUNT,
                "debit": net_amount - debit_total,
                "credit": 0,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": "فرق ضريبة أو رسوم على فاتورة المورد",
            }
        )
    elif net_amount < debit_total:
        journal_rows.append(
            {
                "account_code": ADMIN_EXPENSE_ACCOUNT,
                "debit": 0,
                "credit": debit_total - net_amount,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": "خصم على فاتورة المورد",
            }
        )

    journal_rows.append(
        {
            "account_code": SUPPLIER_PAYABLE_ACCOUNT,
            "debit": 0,
            "credit": obj.net_amount,
            "party_type": "supplier",
            "party_id": obj.supplier_id,
            "description": obj.description or obj.internal_invoice_no,
        }
    )
    create_journal(db, obj.invoice_date, f"اعتماد فاتورة مورد {obj.internal_invoice_no}", "supplier_invoice", obj.id, user.id, journal_rows)
    if obj.invoice_type == "inventory" and not obj.grn_id:
        receive_supplier_invoice_to_stock(db, obj, invoice_lines)
    obj.status = "approved"
    obj.approved_by = user.id
    obj.approved_at = datetime.utcnow()
    add_audit(db, user.id, "approve_supplier_invoice", "supplier_invoice", obj.id, obj.internal_invoice_no)
    db.commit()
    db.refresh(obj)
    return supplier_invoice_payload(db, obj)


@router.post("/supplier-invoices/{invoice_id}/reject")
def reject_supplier_invoice(invoice_id: int, data: PurchaseRejectRequest | None = None, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_invoice"))):
    obj = db.query(SupplierInvoice).filter(SupplierInvoice.id == invoice_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن رفض فاتورة مورد غير مسودة")
    obj.status = "rejected"
    add_audit(db, user.id, "reject_supplier_invoice", "supplier_invoice", obj.id, (data.reason if data else None) or obj.internal_invoice_no)
    db.commit()
    db.refresh(obj)
    return supplier_invoice_payload(db, obj)


@router.post("/supplier-invoices/{invoice_id}/cancel")
def cancel_supplier_invoice(invoice_id: int, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_invoice"))):
    obj = db.query(SupplierInvoice).filter(SupplierInvoice.id == invoice_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
    if obj.status in {"approved", "partially_paid", "paid"}:
        raise HTTPException(status_code=400, detail="لا يمكن إلغاء فاتورة معتمدة أو مدفوعة إلا بإشعار دائن أو قيد عكسي")
    obj.status = "cancelled"
    add_audit(db, user.id, "cancel_supplier_invoice", "supplier_invoice", obj.id, obj.internal_invoice_no)
    db.commit()
    return supplier_invoice_payload(db, obj)


@router.get("/supplier-payments")
def list_supplier_payments(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_purchase_schema(db)
    rows = db.query(SupplierPayment).order_by(SupplierPayment.id.desc()).limit(300).all()
    return [supplier_payment_payload(row) for row in rows]


@router.post("/supplier-payments")
def create_supplier_payment(data: SupplierPaymentCreate, db: Session = Depends(get_db), user=Depends(require_permission("purchases.write"))):
    ensure_purchase_schema(db)
    require_supplier(db, data.supplier_id)
    if money(data.amount) <= 0:
        raise HTTPException(status_code=400, detail="مبلغ دفعة المورد يجب أن يكون أكبر من صفر")
    invoice = None
    if data.invoice_id:
        invoice = db.query(SupplierInvoice).filter(SupplierInvoice.id == data.invoice_id).first()
        if not invoice:
            raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
        if invoice.supplier_id != data.supplier_id:
            raise HTTPException(status_code=400, detail="المورد لا يطابق الفاتورة")

    obj = SupplierPayment(
        payment_no=next_year_no(db, "supplier_payment", "ASH-SPV", data.payment_date),
        supplier_id=data.supplier_id,
        invoice_id=data.invoice_id,
        payment_date=data.payment_date,
        amount=money(data.amount),
        payment_method=data.payment_method,
        cash_account_code=data.cash_account_code,
        currency=data.currency,
        description=data.description,
        attachment_id=data.attachment_id,
        status="draft",
        created_by=user.id,
    )
    db.add(obj)
    db.flush()
    add_audit(db, user.id, "create_supplier_payment", "supplier_payment", obj.id, obj.payment_no)
    db.commit()
    db.refresh(obj)
    return supplier_payment_payload(obj)


@router.get("/supplier-payments/{payment_id}")
def get_supplier_payment(payment_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    obj = db.query(SupplierPayment).filter(SupplierPayment.id == payment_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="سند دفع المورد غير موجود")
    return supplier_payment_payload(obj)


@router.post("/supplier-payments/{payment_id}/approve")
def approve_supplier_payment(payment_id: int, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_payment"))):
    obj = db.query(SupplierPayment).filter(SupplierPayment.id == payment_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="سند دفع المورد غير موجود")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند دفع غير مسودة")
    cash = account(db, obj.cash_account_code)
    if cash.type not in {"cash", "bank"} and not str(cash.code).startswith(("101", "102")):
        raise HTTPException(status_code=400, detail="حساب الدفع يجب أن يكون صندوقًا أو بنكًا")

    debit_account = SUPPLIER_ADVANCE_ACCOUNT
    invoice = None
    payable_amount = money(obj.amount)
    advance_amount = Decimal("0")
    if obj.invoice_id:
        invoice = db.query(SupplierInvoice).filter(SupplierInvoice.id == obj.invoice_id).first()
        if not invoice:
            raise HTTPException(status_code=404, detail="فاتورة المورد غير موجودة")
        if invoice.status not in {"approved", "partially_paid"}:
            raise HTTPException(status_code=400, detail="لا يمكن دفع فاتورة مورد غير معتمدة")
        open_balance = money(dec(invoice.net_amount) - dec(invoice.paid_amount))
        if dec(obj.amount) > open_balance and not can_override(user):
            raise HTTPException(status_code=400, detail="لا يمكن دفع مبلغ أكبر من رصيد الفاتورة إلا بصلاحية مدير")
        debit_account = SUPPLIER_PAYABLE_ACCOUNT
        payable_amount = min(money(obj.amount), open_balance)
        advance_amount = money(dec(obj.amount) - payable_amount)

    journal_rows = []
    if payable_amount > 0:
        journal_rows.append(
            {
                "account_code": debit_account,
                "debit": payable_amount,
                "credit": 0,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": obj.description or obj.payment_no,
            }
        )
    if advance_amount > 0:
        journal_rows.append(
            {
                "account_code": SUPPLIER_ADVANCE_ACCOUNT,
                "debit": advance_amount,
                "credit": 0,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": f"دفعة مقدمة للمورد - زيادة عن رصيد الفاتورة {obj.payment_no}",
            }
        )
    journal_rows.append(
            {
                "account_code": cash.code,
                "debit": 0,
                "credit": obj.amount,
                "party_type": "supplier",
                "party_id": obj.supplier_id,
                "description": obj.description or obj.payment_no,
            },
    )

    create_journal(
        db,
        obj.payment_date,
        f"اعتماد سند دفع مورد {obj.payment_no}",
        "supplier_payment",
        obj.id,
        user.id,
        journal_rows,
    )
    if invoice:
        invoice.paid_amount = money(dec(invoice.paid_amount) + payable_amount)
        if money(dec(invoice.paid_amount)) >= money(dec(invoice.net_amount)):
            invoice.status = "paid"
        else:
            invoice.status = "partially_paid"
    decrease_cash_balance(db, cash.code, obj.amount)
    obj.status = "approved"
    obj.approved_by = user.id
    obj.approved_at = datetime.utcnow()
    add_audit(db, user.id, "approve_supplier_payment", "supplier_payment", obj.id, obj.payment_no)
    db.commit()
    db.refresh(obj)
    return supplier_payment_payload(obj)


@router.post("/supplier-payments/{payment_id}/reject")
def reject_supplier_payment(payment_id: int, data: PurchaseRejectRequest | None = None, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_payment"))):
    obj = db.query(SupplierPayment).filter(SupplierPayment.id == payment_id).first()
    if not obj:
        raise HTTPException(status_code=404, detail="سند دفع المورد غير موجود")
    if obj.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن رفض سند دفع غير مسودة")
    obj.status = "rejected"
    add_audit(db, user.id, "reject_supplier_payment", "supplier_payment", obj.id, (data.reason if data else None) or obj.payment_no)
    db.commit()
    return supplier_payment_payload(obj)


@router.get("/reports/supplier-aging")
def supplier_aging(
    as_of: date | None = None,
    db: Session = Depends(get_db),
    user=Depends(get_current_user),
):
    rows = db.query(Supplier).order_by(Supplier.name.asc()).all()
    payload = []
    today = as_of or datetime.utcnow().date()
    for supplier in rows:
        invoices = db.query(SupplierInvoice).filter(SupplierInvoice.supplier_id == supplier.id, SupplierInvoice.status.in_(["approved", "partially_paid"])).all()
        current = Decimal("0")
        d30 = Decimal("0")
        d60 = Decimal("0")
        d90 = Decimal("0")
        over90 = Decimal("0")
        for invoice in invoices:
            balance = money(dec(invoice.net_amount) - dec(invoice.paid_amount))
            if balance <= 0:
                continue
            days = (today - (invoice.due_date or invoice.invoice_date)).days
            if days <= 0:
                current += balance
            elif days <= 30:
                d30 += balance
            elif days <= 60:
                d60 += balance
            elif days <= 90:
                d90 += balance
            else:
                over90 += balance
        total = current + d30 + d60 + d90 + over90
        if total > 0:
            payload.append({
                "supplier_id": supplier.id,
                "supplier": supplier.name,
                "current": float(current),
                "days_1_30": float(d30),
                "days_31_60": float(d60),
                "days_61_90": float(d90),
                "days_over_90": float(over90),
                "days_over_60": float(d90 + over90),
                "total": float(total),
                "risk_level": "high" if over90 > 0 else ("medium" if d90 > 0 else "normal"),
            })
    return payload


@router.get("/reports/purchase-summary")
def purchase_summary(db: Session = Depends(get_db), user=Depends(get_current_user)):
    invoices = db.query(func.coalesce(func.sum(SupplierInvoice.net_amount), 0)).filter(SupplierInvoice.status.in_(["approved", "partially_paid", "paid"])).scalar()
    payments = db.query(func.coalesce(func.sum(SupplierPayment.amount), 0)).filter(SupplierPayment.status == "approved").scalar()
    open_po = db.query(PurchaseOrder).filter(PurchaseOrder.status.in_(["issued", "partially_received"])).count()
    draft_requests = db.query(PurchaseRequest).filter(PurchaseRequest.status.in_(["draft", "submitted"])).count()
    return {"approved_invoices": float(dec(invoices)), "approved_payments": float(dec(payments)), "open_purchase_orders": open_po, "pending_purchase_requests": draft_requests}


@router.get("/reports/open-purchase-orders")
def open_purchase_orders(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.query(PurchaseOrder).filter(PurchaseOrder.status.in_(["issued", "partially_received"])).order_by(PurchaseOrder.id.desc()).all()
    return [order_payload(db, row) for row in rows]


@router.get("/reports/grni")
def grni_report(db: Session = Depends(get_db), user=Depends(get_current_user)):
    receipts = db.query(GoodsReceipt).filter(GoodsReceipt.status == "received").all()
    payload = []
    for receipt in receipts:
        invoiced = db.query(SupplierInvoice).filter(SupplierInvoice.grn_id == receipt.id, SupplierInvoice.status.in_(["approved", "partially_paid", "paid"])).first()
        if not invoiced:
            lines = lines_for(db, GoodsReceiptLine, "grn_id", receipt.id)
            amount = Decimal("0")
            for line in lines:
                if line.po_line_id:
                    po_line = db.query(PurchaseOrderLine).filter(PurchaseOrderLine.id == line.po_line_id).first()
                    if po_line:
                        amount += money(dec(line.qty_received) * dec(po_line.unit_price))
            payload.append({"grn_id": receipt.id, "grn_no": receipt.grn_no, "supplier_id": receipt.supplier_id, "date": receipt.date, "estimated_amount": float(amount)})
    return payload


@router.get("/reports/supplier-statement/{supplier_id}")
def purchase_supplier_statement(supplier_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    supplier = require_supplier(db, supplier_id)
    invoices = db.query(SupplierInvoice).filter(SupplierInvoice.supplier_id == supplier_id).order_by(SupplierInvoice.invoice_date.desc()).all()
    payments = db.query(SupplierPayment).filter(SupplierPayment.supplier_id == supplier_id).order_by(SupplierPayment.payment_date.desc()).all()
    invoice_total = sum(dec(row.net_amount) for row in invoices if row.status in {"approved", "partially_paid", "paid"})
    payment_total = sum(dec(row.amount) for row in payments if row.status == "approved")
    return {
        "supplier_id": supplier.id,
        "supplier": supplier.name,
        "invoice_total": float(invoice_total),
        "payment_total": float(payment_total),
        "balance": float(invoice_total - payment_total),
        "invoices": [supplier_invoice_payload(db, row) for row in invoices],
        "payments": [supplier_payment_payload(row) for row in payments],
    }
