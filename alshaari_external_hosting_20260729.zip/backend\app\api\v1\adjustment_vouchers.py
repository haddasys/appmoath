from datetime import datetime
from decimal import Decimal

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, normalize_role, require_permission
from app.db.database import get_db
from app.models.models import (
    Account,
    AdjustmentVoucher,
    AdjustmentVoucherLine,
    AuditLog,
    DocumentSequence,
    JournalEntry,
    JournalEntryLine,
    ProjectCost,
)
from app.schemas.schemas import (
    AdjustmentVoucherCreate,
    AdjustmentVoucherRejectRequest,
    AdjustmentVoucherReverseRequest,
)
from app.services.adjustment_schema import ensure_adjustment_schema
from app.services.accounting_periods import assert_period_open
from app.services.document_sequence import next_document_no
from app.services.posting_engine import _assert_journal_entry_balanced

router = APIRouter(prefix="/api/v1/adjustment-vouchers", tags=["Adjustment Vouchers"])

ALLOWED_REASONS = {
    "general_adjustment",
    "worker_advance_settlement",
    "supplier_settlement",
    "customer_settlement",
    "inventory_settlement",
    "project_cost_settlement",
    "error_correction",
    "accrued_expense",
    "accrued_revenue",
    "reclassification",
    "inventory_adjustment",
    "cost_allocation",
    "supplier_adjustment",
    "customer_adjustment",
    "payroll_adjustment",
    "opening_balance",
    "other",
}

ADJUSTMENT_ROLES = {"manager", "accountant", "accountant_admin"}
CASH_ALLOWED_ROLES = {"manager", "accountant_admin"}


def as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


def user_role(user) -> str:
    return normalize_role(getattr(user, "role", None))


def require_adjustment_user(user):
    if user_role(user) not in ADJUSTMENT_ROLES:
        raise HTTPException(status_code=403, detail="لا تملك صلاحية إنشاء أو اعتماد سندات التسوية")


def dec(value) -> Decimal:
    return Decimal(str(value or 0))


def money(value) -> Decimal:
    return dec(value).quantize(Decimal("0.01"))


def next_adjustment_no(db: Session, voucher_date) -> str:
    return next_document_no(db, "adjustment_voucher", document_date=voucher_date)


def load_voucher(db: Session, voucher_id: int) -> AdjustmentVoucher:
    voucher = db.query(AdjustmentVoucher).filter(AdjustmentVoucher.id == voucher_id).first()
    if not voucher:
        raise HTTPException(status_code=404, detail="سند التسوية غير موجود")
    return voucher


def voucher_payload(db: Session, voucher: AdjustmentVoucher):
    lines = (
        db.query(AdjustmentVoucherLine)
        .filter(AdjustmentVoucherLine.voucher_id == voucher.id)
        .order_by(AdjustmentVoucherLine.id.asc())
        .all()
    )
    payload = as_dict(voucher)
    payload["lines"] = [as_dict(line) for line in lines]
    payload["total_debit"] = float(sum(dec(line.debit) for line in lines))
    payload["total_credit"] = float(sum(dec(line.credit) for line in lines))
    payload["difference"] = float(payload["total_debit"] - payload["total_credit"])
    return payload


def is_cash_or_bank(account: Account) -> bool:
    return account.type in {"cash", "bank"} or str(account.code).startswith("101")


def validate_lines(db: Session, data: AdjustmentVoucherCreate, user) -> list[dict]:
    if data.reason not in ALLOWED_REASONS:
        raise HTTPException(status_code=400, detail="سبب التسوية غير معتمد")
    if not data.description or len(data.description.strip()) < 5:
        raise HTTPException(status_code=400, detail="يجب كتابة بيان واضح لسند التسوية")
    if len(data.lines) < 2:
        raise HTTPException(status_code=400, detail="سند التسوية يجب أن يحتوي على سطرين على الأقل")

    total_debit = Decimal("0")
    total_credit = Decimal("0")
    validated = []

    for index, line in enumerate(data.lines, start=1):
        debit = money(line.debit)
        credit = money(line.credit)
        if debit > 0 and credit > 0:
            raise HTTPException(status_code=400, detail=f"السطر {index}: لا يجوز إدخال مدين ودائن معًا")
        if debit <= 0 and credit <= 0:
            raise HTTPException(status_code=400, detail=f"السطر {index}: يجب إدخال مدين أو دائن")
        if line.project_id and not line.cost_center_id:
            raise HTTPException(status_code=400, detail=f"السطر {index}: عند اختيار مشروع يجب اختيار مركز تكلفة")
        if line.party_type and line.party_type not in {"customer", "supplier", "worker", "none"}:
            raise HTTPException(status_code=400, detail=f"السطر {index}: نوع الطرف يجب أن يكون عميل أو مورد أو عامل")
        if line.party_type and line.party_type != "none" and not line.party_id:
            raise HTTPException(status_code=400, detail=f"السطر {index}: يجب تحديد الطرف المرتبط")
        if line.party_id and (not line.party_type or line.party_type == "none"):
            raise HTTPException(status_code=400, detail=f"السطر {index}: يجب تحديد نوع الطرف")

        account = db.query(Account).filter(Account.code == line.account_code, Account.is_active == True).first()
        if not account:
            raise HTTPException(status_code=400, detail=f"السطر {index}: الحساب غير موجود أو غير نشط")
        if is_cash_or_bank(account) and user_role(user) not in CASH_ALLOWED_ROLES:
            raise HTTPException(status_code=403, detail="استخدام حساب الصندوق أو البنك في سند التسوية يتطلب صلاحية مدير أو محاسب رئيسي")

        total_debit += debit
        total_credit += credit
        validated.append(
            {
                "account": account,
                "debit": debit,
                "credit": credit,
                "project_id": line.project_id,
                "cost_center_id": line.cost_center_id,
                "party_type": None if line.party_type == "none" else line.party_type,
                "party_id": line.party_id,
                "description": line.description,
            }
        )

    if False:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند تسوية بدون سطرين على الأقل")
    if total_debit != total_credit:
        raise HTTPException(status_code=400, detail="سند التسوية غير متوازن: إجمالي المدين لا يساوي إجمالي الدائن")

    return validated


def create_journal_entry(db: Session, voucher: AdjustmentVoucher, user_id: int) -> JournalEntry:
    exists = (
        db.query(JournalEntry)
        .filter(JournalEntry.source_type == "adjustment_voucher", JournalEntry.source_id == voucher.id)
        .first()
    )
    if exists:
        raise HTTPException(status_code=400, detail="تم إنشاء قيد محاسبي لهذا السند مسبقًا")

    lines = (
        db.query(AdjustmentVoucherLine)
        .filter(AdjustmentVoucherLine.voucher_id == voucher.id)
        .order_by(AdjustmentVoucherLine.id.asc())
        .all()
    )
    total_debit = money(sum(dec(line.debit) for line in lines))
    total_credit = money(sum(dec(line.credit) for line in lines))
    if total_debit != total_credit:
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند تسوية غير متوازن")

    entry = JournalEntry(
        entry_no=next_document_no(db, "journal_entry", document_date=voucher.date),
        entry_date=voucher.date,
        source_type="adjustment_voucher",
        source_id=voucher.id,
        description=voucher.description,
        status="posted",
        total_debit=total_debit,
        total_credit=total_credit,
        created_by=user_id,
    )
    db.add(entry)
    db.flush()

    for line in lines:
        db.add(
            JournalEntryLine(
                journal_entry_id=entry.id,
                account_code=line.account_code,
                account_name=line.account_name,
                debit=line.debit,
                credit=line.credit,
                project_id=line.project_id,
                cost_center_id=line.cost_center_id,
                party_type=line.party_type,
                party_id=line.party_id,
                description=line.description or voucher.description,
            )
        )
        if line.project_id and dec(line.debit) > 0:
            db.add(
                ProjectCost(
                    project_id=line.project_id,
                    cost_center_id=line.cost_center_id,
                    date=voucher.date,
                    category=voucher.reason,
                    amount=line.debit,
                    source_type="adjustment_voucher",
                    source_id=voucher.id,
                    notes=line.description or voucher.description,
                )
            )

    _assert_journal_entry_balanced(db, entry.id)

    return entry


@router.get("")
def list_adjustment_vouchers(db: Session = Depends(get_db), user=Depends(get_current_user)):
    require_adjustment_user(user)
    ensure_adjustment_schema(db)
    vouchers = db.query(AdjustmentVoucher).order_by(AdjustmentVoucher.id.desc()).limit(300).all()
    return [voucher_payload(db, voucher) for voucher in vouchers]


@router.post("")
def create_adjustment_voucher(data: AdjustmentVoucherCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    require_adjustment_user(user)
    ensure_adjustment_schema(db)
    assert_period_open(db, data.date, user=user)
    validated_lines = validate_lines(db, data, user)
    voucher = AdjustmentVoucher(
        voucher_no=next_adjustment_no(db, data.date),
        date=data.date,
        reason=data.reason,
        description=data.description.strip(),
        attachment_url=data.attachment,
        status="draft",
        created_by=user.id,
    )
    db.add(voucher)
    db.flush()

    for item in validated_lines:
        account = item["account"]
        db.add(
            AdjustmentVoucherLine(
                voucher_id=voucher.id,
                account_code=account.code,
                account_name=account.name,
                debit=item["debit"],
                credit=item["credit"],
                project_id=item["project_id"],
                cost_center_id=item["cost_center_id"],
                party_type=item["party_type"],
                party_id=item["party_id"],
                description=item["description"],
            )
        )

    db.add(AuditLog(user_id=user.id, action="create_adjustment_voucher", entity="adjustment_voucher", entity_id=voucher.id, details=voucher.voucher_no))
    db.commit()
    db.refresh(voucher)
    return voucher_payload(db, voucher)


@router.get("/{voucher_id}")
def get_adjustment_voucher(voucher_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    require_adjustment_user(user)
    return voucher_payload(db, load_voucher(db, voucher_id))


@router.post("/{voucher_id}/approve")
def approve_adjustment_voucher(voucher_id: int, db: Session = Depends(get_db), user=Depends(require_permission("approve_adjustment_journal"))):
    voucher = load_voucher(db, voucher_id)
    assert_period_open(db, voucher.date, user=user)
    if voucher.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد سند غير مسودة")
    create_journal_entry(db, voucher, user.id)
    voucher.status = "approved"
    voucher.approved_by = user.id
    voucher.approved_at = datetime.utcnow()
    db.add(AuditLog(user_id=user.id, action="approve_adjustment_voucher", entity="adjustment_voucher", entity_id=voucher.id, details=voucher.voucher_no))
    db.commit()
    db.refresh(voucher)
    return voucher_payload(db, voucher)


@router.post("/{voucher_id}/reject")
def reject_adjustment_voucher(voucher_id: int, data: AdjustmentVoucherRejectRequest | None = None, db: Session = Depends(get_db), user=Depends(require_permission("approve_adjustment_journal"))):
    voucher = load_voucher(db, voucher_id)
    if voucher.status != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن رفض سند غير مسودة")
    voucher.status = "rejected"
    voucher.rejected_by = user.id
    voucher.rejected_at = datetime.utcnow()
    db.add(AuditLog(user_id=user.id, action="reject_adjustment_voucher", entity="adjustment_voucher", entity_id=voucher.id, details=(data.reason if data else None) or voucher.voucher_no))
    db.commit()
    db.refresh(voucher)
    return voucher_payload(db, voucher)


@router.post("/{voucher_id}/reverse")
def reverse_adjustment_voucher(voucher_id: int, data: AdjustmentVoucherReverseRequest, db: Session = Depends(get_db), user=Depends(require_permission("approve_adjustment_journal"))):
    voucher = load_voucher(db, voucher_id)
    if voucher.status != "approved":
        raise HTTPException(status_code=400, detail="لا يمكن عكس سند غير معتمد")
    lines = db.query(AdjustmentVoucherLine).filter(AdjustmentVoucherLine.voucher_id == voucher.id).all()
    reverse_data = AdjustmentVoucherCreate(
        date=voucher.date,
        reason="error_correction",
        description=f"قيد عكسي لسند {voucher.voucher_no}: {data.reason}",
        lines=[
            {
                "account_code": line.account_code,
                "debit": line.credit,
                "credit": line.debit,
                "project_id": line.project_id,
                "cost_center_id": line.cost_center_id,
                "party_type": line.party_type,
                "party_id": line.party_id,
                "description": f"عكس: {line.description or voucher.description}",
            }
            for line in lines
        ],
    )
    validated_lines = validate_lines(db, reverse_data, user)
    reverse_voucher = AdjustmentVoucher(
        voucher_no=next_adjustment_no(db, voucher.date),
        date=voucher.date,
        reason=reverse_data.reason,
        description=reverse_data.description,
        attachment_url=None,
        status="approved",
        created_by=user.id,
        approved_by=user.id,
        approved_at=datetime.utcnow(),
        reversal_of_id=voucher.id,
    )
    db.add(reverse_voucher)
    db.flush()
    for item in validated_lines:
        account = item["account"]
        db.add(
            AdjustmentVoucherLine(
                voucher_id=reverse_voucher.id,
                account_code=account.code,
                account_name=account.name,
                debit=item["debit"],
                credit=item["credit"],
                project_id=item["project_id"],
                cost_center_id=item["cost_center_id"],
                party_type=item["party_type"],
                party_id=item["party_id"],
                description=item["description"],
            )
        )
    db.flush()
    create_journal_entry(db, reverse_voucher, user.id)
    voucher.status = "reversed"
    voucher.reversed_by = user.id
    voucher.reversed_at = datetime.utcnow()
    db.add(AuditLog(user_id=user.id, action="reverse_adjustment_voucher", entity="adjustment_voucher", entity_id=voucher.id, details=reverse_voucher.voucher_no))
    db.commit()
    db.refresh(reverse_voucher)
    return voucher_payload(db, reverse_voucher)
