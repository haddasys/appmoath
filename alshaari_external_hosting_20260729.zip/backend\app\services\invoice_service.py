from datetime import datetime
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy.orm import Session

from app.models.models import (
    Account,
    AuditLog,
    Customer,
    Invoice,
    InvoiceLine,
    JournalEntry,
    JournalEntryLine,
    Supplier,
)
from app.services.accounting_periods import assert_period_open
from app.services.document_sequence import next_document_no
from app.services.posting_engine import _assert_journal_entry_balanced


CUSTOMER_RECEIVABLE_ACCOUNT = "10301"
SUPPLIER_PAYABLE_ACCOUNT = "20101"
PROJECT_REVENUE_ACCOUNT = "40101"
INVENTORY_ACCOUNT = "10401"


def _decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _account(db: Session, code: str) -> Account:
    account = db.query(Account).filter(Account.code == code).first()
    if not account:
        raise HTTPException(status_code=400, detail=f"الحساب غير موجود في دليل الحسابات: {code}")
    return account


def _line_total(qty, unit_price, explicit_total=None) -> Decimal:
    if explicit_total is not None:
        return _decimal(explicit_total)
    return _decimal(qty) * _decimal(unit_price)


def _normalize_invoice_type(invoice_type: str) -> str:
    value = (invoice_type or "").strip()
    if value in {"customer", "customer_invoice", "sales"}:
        return "customer"
    if value in {"supplier", "supplier_invoice", "purchase"}:
        return "supplier"
    raise HTTPException(status_code=400, detail="نوع الفاتورة غير معتمد، يرجى الاختيار بين (فاتورة عميل) أو (فاتورة مورد)")


def create_invoice(db: Session, data, user_id: int) -> Invoice:
    invoice_type = _normalize_invoice_type(data.invoice_type)

    if invoice_type == "customer":
        if not db.query(Customer).filter(Customer.id == data.party_id).first():
            raise HTTPException(status_code=404, detail="العميل غير موجود")
        party_type = "customer"
    else:
        if not db.query(Supplier).filter(Supplier.id == data.party_id).first():
            raise HTTPException(status_code=404, detail="المورد غير موجود")
        party_type = "supplier"

    if not data.lines:
        raise HTTPException(status_code=400, detail="يجب إضافة بند واحد على الأقل للفاتورة")

    lines_payload = []
    total = Decimal("0")

    for line in data.lines:
        line_total = _line_total(line.qty, line.unit_price, line.total)
        if _decimal(line.qty) <= 0:
            raise HTTPException(status_code=400, detail="كمية بند الفاتورة يجب أن تكون أكبر من صفر")
        if line_total <= 0:
            raise HTTPException(status_code=400, detail="إجمالي بند الفاتورة يجب أن يكون أكبر من صفر")
        lines_payload.append((line, line_total))
        total += line_total

    if data.total and _decimal(data.total) != total:
        raise HTTPException(status_code=400, detail="إجمالي الفاتورة لا يساوي مجموع البنود")

    document_type = "sales_invoice" if invoice_type == "customer" else "supplier_invoice"
    invoice = Invoice(
        invoice_no=next_document_no(db, document_type, document_date=data.date),
        invoice_type=invoice_type,
        party_type=party_type,
        party_id=data.party_id,
        project_id=data.project_id,
        date=data.date,
        total=total,
        paid_amount=data.paid_amount,
        due_date=data.due_date,
        status="draft",
        notes=data.notes,
    )
    db.add(invoice)
    db.flush()

    for line, line_total in lines_payload:
        db.add(
            InvoiceLine(
                invoice_id=invoice.id,
                item_description=line.item_description,
                qty=line.qty,
                unit_price=line.unit_price,
                total=line_total,
                project_id=line.project_id or data.project_id,
                notes=line.notes,
            )
        )

    db.add(
        AuditLog(
            user_id=user_id,
            action="create_invoice",
            entity="invoice",
            entity_id=invoice.id,
            details=invoice.invoice_no,
        )
    )
    db.commit()
    db.refresh(invoice)
    return invoice


def _create_invoice_entry(db: Session, invoice: Invoice, user_id: int):
    if db.query(JournalEntry).filter(JournalEntry.source_type == "invoice", JournalEntry.source_id == invoice.id).first():
        raise HTTPException(status_code=400, detail="تم إنشاء قيد محاسبي لهذه الفاتورة مسبقًا")
    assert_period_open(db, invoice.date, user_id=user_id)

    amount = _decimal(invoice.total)
    if amount <= 0:
        raise HTTPException(status_code=400, detail="لا يمكن ترحيل فاتورة بمبلغ صفر")

    if invoice.invoice_type == "customer":
        debit = _account(db, CUSTOMER_RECEIVABLE_ACCOUNT)
        credit = _account(db, PROJECT_REVENUE_ACCOUNT)
    elif invoice.invoice_type == "supplier":
        debit = _account(db, INVENTORY_ACCOUNT)
        credit = _account(db, SUPPLIER_PAYABLE_ACCOUNT)
    else:
        raise HTTPException(status_code=400, detail="نوع الفاتورة غير معروف")

    entry = JournalEntry(
        entry_no=next_document_no(db, "journal_entry", document_date=invoice.date),
        entry_date=invoice.date,
        description=f"ترحيل فاتورة {invoice.invoice_no}",
        source_type="invoice",
        source_id=invoice.id,
        status="posted",
        total_debit=amount,
        total_credit=amount,
        created_by=user_id,
    )
    db.add(entry)
    db.flush()

    db.add(
        JournalEntryLine(
            journal_entry_id=entry.id,
            account_code=debit.code,
            account_name=debit.name,
            debit=amount,
            credit=0,
            project_id=invoice.project_id,
            party_type=invoice.party_type,
            party_id=invoice.party_id,
            description=invoice.notes,
        )
    )
    db.add(
        JournalEntryLine(
            journal_entry_id=entry.id,
            account_code=credit.code,
            account_name=credit.name,
            debit=0,
            credit=amount,
            project_id=invoice.project_id,
            party_type=invoice.party_type,
            party_id=invoice.party_id,
            description=invoice.notes,
        )
    )
    _assert_journal_entry_balanced(db, entry.id)
    return entry


def post_invoice(db: Session, invoice_id: int, user_id: int) -> Invoice:
    invoice = db.query(Invoice).filter(Invoice.id == invoice_id).first()
    if not invoice:
        raise HTTPException(status_code=404, detail="الفاتورة غير موجودة")

    if invoice.status == "posted":
        raise HTTPException(status_code=400, detail="الفاتورة مرحلة مسبقًا")

    if invoice.status not in {"draft", "open"}:
        raise HTTPException(status_code=400, detail="لا يمكن ترحيل هذه الفاتورة بحالتها الحالية")

    if not db.query(InvoiceLine).filter(InvoiceLine.invoice_id == invoice.id).first():
        raise HTTPException(status_code=400, detail="لا يمكن ترحيل فاتورة بدون بنود")

    _create_invoice_entry(db, invoice, user_id)
    invoice.status = "posted"
    invoice.posted_by = user_id
    invoice.posted_at = datetime.utcnow()

    db.add(
        AuditLog(
            user_id=user_id,
            action="post_invoice",
            entity="invoice",
            entity_id=invoice.id,
            details=invoice.invoice_no,
        )
    )
    db.commit()
    db.refresh(invoice)
    return invoice


def invoice_to_dict(db: Session, invoice: Invoice) -> dict:
    result = {c.name: getattr(invoice, c.name) for c in invoice.__table__.columns}
    lines = db.query(InvoiceLine).filter(InvoiceLine.invoice_id == invoice.id).order_by(InvoiceLine.id).all()
    result["lines"] = [{c.name: getattr(line, c.name) for c in line.__table__.columns} for line in lines]
    return result
