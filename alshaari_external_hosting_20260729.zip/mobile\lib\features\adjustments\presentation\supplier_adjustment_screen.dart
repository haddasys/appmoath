import 'package:flutter/material.dart';

import 'adjustment_voucher_screen.dart';

class SupplierAdjustmentScreen extends StatelessWidget {
  const SupplierAdjustmentScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return const AdjustmentVoucherScreen();
  }
}
