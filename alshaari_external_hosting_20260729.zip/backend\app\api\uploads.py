from fastapi import APIRouter, UploadFile, File, Depends
from sqlalchemy.orm import Session
from app.core.deps import get_current_user
from app.db.database import get_db
from app.models.models import Attachment
import os, shutil
from pathlib import Path

router = APIRouter(tags=["Attachments"])
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)

def _store_attachment(entity: str, entity_id: int, file: UploadFile, user, db: Session):
    safe_name = file.filename.replace("/", "_").replace("\\", "_")
    path = UPLOAD_DIR / f"{entity}_{entity_id}_{safe_name}"
    with path.open("wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    attachment = Attachment(
        entity=entity,
        entity_type=entity,
        entity_id=entity_id,
        file_name=safe_name,
        file_url=str(path),
        file_path=str(path),
        file_type=file.content_type,
        uploaded_by=user.id,
    )
    db.add(attachment)
    db.commit()
    db.refresh(attachment)
    return {
        "id": attachment.id,
        "file_name": safe_name,
        "file_url": str(path),
        "file_path": str(path),
        "file_type": file.content_type,
        "entity_type": entity,
        "entity_id": entity_id,
    }

@router.post("/attachments/upload")
def upload_file(entity: str, entity_id: int, file: UploadFile = File(...), user=Depends(get_current_user), db: Session = Depends(get_db)):
    return _store_attachment(entity, entity_id, file, user, db)

@router.post("/api/v1/attachments/upload")
def upload_file_v1(entity: str, entity_id: int, file: UploadFile = File(...), user=Depends(get_current_user), db: Session = Depends(get_db)):
    return _store_attachment(entity, entity_id, file, user, db)
