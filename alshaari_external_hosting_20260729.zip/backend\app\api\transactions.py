from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.db.database import get_db
from app.core.deps import get_current_user, require_manager_or_accountant
from app.models.models import Transaction
from app.schemas.schemas import TransactionCreate
from app.services.transaction_service import (
    approve_transaction,
    create_transaction,
    delete_transaction_draft,
    reject_transaction,
    update_transaction_draft,
)

router = APIRouter(prefix="/transactions", tags=["Transactions"])

@router.post("")
def add_transaction(data: TransactionCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return create_transaction(db, data, user.id)

@router.put("/{transaction_id}")
def update(transaction_id: int, data: TransactionCreate, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return update_transaction_draft(db, transaction_id, data, user.id)

@router.delete("/{transaction_id}")
def delete(transaction_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return delete_transaction_draft(db, transaction_id, user.id)

@router.get("")
def list_transactions(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return db.query(Transaction).order_by(Transaction.id.desc()).limit(200).all()

@router.patch("/{transaction_id}/approve")
def approve(transaction_id: int, db: Session = Depends(get_db), user=Depends(require_manager_or_accountant)):
    return approve_transaction(db, transaction_id, user.id)

@router.patch("/{transaction_id}/reject")
def reject(transaction_id: int, db: Session = Depends(get_db), user=Depends(require_manager_or_accountant)):
    return reject_transaction(db, transaction_id, user.id)
