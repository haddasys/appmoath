from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.db.database import engine
from app.models.models import Attendance, Employee, EmployeeAdjustment, Payroll, PayrollPeriod


PAYROLL_ACCOUNTS = [
    ("20201", "أجور مستحقة للعمال", "liability", "YER", None),
    ("20203", "عهد وسلف العمال", "asset", "YER", None),
    ("50201", "أجور مباشرة للمشاريع", "cost", "YER", None),
    ("60301", "مصروف أجور عام", "expense", "YER", None),
]


def _has_table(db: Session, table_name: str) -> bool:
    return inspect(db.get_bind()).has_table(table_name)


def _columns(db: Session, table_name: str) -> set[str]:
    if not _has_table(db, table_name):
        return set()
    return {column["name"] for column in inspect(db.get_bind()).get_columns(table_name)}


def _add_column_if_missing(
    db: Session, table_name: str, column_name: str, definition: str
) -> None:
    if column_name not in _columns(db, table_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def _seed_payroll_accounts(db: Session) -> None:
    for code, name, account_type, currency, parent_code in PAYROLL_ACCOUNTS:
        db.execute(
            text(
                """
                INSERT INTO accounts (code, name, type, currency, balance, parent_code, is_active)
                VALUES (:code, :name, :type, :currency, 0, :parent_code, TRUE)
                ON CONFLICT (code) DO UPDATE SET
                    name = EXCLUDED.name,
                    type = EXCLUDED.type,
                    currency = EXCLUDED.currency,
                    parent_code = EXCLUDED.parent_code,
                    is_active = TRUE
                """
            ),
            {
                "code": code,
                "name": name,
                "type": account_type,
                "currency": currency,
                "parent_code": parent_code,
            },
        )


def ensure_payroll_schema(db: Session) -> None:
    Employee.__table__.create(bind=engine, checkfirst=True)
    Attendance.__table__.create(bind=engine, checkfirst=True)
    Payroll.__table__.create(bind=engine, checkfirst=True)
    EmployeeAdjustment.__table__.create(bind=engine, checkfirst=True)
    PayrollPeriod.__table__.create(bind=engine, checkfirst=True)

    if _has_table(db, "employees"):
        _add_column_if_missing(db, "employees", "department", "VARCHAR(80)")
        _add_column_if_missing(db, "employees", "monthly_wage", "NUMERIC(14, 2)")
        _add_column_if_missing(db, "employees", "friday_included", "BOOLEAN DEFAULT FALSE")
        _add_column_if_missing(db, "employees", "qat_allowance_daily", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "employees", "transport_allowance_daily", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "employees", "food_allowance_daily", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "employees", "is_active", "BOOLEAN DEFAULT TRUE")
        _add_column_if_missing(db, "employees", "created_at", "TIMESTAMP")

    if _has_table(db, "attendance"):
        _add_column_if_missing(db, "attendance", "cost_center_id", "INTEGER")
        _add_column_if_missing(db, "attendance", "created_by", "INTEGER")
        _add_column_if_missing(db, "attendance", "created_at", "TIMESTAMP")
        _add_column_if_missing(db, "attendance", "updated_at", "TIMESTAMP")
        db.execute(
            text(
                """
                CREATE UNIQUE INDEX IF NOT EXISTS ux_attendance_employee_date
                ON attendance (employee_id, date)
                WHERE employee_id IS NOT NULL
                """
            )
        )

    db.execute(
        text(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS ux_payroll_period_year_month
            ON payroll_periods (year, month)
            """
        )
    )

    if _has_table(db, "payrolls"):
        _add_column_if_missing(db, "payrolls", "payroll_no", "VARCHAR(80)")
        _add_column_if_missing(db, "payrolls", "payroll_period_id", "INTEGER")
        _add_column_if_missing(db, "payrolls", "daily_wage", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "friday_included", "BOOLEAN DEFAULT FALSE")
        _add_column_if_missing(db, "payrolls", "worked_days", "NUMERIC(8, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "paid_fridays", "NUMERIC(8, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "half_days", "NUMERIC(8, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "absent_days", "NUMERIC(8, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "gross_wage", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "qat_allowance_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "transport_allowance_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "food_allowance_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "bonuses_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "deductions_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "advances_total", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "net_due", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "paid_amount", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "remaining_due", "NUMERIC(14, 2) DEFAULT 0")
        _add_column_if_missing(db, "payrolls", "approved_by", "INTEGER")
        _add_column_if_missing(db, "payrolls", "approved_at", "TIMESTAMP")
        _add_column_if_missing(db, "payrolls", "paid_by", "INTEGER")
        _add_column_if_missing(db, "payrolls", "paid_at", "TIMESTAMP")
        _add_column_if_missing(db, "payrolls", "cash_account_id", "INTEGER")
        _add_column_if_missing(db, "payrolls", "created_at", "TIMESTAMP")

    _seed_payroll_accounts(db)
    db.commit()
