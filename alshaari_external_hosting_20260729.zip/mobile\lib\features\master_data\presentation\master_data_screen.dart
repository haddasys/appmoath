import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../../../core/network/api_client.dart';
import '../../../core/widgets/empty_state.dart';

class MasterDataScreen extends StatefulWidget {
  final int initialTab;
  const MasterDataScreen({super.key, this.initialTab = 0});
  @override
  State<MasterDataScreen> createState() => _MasterDataScreenState();
}

class _MasterDataScreenState extends State<MasterDataScreen>
    with SingleTickerProviderStateMixin {
  late final TabController controller;
  final money = NumberFormat.decimalPattern('ar');
  int refreshKey = 0;
  static const numericFields = {
    'contract_value',
    'daily_wage',
    'monthly_salary',
    'current_qty',
    'avg_cost',
    'reorder_level',
    'balance',
    'opening_balance',
    'budget_amount',
  };
  static const integerFields = {
    'customer_id',
    'responsible_id',
    'responsible_user_id',
    'parent_id',
    'progress_percent',
  };
  static const booleanFields = {
    'is_active',
    'is_postable',
  };

  @override
  void initState() {
    super.initState();
    controller = TabController(
        length: 9, vsync: this, initialIndex: widget.initialTab.clamp(0, 8));
  }

  Future<List<dynamic>> fetch(String path) async =>
      (await apiClient.dio.get(path)).data as List<dynamic>;
  Future<Map<String, dynamic>> fetchProjectCosts(int projectId) async =>
      Map<String, dynamic>.from(
          (await apiClient.dio.get('/projects/$projectId/costs')).data as Map);
  void refresh() => setState(() => refreshKey++);

  double asDouble(dynamic value) {
    if (value is num) return value.toDouble();
    return double.tryParse('$value') ?? 0;
  }

  String moneyText(dynamic value) => '${money.format(asDouble(value))} YER';

  dynamic fieldValue(String key, String value) {
    final trimmed = value.trim();
    if (numericFields.contains(key)) return double.tryParse(trimmed) ?? 0;
    if (integerFields.contains(key)) {
      return trimmed.isEmpty ? null : int.tryParse(trimmed);
    }
    if (booleanFields.contains(key)) {
      if (trimmed.isEmpty) return true;
      return ['1', 'true', 'yes', 'نعم', 'نشط'].contains(trimmed.toLowerCase());
    }
    return trimmed;
  }

  Future<void> saveSimple(
    String title,
    String path,
    Map<String, String> fields, {
    Map<String, dynamic>? initial,
    Map<String, dynamic>? extra,
  }) async {
    final controllers = {
      for (final k in fields.keys) k: TextEditingController()
    };
    initial?.forEach((key, value) {
      if (controllers.containsKey(key) && value != null) {
        controllers[key]!.text = '$value';
      }
    });
    await showDialog(
        context: context,
        builder: (_) => AlertDialog(
              title: Text(initial == null ? 'إضافة $title' : 'تعديل $title'),
              content: SingleChildScrollView(
                  child: Column(
                      mainAxisSize: MainAxisSize.min,
                      children: fields.entries
                          .map((e) => Padding(
                              padding: const EdgeInsets.only(bottom: 10),
                              child: TextField(
                                  controller: controllers[e.key],
                                  decoration:
                                      InputDecoration(labelText: e.value))))
                          .toList())),
              actions: [
                TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('إلغاء')),
                FilledButton(
                    onPressed: () async {
                      final data = <String, dynamic>{};
                      controllers.forEach((k, c) {
                        data[k] = fieldValue(k, c.text);
                      });
                      if (extra != null) data.addAll(extra);
                      try {
                        if (initial == null) {
                          await apiClient.dio.post(path, data: data);
                        } else {
                          await apiClient.dio
                              .put('$path/${initial['id']}', data: data);
                        }
                        if (!mounted) return;
                        Navigator.pop(context);
                        refresh();
                        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
                            content: Text(initial == null
                                ? 'تمت الإضافة'
                                : 'تم التعديل')));
                      } catch (e) {
                        if (!mounted) return;
                        ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text('فشل الحفظ: $e')));
                      }
                    },
                    child: const Text('حفظ'))
              ],
            ));
  }

  Widget list(String title, String path, Map<String, String> fields,
          String Function(Map<String, dynamic>) subtitle) =>
      Column(children: [
        Padding(
            padding: const EdgeInsets.all(12),
            child: SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                    onPressed: () => saveSimple(title, path, fields),
                    icon: const Icon(Icons.add),
                    label: Text('إضافة $title')))),
        Expanded(
            child: FutureBuilder<List<dynamic>>(
                key: ValueKey('$path-$refreshKey'),
                future: fetch(path),
                builder: (_, s) {
                  if (s.connectionState == ConnectionState.waiting) {
                    return const Center(child: CircularProgressIndicator());
                  }
                  if (s.hasError) return Center(child: Text('خطأ: ${s.error}'));
                  final data = s.data ?? [];
                  if (data.isEmpty) return EmptyState('لا توجد بيانات');
                  return ListView.separated(
                      itemCount: data.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final e = Map<String, dynamic>.from(data[i] as Map);
                        final name = e['name'] ??
                            e['project_code'] ??
                            e['code'] ??
                            e['key'] ??
                            'عنصر';
                        return ListTile(
                          leading: CircleAvatar(child: Text('${e['id']}')),
                          title: Text('$name'),
                          subtitle: Text(subtitle(e)),
                          trailing: IconButton(
                            tooltip: 'تعديل',
                            icon: const Icon(Icons.edit_outlined),
                            onPressed: () =>
                                saveSimple(title, path, fields, initial: e),
                          ),
                          onTap: () =>
                              saveSimple(title, path, fields, initial: e),
                        );
                      });
                }))
      ]);

  Widget projectMetric(String title, String value, IconData icon, Color color) {
    return Container(
      constraints: const BoxConstraints(minHeight: 74),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: color.withOpacity(.08),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: color.withOpacity(.22)),
      ),
      child: Row(children: [
        Icon(icon, color: color),
        const SizedBox(width: 10),
        Expanded(
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
              Text(title, style: Theme.of(context).textTheme.bodySmall),
              const SizedBox(height: 4),
              Text(value,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: Theme.of(context)
                      .textTheme
                      .titleMedium
                      ?.copyWith(fontWeight: FontWeight.w900)),
            ])),
      ]),
    );
  }

  Future<void> addProjectEstimate(int projectId) async {
    final amountController = TextEditingController();
    final descriptionController = TextEditingController();
    final notesController = TextEditingController();
    var estimateType = 'material';
    const estimateTypes = [
      ('material', 'مواد متوقعة'),
      ('labor', 'أجور متوقعة'),
      ('service', 'خدمات متوقعة'),
      ('direct_expense', 'مصاريف مباشرة متوقعة'),
      ('other', 'أخرى / احتياطي هالك'),
    ];

    try {
      await showDialog(
        context: context,
        builder: (_) => StatefulBuilder(
          builder: (context, setLocal) {
            return AlertDialog(
              title: const Text('إضافة تكلفة مقدرة'),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    DropdownButtonFormField<String>(
                      initialValue: estimateType,
                      decoration: const InputDecoration(
                        labelText: 'نوع التقدير',
                      ),
                      items: estimateTypes
                          .map(
                            (item) => DropdownMenuItem<String>(
                              value: item.$1,
                              child: Text(item.$2),
                            ),
                          )
                          .toList(),
                      onChanged: (value) {
                        if (value != null) {
                          setLocal(() => estimateType = value);
                        }
                      },
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: descriptionController,
                      decoration: const InputDecoration(
                        labelText: 'البيان',
                        hintText: 'مثال: ألواح MDF ومستلزمات المشروع',
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: amountController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'المبلغ المقدر',
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: notesController,
                      minLines: 2,
                      maxLines: 3,
                      decoration: const InputDecoration(
                        labelText: 'ملاحظات',
                      ),
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('إلغاء'),
                ),
                FilledButton.icon(
                  icon: const Icon(Icons.save_outlined),
                  label: const Text('حفظ التقدير'),
                  onPressed: () async {
                    final amount = double.tryParse(amountController.text);
                    final description = descriptionController.text.trim();
                    if (amount == null || amount <= 0 || description.isEmpty) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('أدخل البيان والمبلغ المقدر بشكل صحيح.'),
                        ),
                      );
                      return;
                    }

                    try {
                      await apiClient.dio.post(
                        '/projects/$projectId/estimates',
                        data: {
                          'estimate_type': estimateType,
                          'description': description,
                          'estimated_amount': amount,
                          'notes': notesController.text.trim(),
                        },
                      );
                      if (!mounted) return;
                      Navigator.pop(context);
                      refresh();
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content: Text('تم حفظ التكلفة المقدرة بنجاح.'),
                        ),
                      );
                    } catch (error) {
                      if (!mounted) return;
                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(content: Text('فشل حفظ التقدير: $error')),
                      );
                    }
                  },
                ),
              ],
            );
          },
        ),
      );
    } finally {
      amountController.dispose();
      descriptionController.dispose();
      notesController.dispose();
    }
  }

  Widget projectCard(Map<String, dynamic> project, Map<String, String> fields) {
    final projectId = project['id'] as int;
    final contractValue = asDouble(project['contract_value']);
    final progress = asDouble(project['progress_percent']).clamp(0, 100);
    final status = '${project['status'] ?? 'active'}';
    final statusLabel = switch (status) {
      'closed' => 'مغلق ماليًا',
      'delivered' => 'تم التسليم',
      'ready_for_delivery' => 'جاهز للتسليم',
      'in_production' => 'قيد الإنتاج',
      'blocked' => 'متوقف',
      _ => 'نشط',
    };

    return FutureBuilder<Map<String, dynamic>>(
      future: fetchProjectCosts(projectId),
      builder: (context, snapshot) {
        final costs = snapshot.data;
        final totalCollected = asDouble(costs?['total_collected']);
        final remaining = asDouble(costs?['remaining_customer_balance']);
        final estimatedTotal = asDouble(costs?['estimated_total_cost']);
        final totalCost =
            asDouble(costs?['actual_total_cost'] ?? costs?['total']);
        final materials =
            asDouble(costs?['actual_material_cost'] ?? costs?['materials']);
        final labor = asDouble(costs?['actual_labor_cost'] ?? costs?['labor']);
        final service = asDouble(costs?['actual_service_cost']);
        final directExpense = asDouble(costs?['actual_direct_expense']);
        final adjustments = asDouble(costs?['actual_adjustments']);
        final profit = asDouble(costs?['actual_profit']);
        final margin = asDouble(costs?['actual_profit_percent']);
        final costVariance = asDouble(costs?['cost_variance']);
        final isOverBudget = costs?['is_over_budget'] == true;
        final isLoss = profit < 0;
        final comparison = costs?['comparison'] is List
            ? List<dynamic>.from(costs!['comparison'] as List)
            : const <dynamic>[];

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(children: [
                    Container(
                      width: 44,
                      height: 44,
                      decoration: BoxDecoration(
                          color: const Color(0xFFB87E62).withOpacity(.14),
                          borderRadius: BorderRadius.circular(12)),
                      child: const Icon(Icons.work_outline,
                          color: Color(0xFFB87E62)),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                        child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                          Text('${project['name'] ?? 'مشروع'}',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleMedium
                                  ?.copyWith(fontWeight: FontWeight.w900)),
                          const SizedBox(height: 3),
                          Text(
                              'الكود: ${project['project_code'] ?? '-'} | الحالة: $statusLabel',
                              style: Theme.of(context).textTheme.bodySmall),
                        ])),
                    Wrap(
                      spacing: 4,
                      children: [
                        IconButton(
                          tooltip: 'إضافة تكلفة مقدرة',
                          icon: const Icon(Icons.calculate_outlined),
                          onPressed: () => addProjectEstimate(projectId),
                        ),
                        IconButton(
                          tooltip: 'تعديل المشروع',
                          icon: const Icon(Icons.edit_outlined),
                          onPressed: () => saveSimple(
                            'مشروع',
                            '/projects',
                            fields,
                            initial: project,
                          ),
                        ),
                      ],
                    ),
                  ]),
                  const SizedBox(height: 12),
                  ClipRRect(
                    borderRadius: BorderRadius.circular(99),
                    child: LinearProgressIndicator(
                        value: progress / 100,
                        minHeight: 8,
                        backgroundColor: Colors.black.withOpacity(.08),
                        color: const Color(0xFFB87E62)),
                  ),
                  const SizedBox(height: 6),
                  Text('نسبة الإنجاز: ${progress.toStringAsFixed(0)}%'),
                  const SizedBox(height: 12),
                  if (snapshot.connectionState == ConnectionState.waiting)
                    const Padding(
                        padding: EdgeInsets.symmetric(vertical: 12),
                        child: Center(child: CircularProgressIndicator()))
                  else if (snapshot.hasError)
                    Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                          color: Colors.orange.withOpacity(.1),
                          borderRadius: BorderRadius.circular(12)),
                      child: const Text(
                          'تعذر تحميل تكلفة المشروع، سيتم عرض بيانات العقد فقط.'),
                    )
                  else ...[
                    if (isOverBudget) ...[
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          color: Colors.red.withOpacity(.08),
                          borderRadius: BorderRadius.circular(12),
                          border:
                              Border.all(color: Colors.red.withOpacity(.22)),
                        ),
                        child: Row(
                          children: [
                            Icon(Icons.warning_amber_outlined,
                                color: Colors.red.shade700),
                            const SizedBox(width: 10),
                            Expanded(
                              child: Text(
                                '${costs?['over_budget_message'] ?? 'تكلفة المشروع الفعلية تجاوزت التكلفة المقدرة'}: ${moneyText(costVariance)}',
                                style: TextStyle(
                                  color: Colors.red.shade700,
                                  fontWeight: FontWeight.w900,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(height: 12),
                    ],
                    LayoutBuilder(builder: (context, constraints) {
                      final width = constraints.maxWidth > 720
                          ? (constraints.maxWidth - 24) / 3
                          : constraints.maxWidth;
                      return Wrap(spacing: 12, runSpacing: 12, children: [
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'قيمة العقد',
                                moneyText(contractValue),
                                Icons.assignment_outlined,
                                const Color(0xFF1C1C1C))),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'المقبوض',
                                moneyText(totalCollected),
                                Icons.south_west,
                                Colors.green.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'المتبقي على العميل',
                                moneyText(remaining),
                                Icons.person_search_outlined,
                                Colors.blueGrey.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'التكلفة المقدرة',
                                moneyText(estimatedTotal),
                                Icons.calculate_outlined,
                                Colors.indigo.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'التكلفة الفعلية',
                                moneyText(totalCost),
                                Icons.receipt_long_outlined,
                                const Color(0xFFB87E62))),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'الربح الفعلي',
                                '${moneyText(profit)} | ${margin.toStringAsFixed(1)}%',
                                isLoss
                                    ? Icons.trending_down
                                    : Icons.trending_up,
                                isLoss
                                    ? Colors.red.shade700
                                    : Colors.green.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'مواد',
                                moneyText(materials),
                                Icons.inventory_2_outlined,
                                Colors.blueGrey.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'عمالة',
                                moneyText(labor),
                                Icons.engineering_outlined,
                                Colors.indigo.shade700)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'خدمات ومصاريف مباشرة',
                                moneyText(service + directExpense),
                                Icons.account_tree_outlined,
                                Colors.orange.shade800)),
                        SizedBox(
                            width: width,
                            child: projectMetric(
                                'تسويات',
                                moneyText(adjustments),
                                Icons.tune_outlined,
                                Colors.purple.shade700)),
                      ]);
                    }),
                    if (comparison.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Text('مقارنة المقدر بالفعلي',
                          style: Theme.of(context)
                              .textTheme
                              .titleSmall
                              ?.copyWith(fontWeight: FontWeight.w900)),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 8),
                        decoration: BoxDecoration(
                          color: Colors.black.withOpacity(.04),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: const Row(children: [
                          Expanded(flex: 2, child: Text('نوع التكلفة')),
                          Expanded(child: Text('المقدر')),
                          Expanded(child: Text('الفعلي')),
                          Expanded(child: Text('الفرق')),
                        ]),
                      ),
                      ...comparison.map((raw) {
                        final row = Map<String, dynamic>.from(raw as Map);
                        final variance = asDouble(row['variance']);
                        final danger = variance > 0;
                        return Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 7),
                          child: Row(children: [
                            Expanded(
                                flex: 2,
                                child: Text('${row['label'] ?? 'غير مصنف'}')),
                            Expanded(child: Text(moneyText(row['estimated']))),
                            Expanded(child: Text(moneyText(row['actual']))),
                            Expanded(
                              child: Text(
                                moneyText(variance),
                                style: TextStyle(
                                  color: danger
                                      ? Colors.red.shade700
                                      : Colors.green.shade700,
                                  fontWeight: FontWeight.w800,
                                ),
                              ),
                            ),
                          ]),
                        );
                      }),
                      if (estimatedTotal == 0) ...[
                        const SizedBox(height: 8),
                        OutlinedButton.icon(
                          onPressed: () => addProjectEstimate(projectId),
                          icon: const Icon(Icons.add_chart_outlined),
                          label: const Text(
                            'أضف التكاليف المقدرة لقراءة فرق التكلفة بدقة',
                          ),
                        ),
                      ],
                    ],
                  ],
                ]),
          ),
        );
      },
    );
  }

  Widget projectsList() {
    final fields = {
      'project_code': 'كود المشروع',
      'name': 'اسم المشروع',
      'customer_id': 'رقم العميل',
      'project_type': 'نوع المشروع',
      'contract_value': 'قيمة العقد',
      'status': 'الحالة',
      'progress_percent': 'نسبة الإنجاز',
      'notes': 'ملاحظات',
    };
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Row(children: [
          Expanded(
              child: Text('المشاريع وربحيتها',
                  style: Theme.of(context)
                      .textTheme
                      .titleLarge
                      ?.copyWith(fontWeight: FontWeight.w900))),
          FilledButton.icon(
              onPressed: () => saveSimple('مشروع', '/projects', fields),
              icon: const Icon(Icons.add),
              label: const Text('إضافة مشروع')),
        ]),
      ),
      Expanded(
        child: FutureBuilder<List<dynamic>>(
          key: ValueKey('projects-$refreshKey'),
          future: fetch('/projects'),
          builder: (_, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            if (snapshot.hasError) {
              return Center(
                  child: Text('تعذر تحميل المشاريع: ${snapshot.error}'));
            }
            final data = snapshot.data ?? [];
            if (data.isEmpty) return EmptyState('لا توجد مشاريع حتى الآن');
            return RefreshIndicator(
              onRefresh: () async => refresh(),
              child: ListView.builder(
                itemCount: data.length,
                itemBuilder: (_, index) => projectCard(
                    Map<String, dynamic>.from(data[index] as Map), fields),
              ),
            );
          },
        ),
      ),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
            title: const Text('إدارة البيانات الأساسية'),
            actions: [
              IconButton(onPressed: refresh, icon: const Icon(Icons.refresh))
            ],
            bottom:
                TabBar(controller: controller, isScrollable: true, tabs: const [
              Tab(text: 'العملاء'),
              Tab(text: 'الموردين'),
              Tab(text: 'العمال'),
              Tab(text: 'الموظفين'),
              Tab(text: 'المشاريع'),
              Tab(text: 'المخزون'),
              Tab(text: 'الحسابات'),
              Tab(text: 'حسابات النقدية'),
              Tab(text: 'مراكز التكلفة')
            ])),
        body: TabBarView(controller: controller, children: [
          list(
              'عميل',
              '/customers',
              {
                'name': 'اسم العميل',
                'phone': 'الهاتف',
                'address': 'العنوان',
                'customer_type': 'نوع العميل',
                'notes': 'ملاحظات'
              },
              (e) => 'هاتف: ${e['phone'] ?? '-'}'),
          list(
              'مورد',
              '/suppliers',
              {
                'name': 'اسم المورد',
                'phone': 'الهاتف',
                'category': 'نوع التوريد',
                'notes': 'ملاحظات'
              },
              (e) => 'نوع: ${e['category'] ?? '-'}'),
          list(
              'عامل',
              '/workers',
              {
                'name': 'اسم العامل',
                'phone': 'الهاتف',
                'daily_wage': 'الأجر اليومي',
                'notes': 'ملاحظات'
              },
              (e) => 'أجر يومي: ${e['daily_wage'] ?? 0}'),
          list(
              'موظف',
              '/employees',
              {
                'name': 'اسم الموظف',
                'phone': 'الهاتف',
                'job_title': 'المسمى الوظيفي',
                'wage_type': 'نوع الأجر',
                'daily_wage': 'الأجر اليومي',
                'monthly_salary': 'الراتب الشهري',
                'department': 'القسم',
                'status': 'الحالة',
                'notes': 'ملاحظات'
              },
              (e) => '${e['job_title'] ?? '-'} | ${e['status'] ?? 'active'}'),
          projectsList(),
          list(
              'مادة',
              '/items',
              {
                'code': 'كود المادة',
                'name': 'اسم المادة',
                'category': 'التصنيف',
                'unit': 'الوحدة',
                'current_qty': 'الرصيد',
                'avg_cost': 'متوسط التكلفة',
                'reorder_level': 'حد الطلب'
              },
              (e) =>
                  '${e['code'] ?? ''} | الرصيد: ${e['current_qty'] ?? 0} ${e['unit'] ?? ''}'),
          list(
              'حساب',
              '/accounts',
              {
                'code': 'الكود',
                'name': 'اسم الحساب',
                'type': 'النوع',
                'currency': 'العملة',
                'balance': 'الرصيد',
                'parent_code': 'الحساب الأب'
              },
              (e) =>
                  '${e['code'] ?? ''} | ${e['type'] ?? ''} | ${e['balance'] ?? 0}'),
          list(
              'حساب نقدية',
              '/cash-accounts',
              {
                'code': 'الكود',
                'name': 'اسم الحساب',
                'currency': 'العملة',
                'opening_balance': 'الرصيد الافتتاحي',
                'balance': 'الرصيد الحالي'
              },
              (e) =>
                  '${e['code'] ?? ''} | ${e['currency'] ?? ''} | الرصيد: ${e['balance'] ?? 0}'),
          list(
              'مركز تكلفة',
              '/cost-centers',
              {
                'code': 'الكود',
                'name': 'اسم المركز',
                'type': 'النوع',
                'parent_id': 'رقم المركز الأب',
                'allocation_method': 'طريقة التحميل',
                'allocation_base': 'أساس التحميل',
                'budget_amount': 'الموازنة',
                'is_postable': 'قابل للترحيل true/false',
                'is_active': 'نشط true/false',
                'notes': 'ملاحظات'
              },
              (e) =>
                  '${e['code'] ?? ''} | ${e['type'] ?? ''} | ${e['is_postable'] == false ? 'تجميعي' : 'قابل للترحيل'} | موازنة: ${e['budget_amount'] ?? 0}'),
        ]));
  }
}
