from decimal import Decimal

from datetime import date

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_approval_role, require_permission
from app.db.database import get_db
from app.models.models import (
    Account,
    Attachment,
    AuditLog,
    CostCenter,
    Item,
    JournalEntry,
    JournalEntryLine,
    Project,
    ProjectCost,
    StockMovement,
    Supplier,
    Transaction,
    Warehouse,
)
from app.schemas.schemas import (
    InventoryAdjustmentCreate,
    InventoryDirectPurchaseToProjectCreate,
    InventoryIssueToProjectCreate,
    InventoryPurchaseToGeneralCreate,
    InventoryReserveForProjectCreate,
    WarehouseCreate,
)
from app.services.posting_engine import _assert_journal_entry_balanced
from app.services.accounting_periods import assert_period_open
from app.services.document_sequence import next_document_no
from app.services.inventory_schema import ensure_inventory_schema

router = APIRouter(prefix="/api/v1/inventory", tags=["Inventory"])

INVENTORY_ACCOUNT = "10401"
SUPPLIER_PAYABLE_ACCOUNT = "20101"
PROJECT_MATERIAL_COST_ACCOUNT = "50101"
INVENTORY_ADJUSTMENT_EXPENSE = "60301"
INVENTORY_ADJUSTMENT_GAIN = "49999"
ATTACHMENT_REQUIRED_LIMIT = Decimal("50000")


def _decimal(value) -> Decimal:
    if value is None:
        return Decimal("0")
    return Decimal(str(value))


def _number(value):
    return float(_decimal(value))


def _money(value) -> Decimal:
    return _decimal(value).quantize(Decimal("0.01"))


def _qty(value) -> Decimal:
    return _decimal(value).quantize(Decimal("0.001"))


def _as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


def _account(db: Session, code: str) -> Account:
    account = db.query(Account).filter(Account.code == code, Account.is_active == True).first()
    if not account:
        raise HTTPException(status_code=400, detail=f"الحساب غير موجود أو غير نشط: {code}")
    return account


def _next_entry_no(db: Session, entry_date=None) -> str:
    return next_document_no(db, "journal_entry", document_date=entry_date)


def _journal(db: Session, *, entry_date, source_type: str, source_id: int, description: str, user_id: int, lines: list[dict]) -> None:
    if db.query(JournalEntry).filter(JournalEntry.source_type == source_type, JournalEntry.source_id == source_id).first():
        raise HTTPException(status_code=400, detail="تم إنشاء قيد محاسبي لهذا المستند مسبقًا")
    assert_period_open(db, entry_date, user_id=user_id)
    if len(lines) < 2:
        raise HTTPException(status_code=400, detail="القيد المحاسبي يجب أن يحتوي على سطرين على الأقل")
    total_debit = _money(sum(_decimal(line.get("debit")) for line in lines))
    total_credit = _money(sum(_decimal(line.get("credit")) for line in lines))
    if total_debit <= 0 or total_debit != total_credit:
        raise HTTPException(status_code=400, detail="القيد المحاسبي غير متوازن")
    entry = JournalEntry(
        entry_no=_next_entry_no(db, entry_date),
        entry_date=entry_date,
        source_type=source_type,
        source_id=source_id,
        description=description,
        total_debit=total_debit,
        total_credit=total_credit,
        created_by=user_id,
    )
    db.add(entry)
    db.flush()
    for line in lines:
        account = _account(db, line["account_code"])
        debit = _money(line.get("debit"))
        credit = _money(line.get("credit"))
        if debit > 0 and credit > 0:
            raise HTTPException(status_code=400, detail="سطر القيد لا يمكن أن يكون مدينًا ودائنًا في نفس الوقت")
        if debit <= 0 and credit <= 0:
            raise HTTPException(status_code=400, detail="كل سطر قيد يجب أن يحتوي مبلغًا مدينًا أو دائنًا")
        db.add(
            JournalEntryLine(
                journal_entry_id=entry.id,
                account_code=account.code,
                account_name=account.name,
                debit=debit,
                credit=credit,
                project_id=line.get("project_id"),
                cost_center_id=line.get("cost_center_id"),
                party_type=line.get("party_type"),
                party_id=line.get("party_id"),
                description=line.get("description") or description,
            )
        )
    db.flush()
    _assert_journal_entry_balanced(db, entry.id)


def _require_item(db: Session, item_id: int) -> Item:
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")
    return item


def _require_warehouse(db: Session, warehouse_id: int | None) -> Warehouse:
    if warehouse_id is None:
        warehouse = db.query(Warehouse).filter(Warehouse.code == "WH-GEN-001").first()
    else:
        warehouse = db.query(Warehouse).filter(Warehouse.id == warehouse_id, Warehouse.is_active == True).first()
    if not warehouse:
        raise HTTPException(status_code=404, detail="المخزن غير موجود أو غير نشط")
    return warehouse


def _require_supplier(db: Session, supplier_id: int | None) -> Supplier | None:
    if supplier_id is None:
        return None
    supplier = db.query(Supplier).filter(Supplier.id == supplier_id).first()
    if not supplier:
        raise HTTPException(status_code=404, detail="المورد غير موجود")
    return supplier


def _require_project(db: Session, project_id: int) -> Project:
    project = db.query(Project).filter(Project.id == project_id).first()
    if not project:
        raise HTTPException(status_code=404, detail="المشروع غير موجود")
    return project


def _require_cost_center(db: Session, cost_center_id: int) -> CostCenter:
    center = db.query(CostCenter).filter(CostCenter.id == cost_center_id, CostCenter.is_active == True).first()
    if not center:
        raise HTTPException(status_code=404, detail="مركز التكلفة غير موجود أو غير نشط")
    return center


def _available_qty(db: Session, item_id: int, warehouse_id: int | None = None) -> Decimal:
    item = _require_item(db, item_id)
    reserved_query = db.query(func.coalesce(func.sum(StockMovement.qty), 0)).filter(
        StockMovement.item_id == item_id,
        StockMovement.movement_type == "reserve_stock_for_project",
    )
    issued_query = db.query(func.coalesce(func.sum(StockMovement.qty), 0)).filter(
        StockMovement.item_id == item_id,
        StockMovement.movement_type == "issue_stock_to_project",
    )
    if warehouse_id is not None:
        reserved_query = reserved_query.filter(StockMovement.warehouse_id == warehouse_id)
        issued_query = issued_query.filter(StockMovement.warehouse_id == warehouse_id)
    reserved_open = max(
        _decimal(reserved_query.scalar()) - _decimal(issued_query.scalar()),
        Decimal("0"),
    )
    return _qty(max(_decimal(item.current_qty) - reserved_open, Decimal("0")))


def _physical_qty(db: Session, item_id: int) -> Decimal:
    item = _require_item(db, item_id)
    return _qty(item.current_qty)


def _stock_movement_payload(movement: StockMovement):
    return _as_dict(movement)


def _record_stock_movement(db: Session, **kwargs) -> StockMovement:
    movement = StockMovement(**kwargs)
    db.add(movement)
    db.flush()
    return movement


def _status_for(item: Item):
    qty = _decimal(item.current_qty)
    reorder_level = _decimal(item.reorder_level)
    avg_cost = _decimal(item.avg_cost)

    if qty <= 0:
        return "out", "نفد المخزون"
    if reorder_level > 0 and qty <= reorder_level:
        return "low", "أقل من حد الطلب"
    if avg_cost <= 0:
        return "no_cost", "بدون تكلفة"
    return "normal", "طبيعي"


def _item_payload(item: Item):
    status, status_label = _status_for(item)
    current_qty = _decimal(item.current_qty)
    avg_cost = _decimal(item.avg_cost)

    return {
        "id": item.id,
        "code": item.code,
        "name": item.name,
        "category": item.category,
        "unit": item.unit,
        "current_qty": _number(current_qty),
        "avg_cost": _number(avg_cost),
        "reorder_level": _number(item.reorder_level),
        "stock_value": _number(current_qty * avg_cost),
        "status": status,
        "status_label": status_label,
    }


@router.get("/warehouses")
def list_inventory_warehouses(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_inventory_schema(db)
    return [_as_dict(row) for row in db.query(Warehouse).order_by(Warehouse.code.asc()).all()]


@router.post("/warehouses")
def create_inventory_warehouse(data: WarehouseCreate, db: Session = Depends(get_db), user=Depends(require_approval_role)):
    ensure_inventory_schema(db)
    if data.type not in {"general", "project", "temporary"}:
        raise HTTPException(status_code=400, detail="نوع المخزن يجب أن يكون عام أو مشروع أو مؤقت")
    if data.type == "project" and not data.project_id:
        raise HTTPException(status_code=400, detail="مخزن المشروع يتطلب تحديد المشروع")
    if db.query(Warehouse).filter(Warehouse.code == data.code).first():
        raise HTTPException(status_code=400, detail="كود المخزن موجود مسبقا")
    obj = Warehouse(**data.model_dump(exclude_unset=True))
    db.add(obj)
    db.add(AuditLog(user_id=user.id, action="create_warehouse", entity="warehouse", entity_id=None, details=data.code))
    db.commit()
    db.refresh(obj)
    return _as_dict(obj)


@router.get("/movements")
def list_inventory_movements(db: Session = Depends(get_db), user=Depends(get_current_user)):
    ensure_inventory_schema(db)
    rows = db.query(StockMovement).order_by(StockMovement.id.desc()).limit(500).all()
    return [_stock_movement_payload(row) for row in rows]


@router.post("/purchase-to-general")
def purchase_to_general_warehouse(data: InventoryPurchaseToGeneralCreate, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_invoice"))):
    ensure_inventory_schema(db)
    item = _require_item(db, data.item_id)
    warehouse = _require_warehouse(db, data.warehouse_id)
    _require_supplier(db, data.supplier_id)
    if warehouse.type != "general":
        raise HTTPException(status_code=400, detail="شراء المخزن العام يجب أن يرتبط بمخزن عام")
    if _qty(data.qty) <= 0 or _money(data.unit_cost) <= 0:
        raise HTTPException(status_code=400, detail="الكمية وتكلفة الوحدة يجب أن تكون أكبر من صفر")
    amount = _money(_decimal(data.qty) * _decimal(data.unit_cost))
    old_qty = _decimal(item.current_qty)
    old_cost = _decimal(item.avg_cost)
    new_qty = old_qty + _decimal(data.qty)
    item.current_qty = _qty(new_qty)
    item.avg_cost = _money(((old_qty * old_cost) + amount) / new_qty) if new_qty > 0 else item.avg_cost
    movement = _record_stock_movement(
        db,
        date=date.today(),
        item_id=data.item_id,
        movement_type="purchase_to_general_warehouse",
        qty=data.qty,
        unit_cost=data.unit_cost,
        warehouse_id=warehouse.id,
        supplier_invoice_id=data.supplier_invoice_id,
        goods_receipt_id=data.goods_receipt_id,
        attachment_id=data.attachment_id,
        movement_source="purchase",
        movement_reference=data.goods_receipt_id or data.supplier_invoice_id,
        notes=data.description,
    )
    credit_account = SUPPLIER_PAYABLE_ACCOUNT if data.supplier_id else "10101"
    _journal(
        db,
        entry_date=date.today(),
        source_type="inventory_movement",
        source_id=movement.id,
        description=data.description,
        user_id=user.id,
        lines=[
            {"account_code": INVENTORY_ACCOUNT, "debit": amount, "credit": 0, "description": data.description},
            {"account_code": credit_account, "debit": 0, "credit": amount, "party_type": "supplier" if data.supplier_id else None, "party_id": data.supplier_id, "description": data.description},
        ],
    )
    db.add(AuditLog(user_id=user.id, action="purchase_to_general_warehouse", entity="stock_movement", entity_id=movement.id, details=data.description))
    db.commit()
    db.refresh(movement)
    return _stock_movement_payload(movement)


@router.post("/reserve-for-project")
def reserve_stock_for_project(data: InventoryReserveForProjectCreate, db: Session = Depends(get_db), user=Depends(require_permission("inventory.write"))):
    ensure_inventory_schema(db)
    _require_item(db, data.item_id)
    warehouse = _require_warehouse(db, data.warehouse_id)
    _require_project(db, data.project_id)
    if _qty(data.qty) <= 0:
        raise HTTPException(status_code=400, detail="كمية الحجز يجب أن تكون أكبر من صفر")
    if data.qty > _available_qty(db, data.item_id, warehouse.id):
        raise HTTPException(status_code=400, detail="لا يمكن حجز كمية أكبر من الرصيد المتاح")
    movement = _record_stock_movement(
        db,
        date=date.today(),
        item_id=data.item_id,
        movement_type="reserve_stock_for_project",
        qty=data.qty,
        unit_cost=0,
        warehouse_id=warehouse.id,
        project_id=data.project_id,
        movement_source="reservation",
        notes=data.description,
    )
    db.add(AuditLog(user_id=user.id, action="reserve_stock_for_project", entity="stock_movement", entity_id=movement.id, details=data.description))
    db.commit()
    db.refresh(movement)
    return _stock_movement_payload(movement)


@router.post("/issue-to-project")
def issue_stock_to_project(data: InventoryIssueToProjectCreate, db: Session = Depends(get_db), user=Depends(require_permission("approve_inventory_adjustment"))):
    ensure_inventory_schema(db)
    item = _require_item(db, data.item_id)
    warehouse = _require_warehouse(db, data.warehouse_id)
    _require_project(db, data.project_id)
    _require_cost_center(db, data.cost_center_id)
    if _qty(data.qty) <= 0:
        raise HTTPException(status_code=400, detail="كمية الصرف يجب أن تكون أكبر من صفر")
    if _qty(data.qty) > _physical_qty(db, data.item_id):
        raise HTTPException(status_code=400, detail="لا يمكن صرف كمية أكبر من الرصيد المتاح")
    unit_cost = _money(item.avg_cost)
    amount = _money(_decimal(data.qty) * unit_cost)
    item.current_qty = _qty(_decimal(item.current_qty) - _decimal(data.qty))
    movement = _record_stock_movement(
        db,
        date=date.today(),
        item_id=data.item_id,
        movement_type="issue_stock_to_project",
        qty=data.qty,
        unit_cost=unit_cost,
        warehouse_id=warehouse.id,
        project_id=data.project_id,
        cost_center_id=data.cost_center_id,
        movement_source="project_issue",
        notes=data.description,
    )
    db.add(ProjectCost(project_id=data.project_id, cost_center_id=data.cost_center_id, date=date.today(), category="materials", amount=amount, source_type="stock_movement", source_id=movement.id, notes=data.description))
    _journal(
        db,
        entry_date=date.today(),
        source_type="stock_movement",
        source_id=movement.id,
        description=data.description,
        user_id=user.id,
        lines=[
            {"account_code": PROJECT_MATERIAL_COST_ACCOUNT, "debit": amount, "credit": 0, "project_id": data.project_id, "cost_center_id": data.cost_center_id, "description": data.description},
            {"account_code": INVENTORY_ACCOUNT, "debit": 0, "credit": amount, "description": data.description},
        ],
    )
    db.add(AuditLog(user_id=user.id, action="issue_stock_to_project", entity="stock_movement", entity_id=movement.id, details=data.description))
    db.commit()
    db.refresh(movement)
    return _stock_movement_payload(movement)


@router.post("/direct-purchase-to-project")
def direct_purchase_to_project(data: InventoryDirectPurchaseToProjectCreate, db: Session = Depends(get_db), user=Depends(require_permission("approve_supplier_invoice"))):
    ensure_inventory_schema(db)
    _require_supplier(db, data.supplier_id)
    item_id = data.item_id
    if item_id:
        _require_item(db, item_id)
    else:
        item = db.query(Item).filter(Item.code == "DIRECT-PRJ-PURCHASE").first()
        if not item:
            item = Item(
                code="DIRECT-PRJ-PURCHASE",
                name="شراء مباشر لمشروع بدون مادة مخزنية",
                category="direct_project_purchase",
                unit="unit",
                current_qty=0,
                avg_cost=0,
                reorder_level=0,
            )
            db.add(item)
            db.flush()
        item_id = item.id
    _require_project(db, data.project_id)
    _require_cost_center(db, data.cost_center_id)
    amount = _money(_decimal(data.qty) * _decimal(data.unit_cost))
    if _qty(data.qty) <= 0 or _money(data.unit_cost) <= 0:
        raise HTTPException(status_code=400, detail="الكمية وتكلفة الوحدة يجب أن تكون أكبر من صفر")
    if not data.attachment_id:
        raise HTTPException(status_code=400, detail="الشراء المباشر للمشروع يتطلب إرفاق صورة الفاتورة")
    movement = _record_stock_movement(
        db,
        date=date.today(),
        item_id=item_id,
        movement_type="direct_purchase_to_project",
        qty=data.qty,
        unit_cost=data.unit_cost,
        project_id=data.project_id,
        cost_center_id=data.cost_center_id,
        supplier_invoice_id=data.supplier_invoice_id,
        attachment_id=data.attachment_id,
        movement_source="direct_project_purchase",
        notes=data.description,
    )
    db.add(ProjectCost(project_id=data.project_id, cost_center_id=data.cost_center_id, date=date.today(), category="direct_project_purchase", amount=amount, source_type="stock_movement", source_id=movement.id, notes=data.description))
    _journal(
        db,
        entry_date=date.today(),
        source_type="direct_project_purchase",
        source_id=movement.id,
        description=data.description,
        user_id=user.id,
        lines=[
            {"account_code": PROJECT_MATERIAL_COST_ACCOUNT, "debit": amount, "credit": 0, "project_id": data.project_id, "cost_center_id": data.cost_center_id, "party_type": "supplier", "party_id": data.supplier_id, "description": data.description},
            {"account_code": SUPPLIER_PAYABLE_ACCOUNT, "debit": 0, "credit": amount, "party_type": "supplier", "party_id": data.supplier_id, "description": data.description},
        ],
    )
    db.add(AuditLog(user_id=user.id, action="direct_purchase_to_project", entity="stock_movement", entity_id=movement.id, details=data.description))
    db.commit()
    db.refresh(movement)
    return _stock_movement_payload(movement)


@router.post("/adjustment")
def inventory_adjustment(data: InventoryAdjustmentCreate, db: Session = Depends(get_db), user=Depends(require_permission("approve_inventory_adjustment"))):
    ensure_inventory_schema(db)
    item = _require_item(db, data.item_id)
    warehouse = _require_warehouse(db, data.warehouse_id)
    if data.adjustment_type not in {"increase", "decrease"}:
        raise HTTPException(status_code=400, detail="نوع التسوية يجب أن يكون زيادة أو نقص")
    if _qty(data.qty) <= 0:
        raise HTTPException(status_code=400, detail="كمية التسوية يجب أن تكون أكبر من صفر")
    unit_cost = _money(data.unit_cost or item.avg_cost)
    amount = _money(_decimal(data.qty) * unit_cost)
    if data.adjustment_type == "decrease" and _decimal(data.qty) > _decimal(item.current_qty):
        raise HTTPException(status_code=400, detail="لا يمكن تسوية نقص أكبر من الرصيد المتاح")
    item.current_qty = _qty(_decimal(item.current_qty) + (_decimal(data.qty) if data.adjustment_type == "increase" else -_decimal(data.qty)))
    movement = _record_stock_movement(
        db,
        date=date.today(),
        item_id=data.item_id,
        movement_type=f"inventory_adjustment_{data.adjustment_type}",
        qty=data.qty,
        unit_cost=unit_cost,
        warehouse_id=warehouse.id,
        attachment_id=data.attachment_id,
        movement_source="inventory_adjustment",
        notes=data.reason,
    )
    if data.adjustment_type == "decrease":
        lines = [
            {"account_code": INVENTORY_ADJUSTMENT_EXPENSE, "debit": amount, "credit": 0, "description": data.reason},
            {"account_code": INVENTORY_ACCOUNT, "debit": 0, "credit": amount, "description": data.reason},
        ]
    else:
        lines = [
            {"account_code": INVENTORY_ACCOUNT, "debit": amount, "credit": 0, "description": data.reason},
            {"account_code": INVENTORY_ADJUSTMENT_GAIN, "debit": 0, "credit": amount, "description": data.reason},
        ]
    _journal(db, entry_date=date.today(), source_type="inventory_adjustment", source_id=movement.id, description=data.reason, user_id=user.id, lines=lines)
    db.add(AuditLog(user_id=user.id, action="inventory_adjustment", entity="stock_movement", entity_id=movement.id, details=data.reason))
    db.commit()
    db.refresh(movement)
    return _stock_movement_payload(movement)


@router.get("/summary")
def inventory_summary(db: Session = Depends(get_db), user=Depends(get_current_user)):
    items = db.query(Item).order_by(Item.code.asc()).all()
    payload = [_item_payload(item) for item in items]

    return {
        "total_items": len(payload),
        "low_stock": len([item for item in payload if item["status"] == "low"]),
        "out_of_stock": len([item for item in payload if item["status"] == "out"]),
        "no_cost": len([item for item in payload if item["status"] == "no_cost"]),
        "stock_value": sum(item["stock_value"] for item in payload),
    }


@router.get("/items")
def list_inventory_stock_items(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [_item_payload(item) for item in db.query(Item).order_by(Item.code.asc()).all()]


@router.get("/items/{item_id}/movements")
def item_movements(item_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    item = db.query(Item).filter(Item.id == item_id).first()
    if not item:
        raise HTTPException(status_code=404, detail="المادة غير موجودة")

    rows = (
        db.query(StockMovement, Transaction, Project)
        .outerjoin(Transaction, StockMovement.transaction_id == Transaction.id)
        .outerjoin(Project, StockMovement.project_id == Project.id)
        .filter(StockMovement.item_id == item_id)
        .order_by(StockMovement.date.desc(), StockMovement.id.desc())
        .limit(300)
        .all()
    )

    items = []
    for movement, transaction, project in rows:
        items.append(
            {
                "id": movement.id,
                "date": movement.date.isoformat(),
                "movement_type": movement.movement_type,
                "qty": _number(movement.qty),
                "unit_cost": _number(movement.unit_cost),
                "total_cost": _number(_decimal(movement.qty) * _decimal(movement.unit_cost)),
                "project_id": movement.project_id,
                "project_name": project.name if project else None,
                "transaction_id": movement.transaction_id,
                "document_no": transaction.document_no if transaction else None,
                "transaction_status": transaction.status if transaction else None,
                "notes": movement.notes,
            }
        )

    return {
        "item": _item_payload(item),
        "items": items,
    }
