import 'package:shared_preferences/shared_preferences.dart';

class LocalNumberService {
  static const Map<String, String> _prefixByDocumentType = {
    'general_payment': 'PAY',
    'cash_payment': 'PAY',
    'payment_voucher': 'PAY',
    'receipt_from_customer': 'RCV',
    'customer_advance': 'RCV',
    'cash_receipt': 'RCV',
    'advance_payment': 'ADV',
    'attendance': 'ATT',
    'attendance_bulk': 'ATT',
    'supplier_invoice': 'PINV',
    'project_note': 'NOTE',
    'attachment': 'ATTACH',
  };

  Future<String> next(String documentType, {String? preferredPrefix}) async {
    final year = DateTime.now().year;
    final prefix = _normalizePrefix(
      preferredPrefix ?? _prefixByDocumentType[documentType] ?? 'DOC',
    );
    final prefs = await SharedPreferences.getInstance();
    final key = 'alshaari_local_number_${documentType}_$year';
    final next = (prefs.getInt(key) ?? 0) + 1;
    await prefs.setInt(key, next);
    return 'LOCAL-$prefix-$year-${next.toString().padLeft(4, '0')}';
  }

  String _normalizePrefix(String value) {
    final trimmed = value.trim().toUpperCase();
    if (trimmed.startsWith('LOCAL-')) {
      return trimmed.substring('LOCAL-'.length);
    }
    return trimmed;
  }
}

final localNumberService = LocalNumberService();
