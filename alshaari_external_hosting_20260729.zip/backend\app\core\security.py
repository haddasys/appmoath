from datetime import datetime, timedelta, timezone
from jose import jwt, JWTError
import hashlib, os
import hmac
from dotenv import load_dotenv

load_dotenv()
SECRET_KEY = os.getenv("SECRET_KEY", "change_this")
APP_ENV = os.getenv("APP_ENV", "development").lower()
ALGORITHM = "HS256"
EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "1440"))

if APP_ENV == "production" and SECRET_KEY in {"change_this", "change_this_secret_key"}:
    raise RuntimeError("SECRET_KEY must be changed before running in production")

def hash_password(password: str) -> str:
    salt = "alshaari_static_salt_v1"
    return hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000).hex()

def verify_password(password: str, password_hash: str) -> bool:
    return hmac.compare_digest(hash_password(password), password_hash)

def create_access_token(subject: str, role: str):
    expire = datetime.now(timezone.utc) + timedelta(minutes=EXPIRE_MINUTES)
    payload = {"sub": subject, "role": role, "exp": expire}
    return jwt.encode(payload, SECRET_KEY, algorithm=ALGORITHM)

def decode_token(token: str):
    try:
        return jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
    except JWTError:
        return None
