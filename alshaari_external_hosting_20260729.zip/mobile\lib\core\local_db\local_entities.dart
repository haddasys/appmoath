import 'dart:convert';

class LocalTransactionDraft {
  final String localUuid;
  final String temporaryNo;
  final String payloadJson;
  final String syncStatus;
  final bool createdOffline;
  final int? serverId;
  final String? officialNo;
  final String? errorMessage;
  final int createdAt;
  final int updatedAt;
  final int? syncedAt;

  const LocalTransactionDraft({
    required this.localUuid,
    required this.temporaryNo,
    required this.payloadJson,
    required this.syncStatus,
    required this.createdOffline,
    required this.createdAt,
    required this.updatedAt,
    this.serverId,
    this.officialNo,
    this.errorMessage,
    this.syncedAt,
  });

  factory LocalTransactionDraft.fromPayload({
    required String localUuid,
    required String temporaryNo,
    required Map<String, dynamic> payload,
    required int now,
    String status = 'pending',
    bool createdOffline = true,
    int? serverId,
    String? officialNo,
    String? errorMessage,
    int? syncedAt,
  }) {
    return LocalTransactionDraft(
      localUuid: localUuid,
      temporaryNo: temporaryNo,
      payloadJson: jsonEncode(payload),
      syncStatus: status,
      createdOffline: createdOffline,
      serverId: serverId,
      officialNo: officialNo,
      errorMessage: errorMessage,
      createdAt: now,
      updatedAt: now,
      syncedAt: syncedAt,
    );
  }

  factory LocalTransactionDraft.fromJson(Map<String, dynamic> json) {
    return LocalTransactionDraft(
      localUuid: '${json['local_uuid']}',
      temporaryNo: '${json['temporary_no'] ?? ''}',
      payloadJson: '${json['payload_json'] ?? '{}'}',
      syncStatus: '${json['sync_status'] ?? 'pending'}',
      createdOffline: json['created_offline'] != false,
      serverId: _intOrNull(json['server_id']),
      officialNo: json['official_no']?.toString(),
      errorMessage: json['error_message']?.toString(),
      createdAt: _intOrNull(json['created_at']) ?? 0,
      updatedAt: _intOrNull(json['updated_at']) ?? 0,
      syncedAt: _intOrNull(json['synced_at']),
    );
  }

  Map<String, dynamic> toJson() => {
        'local_uuid': localUuid,
        'temporary_no': temporaryNo,
        'payload_json': payloadJson,
        'sync_status': syncStatus,
        'created_offline': createdOffline,
        'server_id': serverId,
        'official_no': officialNo,
        'error_message': errorMessage,
        'created_at': createdAt,
        'updated_at': updatedAt,
        'synced_at': syncedAt,
      };
}

class LocalAttendanceDraft {
  final String localUuid;
  final int? serverId;
  final int employeeId;
  final String attendanceDate;
  final String status;
  final int? projectId;
  final int? costCenterId;
  final String? notes;
  final String syncStatus;
  final String payloadJson;
  final int createdAt;
  final int updatedAt;
  final int? syncedAt;

  const LocalAttendanceDraft({
    required this.localUuid,
    required this.employeeId,
    required this.attendanceDate,
    required this.status,
    required this.syncStatus,
    required this.payloadJson,
    required this.createdAt,
    required this.updatedAt,
    this.serverId,
    this.projectId,
    this.costCenterId,
    this.notes,
    this.syncedAt,
  });

  factory LocalAttendanceDraft.fromJson(Map<String, dynamic> json) {
    return LocalAttendanceDraft(
      localUuid: '${json['local_uuid']}',
      serverId: _intOrNull(json['server_id']),
      employeeId: _intOrNull(json['employee_id']) ?? 0,
      attendanceDate: '${json['attendance_date'] ?? ''}',
      status: '${json['status'] ?? 'present'}',
      projectId: _intOrNull(json['project_id']),
      costCenterId: _intOrNull(json['cost_center_id']),
      notes: json['notes']?.toString(),
      syncStatus: '${json['sync_status'] ?? 'pending'}',
      payloadJson: '${json['payload_json'] ?? '{}'}',
      createdAt: _intOrNull(json['created_at']) ?? 0,
      updatedAt: _intOrNull(json['updated_at']) ?? 0,
      syncedAt: _intOrNull(json['synced_at']),
    );
  }

  Map<String, dynamic> toJson() => {
        'local_uuid': localUuid,
        'server_id': serverId,
        'employee_id': employeeId,
        'attendance_date': attendanceDate,
        'status': status,
        'project_id': projectId,
        'cost_center_id': costCenterId,
        'notes': notes,
        'sync_status': syncStatus,
        'payload_json': payloadJson,
        'created_at': createdAt,
        'updated_at': updatedAt,
        'synced_at': syncedAt,
      };
}

class LocalAttachmentDraft {
  final String localUuid;
  final String entityLocalUuid;
  final String entityType;
  final String filePath;
  final String fileName;
  final String? mimeType;
  final int? serverAttachmentId;
  final String syncStatus;
  final String? errorMessage;
  final String? fileDataBase64;
  final int createdAt;
  final int? syncedAt;

  const LocalAttachmentDraft({
    required this.localUuid,
    required this.entityLocalUuid,
    required this.entityType,
    required this.filePath,
    required this.fileName,
    required this.syncStatus,
    required this.createdAt,
    this.mimeType,
    this.serverAttachmentId,
    this.errorMessage,
    this.fileDataBase64,
    this.syncedAt,
  });

  factory LocalAttachmentDraft.fromJson(Map<String, dynamic> json) {
    return LocalAttachmentDraft(
      localUuid: '${json['local_uuid']}',
      entityLocalUuid: '${json['entity_local_uuid'] ?? ''}',
      entityType: '${json['entity_type'] ?? ''}',
      filePath: '${json['file_path'] ?? ''}',
      fileName: '${json['file_name'] ?? ''}',
      mimeType: json['mime_type']?.toString(),
      serverAttachmentId: _intOrNull(json['server_attachment_id']),
      syncStatus: '${json['sync_status'] ?? 'pending'}',
      errorMessage: json['error_message']?.toString(),
      fileDataBase64: json['file_data_base64']?.toString(),
      createdAt: _intOrNull(json['created_at']) ?? 0,
      syncedAt: _intOrNull(json['synced_at']),
    );
  }

  Map<String, dynamic> toJson() => {
        'local_uuid': localUuid,
        'entity_local_uuid': entityLocalUuid,
        'entity_type': entityType,
        'file_path': filePath,
        'file_name': fileName,
        'mime_type': mimeType,
        'server_attachment_id': serverAttachmentId,
        'sync_status': syncStatus,
        'error_message': errorMessage,
        'file_data_base64': fileDataBase64,
        'created_at': createdAt,
        'synced_at': syncedAt,
      };
}

class LocalMasterDataRecord {
  final String entityType;
  final int serverId;
  final String name;
  final String? code;
  final String payloadJson;
  final int updatedAt;

  const LocalMasterDataRecord({
    required this.entityType,
    required this.serverId,
    required this.name,
    required this.payloadJson,
    required this.updatedAt,
    this.code,
  });

  factory LocalMasterDataRecord.fromJson(Map<String, dynamic> json) {
    return LocalMasterDataRecord(
      entityType: '${json['entity_type']}',
      serverId: _intOrNull(json['server_id']) ?? 0,
      name: '${json['name'] ?? ''}',
      code: json['code']?.toString(),
      payloadJson: '${json['payload_json'] ?? '{}'}',
      updatedAt: _intOrNull(json['updated_at']) ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'entity_type': entityType,
        'server_id': serverId,
        'name': name,
        'code': code,
        'payload_json': payloadJson,
        'updated_at': updatedAt,
      };
}

int? _intOrNull(Object? value) {
  if (value == null) return null;
  if (value is int) return value;
  return int.tryParse('$value');
}
