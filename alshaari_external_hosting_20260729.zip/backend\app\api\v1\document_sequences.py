from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.core.deps import get_current_user, require_approval_role
from app.db.database import get_db
from app.models.models import DocumentSequence
from app.schemas.schemas import DocumentSequenceCreate

router = APIRouter(prefix="/api/v1/document-sequences", tags=["Document Sequences"])


def as_dict(obj):
    return {c.name: getattr(obj, c.name) for c in obj.__table__.columns}


@router.get("")
def list_document_sequences(db: Session = Depends(get_db), user=Depends(get_current_user)):
    return [
        as_dict(seq)
        for seq in db.query(DocumentSequence).order_by(DocumentSequence.document_type).all()
    ]


@router.post("")
def upsert_document_sequence(
    data: DocumentSequenceCreate,
    db: Session = Depends(get_db),
    user=Depends(require_approval_role),
):
    if data.next_number < 1:
        raise HTTPException(status_code=400, detail="رقم التسلسل التالي يجب أن يكون أكبر من صفر")

    if data.padding < 3 or data.padding_length < 3:
        raise HTTPException(status_code=400, detail="طول الترقيم يجب ألا يقل عن 3 خانات")

    payload = data.model_dump()
    payload["padding"] = payload.get("padding_length") or payload.get("padding") or 4
    payload["padding_length"] = payload["padding"]

    seq = (
        db.query(DocumentSequence)
        .filter(DocumentSequence.document_type == data.document_type)
        .first()
    )

    if not seq:
        seq = DocumentSequence(**payload)
        db.add(seq)
    else:
        for key, value in payload.items():
            setattr(seq, key, value)

    db.commit()
    db.refresh(seq)
    return as_dict(seq)
