import 'dart:html' as html;

Future<void> openPrintDocument({
  required String title,
  required String content,
}) async {
  final blob = html.Blob([content], 'text/html;charset=utf-8');
  final url = html.Url.createObjectUrlFromBlob(blob);
  final opened = html.window.open(url, '_blank');

  Future<void>.delayed(const Duration(seconds: 15), () {
    html.Url.revokeObjectUrl(url);
  });
}
