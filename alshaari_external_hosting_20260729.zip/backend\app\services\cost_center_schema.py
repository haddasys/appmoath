from sqlalchemy import inspect, text
from sqlalchemy.orm import Session

from app.models.models import CostCenter


DEFAULT_COST_CENTERS = [
    ("CC-PRD-CARPENTRY", "قسم النجارة", "production", None, True, "direct", "labor_hours"),
    ("CC-PRD-CNC", "قسم CNC", "production", None, True, "direct", "machine_hours"),
    ("CC-PRD-SANDING", "قسم الصنفرة", "production", None, True, "direct", "labor_hours"),
    ("CC-PRD-PAINT", "قسم الدهان", "production", None, True, "direct", "labor_hours"),
    ("CC-PRD-FINISHING", "قسم التشطيب", "production", None, True, "direct", "labor_hours"),
    ("CC-PRD-INSTALL", "قسم التركيب", "production", None, True, "direct", "labor_hours"),
    ("CC-PRD-UPHOLSTERY", "قسم التنجيد", "production", None, True, "direct", "labor_hours"),
    ("CC-ADM-MGMT", "الإدارة", "admin", None, True, "period", None),
    ("CC-ADM-SHOWROOM", "المعرض", "admin", None, True, "period", None),
    ("CC-ADM-MAINT", "الصيانة", "admin", None, True, "allocation", "machine_hours"),
    ("CC-ADM-GENERAL", "مصروفات عامة", "admin", None, True, "period", None),
    ("100", "الإنتاج", "production", None, False, "direct", None),
    ("110", "النجارة", "production", "100", True, "direct", "labor_hours"),
    ("120", "CNC", "production", "100", True, "direct", "machine_hours"),
    ("130", "الصنفرة", "production", "100", True, "direct", "labor_hours"),
    ("140", "الدهان", "production", "100", True, "direct", "labor_hours"),
    ("150", "التشطيب", "production", "100", True, "direct", "labor_hours"),
    ("160", "التركيب", "production", "100", True, "direct", "labor_hours"),
    ("170", "التصميم والهندسة", "production", "100", True, "direct", "labor_hours"),
    ("180", "صيانة وتشغيل الورشة", "production", "100", True, "allocation", "machine_hours"),
    ("200", "المخزون والمشتريات", "service", None, False, "allocation", "material_value"),
    ("210", "المستودع", "service", "200", True, "allocation", "material_value"),
    ("220", "المشتريات", "service", "200", True, "allocation", "purchase_value"),
    ("300", "الإدارة", "admin", None, True, "period", None),
    ("400", "المبيعات والمعرض", "sales", None, True, "period", None),
    ("500", "مشاريع العملاء", "project", None, False, "direct", None),
]


def _table_has_column(db: Session, table_name: str, column_name: str) -> bool:
    inspector = inspect(db.get_bind())
    if not inspector.has_table(table_name):
        return True
    return column_name in {column["name"] for column in inspector.get_columns(table_name)}


def _add_column_if_missing(db: Session, table_name: str, column_name: str, definition: str) -> None:
    if not _table_has_column(db, table_name, column_name):
        db.execute(text(f"ALTER TABLE {table_name} ADD COLUMN {column_name} {definition}"))


def ensure_cost_center_schema(db: Session) -> None:
    CostCenter.__table__.create(db.get_bind(), checkfirst=True)

    for table_name in [
        "transactions",
        "journal_entry_lines",
        "project_costs",
        "stock_movements",
        "expenses",
    ]:
        _add_column_if_missing(db, table_name, "cost_center_id", "INTEGER")

    _add_column_if_missing(db, "cost_centers", "responsible_user_id", "INTEGER")
    _add_column_if_missing(db, "cost_centers", "allocation_method", "VARCHAR(40) DEFAULT 'direct'")
    _add_column_if_missing(db, "cost_centers", "allocation_base", "VARCHAR(40)")
    _add_column_if_missing(db, "cost_centers", "budget_amount", "NUMERIC(14,2) DEFAULT 0")
    _add_column_if_missing(db, "cost_centers", "is_postable", "BOOLEAN DEFAULT TRUE")
    _add_column_if_missing(db, "cost_centers", "project_id", "INTEGER")
    _add_column_if_missing(db, "cost_centers", "created_at", "TIMESTAMP")
    db.execute(text("UPDATE cost_centers SET created_at = CURRENT_TIMESTAMP WHERE created_at IS NULL"))
    _add_column_if_missing(db, "transactions", "settlement_type", "VARCHAR(40)")

    db.flush()

    existing = {
        row["code"]: row["id"]
        for row in db.execute(text("SELECT id, code FROM cost_centers")).mappings().all()
    }

    for code, name, center_type, parent_code, is_postable, allocation_method, allocation_base in DEFAULT_COST_CENTERS:
        parent_id = existing.get(parent_code) if parent_code else None
        if code in existing:
            db.execute(
                text(
                    """
                    UPDATE cost_centers
                    SET parent_id = COALESCE(parent_id, :parent_id),
                        type = :type,
                        allocation_method = :allocation_method,
                        allocation_base = :allocation_base,
                        is_postable = :is_postable
                    WHERE code = :code
                    """
                ),
                {
                    "code": code,
                    "parent_id": parent_id,
                    "type": center_type,
                    "allocation_method": allocation_method,
                    "allocation_base": allocation_base,
                    "is_postable": is_postable,
                },
            )
            continue

        result = db.execute(
            text(
                """
                INSERT INTO cost_centers (
                    code, name, parent_id, type, allocation_method,
                    allocation_base, is_postable, is_active, budget_amount
                )
                VALUES (
                    :code, :name, :parent_id, :type, :allocation_method,
                    :allocation_base, :is_postable, TRUE, 0
                )
                RETURNING id
                """
            ),
            {
                "code": code,
                "name": name,
                "parent_id": parent_id,
                "type": center_type,
                "allocation_method": allocation_method,
                "allocation_base": allocation_base,
                "is_postable": is_postable,
            },
        ).mappings().first()
        existing[code] = result["id"]

    db.commit()
