from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.core.deps import get_current_user
from app.db.database import get_db
from app.schemas.schemas import DeviceRegisterRequest
from app.services.sync_service import register_device


router = APIRouter(prefix="/api/v1/devices", tags=["Offline Sync"])


@router.post("/register")
def register(data: DeviceRegisterRequest, db: Session = Depends(get_db), user=Depends(get_current_user)):
    return register_device(
        db,
        device_id=data.device_id,
        device_name=data.device_name,
        user_id=user.id,
    )
