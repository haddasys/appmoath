from pydantic import BaseModel, Field
from typing import Optional, Any
from datetime import date, datetime
from decimal import Decimal

class LoginRequest(BaseModel):
    phone: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
    name: str
    permissions: list[str] = Field(default_factory=list)

class UserCreate(BaseModel):
    name: str
    phone: str
    password: str
    role: str = "data_entry"
    is_active: bool = True

class UserUpdate(BaseModel):
    name: Optional[str] = None
    phone: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None

class UserPasswordUpdate(BaseModel):
    password: str

class RolePermissionsUpdate(BaseModel):
    permissions: list[str] = Field(default_factory=list)

class CompanySettings(BaseModel):
    company_name: str = "الشعري لصناعة وحلول الأثاث المخصص والديكور"
    legal_name: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    address: Optional[str] = None
    tax_number: Optional[str] = None
    commercial_record: Optional[str] = None
    default_currency: str = "YER"
    invoice_prefix: str = "INV"
    receipt_prefix: str = "RV"
    payment_prefix: str = "PV"
    primary_color: str = "#B87E62"
    secondary_color: str = "#1C1C1C"
    notes: Optional[str] = None

class AccountCreate(BaseModel):
    code: str
    name: str
    type: str
    currency: str = "YER"
    balance: Decimal = 0
    parent_code: Optional[str] = None

class AccountBalanceUpdate(BaseModel):
    balance: Decimal
    notes: Optional[str] = None

class CostCenterCreate(BaseModel):
    code: str
    name: str
    parent_id: Optional[int] = None
    type: str = "production"
    responsible_user_id: Optional[int] = None
    allocation_method: str = "direct"
    allocation_base: Optional[str] = None
    budget_amount: Decimal = 0
    is_postable: bool = True
    is_active: bool = True
    notes: Optional[str] = None

class CustomerCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    address: Optional[str] = None
    customer_type: Optional[str] = None
    notes: Optional[str] = None

class SupplierCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    category: Optional[str] = None
    notes: Optional[str] = None

class EmployeeCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    job_title: Optional[str] = None
    wage_type: str = "daily"
    daily_wage: Decimal = 0
    monthly_salary: Decimal = 0
    department: Optional[str] = None
    status: str = "active"
    notes: Optional[str] = None

class WorkerCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    daily_wage: Decimal = 0
    notes: Optional[str] = None

class ProjectCreate(BaseModel):
    project_code: Optional[str] = None
    name: str
    customer_id: Optional[int] = None
    project_type: Optional[str] = None
    contract_value: Decimal = 0
    status: str = "new"
    progress_percent: int = 0
    responsible_id: Optional[int] = None
    start_date: Optional[date] = None
    expected_end_date: Optional[date] = None
    notes: Optional[str] = None

class ProjectStageCreate(BaseModel):
    project_id: int
    stage_order: int = 1
    stage_code: str
    name: str
    status: str = "not_started"
    progress_percent: int = 0
    planned_start_date: Optional[date] = None
    planned_end_date: Optional[date] = None
    actual_start_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    responsible_id: Optional[int] = None
    notes: Optional[str] = None

class ProjectStageUpdate(BaseModel):
    stage_order: Optional[int] = None
    stage_code: Optional[str] = None
    name: Optional[str] = None
    status: Optional[str] = None
    progress_percent: Optional[int] = None
    planned_start_date: Optional[date] = None
    planned_end_date: Optional[date] = None
    actual_start_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    responsible_id: Optional[int] = None
    notes: Optional[str] = None

class ProductionOrderCreate(BaseModel):
    project_id: int
    stage_id: Optional[int] = None
    item_description: str
    qty: Decimal = 1
    unit: str = "pcs"
    priority: str = "normal"
    status: str = "planned"
    planned_start_date: Optional[date] = None
    planned_end_date: Optional[date] = None
    notes: Optional[str] = None

class ProductionOrderUpdate(BaseModel):
    stage_id: Optional[int] = None
    item_description: Optional[str] = None
    qty: Optional[Decimal] = None
    unit: Optional[str] = None
    priority: Optional[str] = None
    status: Optional[str] = None
    planned_start_date: Optional[date] = None
    planned_end_date: Optional[date] = None
    actual_start_date: Optional[date] = None
    actual_end_date: Optional[date] = None
    notes: Optional[str] = None

class CashAccountCreate(BaseModel):
    code: str
    name: str
    account_code: Optional[str] = None
    type: str = "cash"
    holder_name: Optional[str] = None
    currency: str = "YER"
    opening_balance: Decimal = 0
    balance: Decimal = 0
    current_balance: Decimal = 0

class CashTransactionCreate(BaseModel):
    date: date
    transaction_type: str
    amount: Decimal
    currency: str = "YER"
    cash_account_id: Optional[int] = None
    related_account_type: Optional[str] = None
    related_id: Optional[int] = None
    project_id: Optional[int] = None
    payment_method: Optional[str] = None
    description: Optional[str] = None

class ExpenseCreate(BaseModel):
    date: date
    category: str
    amount: Decimal
    currency: str = "YER"
    payment_method: Optional[str] = None
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    employee_id: Optional[int] = None
    supplier_id: Optional[int] = None
    description: Optional[str] = None

class RevenueCreate(BaseModel):
    date: date
    revenue_type: str
    amount: Decimal
    currency: str = "YER"
    customer_id: Optional[int] = None
    project_id: Optional[int] = None
    payment_method: Optional[str] = None
    description: Optional[str] = None

class ItemCreate(BaseModel):
    code: str
    name: str
    unit: str = "pcs"
    current_qty: Decimal = 0
    avg_cost: Decimal = 0
    reorder_level: Decimal = 0
    category: Optional[str] = None

class InventoryItemCreate(ItemCreate):
    pass

class TransactionCreate(BaseModel):
    local_uuid: Optional[str] = None
    device_id: Optional[str] = None
    sync_status: Optional[str] = None
    created_offline: bool = False
    date: date
    type: str
    amount: Decimal = 0
    currency: str = "YER"
    payment_method: Optional[str] = None
    cash_account_id: Optional[int] = None
    from_cash_account_id: Optional[int] = None
    to_cash_account_id: Optional[int] = None
    related_account_type: Optional[str] = None
    related_id: Optional[int] = None
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    settlement_type: Optional[str] = None
    cost_category: Optional[str] = None
    item_id: Optional[int] = None
    qty: Decimal = 0
    unit_cost: Decimal = 0
    description: Optional[str] = None

class TransactionReverseRequest(BaseModel):
    reason: str

class AdjustmentVoucherLineCreate(BaseModel):
    account_code: str
    debit: Decimal = 0
    credit: Decimal = 0
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    party_type: Optional[str] = None
    party_id: Optional[int] = None
    description: Optional[str] = None

class AdjustmentVoucherCreate(BaseModel):
    date: date
    reason: str
    description: str
    attachment: Optional[str] = None
    lines: list[AdjustmentVoucherLineCreate] = Field(default_factory=list)

class AdjustmentVoucherRejectRequest(BaseModel):
    reason: Optional[str] = None

class AdjustmentVoucherReverseRequest(BaseModel):
    reason: str

class EmployeeCreate(BaseModel):
    name: str
    phone: Optional[str] = None
    job_title: Optional[str] = None
    department: Optional[str] = None
    wage_type: str = "daily"
    daily_wage: Decimal = 0
    monthly_wage: Optional[Decimal] = None
    friday_included: bool = False
    qat_allowance_daily: Decimal = 0
    transport_allowance_daily: Decimal = 0
    food_allowance_daily: Decimal = 0
    is_active: bool = True
    notes: Optional[str] = None

class AttendanceCreate(BaseModel):
    employee_id: int
    date: date
    status: str
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    notes: Optional[str] = None

class AttendanceBulkRecord(BaseModel):
    employee_id: int
    status: str
    notes: Optional[str] = None
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None

class AttendanceBulkCreate(BaseModel):
    date: date
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    records: list[AttendanceBulkRecord] = Field(default_factory=list)


class DeviceRegisterRequest(BaseModel):
    device_id: str
    device_name: Optional[str] = None


class SyncOperation(BaseModel):
    local_uuid: str
    entity_type: str
    operation: str
    payload: dict[str, Any] = Field(default_factory=dict)
    client_created_at: Optional[datetime] = None


class SyncPushRequest(BaseModel):
    device_id: str
    operations: list[SyncOperation] = Field(default_factory=list)

class EmployeeAdjustmentCreate(BaseModel):
    employee_id: int
    date: date
    adjustment_type: str
    amount: Decimal
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    description: Optional[str] = None

class EmployeeAdjustmentRejectRequest(BaseModel):
    reason: Optional[str] = None

class PayrollPeriodCreate(BaseModel):
    year: int
    month: int
    start_date: date
    end_date: date

class PayrollPayRequest(BaseModel):
    amount: Decimal
    cash_account_id: int
    payment_date: Optional[date] = None
    description: Optional[str] = None

class PayrollUpdateRequest(BaseModel):
    daily_wage: Optional[Decimal] = None
    worked_days: Optional[Decimal] = None
    paid_fridays: Optional[Decimal] = None
    half_days: Optional[Decimal] = None
    absent_days: Optional[Decimal] = None
    gross_wage: Optional[Decimal] = None
    qat_allowance_total: Optional[Decimal] = None
    transport_allowance_total: Optional[Decimal] = None
    food_allowance_total: Optional[Decimal] = None
    bonuses_total: Optional[Decimal] = None
    deductions_total: Optional[Decimal] = None
    advances_total: Optional[Decimal] = None
    net_due: Optional[Decimal] = None

class PurchaseRequestLineCreate(BaseModel):
    item_id: Optional[int] = None
    item_name: Optional[str] = None
    qty: Decimal
    unit: str = "pcs"
    estimated_unit_cost: Decimal = 0
    estimated_total: Optional[Decimal] = None
    needed_date: Optional[date] = None
    notes: Optional[str] = None

class PurchaseRequestCreate(BaseModel):
    date: date
    department: Optional[str] = None
    cost_center_id: Optional[int] = None
    project_id: Optional[int] = None
    request_type: str = "materials"
    priority: str = "normal"
    description: Optional[str] = None
    lines: list[PurchaseRequestLineCreate] = Field(default_factory=list)

class PurchaseRejectRequest(BaseModel):
    reason: Optional[str] = None

class PurchaseOrderLineCreate(BaseModel):
    item_id: Optional[int] = None
    item_name: Optional[str] = None
    qty_ordered: Decimal
    unit: str = "pcs"
    unit_price: Decimal
    discount: Decimal = 0
    tax: Decimal = 0
    total: Optional[Decimal] = None

class PurchaseOrderCreate(BaseModel):
    supplier_id: int
    purchase_request_id: Optional[int] = None
    date: date
    expected_delivery_date: Optional[date] = None
    payment_terms: Optional[str] = None
    currency: str = "YER"
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    description: Optional[str] = None
    lines: list[PurchaseOrderLineCreate] = Field(default_factory=list)

class GoodsReceiptLineCreate(BaseModel):
    po_line_id: Optional[int] = None
    item_id: int
    qty_ordered: Decimal = 0
    qty_received: Decimal
    qty_rejected: Decimal = 0
    unit: str = "pcs"
    condition_status: str = "accepted"
    notes: Optional[str] = None

class GoodsReceiptCreate(BaseModel):
    po_id: Optional[int] = None
    supplier_id: int
    date: date
    warehouse_id: Optional[int] = None
    notes: Optional[str] = None
    attachment_id: Optional[int] = None
    lines: list[GoodsReceiptLineCreate] = Field(default_factory=list)

class SupplierInvoiceLineCreate(BaseModel):
    item_id: Optional[int] = None
    description: str
    qty: Decimal
    unit_price: Decimal
    account_code: str = "10401"
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    total: Optional[Decimal] = None

class SupplierInvoiceCreate(BaseModel):
    supplier_invoice_no: Optional[str] = None
    supplier_id: int
    po_id: Optional[int] = None
    grn_id: Optional[int] = None
    invoice_date: date
    due_date: Optional[date] = None
    invoice_type: str = "inventory"
    currency: str = "YER"
    subtotal: Decimal = 0
    discount: Decimal = 0
    tax: Decimal = 0
    net_amount: Decimal = 0
    description: Optional[str] = None
    attachment_id: Optional[int] = None
    lines: list[SupplierInvoiceLineCreate] = Field(default_factory=list)

class SupplierPaymentCreate(BaseModel):
    supplier_id: int
    invoice_id: Optional[int] = None
    payment_date: date
    amount: Decimal
    payment_method: str
    cash_account_code: str = "10101"
    currency: str = "YER"
    description: Optional[str] = None
    attachment_id: Optional[int] = None

class DocumentSequenceCreate(BaseModel):
    document_type: str
    prefix: str
    year: Optional[int] = None
    next_number: int = 1
    padding: int = 4
    padding_length: int = 4
    is_active: bool = True

class StockMovementCreate(BaseModel):
    date: date
    item_id: int
    movement_type: str
    qty: Decimal
    unit_cost: Decimal = 0
    project_id: Optional[int] = None
    cost_center_id: Optional[int] = None
    notes: Optional[str] = None

class WarehouseCreate(BaseModel):
    code: str
    name: str
    type: str = "general"
    project_id: Optional[int] = None
    is_active: bool = True

class InventoryPurchaseToGeneralCreate(BaseModel):
    supplier_id: Optional[int] = None
    item_id: int
    qty: Decimal
    unit_cost: Decimal
    warehouse_id: int
    supplier_invoice_id: Optional[int] = None
    goods_receipt_id: Optional[int] = None
    attachment_id: Optional[int] = None
    description: str

class InventoryReserveForProjectCreate(BaseModel):
    item_id: int
    qty: Decimal
    warehouse_id: int
    project_id: int
    description: str

class InventoryIssueToProjectCreate(BaseModel):
    item_id: int
    qty: Decimal
    warehouse_id: int
    project_id: int
    cost_center_id: int
    description: str

class InventoryDirectPurchaseToProjectCreate(BaseModel):
    supplier_id: int
    item_id: Optional[int] = None
    description: str
    qty: Decimal
    unit_cost: Decimal
    project_id: int
    cost_center_id: int
    supplier_invoice_id: Optional[int] = None
    attachment_id: Optional[int] = None

class InventoryAdjustmentCreate(BaseModel):
    item_id: int
    qty: Decimal
    unit_cost: Decimal = 0
    warehouse_id: Optional[int] = None
    adjustment_type: str
    reason: str
    attachment_id: Optional[int] = None

class InvoiceLineCreate(BaseModel):
    item_description: str
    qty: Decimal = 1
    unit_price: Decimal = 0
    total: Optional[Decimal] = None
    project_id: Optional[int] = None
    notes: Optional[str] = None

class InvoiceCreate(BaseModel):
    invoice_type: str
    party_type: Optional[str] = None
    party_id: int
    project_id: Optional[int] = None
    date: date
    total: Decimal = 0
    paid_amount: Decimal = 0
    due_date: Optional[date] = None
    notes: Optional[str] = None
    lines: list[InvoiceLineCreate] = Field(default_factory=list)

class PayrollCreate(BaseModel):
    employee_id: Optional[int] = None
    worker_id: Optional[int] = None
    period: str
    work_days: Decimal = 0
    gross_amount: Decimal = 0
    advances: Decimal = 0
    deductions: Decimal = 0
    additions: Decimal = 0
    net_amount: Decimal = 0
    status: str = "open"

class GenericOut(BaseModel):
    id: int

class DashboardOut(BaseModel):
    data: dict[str, Any]
