import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

class AlshaariPermissions {
  static const manager = 'manager';
  static const accountant = 'accountant';
  static const accountantAdmin = 'accountant_admin';
  static const purchasing = 'purchasing';
  static const inventory = 'inventory';
  static const cashier = 'cashier';
  static const production = 'production';
  static const dataEntry = 'data_entry';
  static const readOnly = 'read_only';

  static const _aliases = {
    'general_manager': manager,
    'admin': manager,
    'owner': manager,
    'مدير': manager,
    'المدير العام': manager,
    'محاسب': accountant,
    'accountant_admin': accountantAdmin,
    'محاسب رئيسي': accountantAdmin,
    'أمين الصندوق': cashier,
    'امين الصندوق': cashier,
    'مسؤول مشتريات': purchasing,
    'مسؤول المخزون': inventory,
    'مسؤول الإنتاج': production,
    'مسؤول الانتاج': production,
    'مدخل بيانات': dataEntry,
    'مشاهد': readOnly,
  };

  static const Map<String, Set<String>> _rolePermissions = {
    manager: {'*'},
    accountantAdmin: {
      'master_data.write',
      'suppliers.write',
      'purchases.write',
      'inventory.write',
      'materials.issue',
      'transactions.write',
      'employees.write',
      'payroll.write',
      'payroll.approve',
      'payroll.pay',
      'transactions.approve',
      'transactions.reverse',
      'approve_adjustment_journal',
      'manage_settlements',
      'approve_supplier_invoice',
      'approve_supplier_payment',
      'approve_inventory_adjustment',
      'close_period',
      'open_closed_period',
      'reports.view',
      'reports.print',
    },
    accountant: {
      'master_data.write',
      'suppliers.write',
      'purchases.write',
      'inventory.write',
      'materials.issue',
      'transactions.write',
      'employees.write',
      'payroll.write',
      'payroll.approve',
      'payroll.pay',
      'transactions.approve',
      'transactions.reverse',
      'approve_adjustment_journal',
      'manage_settlements',
      'approve_supplier_invoice',
      'approve_supplier_payment',
      'approve_inventory_adjustment',
      'close_period',
      'reports.view',
      'reports.print',
    },
    purchasing: {
      'purchases.write',
      'suppliers.write',
      'reports.view',
    },
    inventory: {
      'inventory.write',
      'materials.issue',
      'reports.view',
    },
    cashier: {
      'transactions.write',
      'cashbox.write',
      'reports.view',
    },
    production: {
      'projects.write',
      'project_costs.write',
      'reports.view',
    },
    dataEntry: {
      'master_data.write',
      'transactions.write',
      'invoices.write',
      'reports.view',
    },
    readOnly: {
      'reports.view',
    },
  };

  static String normalizeRole(String? role) {
    final raw = (role ?? '').trim();
    if (raw.isEmpty) return dataEntry;
    final lower = raw.toLowerCase();
    return _aliases[raw] ?? _aliases[lower] ?? lower;
  }

  static Set<String> permissionsForRole(String? role) {
    final normalized = normalizeRole(role);
    return _rolePermissions[normalized] ?? _rolePermissions[dataEntry]!;
  }

  static bool hasPermission(Set<String> permissions, String permission) {
    return permissions.contains('*') || permissions.contains(permission);
  }

  static bool hasAny(Set<String> permissions, Iterable<String> required) {
    if (permissions.contains('*')) return true;
    return required.any(permissions.contains);
  }

  static Future<String> currentRole() async {
    final prefs = await SharedPreferences.getInstance();
    for (final key in const ['role', 'user_role', 'current_user_role']) {
      final value = prefs.getString(key);
      if (value != null && value.trim().isNotEmpty) {
        return normalizeRole(value);
      }
    }

    final token = prefs.getString('token') ??
        prefs.getString('access_token') ??
        prefs.getString('auth_token');
    final payload = _decodeJwtPayload(token);
    final role = payload?['role'] ?? payload?['user_role'];
    return normalizeRole(role?.toString());
  }

  static Future<Set<String>> currentPermissions() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString('permissions');
    if (raw != null && raw.trim().isNotEmpty) {
      try {
        final decoded = jsonDecode(raw);
        if (decoded is List) {
          return decoded.map((item) => '$item').toSet();
        }
      } catch (_) {
        // Fall back to the role matrix below if stored permissions are invalid.
      }
    }
    return permissionsForRole(await currentRole());
  }

  static Future<bool> can(String permission) async {
    return hasPermission(await currentPermissions(), permission);
  }

  static Future<bool> canAny(Iterable<String> required) async {
    return hasAny(await currentPermissions(), required);
  }

  static Map<String, dynamic>? _decodeJwtPayload(String? token) {
    if (token == null || token.isEmpty || !token.contains('.')) return null;
    try {
      final parts = token.split('.');
      final payload =
          utf8.decode(base64Url.decode(base64Url.normalize(parts[1])));
      final decoded = jsonDecode(payload);
      return decoded is Map<String, dynamic> ? decoded : null;
    } catch (_) {
      return null;
    }
  }
}
