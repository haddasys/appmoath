import 'package:flutter/material.dart';
import '../app/theme.dart';

class AppShell extends StatelessWidget {
  final String title;
  final Widget child;
  const AppShell({super.key, required this.title, required this.child});

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              const BrandMark(size: 32),
              const SizedBox(width: 10),
              Text(title),
            ],
          ),
        ),
        body: child,
      ),
    );
  }
}
