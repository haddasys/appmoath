from calendar import monthrange
from datetime import date, datetime, timedelta
from decimal import Decimal

from fastapi import HTTPException
from sqlalchemy import text
from sqlalchemy.orm import Session

from app.services.document_sequence import next_document_no
from app.services.posting_engine import _assert_journal_entry_balanced


PROJECT_LABOR_ACCOUNT = "50201"
GENERAL_WAGE_ACCOUNT = "60301"
WAGES_PAYABLE_ACCOUNT = "20201"
WORKER_ADVANCES_ACCOUNT = "20203"


def dec(value) -> Decimal:
    return Decimal(str(value or 0))


def money(value) -> Decimal:
    return dec(value).quantize(Decimal("0.01"))


def month_dates(year: int, month: int) -> tuple[date, date]:
    if month < 1 or month > 12:
        raise HTTPException(status_code=400, detail="الشهر غير صحيح")
    return date(year, month, 1), date(year, month, monthrange(year, month)[1])


def friday_count(start_date: date, end_date: date) -> int:
    current = start_date
    count = 0
    while current <= end_date:
        if current.weekday() == 4:
            count += 1
        current += timedelta(days=1)
    return count


def get_account(db: Session, code: str):
    row = db.execute(
        text("SELECT code, name FROM accounts WHERE code = :code AND is_active = TRUE"),
        {"code": code},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=400, detail=f"الحساب غير موجود أو غير نشط: {code}")
    return row


def create_journal(db: Session, entry_date: date, source_type: str, source_id: int, description: str, user_id: int, lines: list[dict]):
    total_debit = money(sum(dec(line.get("debit")) for line in lines))
    total_credit = money(sum(dec(line.get("credit")) for line in lines))
    if total_debit != total_credit:
        raise HTTPException(status_code=400, detail="قيد الرواتب غير متوازن")

    entry = db.execute(
        text(
            """
            INSERT INTO journal_entries (
                entry_no, entry_date, description, source_type, source_id,
                status, total_debit, total_credit, created_by, created_at
            )
            VALUES (
                :entry_no, :entry_date, :description, :source_type, :source_id,
                'posted', :total_debit, :total_credit, :created_by, CURRENT_TIMESTAMP
            )
            RETURNING id
            """
        ),
        {
            "entry_no": next_document_no(db, "journal_entry", document_date=entry_date),
            "entry_date": entry_date,
            "description": description,
            "source_type": source_type,
            "source_id": source_id,
            "total_debit": total_debit,
            "total_credit": total_credit,
            "created_by": user_id,
        },
    ).mappings().first()
    entry_id = entry["id"]

    for line in lines:
        account = get_account(db, line["account_code"])
        db.execute(
            text(
                """
                INSERT INTO journal_entry_lines (
                    journal_entry_id, account_code, account_name, debit, credit,
                    project_id, cost_center_id, party_type, party_id, description
                )
                VALUES (
                    :journal_entry_id, :account_code, :account_name, :debit, :credit,
                    :project_id, :cost_center_id, :party_type, :party_id, :description
                )
                """
            ),
            {
                "journal_entry_id": entry_id,
                "account_code": account["code"],
                "account_name": account["name"],
                "debit": money(line.get("debit")),
                "credit": money(line.get("credit")),
                "project_id": line.get("project_id"),
                "cost_center_id": line.get("cost_center_id"),
                "party_type": line.get("party_type"),
                "party_id": line.get("party_id"),
                "description": line.get("description"),
            },
        )

    _assert_journal_entry_balanced(db, entry_id)
    return entry_id


def create_payroll_period(db: Session, data, user_id: int):
    start_date, end_date = month_dates(data.year, data.month)
    start_date = data.start_date or start_date
    end_date = data.end_date or end_date
    existing = db.execute(
        text("SELECT * FROM payroll_periods WHERE year = :year AND month = :month"),
        {"year": data.year, "month": data.month},
    ).mappings().first()
    if existing:
        return dict(existing)
    row = db.execute(
        text(
            """
            INSERT INTO payroll_periods (
                year, month, start_date, end_date, status, created_by, created_at
            )
            VALUES (:year, :month, :start_date, :end_date, 'open', :created_by, CURRENT_TIMESTAMP)
            RETURNING *
            """
        ),
        {
            "year": data.year,
            "month": data.month,
            "start_date": start_date,
            "end_date": end_date,
            "created_by": user_id,
        },
    ).mappings().first()
    db.commit()
    return dict(row)


def payroll_period(db: Session, period_id: int):
    row = db.execute(
        text("SELECT * FROM payroll_periods WHERE id = :id"),
        {"id": period_id},
    ).mappings().first()
    if not row:
        raise HTTPException(status_code=404, detail="فترة الراتب غير موجودة")
    return dict(row)


def list_payroll_periods(db: Session):
    rows = db.execute(
        text("SELECT * FROM payroll_periods ORDER BY year DESC, month DESC")
    ).mappings().all()
    return [dict(row) for row in rows]


def _attendance_summary(db: Session, employee_id: int, start_date: date, end_date: date):
    rows = db.execute(
        text(
            """
            SELECT status, date, project_id, cost_center_id
            FROM attendance
            WHERE employee_id = :employee_id
              AND date >= :start_date
              AND date <= :end_date
            """
        ),
        {"employee_id": employee_id, "start_date": start_date, "end_date": end_date},
    ).mappings().all()
    worked = sum(1 for row in rows if row["status"] in {"present", "overtime"})
    half = sum(1 for row in rows if row["status"] == "half_day")
    absent = sum(1 for row in rows if row["status"] == "absent")
    excluded_fridays = sum(
        1
        for row in rows
        if row["date"].weekday() == 4
        and row["status"] in {"present", "half_day", "absent", "unpaid_leave", "leave"}
    )
    return rows, Decimal(worked), Decimal(half), Decimal(absent), excluded_fridays


def _approved_adjustments(db: Session, employee_id: int, start_date: date, end_date: date):
    rows = db.execute(
        text(
            """
            SELECT adjustment_type, amount
            FROM employee_adjustments
            WHERE employee_id = :employee_id
              AND status = 'approved'
              AND date >= :start_date
              AND date <= :end_date
            """
        ),
        {"employee_id": employee_id, "start_date": start_date, "end_date": end_date},
    ).mappings().all()
    totals = {
        "qat": Decimal("0"),
        "transport": Decimal("0"),
        "food": Decimal("0"),
        "bonuses": Decimal("0"),
        "deductions": Decimal("0"),
        "advances": Decimal("0"),
    }
    for row in rows:
        amount = money(row["amount"])
        kind = row["adjustment_type"]
        if kind in {"advance", "custody"}:
            totals["advances"] += amount
        elif kind == "deduction":
            totals["deductions"] += amount
        elif kind == "qat":
            totals["qat"] += amount
        elif kind == "transport":
            totals["transport"] += amount
        elif kind == "food":
            totals["food"] += amount
        else:
            totals["bonuses"] += amount
    return totals


def calculate_payroll_period(db: Session, period_id: int, user_id: int):
    period = payroll_period(db, period_id)
    if period["status"] in {"approved", "paid", "closed"}:
        raise HTTPException(status_code=400, detail="لا يمكن إعادة حساب فترة راتب معتمدة أو مدفوعة")

    existing_locked = db.execute(
        text(
            """
            SELECT COUNT(*) AS count
            FROM payrolls
            WHERE payroll_period_id = :period_id
              AND status IN ('approved', 'paid')
            """
        ),
        {"period_id": period_id},
    ).mappings().first()
    if existing_locked and existing_locked["count"]:
        raise HTTPException(status_code=400, detail="توجد كشوف رواتب معتمدة أو مدفوعة لهذه الفترة")

    db.execute(text("DELETE FROM payrolls WHERE payroll_period_id = :period_id AND status = 'draft'"), {"period_id": period_id})

    start_date = period["start_date"]
    end_date = period["end_date"]
    employees = db.execute(
        text(
            """
            SELECT *
            FROM employees
            WHERE COALESCE(is_active, TRUE) = TRUE
              AND COALESCE(wage_type, 'daily') = 'daily'
            ORDER BY name
            """
        )
    ).mappings().all()

    result = []
    for employee in employees:
        employee_id = employee["id"]
        daily_wage = money(employee["daily_wage"])
        friday_included = bool(employee["friday_included"])
        attendance_rows, worked_days, half_days, absent_days, excluded_fridays = _attendance_summary(
            db, employee_id, start_date, end_date
        )
        paid_fridays = Decimal("0")
        if friday_included:
            paid_fridays = Decimal(max(friday_count(start_date, end_date) - excluded_fridays, 0))

        actual_attendance_days = worked_days + (half_days * Decimal("0.5"))
        eligible_days = actual_attendance_days + paid_fridays
        gross_wage = money(
            (daily_wage * worked_days)
            + (daily_wage * Decimal("0.5") * half_days)
            + (daily_wage * paid_fridays)
        )
        adjustments = _approved_adjustments(db, employee_id, start_date, end_date)
        qat_total = money(dec(employee["qat_allowance_daily"]) * eligible_days + adjustments["qat"])
        transport_total = money(dec(employee["transport_allowance_daily"]) * actual_attendance_days + adjustments["transport"])
        food_total = money(dec(employee["food_allowance_daily"]) * actual_attendance_days + adjustments["food"])
        net_due = money(
            gross_wage
            + qat_total
            + transport_total
            + food_total
            + adjustments["bonuses"]
            - adjustments["deductions"]
            - adjustments["advances"]
        )

        row = db.execute(
            text(
                """
                INSERT INTO payrolls (
                    payroll_no, payroll_period_id, employee_id, period, daily_wage,
                    friday_included, worked_days, paid_fridays, half_days,
                    absent_days, gross_wage, qat_allowance_total,
                    transport_allowance_total, food_allowance_total,
                    bonuses_total, deductions_total, advances_total,
                    net_due, paid_amount, remaining_due, status, created_at
                )
                VALUES (
                    :payroll_no, :payroll_period_id, :employee_id, :period, :daily_wage,
                    :friday_included, :worked_days, :paid_fridays, :half_days,
                    :absent_days, :gross_wage, :qat_allowance_total,
                    :transport_allowance_total, :food_allowance_total,
                    :bonuses_total, :deductions_total, :advances_total,
                    :net_due, 0, :remaining_due, 'draft', CURRENT_TIMESTAMP
                )
                RETURNING *
                """
            ),
            {
                "payroll_period_id": period_id,
                "payroll_no": next_document_no(db, "payroll", document_date=period["end_date"]),
                "employee_id": employee_id,
                "period": f"{period['year']}-{period['month']:02d}",
                "daily_wage": daily_wage,
                "friday_included": friday_included,
                "worked_days": worked_days,
                "paid_fridays": paid_fridays,
                "half_days": half_days,
                "absent_days": absent_days,
                "gross_wage": gross_wage,
                "qat_allowance_total": qat_total,
                "transport_allowance_total": transport_total,
                "food_allowance_total": food_total,
                "bonuses_total": adjustments["bonuses"],
                "deductions_total": adjustments["deductions"],
                "advances_total": adjustments["advances"],
                "net_due": net_due,
                "remaining_due": net_due,
            },
        ).mappings().first()
        result.append(dict(row))

    db.execute(
        text("UPDATE payroll_periods SET status = 'calculated' WHERE id = :id"),
        {"id": period_id},
    )
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'calculate_payroll_period', 'payroll_period', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": period_id, "details": f"{period['year']}-{period['month']:02d}"},
    )
    db.commit()
    return result


def list_payrolls(db: Session, period_id: int):
    rows = db.execute(
        text(
            """
            SELECT p.*, e.name AS employee_name
            FROM payrolls p
            JOIN employees e ON e.id = p.employee_id
            WHERE p.payroll_period_id = :period_id
            ORDER BY e.name
            """
        ),
        {"period_id": period_id},
    ).mappings().all()
    return [dict(row) for row in rows]


def update_payroll_draft(db: Session, payroll_id: int, data, user_id: int):
    payroll = db.execute(
        text("SELECT * FROM payrolls WHERE id = :id"),
        {"id": payroll_id},
    ).mappings().first()
    if not payroll:
        raise HTTPException(status_code=404, detail="كشف الراتب غير موجود")
    if payroll["status"] != "draft":
        raise HTTPException(
            status_code=400,
            detail="لا يمكن تعديل كشف راتب معتمد أو مدفوع. استخدم سند تسوية للتصحيح.",
        )

    allowed_fields = [
        "daily_wage",
        "worked_days",
        "paid_fridays",
        "half_days",
        "absent_days",
        "gross_wage",
        "qat_allowance_total",
        "transport_allowance_total",
        "food_allowance_total",
        "bonuses_total",
        "deductions_total",
        "advances_total",
        "net_due",
    ]
    payload = {
        field: money(getattr(data, field))
        for field in allowed_fields
        if getattr(data, field) is not None
    }
    if not payload:
        return dict(payroll)
    for field, value in payload.items():
        if value < 0:
            raise HTTPException(status_code=400, detail=f"لا يسمح بقيمة سالبة في {field}")

    current = dict(payroll)
    current.update(payload)
    if "net_due" not in payload:
        current["net_due"] = money(
            dec(current["gross_wage"])
            + dec(current["qat_allowance_total"])
            + dec(current["transport_allowance_total"])
            + dec(current["food_allowance_total"])
            + dec(current["bonuses_total"])
            - dec(current["deductions_total"])
            - dec(current["advances_total"])
        )
    current["remaining_due"] = money(dec(current["net_due"]) - dec(current["paid_amount"]))
    if current["remaining_due"] < 0:
        raise HTTPException(status_code=400, detail="صافي المستحق أقل من المبلغ المدفوع")

    update_fields = sorted(set(payload) | {"net_due", "remaining_due"})
    set_clause = ", ".join(f"{field} = :{field}" for field in update_fields)
    params = {field: current[field] for field in update_fields}
    params["id"] = payroll_id
    row = db.execute(
        text(f"UPDATE payrolls SET {set_clause} WHERE id = :id RETURNING *"),
        params,
    ).mappings().first()
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'update_payroll_draft', 'payroll', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": payroll_id, "details": "تعديل كشف راتب مسودة"},
    )
    db.commit()
    return dict(row)


def approve_payroll(db: Session, payroll_id: int, user_id: int):
    payroll = db.execute(text("SELECT * FROM payrolls WHERE id = :id"), {"id": payroll_id}).mappings().first()
    if not payroll:
        raise HTTPException(status_code=404, detail="كشف الراتب غير موجود")
    if payroll["status"] != "draft":
        raise HTTPException(status_code=400, detail="لا يمكن اعتماد كشف راتب غير مسودة")

    exists = db.execute(
        text("SELECT id FROM journal_entries WHERE source_type = 'payroll' AND source_id = :id"),
        {"id": payroll_id},
    ).mappings().first()
    if exists:
        raise HTTPException(status_code=400, detail="تم إنشاء قيد لهذا الراتب مسبقًا")

    period = payroll_period(db, payroll["payroll_period_id"])
    start_date = period["start_date"]
    end_date = period["end_date"]
    attendance_rows, worked_days, half_days, _, _ = _attendance_summary(
        db, payroll["employee_id"], start_date, end_date
    )

    expense_base = money(dec(payroll["net_due"]) + dec(payroll["advances_total"]))
    project_lines: dict[tuple[int, int], Decimal] = {}
    attendance_units = Decimal("0")
    for row in attendance_rows:
        unit = Decimal("1") if row["status"] in {"present", "overtime"} else Decimal("0.5") if row["status"] == "half_day" else Decimal("0")
        if unit <= 0:
            continue
        attendance_units += unit
        if row["project_id"] and row["cost_center_id"]:
            project_lines[(row["project_id"], row["cost_center_id"])] = project_lines.get((row["project_id"], row["cost_center_id"]), Decimal("0")) + unit

    lines = []
    allocated = Decimal("0")
    if attendance_units > 0:
        for (project_id, cost_center_id), units in project_lines.items():
            amount = money(expense_base * units / attendance_units)
            allocated += amount
            lines.append(
                {
                    "account_code": PROJECT_LABOR_ACCOUNT,
                    "debit": amount,
                    "credit": 0,
                    "project_id": project_id,
                    "cost_center_id": cost_center_id,
                    "party_type": "employee",
                    "party_id": payroll["employee_id"],
                    "description": "أجور مباشرة لمشروع",
                }
            )
            db.execute(
                text(
                    """
                    INSERT INTO project_costs (
                        project_id, cost_center_id, date, category, amount,
                        source_type, source_id, notes
                    )
                    VALUES (:project_id, :cost_center_id, :date, 'labor', :amount, 'payroll', :source_id, :notes)
                    """
                ),
                {
                    "project_id": project_id,
                    "cost_center_id": cost_center_id,
                    "date": end_date,
                    "amount": amount,
                    "source_id": payroll_id,
                    "notes": "تكلفة عمالة من كشف الراتب",
                },
            )

    remaining_expense = money(expense_base - allocated)
    if remaining_expense > 0:
        lines.append(
            {
                "account_code": GENERAL_WAGE_ACCOUNT,
                "debit": remaining_expense,
                "credit": 0,
                "party_type": "employee",
                "party_id": payroll["employee_id"],
                "description": "أجور عامة",
            }
        )
    lines.append(
        {
            "account_code": WAGES_PAYABLE_ACCOUNT,
            "debit": 0,
            "credit": expense_base,
            "party_type": "employee",
            "party_id": payroll["employee_id"],
            "description": "إثبات أجور مستحقة",
        }
    )
    if dec(payroll["advances_total"]) > 0:
        lines.append(
            {
                "account_code": WAGES_PAYABLE_ACCOUNT,
                "debit": payroll["advances_total"],
                "credit": 0,
                "party_type": "employee",
                "party_id": payroll["employee_id"],
                "description": "خصم سلف من الراتب",
            }
        )
        lines.append(
            {
                "account_code": WORKER_ADVANCES_ACCOUNT,
                "debit": 0,
                "credit": payroll["advances_total"],
                "party_type": "employee",
                "party_id": payroll["employee_id"],
                "description": "تسوية سلف عامل من الراتب",
            }
        )

    create_journal(db, end_date, "payroll", payroll_id, "اعتماد كشف راتب", user_id, lines)
    row = db.execute(
        text(
            """
            UPDATE payrolls
            SET status = 'approved', approved_by = :user_id, approved_at = :approved_at
            WHERE id = :id
            RETURNING *
            """
        ),
        {"id": payroll_id, "user_id": user_id, "approved_at": datetime.utcnow()},
    ).mappings().first()
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'approve_payroll', 'payroll', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": payroll_id, "details": "اعتماد كشف راتب"},
    )
    db.commit()
    return dict(row)


def pay_payroll(db: Session, payroll_id: int, data, user_id: int):
    payroll = db.execute(text("SELECT * FROM payrolls WHERE id = :id"), {"id": payroll_id}).mappings().first()
    if not payroll:
        raise HTTPException(status_code=404, detail="كشف الراتب غير موجود")
    if payroll["status"] not in {"approved", "paid"}:
        raise HTTPException(status_code=400, detail="لا يمكن دفع راتب قبل اعتماد كشف الراتب")
    amount = money(data.amount)
    if amount <= 0:
        raise HTTPException(status_code=400, detail="مبلغ الدفع يجب أن يكون أكبر من صفر")
    if amount > money(payroll["remaining_due"]):
        raise HTTPException(status_code=400, detail="لا يمكن دفع مبلغ أكبر من المتبقي للعامل")
    cash = db.execute(
        text("SELECT id, code, current_balance FROM cash_accounts WHERE id = :id AND is_active = TRUE"),
        {"id": data.cash_account_id},
    ).mappings().first()
    if not cash:
        raise HTTPException(status_code=400, detail="حساب الصندوق أو البنك غير موجود")

    payment_date = data.payment_date or date.today()
    create_journal(
        db,
        payment_date,
        "payroll_payment",
        payroll_id,
        data.description or "دفع راتب عامل",
        user_id,
        [
            {
                "account_code": WAGES_PAYABLE_ACCOUNT,
                "debit": amount,
                "credit": 0,
                "party_type": "employee",
                "party_id": payroll["employee_id"],
                "description": "دفع راتب عامل",
            },
            {
                "account_code": cash["code"],
                "debit": 0,
                "credit": amount,
                "party_type": "employee",
                "party_id": payroll["employee_id"],
                "description": "دفع راتب من حساب نقدية",
            },
        ],
    )
    paid_amount = money(dec(payroll["paid_amount"]) + amount)
    remaining = money(dec(payroll["net_due"]) - paid_amount)
    status = "paid" if remaining <= 0 else "approved"
    row = db.execute(
        text(
            """
            UPDATE payrolls
            SET paid_amount = :paid_amount,
                remaining_due = :remaining_due,
                status = :status,
                paid_by = :user_id,
                paid_at = :paid_at,
                cash_account_id = :cash_account_id
            WHERE id = :id
            RETURNING *
            """
        ),
        {
            "id": payroll_id,
            "paid_amount": paid_amount,
            "remaining_due": remaining,
            "status": status,
            "user_id": user_id,
            "paid_at": datetime.utcnow(),
            "cash_account_id": data.cash_account_id,
        },
    ).mappings().first()
    db.execute(
        text(
            """
            UPDATE cash_accounts
            SET balance = COALESCE(balance, 0) - :amount,
                current_balance = COALESCE(current_balance, balance, 0) - :amount
            WHERE id = :id
            """
        ),
        {"id": data.cash_account_id, "amount": amount},
    )
    db.execute(
        text(
            """
            INSERT INTO audit_logs (user_id, action, entity, entity_id, details, created_at)
            VALUES (:user_id, 'pay_payroll', 'payroll', :entity_id, :details, CURRENT_TIMESTAMP)
            """
        ),
        {"user_id": user_id, "entity_id": payroll_id, "details": str(amount)},
    )
    db.commit()
    return dict(row)


def employee_statement(db: Session, employee_id: int):
    employee = db.execute(
        text("SELECT * FROM employees WHERE id = :id"),
        {"id": employee_id},
    ).mappings().first()
    if not employee:
        raise HTTPException(status_code=404, detail="العامل غير موجود")
    payrolls = db.execute(
        text("SELECT * FROM payrolls WHERE employee_id = :employee_id ORDER BY id DESC"),
        {"employee_id": employee_id},
    ).mappings().all()
    adjustments = db.execute(
        text("SELECT * FROM employee_adjustments WHERE employee_id = :employee_id ORDER BY date DESC, id DESC"),
        {"employee_id": employee_id},
    ).mappings().all()
    total_net = sum(dec(row["net_due"]) for row in payrolls)
    total_paid = sum(dec(row["paid_amount"]) for row in payrolls)
    return {
        "employee": dict(employee),
        "payrolls": [dict(row) for row in payrolls],
        "adjustments": [dict(row) for row in adjustments],
        "totals": {
            "net_due": str(money(total_net)),
            "paid": str(money(total_paid)),
            "remaining": str(money(total_net - total_paid)),
        },
    }


def payroll_summary(db: Session, year: int, month: int):
    row = db.execute(
        text(
            """
            SELECT
                pp.year,
                pp.month,
                COALESCE(SUM(p.gross_wage), 0) AS gross_wage,
                COALESCE(SUM(p.qat_allowance_total + p.transport_allowance_total + p.food_allowance_total + p.bonuses_total), 0) AS allowances,
                COALESCE(SUM(p.deductions_total), 0) AS deductions,
                COALESCE(SUM(p.advances_total), 0) AS advances,
                COALESCE(SUM(p.net_due), 0) AS net_due,
                COALESCE(SUM(p.paid_amount), 0) AS paid_amount,
                COALESCE(SUM(p.remaining_due), 0) AS remaining_due
            FROM payroll_periods pp
            LEFT JOIN payrolls p ON p.payroll_period_id = pp.id
            WHERE pp.year = :year AND pp.month = :month
            GROUP BY pp.year, pp.month
            """
        ),
        {"year": year, "month": month},
    ).mappings().first()
    return dict(row) if row else {}
